package ui.Signon;

import java.io.File;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.scheduling.ExpectedBackendCondition;
import ui.pageobjects.Signon.DashboardPage_objects;
import ui.pageobjects.Signon.MessagePage_object;
import ui.pageobjects.Signon.SettingsuserPage_object;
import ui.pageobjects.Signon.SignonPage_objects;

public class Terms_Conditions extends PageObject{

	WebDriver driver =null;

	String Result=null;
	boolean Status=false;
	SignonPage_objects signonObjects;
	DashboardPage_objects dasboardpageObjects;
	//MessagePage_Objects messagepageobjects;
	MessagePage_object messagepageObjects;
	SettingsuserPage_object settingspageobjects;
	
@Step
public String download_terms_and_condition(String downloaded_Path) throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 50);
	wait.until(ExpectedConditions.elementToBeClickable(signonObjects.download_TermsConditions()));
	if(signonObjects.download_TermsConditions.isCurrentlyVisible())
	{
	wait.until(ExpectedConditions.elementToBeClickable(signonObjects.download_TermsConditions()));
	signonObjects.download_TermsConditions().click();
	wait.until(ExpectedConditions.elementToBeClickable(signonObjects.Accept_TermsAndCondition()));
	File getLatestFile = getLatestFilefromDir(downloaded_Path);
    String fileName = getLatestFile.getName();
    long length = getLatestFile.length();
    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0))
    	{
    		Result="Passed "+fileName;
    	}
    else
    	{
    	Result="Failed "+"We didnot find the document in the folder";
    	}
	}
	return Result;	
}
@Step
public String Accept_terms_and_conditions() throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 10);
	wait.until(ExpectedConditions.elementToBeClickable(signonObjects.Accept_TermsAndCondition()));
	if(signonObjects.Accept_TermsAndCondition.isCurrentlyVisible())
	{
		signonObjects.Accept_TermsAndCondition().click();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Welcome_message()));
		Result="Passed "+"Successfully accepted the terms and conditions ";
	}
	else
	{
		Result="Failed "+" There is no terms and conditions available come back later ";
	}
	return Result;
	
}
@Step
public String Change_Language_code(String Langauge_Change_1st_time,String Validate_PaymentText_Dutch,String Langauge_Change_2nd_time,String Validate_PaymentText_English,String Langauge_Change_3rd_time,String Validate_PaymentText_French) throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 50);
	String Result_Dutch_Language=null,Result_France_Language=null,Result_English_Language=null;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_option()));
	executor.executeScript("arguments[0].click()",dasboardpageObjects.more_option());
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.settings()));
	executor.executeScript("arguments[0].click()",dasboardpageObjects.settings());
	wait.until(ExpectedConditions.elementToBeClickable(settingspageobjects.Language_dropDown()));
	executor.executeScript("arguments[0].click()",settingspageobjects.Language_dropDown());
	if(Langauge_Change_1st_time.equals("Dutch") || Langauge_Change_1st_time.equals("Nederlands") || Langauge_Change_1st_time.equals("N�erlandais") || Langauge_Change_1st_time.equals("Niederl�ndisch"))
	{
		executor.executeScript("arguments[0].click()",settingspageobjects.Dutch_Language());	
	}
	else if(Langauge_Change_1st_time.equals("English") || Langauge_Change_1st_time.equals("Engels") || Langauge_Change_1st_time.equals("Anglais") || Langauge_Change_1st_time.equals("Englisch"))
	{
		executor.executeScript("arguments[0].click()",settingspageobjects.English_Language());
	}
	else if(Langauge_Change_1st_time.equals("French") || Langauge_Change_1st_time.equals("Frans") || Langauge_Change_1st_time.equals("Fran�ais") || Langauge_Change_1st_time.equals("Franz�sisch"))
	{
		executor.executeScript("arguments[0].click()",settingspageobjects.French_Language());
	}
	else if(Langauge_Change_1st_time.equals("German") ||Langauge_Change_1st_time.equals("Duits") || Langauge_Change_1st_time.equals("Allemand") || Langauge_Change_1st_time.equals("Deutsch"))
	{
		executor.executeScript("arguments[0].click()",settingspageobjects.German_Language());
	}
	executor.executeScript("arguments[0].click()",settingspageobjects.Save_language_button());
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Continue_dashboard_button()));
	executor.executeScript("arguments[0].click()",dasboardpageObjects.Continue_dashboard_button());
	if(dasboardpageObjects.payment_dashboard_text.isDisplayed())
	{
		if(dasboardpageObjects.payment_dashboard_text().getText().contains(Validate_PaymentText_Dutch))
		Result_Dutch_Language="Passed "+": "+Langauge_Change_1st_time+"_"+dasboardpageObjects.payment_dashboard_text().getText();
	}
	else
	{
		Result_Dutch_Language="Failed";
	}
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_option()));
	executor.executeScript("arguments[0].click()",dasboardpageObjects.more_option());
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.settings()));
	executor.executeScript("arguments[0].click()",dasboardpageObjects.settings());
	wait.until(ExpectedConditions.elementToBeClickable(settingspageobjects.Language_dropDown()));
	executor.executeScript("arguments[0].click()",settingspageobjects.Language_dropDown());
	if(Langauge_Change_2nd_time.equals("Dutch") || Langauge_Change_2nd_time.equals("Nederlands") || Langauge_Change_2nd_time.equals("N�erlandais") || Langauge_Change_2nd_time.equals("Niederl�ndisch"))
	{
		executor.executeScript("arguments[0].click()",settingspageobjects.Dutch_Language());	
	}
	else if(Langauge_Change_2nd_time.equals("English") || Langauge_Change_2nd_time.equals("Engels") || Langauge_Change_2nd_time.equals("Anglais") || Langauge_Change_2nd_time.equals("Englisch"))
	{
		executor.executeScript("arguments[0].click()",settingspageobjects.English_Language());
	}
	else if(Langauge_Change_2nd_time.equals("French") || Langauge_Change_2nd_time.equals("Frans") || Langauge_Change_2nd_time.equals("Fran�ais") || Langauge_Change_2nd_time.equals("Franz�sisch"))
	{
		executor.executeScript("arguments[0].click()",settingspageobjects.French_Language());
	}
	else if(Langauge_Change_2nd_time.equals("German") ||Langauge_Change_2nd_time.equals("Duits") || Langauge_Change_2nd_time.equals("Allemand") || Langauge_Change_2nd_time.equals("Deutsch"))
	{
		executor.executeScript("arguments[0].click()",settingspageobjects.German_Language());
	}
	executor.executeScript("arguments[0].click()",settingspageobjects.Save_language_button());
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Continue_dashboard_button()));
	executor.executeScript("arguments[0].click()",dasboardpageObjects.Continue_dashboard_button());
	if(dasboardpageObjects.payment_dashboard_text.isDisplayed())
	{
		if(dasboardpageObjects.payment_dashboard_text().getText().contains(Validate_PaymentText_English))
		Result_English_Language="Passed "+": "+Langauge_Change_2nd_time+"_"+dasboardpageObjects.payment_dashboard_text().getText();
	}
	else
	{
		Result_English_Language="Failed";
	}
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_option()));
	executor.executeScript("arguments[0].click()",dasboardpageObjects.more_option());
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.settings()));
	executor.executeScript("arguments[0].click()",dasboardpageObjects.settings());
	wait.until(ExpectedConditions.elementToBeClickable(settingspageobjects.Language_dropDown()));
	executor.executeScript("arguments[0].click()",settingspageobjects.Language_dropDown());
	if(Langauge_Change_3rd_time.equals("Dutch") || Langauge_Change_3rd_time.equals("Nederlands") || Langauge_Change_3rd_time.equals("N�erlandais") || Langauge_Change_3rd_time.equals("Niederl�ndisch"))
	{
		executor.executeScript("arguments[0].click()",settingspageobjects.Dutch_Language());	
	}
	else if(Langauge_Change_3rd_time.equals("English") || Langauge_Change_3rd_time.equals("Engels") || Langauge_Change_3rd_time.equals("Anglais") || Langauge_Change_3rd_time.equals("Englisch"))
	{
		executor.executeScript("arguments[0].click()",settingspageobjects.English_Language());
	}
	else if(Langauge_Change_3rd_time.equals("French") || Langauge_Change_3rd_time.equals("Frans") || Langauge_Change_3rd_time.equals("Fran�ais") || Langauge_Change_3rd_time.equals("Franz�sisch"))
	{
		executor.executeScript("arguments[0].click()",settingspageobjects.French_Language());
	}
	else if(Langauge_Change_3rd_time.equals("German") ||Langauge_Change_3rd_time.equals("Duits") || Langauge_Change_3rd_time.equals("Allemand") || Langauge_Change_3rd_time.equals("Deutsch"))
	{
		executor.executeScript("arguments[0].click()",settingspageobjects.German_Language());
	}
	executor.executeScript("arguments[0].click()",settingspageobjects.Save_language_button());
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Continue_dashboard_button()));
	executor.executeScript("arguments[0].click()",dasboardpageObjects.Continue_dashboard_button());
	if(dasboardpageObjects.payment_dashboard_text.isDisplayed())
	{
		if(dasboardpageObjects.payment_dashboard_text().getText().contains(Validate_PaymentText_French))
		Result_English_Language="Passed "+": "+Langauge_Change_3rd_time+"_"+dasboardpageObjects.payment_dashboard_text().getText();
		Result=Result_Dutch_Language+"::"+Result_English_Language+"::"+Result_France_Language;
	}
	else
	{
		Result_English_Language="Failed";
		Result=Result_Dutch_Language+"::"+Result_English_Language+"::"+Result_France_Language;
	}
	return Result;
}
public boolean isFileDownloaded(String downloadPath, String fileName) {
	boolean flag = false;
    File dir = new File(downloadPath);
    File[] dir_contents = dir.listFiles();
  	    
    for (int i = 0; i < dir_contents.length; i++) {
        if (dir_contents[i].getName().contains(fileName))
            return flag=true;
            }

    return flag;
}
private File getLatestFilefromDir(String dirPath){
    File dir = new File(dirPath);
    File[] files = dir.listFiles();
    if (files == null || files.length == 0) {
        return null;
    }

    File lastModifiedFile = files[0];
    for (int i = 1; i < files.length; i++) {
       if (lastModifiedFile.lastModified() < files[i].lastModified()) {
           lastModifiedFile = files[i];
       }
    }
    return lastModifiedFile;
}
}
