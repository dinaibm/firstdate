package common;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class WrappedWebDriver1
{
	  static String driverName="";
	  static String provider="";
	  public static final String USERNAME = "Dinakaran.GK";
	  public static final String ACCESS_KEY = "a1a9080c-2a89-4f35-b9ed-cacc04a142c6";
	  public static final String URL = "https://" + USERNAME + ":" + ACCESS_KEY + "@ondemand.saucelabs.com:443/wd/hub";
	  private static String filePath;
		private static String fileName;
		private static String datasheetName;
		private static FileInputStream fileInputStream;
		private static XSSFWorkbook workbook;
		public static boolean sheetConfigAccess;
		public static List<Map<String, String>> values;
		private static String [] testConfigs_s = new String[9];
  
	public WebDriver newDriver(String[] testConf) 
	{
		//filePath = "D:\\Serenity 2\\SampleJava";
		//fileName = "Run Manager";
		//datasheetName = "TestConfigurations";
		//Based on the Value given below the appropriate driver will be triggered
		String browserConfig =  "SaucelabsWeb" ;
		String[] keys =  {"TestConfigurationID", "ExecutionMode","MobileToolName", "MobileExecutionPlatform",
							"MobileOSVersion","DeviceName", "Browser", "BrowserVersion", "Platform"};				
		sheetConfigAccess = true;
		String[] testConfig = {"LOCAL","Test","Test","Test","Test","Chrome"};
       WebDriver driver = null;
       String iePageLoadTimeout = ""; //Config.get("setup","webdriver.ie.pageLoadTimeout", "60");
	   try 
	   {
	        if(testConf[0].contains("LOCAL")){
	            if(testConf[6].equalsIgnoreCase("InternetExplorer")){
		            DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer(); 
		            capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		            System.setProperty("webdriver.ie.driver", new File(".").getCanonicalPath()+"\\libs\\IEDriverServer.exe");
		            driver = new InternetExplorerDriver(capabilities);
		            driver.manage().timeouts().pageLoadTimeout(Integer.parseInt(iePageLoadTimeout), TimeUnit.SECONDS);
		            System.out.println("IE DRIVER");
	            }
	            else if (testConf[6].equalsIgnoreCase("Chrome")) { 
	            	/*ChromeDriverService service = new ChromeDriverService.Builder()
                            .usingDriverExecutable(new File("/chromedriver.exe"))
                            .usingAnyFreePort()
                            .build();
		            ChromeOptions options = new ChromeOptions();
		            Map<String, Object> prefs = new HashMap<String, Object>();
		            prefs.put("profile.default_content_setting_values.notifications", 0);
		            prefs.put("profile.default_content_settings.popups", 0);
		            prefs.put("safebrowsing.enabled", "true"); 
		            options.setExperimentalOption("prefs", prefs);
		            options.addArguments("disable-extensions");
		            options.addArguments("--start-maximized");
		            options.setExperimentalOption("prefs", prefs);
		            DesiredCapabilities cap = DesiredCapabilities.chrome();
		            options.merge(cap); */
	            	System.out.println("New Code invoking chrome driver");
	            	System.setProperty("webdriver.chrome.driver", "C:\\Users\\fayz3p2\\Desktop\\Automation\\Automation\\libs\\chromedriver.exe");
		           	driver = new ChromeDriver(); 
	            }
	            else {
	                driver = null;
	            }
	        } 
	        else if (testConf[0].equalsIgnoreCase("SaucelabsWeb")) {      
	        	DesiredCapabilities caps;
	        	if (testConf[6].equalsIgnoreCase("FIREFOX")){
	        		caps = DesiredCapabilities.firefox();
	        	}
	        	else if (testConf[6].equalsIgnoreCase("INTERNET_EXPLORER"))	{
	        		caps = DesiredCapabilities.internetExplorer();
	        	}
	        	else if (testConf[6].equalsIgnoreCase("SAFARI")) {
	        		 caps = DesiredCapabilities.safari();
	        	}
	        	else {
	        		caps = DesiredCapabilities.chrome();
	        	}
	        	if(!(testConf[7].equals(null))&&!(testConf[8].equals(null))){
	        		 caps.setCapability("version", testConf[7]);
	        		 caps.setCapability("platform", testConf[8]);
	        		}
	        	else {
	        		throw new NullPointerException("Browser Version or Platform is null");
	        	}
	        	driver = new RemoteWebDriver(new URL(URL),caps);
	        }
	        else if (testConf[0].equalsIgnoreCase("SaucelabsMobile")) {      
	        	DesiredCapabilities caps;
	        	if(testConf[3].equalsIgnoreCase("WEB_ANDROID"))	{
	        		caps = DesiredCapabilities.android();     		
	        	} 
	        	else if (testConf[3].equalsIgnoreCase("WEB_IOS")) {
	        		caps = DesiredCapabilities.iphone();
	        	}
	        	else {
	        		caps = DesiredCapabilities.iphone(); //Need to agree on the Default Config or restrict the Dropdown in Run Manager
	        	}
	        	if(!(testConf[5].equals(null))&&!(testConf[7].equals(null))&&!(testConf[8].equals(null))){
	        		 caps.setCapability("appiumVersion", "1.7.1");
	        		 caps.setCapability("deviceOrientation", "portrait");
	        		 caps.setCapability("platformVersion",testConf[4]);
	        		 caps.setCapability("deviceName",testConf[5]);
	        		 caps.setCapability("version", testConf[7]);
	        		 //caps.setCapability("platform", testConf[8]); Need to see if the Platform is required in the Mobile Test
	        		}
	        	else {
	        		throw new NullPointerException("Browser Version or Platform is null");
	        	}
	        	driver = new RemoteWebDriver(new URL(URL),caps);
	        }
	        else {
	        	driver = null;
	        }
        } catch (IOException ex) {
		            ex.printStackTrace();
		}  catch (Exception e) {
		            e.printStackTrace();
		}
		   return driver;
	}
}



