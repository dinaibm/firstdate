package common;

import java.io.FileInputStream;
import java.util.Enumeration;
import java.util.Properties;
import java.util.PropertyPermission;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.runner.JUnitCore;

import runner.FeatureTestRunner;
import runner.TestRunner;
import runner.UITestRunner;
import util.ExcelUtil_browserconfig;

public class Source {

	public static void main(String[] args) throws Exception {
		
		XSSFSheet ExcelWSheet;
		XSSFWorkbook ExcelWBook;
		XSSFCell Cell;
	    XSSFCell Cell1;
	    XSSFCell Cell2;
		XSSFRow Row;

		ExcelUtil_browserconfig excel=new ExcelUtil_browserconfig();
		WrappedWebDriver wrappedWebDriver= new WrappedWebDriver();
		String path = System.getProperty("user.dir") +"\\TestCases.xlsx";
		
		 StringBuilder sb=new StringBuilder();
		    String test=null;
		    String browser=null;
		    String executeStatus=null;
		    FileInputStream testCase = new FileInputStream(path);
		  
		    ExcelWBook = new XSSFWorkbook(testCase);
		    ExcelWSheet = ExcelWBook.getSheet("Datasheet");
		    //CellReference cellReference=new CellReference();
		    System.out.println("The total number of rows is:"+ExcelWSheet.getPhysicalNumberOfRows());
			}
}

	

