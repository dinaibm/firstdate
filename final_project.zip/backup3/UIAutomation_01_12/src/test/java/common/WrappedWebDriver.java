package common;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import net.thucydides.core.webdriver.DriverSource;
import util.ExcelUtil;
import util.ExcelUtil_browserconfig;

public class WrappedWebDriver implements DriverSource {
	  	static String driverName="";
	    static String provider="";
	    static String browserCounter;
	    SampleSauceTest sauceLabsTest=new SampleSauceTest();
	    ExcelUtil_browserconfig excelUtil=new ExcelUtil_browserconfig();
        public static String[] testCase,browser;
        public static int browsercounter=0,tccounter=0;  
        public static String currentTC;

	  
	@Override
	public WebDriver newDriver() {
		// TODO Auto-generated method stub  
			//String browserConfig = ui.Signon.Signon.value;
	        
			
			WebDriver driver = null;
			try {
//			ExcelUtil_browserconfig.setExcelFile(System.getProperty("user.dir") + "\\UI_RunManager.xlsx", "Sheet1");
//			browserCounter = ExcelUtil_browserconfig.getCellData(0,58 );
//			int browserCounter_int = Integer.parseInt(browserCounter);  
//			String browserConfig = ExcelUtil_browserconfig.getCellData(browserCounter_int,1 );
//			browserCounter_int++;
//			browserCounter = String.valueOf(browserCounter_int);
//			ExcelUtil_browserconfig.setCellData(browserCounter, 0,58);
//			System.out.println(browserConfig);
			
				testCase=excelUtil.getTestCases().split(",");  
                
                
				System.out.println("tHE TC COUNTER VALUE IS:"+tccounter);
                System.out.println("The current Test Case is:"+testCase[tccounter]); 
                browser=excelUtil.getbrowserName(testCase[tccounter]).split(",");
                System.out.println("tHE BROWSER COUNTER VALUE IS:"+browsercounter);
                String browserConfig=browser[browsercounter];
                System.out.println("The browser is:"+browserConfig);
                System.out.println("the length of the browser is:"+browser.length);

				
				
			String[] keys =  {"TestConfigurationID", "ExecutionMode","MobileToolName", "MobileExecutionPlatform",
					"MobileOSVersion","DeviceName", "Browser", "BrowserVersion", "Platform","AppiumVersion","PlatformVersion"};	
	        String[] testConfig = ExcelUtil_browserconfig.getTestConfig(keys,browserConfig);
	        //String[] testConfig = {"LOCAL","","","","","","Chrome"};
	       // String timeoutMilli = ConfigDetails.prop.getProperty("webdriver.implicitWaitTimeoutMilli", "0");
	        String iePageLoadTimeout = ""; //Config.get("setup","webdriver.ie.pageLoadTimeout", "60");
	       
	        	if(testConfig[0].contains("LOCAL")){
	    	            if(testConfig[6].equalsIgnoreCase("InternetExplorer")){
	    		            DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer(); 
	    		            capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
	    		            System.setProperty("webdriver.ie.driver", new File(".").getCanonicalPath()+"\\libs\\IEDriverServer.exe");
	    		            driver = new InternetExplorerDriver(capabilities);
	    		            driver.manage().timeouts().pageLoadTimeout(Integer.parseInt(iePageLoadTimeout), TimeUnit.SECONDS);
	    		            System.out.println("IE DRIVER");
	    	            }
	    	            else if (testConfig[6].equalsIgnoreCase("Chrome")){ 
	    	            	 System.out.println("Inside the IF Loop and working");
	    	 	            System.setProperty("webdriver.chrome.driver", new File(".").getCanonicalPath()+"\\libs\\chromedriver.exe");
	    	 	            ChromeOptions options = new ChromeOptions();
	    	 	            Map<String, Object> prefs = new HashMap<String, Object>();
	    	 	            prefs.put("profile.default_content_setting_values.notifications", 0);
	    	 	            options.setExperimentalOption("prefs", prefs);
	    	 	            options.addArguments("disable-extensions");
	    	 	            options.addArguments("--start-maximized");
	    	 	            driver = new ChromeDriver(options);
	    	 	            System.out.println("Chrome DRIVER");
	    	            }
	    	            else 
	    	            {
	    	            driver = null;
	    	            }
	    	        } 
	    	        else if (testConfig[0].contains("SaucelabsWeb")) {      
	    	        	DesiredCapabilities caps;
	    	        	if (testConfig[6].equalsIgnoreCase("FIREFOX")){
	    	        		caps = DesiredCapabilities.firefox();
	    	        	}
	    	        	else if (testConfig[6].equalsIgnoreCase("INTERNET_EXPLORER"))	{
	    	        		caps = DesiredCapabilities.internetExplorer();
	    	        	}
	    	        	else if (testConfig[6].equalsIgnoreCase("SAFARI")) {
	    	        		 caps = DesiredCapabilities.safari();
	    	        	}
	    	        	else if(testConfig[6].equalsIgnoreCase("EDGE"))
	    	        	{
	    	        		caps = DesiredCapabilities.edge();
	    	        	}
	    	        	else {
	    	        		caps = DesiredCapabilities.chrome();
	    	        	}
	    	        	if(!(testConfig[7].equals(null))&&!(testConfig[8].equals(null))){
	    	        		 caps.setCapability("version", testConfig[7]);
	    	        		 caps.setCapability("platform", testConfig[8]);
	    	        		}
	    	        	else {
	    	        		throw new NullPointerException("Browser Version or Platform is null");
	    	        	}
	    	        	//driver = new RemoteWebDriver(new URL(URL),caps);//not getting called. 
	    	        	driver=sauceLabsTest.createdriver(testConfig[6], testConfig[7], testConfig[8], testCase[tccounter]);
	    	        }
	    	        else if (testConfig[0].contains("SaucelabsMobile")) {      
	    	        	DesiredCapabilities caps;
	    	        	if(testConfig[2].equalsIgnoreCase("WEB_ANDROID"))	{
	    	        		caps = DesiredCapabilities.android();     		
	    	        	} 
	    	        	else if (testConfig[2].equalsIgnoreCase("WEB_IOS")) {
	    	        		caps = DesiredCapabilities.iphone();
	    	        	}
	    	        	else {
	    	        		caps = DesiredCapabilities.iphone(); //Need to agree on the Default Config or restrict the Dropdown in Run Manager
	    	        	}
	    	        	System.out.println("appiumVersion"+ testConfig[9]+"******"+
    	        				"deviceName"+testConfig[5]+"******"+"platformVersion"+testConfig[10]
    	        						+"******"+"platformName"+testConfig[3]+"********"+"browserName"+testConfig[6]);
	    	        	if(!(testConfig[5].equals(null)) && !(testConfig[9].equals(null))){
	    	        		caps.setCapability("appiumVersion", testConfig[9]);
	    	        		caps.setCapability("deviceName",testConfig[5]);
	    	        		caps.setCapability("platformVersion",testConfig[10]);
	    	        		caps.setCapability("platformName", testConfig[3]);
	    	        		caps.setCapability("browserName", testConfig[6]);
	    	        		//caps.setCapability("platform", testConf[8]); Need to see if the Platform is required in the Mobile Test
	    	        		}
	    	        	else {
	    	        		throw new NullPointerException("Browser Version or Platform is null");
	    	        	}
	    	        	driver=sauceLabsTest.createdrivermobile(testConfig[9],testConfig[5],testConfig[10],testConfig[3],testConfig[6],testCase[tccounter]);
	    	        	//driver = new RemoteWebDriver(new URL(URL),caps); //not getting called. 
	    	        }
	    	        else {
	    	        	driver = null;
	    	        }
	        } catch (IOException ex) {
	            ex.printStackTrace();
	        } catch (Exception e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
	        
	        return driver;
	}

	@Override
	public boolean takesScreenshots() {
		// TODO Auto-generated method stub
		return true;
	}

}
