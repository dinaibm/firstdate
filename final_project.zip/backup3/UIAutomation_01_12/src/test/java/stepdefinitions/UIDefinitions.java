package stepdefinitions;

import java.awt.AWTException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import CreateFeature.CreateFeaturedata;
import CreateFeature.TestFea;
import Reports.TestResult;
import common.JDBCConnection;
import common.WrappedWebDriver;
import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Steps;
/*import ui.Signon.AccountActivationPage;
import ui.Signon.AdminConsoleCreateUserPage;
import ui.Signon.AdminConsoleDocumentsPage;
import ui.Signon.AuthorizationsPage;
import ui.Signon.ChangePasswordPage;
import ui.Signon.CommunicationSummaryPage;*/
import ui.Signon.Dashboard_Customization;
import ui.Signon.Dashboard_Navigation;
import ui.Signon.Document_Management;
/*import ui.Signon.DocumentsPage;
import ui.Signon.EmailTemplatePage;*/
import ui.Signon.FAQPage;
import ui.Signon.Financial_Activity;
//import ui.Signon.FundingPage;
import ui.Signon.Impersonation;
import ui.Signon.MerchantAdminPage;
import ui.Signon.MessagePage;
import ui.Signon.Online_Authorization;
/*import ui.Signon.ParametersPage;
import ui.Signon.PreAuthorizationsPage;
import ui.Signon.SMSTemplatePage;
import ui.Signon.SettingsPage;*/
//import ui.Signon.Funding;
import ui.Signon.Signon;
//import ui.Signon.TermsAndConditionsPage;
import ui.Signon.Terms_Conditions;
import ui.Signon.User_management;
//import ui.Signon.TransactionsPage;
//import ui.Signon.User_management;
//import ui.Signon.userManagementPage;
//import ui.Signon.able;
//import ui.Signon.amount;
//import ui.Signon.clicking;
//import ui.Signon.dashboardPage;
import ui.pageobjects.Signon.AccountActivationPageObjects;
import ui.pageobjects.Signon.AuthorizationsPageObjects;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.FAQPageObjects;
import ui.pageobjects.Signon.FundingPageObjects;
import ui.pageobjects.Signon.ParametersPageObjects;
import ui.pageobjects.Signon.PreAuthorizationsPageObjects;
//import ui.Signon.the;
//import ui.Signon.today;
//import ui.Signon.view;
//import ui.Signon.will;
import ui.pageobjects.Signon.SignonObjects;
import ui.pageobjects.Signon.TransactionsPageObjects;
import ui.pageobjects.Signon.UserManagementPageObjects;
import util.ExcelUtil;

public class UIDefinitions extends PageObject {
	TestResult lib=new TestResult();

	Signon signonpage;
	//dashboardPage dashboardpage;
	MessagePage messagepage;
	//SettingsPage settingspage;
	//DocumentsPage documentspage;
	//userManagementPage userManagementPage;
	//AdminConsoleDocumentsPage adminconsoledocumentspage;
	//AdminConsoleCreateUserPage adminconsolecreateuserpage;
	//TermsAndConditionsPage termsandconditionspage;
	SignonObjects signOnObjects;
	DashboardPage_Objects dashboardpageobject;
	FAQPageObjects faqpageobject;
	SignonObjects signonObjects;
	MerchantAdminPage merchantAdminPage;
	//userManagementPage userslistspage;
	FAQPage faqpage;
	//SMSTemplatePage smstemplatepage;
	//EmailTemplatePage emailtemplatepage;
	//PreAuthorizationsPage preAuthorizationsPage;
	//AuthorizationsPage authorizationsPage;
	//TransactionsPage transactionsPage;
	//FundingPage fundingPage;
	//ParametersPage parametersPage;
	ParametersPageObjects parametersPageObjects;
	//CommunicationSummaryPage communicationSummaryPage;
	//AccountActivationPage accountActivationPage;
	AccountActivationPageObjects accountActivationPageObjects;
	//ChangePasswordPage changePasswordPage; 
	JDBCConnection jdbcConnection;
	User_management userManagementPage;
	Dashboard_Navigation dashboardpage;
	MessagePage messages;
	Terms_Conditions termsandConditions;
	Document_Management documentManagement;
	Financial_Activity financialactivity;
	Online_Authorization onlineauthorization;
	Dashboard_Customization dashboardcustomization;
	Impersonation imporsonation;
	
	public static String driverType ="";
	public String device;
	public static Dimension desktop = new Dimension(2000,2000);
	public static Dimension mobile = new Dimension(375,667);
	public static Dimension tablet = new Dimension(800,480);
	
	

	public static WebDriver driver = null;
	String Result1;


	@Before
	public void bfre() throws Exception{

	}
	@After
	public void aftr()
	{
        if(WrappedWebDriver.browsercounter!=WrappedWebDriver.browser.length-1)
        {
              WrappedWebDriver.browsercounter++;
        }
        else
        {
              WrappedWebDriver.browsercounter=0;
              if(WrappedWebDriver.tccounter!= WrappedWebDriver.testCase.length-1)
              {
            	  WrappedWebDriver.tccounter++;  
              }
              else
              {
            	  System.out.println("Execution complete");
              }
        }
		
		lib.closeTestReport();
		lib.endTestReport();
		lib.SummarizeTestReport();
	}
	
	@Given("^the Feature file path creation$")
	public void the_Feature_file_path_creattion() throws Throwable {
		CreateFeaturedata.CreateFeatureFile();
	}
	@Given("^the EMS portal and configure \"([^\"]*)\"$")
	public void the_EMS_portal(String report) throws Throwable {
		signonpage.loadbrowser();
		lib.initializeTest("RequestForApplicationUIInfo"+" "+report);
		lib.WriteReportStep("1", "Loading the browser", "", "", "");
	}

	/*@And("^user Navigate to URL \"([^\"]*)\"$")
	public void user_Navigate_to_URL(String arg1) throws Throwable {
		lib.WriteReportStep("1", "Get url", "", "", "");
		signonpage.navigate(arg1);
		lib.WriteReportStep("2", "Get url", "URL for MP should be successful", "Requested MP Application successfully", "Passed");


	}*/
//	@And("^user click on RememberMe$")
//	public void user_click_on_RememberMe() throws Throwable {
//		signonpage.RememberMe();
//	}

//	@When("^user enter \"([^\"]*)\" as \"([^\"]*)\"$")
//	public void user_enter_as(String FieldName, String FieldValue) throws Throwable {
//		// Write code here that turns the phrase above into concrete actions
//		lib.WriteReportStep("1", "Get username", "", "", "");
//		signonpage.userInput(FieldName,FieldValue);
//		lib.WriteReportStep("2", "Verify the userid", "Get"+" "+FieldName, FieldName+":"+FieldValue, "Passed");
//	}
//
//	@And("^user entertext \"([^\"]*)\" as \"([^\"]*)\"$")
//	public void user_entertext_as(String FieldName, String FieldValue) throws Throwable {
//		lib.WriteReportStep("1", "Get Password", "", "", "");
//		signonpage.userInput(FieldName,FieldValue);
//		lib.WriteReportStep("2", "Verify the Password", "Get"+" "+FieldName, FieldName+":"+FieldValue, "Passed");
//		// Write code here that turns the phrase above into concrete actions
//
//	}

//	@Then("^user click Submit login and verify \"([^\"]*)\"$$")
//	public void user_click_Submit_login(String Welcome_text) throws Throwable {
//		lib.WriteReportStep("1", "Login to the application", "", "", "");
//		String Result=signonpage.Submitlogin(Welcome_text);
//		System.out.println(Result);
//		if(Result.equals("Passed"))
//		{
//			lib.WriteReportStep("2", "Verify Submit","Login to the application", "Successfully login to application","Passed");
//		}
//		else
//		{
//			lib.WriteReportStep("2", "Verify Submit","Login to the application", "Successfully login to application","Failed");
//		}
//
//	}

	@When("^user click Submit login$")
	public void clickSubmit()
	{
		lib.WriteReportStep("1", "Click on submit", "", "", "");
		try
		{
			driver=this.getDriver();
			JavascriptExecutor executor=(JavascriptExecutor)driver;
			new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(signonObjects.Submit()));
			for(int i=0;i<50;i++){};
			signonObjects.Submit().click();
			if(signonObjects.Accept_TermsAndCondition.isCurrentlyVisible())
			{
				executor.executeScript("arguments[0].click()",signonObjects.Accept_TermsAndCondition);
			}
			
			while(dashboardpageobject.confirmButton.isCurrentlyVisible())
			{
				executor.executeScript("arguments[0].click()",dashboardpageobject.confirmButton);
			}
			
			lib.WriteReportStep("2", "Click on submit", "Submit button must be clicked", "Clicked on submit button successfully", "Passed");
		}
		catch(Exception e){
			lib.WriteReportStep("2", "Click on submit", "Submit button must be clicked", "Error while Clicking on submit button", "Failed");
		}
	}


//	@Then("^user Verify Dashboard cookie information link$")
//	public void user_Verify_Dashboard_cookie_information_link() throws Throwable {
//		lib.WriteReportStep("1", "Verify Cookie information", "", "", "");
//		String Result=dashboardpage.Dashboard_cookie_information_link();
//		if(Result.equals("Passed"))
//		{
//			lib.WriteReportStep("2", "Verify cookie information Link","Verify cookie information", "Cookie information link is present","Passed");
//		}
//		else
//		{
//			lib.WriteReportStep("2", "Verify cookie information Link","Verify cookie information", "Cookie information link is not there","Failed");
//		}
//
//	}

//	@When("^user enterAlliance \"([^\"]*)\" as \"([^\"]*)\"$")
//	public void user_enterAlliance_as(String Alliance, String Alliance_code) throws Throwable {
//		lib.WriteReportStep("1", "Verify Alliance_code", "", "", "");
//		String Result=signonpage.userInput(Alliance, Alliance_code);
//		if(Result.contains("Passed"))
//		{
//			lib.WriteReportStep("2", "Verify Alliance_code","Verify Alliance_code", "Successfully Entered alliancecode ","Passed");
//		}
//		else
//		{
//			lib.WriteReportStep("2", "Verify Alliance_code","Verify Alliance_code", "Failed to Enter Alliance_code","Failed");
//		}
//
//	}

//	@When("^user click login button and enter to the admin console$")
//	public void user_click_login_button_and_enter_to_the_admin_console() throws Throwable {
//		lib.WriteReportStep("1", "Verify Login to Adminconsole", "", "", "");
//		String Result=signonpage.login_admin_console();
//		if(Result.contains("Passed"))
//		{
//			lib.WriteReportStep("2", "Verify Login to Adminconsole","Verify Login to Adminconsole", "Successfully Entered to adminconsole ","Passed");
//		}
//		else
//		{
//			lib.WriteReportStep("2", "Verify Login to Adminconsole","Verify Login to Adminconsole", "Failed to Enter into adminconsole","Failed");
//		}
//	}


//	@Then("^the user will be redirected to the dashboard page having the URL \"([^\"]*)\"$")
//	public void verifyDashboardPageUrl(String dashboardURL) throws Throwable {
//		lib.WriteReportStep("1", "Verify Dashboard URL", "", "", "");
//		if (dashboardpage.getDashboardUrl()!=dashboardURL)
//		{
//			lib.WriteReportStep("2", "Verify Dashboard URL", "URL should be: "+dashboardURL , "URL is: "+dashboardpage.getDashboardUrl(),"Failed");
//		}
//		else
//		{
//			lib.WriteReportStep("2", "Verify Dashboard URL", "URL should be: "+dashboardURL , "URL is: "+dashboardpage.getDashboardUrl(),"Passed");
//		}
//
//	}

	@Then("^the user will be able to view the amount deposited for today by clicking on view details under the Funding Payments widget$")
	public void getAmountDepositedForToday()
	{
		lib.WriteReportStep("1", "GetAmountDepositedForToday", "", "", "");
		try
		{
			lib.WriteReportStep("2","GetAmountDepositedForToday","Amount deposited for today must be displayed","Amount deposited for today is: "+dashboardpage.getAmountFromFundingWidget(),"Passed");
		}
		catch (Exception e)
		{
			lib.WriteReportStep("2","GetAmountDepositedForToday","Amount deposited for today must be displayed","Error while retrieving the amount","Passed");
			e.printStackTrace();
		}
	}

	@And("^the user can click on Messages$")
	public void clickMessagesLinkOnDashboard()
	{
		lib.WriteReportStep("1", "Click on Messages", "", "", "");

		try{
			dashboardpage.clickMessagesLinkOnDashboard();
			lib.WriteReportStep("2","Click on Messages","Messages link should be clicked","Clicked on Messages link successfully","Passed");
		}

		catch (Exception e)
		{
			lib.WriteReportStep("2","Click on Messages","Messages link should be clicked","Error while clicking on Messages link","Failed");
			e.printStackTrace();
		}

	}

	@Then("^the user can can click on Pre-Authorizations$")
	public void clickPreAuthorizationsLinkOnDashboard()
	{
		lib.WriteReportStep("1", "Click on Pre-Authorizations", "", "", "");

		try{
			dashboardpage.clickPreAuthorizationsLinkOnDashboard();
			lib.WriteReportStep("2","Click on Pre-Authorizations","Pre-Authorizations link should be clicked","Clicked on Pre-Authorizations link successfully","Passed");
		}

		catch (Exception e)
		{
			lib.WriteReportStep("2","Click on Pre-Authorizations","Pre-Authorizations link should be clicked","Error while clicking on Pre-Authorizations link","Failed");
			e.printStackTrace();
		}

	}
	@Then("^the user can can click on Authorizations$")
	public void clickAuthorizationsLinkOnDashboard()
	{
		lib.WriteReportStep("1", "Click on Authorizations", "", "", "");

		try{
			dashboardpage.clickAuthorizationsLinkOnDashboard();
			lib.WriteReportStep("2","Click on Authorizations","Authorizations link should be clicked","Clicked on Authorizations link successfully","Passed");
		}

		catch (Exception e)
		{
			lib.WriteReportStep("2","Click on Authorizations","Authorizations link should be clicked","Error while clicking on Authorizations link","Failed");
			e.printStackTrace();
		}

	}
	@Then("^the user can can click on Transactions$")
	public void clickTransactionsLinkOnDashboard()
	{
		lib.WriteReportStep("1", "Click on Transactions", "", "", "");

		try{
			dashboardpage.clickTransactionsLinkOnDashboard();
			lib.WriteReportStep("2","Click on Transactions","Transactions link should be clicked","Clicked on Transactions link successfully","Passed");
		}

		catch (Exception e)
		{
			lib.WriteReportStep("2","Click on Transactions","Transactions link should be clicked","Error while clicking on Transactions link","Failed");
			e.printStackTrace();
		}
		
	}
	
	@Then("^the user can can click on Funding$")
	public void clickFundingLinkOnDashboard()
	{
		lib.WriteReportStep("1", "Click on Funding", "", "", "");

		try{
			dashboardpage.clickFundingLinkOnDashboard();
			lib.WriteReportStep("2","Click on Funding","Funding link should be clicked","Clicked on Funding link successfully","Passed");
		}

		catch (Exception e)
		{
			lib.WriteReportStep("2","Click on Funding","Funding link should be clicked","Error while clicking on Funding link","Failed");
			e.printStackTrace();
		}

	}

	@And("^clicks on the Documents link in the Dashboard$")
	public void clickDocumentsLinkOnDashboard()
	{
		lib.WriteReportStep("1", "Click on Documents", "", "", "");

		try{
			dashboardpage.clickDocumentsLinkOnDashboard();
			lib.WriteReportStep("2","Click on Documents","Documents link should be clicked","Clicked on Documents link successfully","Passed");
		}

		catch (Exception e)
		{
			lib.WriteReportStep("2","Click on Documents","Documents link should be clicked","Error while clicking on Documents link","Failed");
			e.printStackTrace();
		}

	}


	@And("^the user can view the list of archived messages after clicking on Archived link$")
	public void viewArchivedMessagesList()
	{	

		lib.WriteReportStep("1", "View the list of archived messages", "", "", "");
		try
		{
			String messageslist=messagepage.displayArchivedMessages();
			if(messageslist.equalsIgnoreCase("messageArchivedList"))
			{
				lib.WriteReportStep("2","View the list of archived messages","List of archived Messages should be displayed","archived Messages displayed successfully","Passed");
			}
			else if(messageslist.contains("No messages found"))
			{
				lib.WriteReportStep("2","View the list of archived messages","List of archived Messages should be displayed",messageslist,"Failed");
			}
			else
			{
				lib.WriteReportStep("2","View the list of archived messages","List of archived Messages should be displayed","archived Messages not displayed","Failed");	
			}
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","View the list of archived messages","List of archived Messages should be displayed","Error while displaying archived Messages","Failed");
			e.printStackTrace();
		}
	}

	@And("^the user can view the first ten messages in the inbox$")
	public void viewInitialMessageCount()
	{
		lib.WriteReportStep("1", "View the first 10 messages", "", "", "");

		try
		{
			String messageCount=messagepage.displayIntialMessageCount();
			if(messageCount.equals("Passed"))
			{
				lib.WriteReportStep("2","View the first 10 messages","The first 10 Messages should be displayed","First 10 Messages are displayed successfully","Passed");
			}
			else
			{
				lib.WriteReportStep("2","View the first 10 messages","The first 10 Messages should be displayed","Failed to display the first 10 Messages","Failed");
			}
		}
		catch (Exception e)
		{
			lib.WriteReportStep("2","View the first 10 messages","The first 10 Messages should be displayed","Error while displaying the intial number of messages","Failed");
			e.printStackTrace();
		}

	}

	@And("^the user can verify if the search option is present$")
	public void verifySearchOptionPresent()
	{

		lib.WriteReportStep("1", "Verify if Search option is present", "", "", "");

		try{
			String searchboxtext=messagepage.verifySearchOptionPresent();
			if(searchboxtext.equals("Search"))
			{
				lib.WriteReportStep("2","Verify if Search option is present","The Search option should be available","The "+searchboxtext+" option is available","Passed");	
			}
			else
			{
				lib.WriteReportStep("2","Verify if Search option is present","The Search option should be available","The Search option is not available","Failed");	
			}
		}

		catch(Exception e)
		{
			lib.WriteReportStep("2","Verify if Search option is present","The Search option should be available","Error while validating the search option","Failed");
			e.printStackTrace();

		}
	}

	@And("^the user can verify if the search results cover Title \"([^\"]*)\"$")
	public void verifySearchResultCoverTitle(String title)
	{
		String titlevalue;
		lib.WriteReportStep("1", "Verify if Search results cover Title", "", "", "");

		try{
			titlevalue= messagepage.verifySearchResultCoverTitle(title);
			if(titlevalue.contains(title))
			{
				lib.WriteReportStep("2","Verify if Search results cover Title","The Search results should cover Title","The Search results cover Title successfully","Passed");
			}
			else if (titlevalue.equalsIgnoreCase("no messages found"))
			{
				lib.WriteReportStep("2","Verify if Search results cover Title","The Search results should cover Title",titlevalue,"Failed");
			}
			else
			{
				lib.WriteReportStep("2","Verify if Search results cover Title","The Search results should cover Title","The Search results does not cover Title","Failed");
			}
		}
		catch (Exception e)
		{
			lib.WriteReportStep("2","Verify if Search results cover Title","The Search results should cover Title","Error while validating the Search results","Failed");
			e.printStackTrace();
		}

	}

	@And("^the user can verify if the search results cover Subtitle \"([^\"]*)\"$")
	public void verifySearchResultCoverSubtitle(String subtitle)
	{
		String subtitlevalue;
		lib.WriteReportStep("1", "Verify if Search results cover Subtitle", "", "", "");

		try{
			subtitlevalue= messagepage.verifySearchResultCoverSubtitle(subtitle);
			if(subtitlevalue.contains(subtitle))
			{
				lib.WriteReportStep("2","Verify if Search results cover Subtitle","The Search results should cover Subtitle","The Search results cover Subtitle successfully","Passed");
			}
			else if (subtitlevalue.equalsIgnoreCase("no messages found"))
			{
				lib.WriteReportStep("2","Verify if Search results cover Subtitle","The Search results should cover Subtitle",subtitlevalue,"Failed");
			}
			else
			{
				lib.WriteReportStep("2","Verify if Search results cover Subtitle","The Search results should cover Subtitle","The Search results does not cover Subtitle","Failed");
			}
		}
		catch (Exception e)
		{
			lib.WriteReportStep("2","Verify if Search results cover Subtitle","The Search results should cover Subtitle","Error while validating the Search results","Failed");
			e.printStackTrace();
		}


	}

	@And("^the user can verify if the search results cover Message body \"([^\"]*)\"$")
	public void verifySearchResultCoverMessageBody(String messagebody)
	{
		String messagebodyvalue;
		lib.WriteReportStep("1", "Verify if Search results cover Title", "", "", "");

		try{
			messagebodyvalue= messagepage.verifySearchResultCoverMessageBody(messagebody);
			if(messagebodyvalue.contains(messagebody))
			{
				lib.WriteReportStep("2","Verify if Search results cover Message body","The Search results should cover Message body","The Search results cover Message body successfully","Passed");
			}
			else if(messagebodyvalue.equalsIgnoreCase("no messages found"))
			{
				lib.WriteReportStep("2","Verify if Search results cover Message body","The Search results should cover Message body",messagebodyvalue,"Failed");
			}
			
			else
			{
				lib.WriteReportStep("2","Verify if Search results cover Message body","The Search results should cover Message body","The Search results does not cover Message body","Failed");
			}
		}
		catch (Exception e)
		{
			lib.WriteReportStep("2","Verify if Search results cover Message body","The Search results should cover Message body","Error while validating the Search results","Failed");
			e.printStackTrace();
		}


	}

	@And("^archive the message \"([^\"]*)\" and view the archived message by clicking on archived link$")
	public void archiveFirstSearchResult(String messagetitle)
	{
		lib.WriteReportStep("1", "View Archived message under Archived section", "", "", "");
		try
		{
			String archivedmessagettitle=messagepage.archiveFirstSearchResult(messagetitle);
			if(archivedmessagettitle.equals(messagetitle))
			{
				lib.WriteReportStep("2","View Archived message","Archived Message must be available","Archived Message available","Passed");
			}
			else
			{
				lib.WriteReportStep("2","View Archived message","Archived Message must be available","Archived Message is not available","Failed");
			}
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","Archive message","The message must be archived","Error while archiving and viewing the archived message","Failed");
		}

	}

	@And("^the user can click on an unread message and then check if the status is Read$")
	public void markUnreadMessageAsRead()
	{
		lib.WriteReportStep("1", "Mark Message status as Read after opening it", "", "", "");
		try
		{
			String statusafterclick=messagepage.markUnreadMessageAsRead();
			if(statusafterclick.equalsIgnoreCase("Passed"))
			{
				lib.WriteReportStep("2","Mark Message status as Read","Message status must be Read","Message status is Read","Passed");
			}
			else if(statusafterclick.equalsIgnoreCase("No Unread Messages Found"))
			{
				lib.WriteReportStep("2","Mark Message status as Read","Message status must be Read","No Unread Messages Found","Failed");
			}
			else if(statusafterclick.equalsIgnoreCase("No Messages Found"))
			{
				lib.WriteReportStep("2","Mark Message status as Read","Message status must be Read","No Messages Found","Failed");
			}
			else
			{
				lib.WriteReportStep("2","Mark Message status as Read","Message status must be Read","Message status is not Read","Failed");
			}
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","Mark Message status as Read","Message status must be Read","Error while retrieving messgae status","Failed");
		}

	}

	@Then("^the user can enable the email notification check box under the Settings window to receive notifications in case of a new EMS message$")
	public void enableEmailNotifications()
	{
		lib.WriteReportStep("1","Enable the email notification check box", "", "", "");
		try
		{
			String enableEmailNotifications=dashboardpage.enableEmailNotifications();
			if(enableEmailNotifications.equals("Passed"))
			{
				lib.WriteReportStep("2","Enable the email notification check box","Email notification check box must be enabled","Email notification check box is enabled","Passed");
			}
			else if(enableEmailNotifications.equals("Button already clicked"))
			{
				lib.WriteReportStep("2","Enable the email notification check box","Email notification check box must be enabled","Email notification check box is already enabled","Passed");
			}
			else
			{
				lib.WriteReportStep("2","Enable the email notification check box","Email notification check box must be enabled","Email notification check box is not enabled","Failed");
			}
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","Enable the email notification check box","Email notification check box must be enabled","Error while enabling the email notification check box","Failed");
			e.printStackTrace();
		}

	}

	@Then("^the user can enable one or more messages and archive them$")
	public void archiveMultipleMessages()
	{
		lib.WriteReportStep("1","Archive multiple messages", "", "", "");
		try
		{
			String Result=messagepage.archiveMultipleMessages();
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2","Archive multiple messages", "Multiple Messages must be archived", "Archived More than 1 message successfully", "Passed");
			}
			else if(Result.equals("Failed"))
			{
				lib.WriteReportStep("2","Archive multiple messages", "Multiple Messages must be archived", "Failed to archive message", "Passed");	
			}
			else
			{
				lib.WriteReportStep("2","Archive multiple messages", "Multiple Messages must be archived", "No messages found", "Passed");
			}
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","Archive multiple messages", "Multiple Messages must be archived", e.getMessage(), "Failed");
			e.printStackTrace();
		}
	}

	@And("^clicks on Documents$")
	public void clickDocumentsLink()
	{

		lib.WriteReportStep("1","Click on Documents", "", "", "");
		try
		{
			merchantAdminPage.clickDocumentsLink();
			lib.WriteReportStep("2","Click on Documents", "The User must click on Documents", "User successfully clicked on Documents", "Passed");
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","Click on Documents", "The User must click on Documents", "Error while clicking on Documents", "Failed");
		}	
	}


	@And("^clicks on Users List$")
	public void clickUsersListLink()
	{

		lib.WriteReportStep("1","Click on Users List", "", "", "");
		try
		{
			merchantAdminPage.clickUsersListLink();
			lib.WriteReportStep("2","Click on Users List", "The User must click on Users List", "User successfully clicked on Users List", "Passed");
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","Click on Users List", "The User must click on Users List", "Error while clicking on Users List", "Failed");
		}	
	}

	@And("^the admin user then clicks on Users List$")
	public void clickUsersListAdminUserLink()
	{

		lib.WriteReportStep("1","Click on Users List", "", "", "");
		try
		{
			merchantAdminPage.clickUsersListAdminUserLink();
			lib.WriteReportStep("2","Click on Users List", "The User must click on Users List", "User successfully clicked on Users List", "Passed");
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","Click on Users List", "The User must click on Users List", "Error while clicking on Users List", "Failed");
		}	
	}

	@And("^clicks on SMS Templates$")
	public void clickSMSTemplatesLink()
	{

		lib.WriteReportStep("1","Click on SMS Templates", "", "", "");
		try
		{
			merchantAdminPage.clickSmsTemplatesLink();
			lib.WriteReportStep("2","Click on SMS Templates", "The User must click on SMS Templates", "User successfully clicked on SMS Templates", "Passed");
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","Click on SMS Templates", "The User must click on SMS Templates", "Error while clicking on SMS Templates", "Failed");
		}	
	}

	@And("^clicks on Email Templates$")
	public void clickEmailTemplatesLink()
	{

		lib.WriteReportStep("1","Click on Email Templates", "", "", "");
		try
		{
			merchantAdminPage.clickEmailTemplatesLink();
			lib.WriteReportStep("2","Click on Email Templates", "The User must click on Email Templates", "User successfully clicked on Email Templates", "Passed");
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","Click on Email Templates", "The User must click on Email Templates", "Error while clicking on Email Templates", "Failed");
		}	
	}

	@And("^clicks on Communication Summary$")
	public void clickcommunicationSummaryLink()
	{

		lib.WriteReportStep("1","Click on Communication Summary", "", "", "");
		try
		{
			merchantAdminPage.clickCommunicationSummaryLink();
			lib.WriteReportStep("2","Click on Communication Summary", "The User must click on Communication Summary", "User successfully clicked on Communication Summary", "Passed");
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","Click on Communication Summary", "The User must click on Communication Summary", "Error while clicking on Communication Summary", "Failed");
		}	
	}

	@And("^clicks on Export Email")
	public void clickExportEmailLink()
	{

		lib.WriteReportStep("1","Click on Export Email", "", "", "");
		try
		{
			merchantAdminPage.clickEmailTemplatesLink();
			lib.WriteReportStep("2","Click on Export Email", "The User must click on Export Email", "User successfully clicked on Export Email", "Passed");
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","Click on Export Email", "The User must click on Export Email", "Error while clicking on Export Email", "Failed");
		}	
	}

	@And("^clicks on Parameters$")
	public void clickParametersLink()
	{

		lib.WriteReportStep("1","Click on Parameters", "", "", "");
		try
		{
			merchantAdminPage.clickParametersLink();
			lib.WriteReportStep("2","Click on Parameters", "The User must click on Parameters", "User successfully clicked on Parameters", "Passed");
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","Click on Parameters", "The User must click on Parameters", "Error while clicking on Parameters."+e.getLocalizedMessage(), "Failed");
			e.printStackTrace();
		}	
	}


	@And("^clicks on Terms And Conditions$")
	public void clickTermsAndConditionsLink()
	{

		lib.WriteReportStep("1","Click on Terms And Conditions", "", "", "");
		try
		{
			merchantAdminPage.clickTermsAndConditionsLink();
			lib.WriteReportStep("2","Click on Terms And Conditions", "The User must click on Terms And Conditions", "User successfully clicked on Terms And Conditions", "Passed");
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","Click on Terms And Conditions", "The User must click on Terms And Conditions", "Error while clicking on Terms And Conditions", "Failed");
		}	
	}

	@Then("^the user can search for a user by giving details like \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and verify their last updated Terms and conditions$")
	public void verifyLastUpdatedTermsAndConditions(String firstname, String lastname, String username, String email, String accountstatus) throws InterruptedException
	{

		String TC_Id;
		lib.WriteReportStep("1","Verify last updated Terms and Conditions", "", "", "");
		try
		{
			TC_Id=termsandConditions.getTermsAndConditionsId(firstname, lastname, username, email, accountstatus);
			lib.WriteReportStep("2","Verify last updated Terms and Conditions", "The last updated Terms and Conditions ID must be displayed", "The Terms and conditions ID is:"+TC_Id, "Passed");
		}
		catch(ElementNotVisibleException e)
		{
			e.printStackTrace();
			lib.WriteReportStep("2","Verify last updated Terms and Conditions", "The last updated Terms and Conditions ID must be displayed", "The Terms and conditions ID is not available.Please verify the details of the user", "Failed");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			lib.WriteReportStep("2","Verify Terms and Conditions", "The Terms and Conditions ID must be displayed", "Error in verifying the last updated terms and conditions", "Failed");
		}

	}

	@Then("^the user can view the list of available folders$")
	public void getDocumentFolderList()
	{
		ArrayList<String> folderlist;
		lib.WriteReportStep("1","View the list of available folders", "", "", "");
		try
		{
			folderlist=documentManagement.getDocumentsFolderList();
			lib.WriteReportStep("2","View the list of available folders", "The  list of available folders must be displayed", "The available folders are:"+folderlist, "Passed");
		}
		catch (Exception e)
		{
			lib.WriteReportStep("2","View the list of available folders", "The  list of available folders must be displayed", "Error while retrieving the list of available folders", "Failed");
			e.printStackTrace();
		}

	}

	@Then("^the user can search for an active user by giving details like user name \"([^\"]*)\", first name \"([^\"]*)\", last name \"([^\"]*)\", email \"([^\"]*)\", account status \"([^\"]*)\", target status \"([^\"]*)\" and block the account after selecting the reason \"([^\"]*)\" from the list$")
	public void blockUserafterSelectingReason(String username, String firstname, String lastname, String email, String accountstatus, String targetstatus, String blockreason) throws AWTException, InterruptedException
	{
		lib.WriteReportStep("1","Select reason from list for blocking the user", "", "", "");
		try{

			userManagementPage.blockUser(firstname,lastname,username,email,accountstatus,targetstatus,blockreason);
			String reason= userManagementPage.getBlockReason(firstname, lastname, username, email, targetstatus);
			if(reason.equalsIgnoreCase(blockreason))
			{
				lib.WriteReportStep("2","Select reason from list for blocking the user", "The admin must be able to select reason from list for blocking the user ", "admin is able to successfully select the reason. Reason is:"+reason, "Passed");
			}
			else
			{
				lib.WriteReportStep("2","Select reason from list for blocking the user", "The admin must be able to select reason from list for blocking the user ", "admin is not able to select the reason", "Failed");
			}
		}
		catch (Exception e)
		{
			lib.WriteReportStep("2","Select reason from list for blocking the user", "The admin must be able to select reason from list for blocking the user ", "error while selecting the reason. Cause is: "+e.getLocalizedMessage(), "Failed");

		}
	}

	@Then("^the user can search for an active user by giving details like user name \"([^\"]*)\", first name \"([^\"]*)\", last name \"([^\"]*)\", email \"([^\"]*)\", account status \"([^\"]*)\", target status \"([^\"]*)\" and block the account after selecting the \"([^\"]*)\" as reason$")
	public void blockUser(String username, String firstname, String lastname, String email, String accountstatus, String targetstatus, String blockreason) throws AWTException, InterruptedException
	{
		lib.WriteReportStep("1","Block User", "", "", "");
		try{

			userManagementPage.blockUser(firstname,lastname,username,email,accountstatus,targetstatus,blockreason);
			String reason= userManagementPage.getBlockReason(firstname, lastname, username, email, targetstatus);
			String status=userManagementPage.clickedAccountStatus;
			if(status.equalsIgnoreCase(targetstatus))
			{
				lib.WriteReportStep("2","Block User", "The admin must be able to block the user", "admin is able to successfully block the user. Reason is:"+reason, "Passed");
			}
			else
			{
				lib.WriteReportStep("2","Block User", "The admin must be able to block the user", "admin is not able to block the user", "Failed");
			}
		}
		catch (Exception e)
		{
			lib.WriteReportStep("2","Block User", "The admin must be able to block the user", "error while blocking the user. Cause is: "+e.getLocalizedMessage(), "Failed");

		}
	}

	@Then("^the user can search for an active user by giving details like user name \"([^\"]*)\", first name \"([^\"]*)\", last name \"([^\"]*)\", email \"([^\"]*)\", account status \"([^\"]*)\", target status \"([^\"]*)\" and lock the account after selecting the \"([^\"]*)\" as reason$")
	public void lockUser(String username, String firstname, String lastname, String email, String accountstatus, String targetstatus, String blockreason) throws AWTException, InterruptedException
	{
		lib.WriteReportStep("1","lock User", "", "", "");
		try{

			userManagementPage.blockUser(firstname,lastname,username,email,accountstatus,targetstatus,blockreason);
			String reason= userManagementPage.getBlockReason(firstname, lastname, username, email, targetstatus);
			String status=userManagementPage.clickedAccountStatus;
			if(status.equalsIgnoreCase(targetstatus))
			{
				lib.WriteReportStep("2","lock User", "The admin must be able to lock the user", "admin is able to successfully lock the user. Reason is:"+reason, "Passed");
			}
			else
			{
				lib.WriteReportStep("2","lock User", "The admin must be able to lock the user", "admin is not able to lock the user", "Failed");
			}
		}
		catch (Exception e)
		{
			lib.WriteReportStep("2","lock User", "The admin must be able to lock the user", "error while locking the user. Cause is: "+e.getLocalizedMessage(), "Failed");

		}
	}

	@Then("^the user can search for a blocked user by giving details like user name \"([^\"]*)\", first name \"([^\"]*)\", last name \"([^\"]*)\", email \"([^\"]*)\", account status \"([^\"]*)\", target status \"([^\"]*)\" and unblock the account$")
	public void unBlockUser(String username, String firstname, String lastname, String email, String accountstatus, String targetstatus) throws AWTException, InterruptedException
	{
		lib.WriteReportStep("1","Unblock User", "", "", "");
		try{

			String status=userManagementPage.unBlockUser(firstname,lastname,username,email,accountstatus,targetstatus);
			if(status.equalsIgnoreCase(targetstatus))
			{
				lib.WriteReportStep("2","UnBlock User", "The admin must be able to unblock the user", "admin is able to successfully unblock the user. Status is:"+status, "Passed");
			}
			else
			{
				lib.WriteReportStep("2","UnBlock User", "The admin must be able to unblock the user", "admin is not able to unblock the user", "Failed");
			}
		}
		catch (Exception e)
		{
			lib.WriteReportStep("2","UnBlock User", "The admin must be able to unblock the user", "error while unblocking the user. Cause is: "+e.getLocalizedMessage(), "Failed");

		}
	}

	@Then("^the user can search for a user by giving details like user name \"([^\"]*)\", first name \"([^\"]*)\", last name \"([^\"]*)\", email \"([^\"]*)\", account status \"([^\"]*)\" and set the account to expire by giving \"([^\"]*)\" as day, giving \"([^\"]*)\" as month and giving \"([^\"]*)\" as year$")
	public void SetAccountToExpire(String username, String firstname, String lastname, String email, String accountstatus, String day, String month, String year) throws AWTException, InterruptedException
	{
		lib.WriteReportStep("1","SetAccountToExpire", "", "", "");
		try{

			userManagementPage.setAccountExpiryDate(firstname,lastname,username,email,accountstatus,day,month,year);
			userManagementPage.getAccountExpiryDate(firstname,lastname,username,email,accountstatus);

			if(day.equals(userManagementPage.expiryDay) && month.equals(userManagementPage.expiryMonth) && year.equals(userManagementPage.expiryYear))
			{
				lib.WriteReportStep("2","SetAccountToExpire", "The admin must be able to set account to expire", "admin is able to successfully set account to expire", "Passed");
			}
			else
			{
				lib.WriteReportStep("2","SetAccountToExpire", "The admin must be able to set account to expire", "admin is not able to set account to expire", "Failed");
			}
		}
		catch (Exception e)
		{
			lib.WriteReportStep("2","SetAccountToExpire", "The admin must be able to unblock the user", "error while setting the account to expire. Cause is: "+e.getLocalizedMessage(), "Failed");

		}
	}


	@Then("^the User can enter the details like alliance name \"([^\"]*)\", type \"([^\"]*)\", language \"([^\"]*)\", TCname \"([^\"]*)\", description \"([^\"]*)\" and upload the new Terms and Conditions in HTML \"([^\"]*)\" and in PDF \"([^\"]*)\" format$")
	public void uploadTermsAndConditions(String alliancename,String type, String language,String TCName, String description, String htmlfilepath, String pdffilepath) throws AWTException, InterruptedException
	{

		lib.WriteReportStep("1","Upload Terms And Conditions", "", "", "");
		try{	
			String name=termsandConditions.uploadTermsAndConditions(alliancename,type,language,TCName,description,htmlfilepath,pdffilepath);
			System.out.println("returned TCname is"+name);
			System.out.println("returned TC ID is:"+termsandConditions.newTermsAndConditionsID);
			if(name.equals(TCName))
			{
				lib.WriteReportStep("2","Upload Terms And Conditions", "Terms And Conditions must be uploaded", "Terms And Conditions successfully uploaded", "Passed");
			}
			else
			{
				lib.WriteReportStep("2","Upload Terms And Conditions", "Terms And Conditions must be uploaded", "Terms And Conditions not uploaded", "Failed");
			}
		}

		catch(Exception e)
		{
			lib.WriteReportStep("2","Upload Terms And Conditions", "Terms And Conditions must be uploaded", "Error while uploading Terms And Conditions", "Failed");
			e.printStackTrace();
		}
	}

//	@Then("^user should be able to download the terms and conditions in the chosen language in the given path \"([^\"]*)\"$")
//	public void user_should_be_able_to_download_the_terms_and_conditions_in_the_given_path(String downloaded_Path) throws Throwable {
//		lib.WriteReportStep("1", "Verify BO should be able to download the terms and conditions", "", "", "");
//		String Result=signonpage.download_terms_and_condition(downloaded_Path);
//		if(Result.contains("Passed"))
//		{
//			lib.WriteReportStep("2", "Verify BO should be able to download the terms and conditions in the chosen language","Verify BO should be able to download the terms and conditions in the chosen language", "Successfully Downloaded the terms and conditions in the chosen language"+Result,"Passed");
//		}
//		else
//		{
//			lib.WriteReportStep("2", "Verify BO should be able to download the terms and conditions in the chosen language","Verify BO should be able to download the terms and conditions in the chosen language", "Failed to Downloaded the terms and conditions in the chosen language"+Result,"Failed");
//		}
//	}


	@Then("^user should be able to view the terms and conditions$")
	public void user_should_be_able_to_view_the_terms_and_conditions() throws Throwable {
		lib.WriteReportStep("1", "View the terms and conditions", "", "", "");
		String Result=signonpage.View_terms_and_conditions();
		if(Result.contains("Passed"))
		{
			lib.WriteReportStep("2", "View the terms and conditions","User should be able to view the terms and conditions", "User is able to successfully view the terms and conditions"+Result,"Passed");
		}
		else
		{
			lib.WriteReportStep("2", "View the terms and conditions","User should be able to view the terms and conditions", "User is not able to view the terms and conditions"+Result,"Failed");
		}
	}

	@Then("^user should be able to view the terms and conditions in the chosen language$")
	public void user_should_be_able_to_view_the_terms_and_conditions_in_the_chosen_language() throws Throwable {
		lib.WriteReportStep("1", "View the terms and conditions in the chosen language", "", "", "");
		String Result=signonpage.View_terms_and_conditions();
		if(Result.contains("Passed"))
		{
			lib.WriteReportStep("2", "View the terms and conditions in the chosen language","User should be able to view the terms and conditions in the chosen language", "User is able to successfully view the terms and conditions in the chosen language"+Result,"Passed");
		}
		else
		{
			lib.WriteReportStep("2", "View the terms and conditions in the chosen language","User should be able to view the terms and conditions in the chosen language", "User is not able to view the terms and conditions in the chosen language"+Result,"Failed");
		}
	}


	@Then("^the user can search for the user by giving details like \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and confirm if their Terms and conditions have been updated or not$")
	public void checkTermsAndConditionUpdateStatus(String firstname, String lastname, String username, String email, String accountstatus) throws InterruptedException, AWTException
	{

		lib.WriteReportStep("1", "Check if the user has accepted the latest terms and conditions", "", "", "");
		String newTermsAndConditionsId,userTermsAndConditionsId;
		try
		{
			newTermsAndConditionsId=termsandConditions.newTermsAndConditionsID;
			System.out.println("The latest terms and condtions ID is:"+newTermsAndConditionsId);
			userTermsAndConditionsId=termsandConditions.getTermsAndConditionsId(firstname, lastname, username, email, accountstatus);
			System.out.println("The terms and condtions ID accepted by the user is:"+userTermsAndConditionsId);
			if(userTermsAndConditionsId.equals(newTermsAndConditionsId))
			{
				lib.WriteReportStep("2", "Check if the user has accepted the latest terms and conditions", "user must have accepted the latest terms and conditions", "user has accepted the latest terms and conditions", "Passed");
			}
			else
			{
				lib.WriteReportStep("2", "Check if the user has accepted the latest terms and conditions", "user must have accepted the latest terms and conditions", "user has not accepted the latest terms and conditions", "Passed");
			}
		}
		catch (Exception e)
		{
			lib.WriteReportStep("2", "Check if the user has accepted the latest terms and conditions", "user must have accepted the latest terms and conditions", "error while verifying the accept status", "Failed");
		}
	}

	@Then("^user should not be able to login to the portal after rejecting the terms and conditions$")
	public void checkIfAccessIsDenied()
	{
		lib.WriteReportStep("1", "Check if portal access is denied after rejecting the Terms And Conditions", "", "", "");
		String Result;
		try
		{
			Result=signonpage.checkIfAccessIsDenied();
			System.out.println("Status is:"+Result);
			if(Result.equals("PASSED"))
			{
				lib.WriteReportStep("2", "Check if portal access is denied after rejecting the Terms And Conditions", "Portal should not be accessible", "Portal is not accessible", "Passed");
			}
			else
			{
				lib.WriteReportStep("2", "Check if portal access is denied after rejecting the Terms And Conditions", "Portal should not be accessible", "Portal is accessible", "Failed");
			}
		}

		catch(Exception e)
		{
			lib.WriteReportStep("2", "Check if portal access is denied after rejecting the Terms And Conditions", "Portal should not be accessible", "Error while logging into the portal", "Failed");
		}
	}

	@Then("^the user can give information like document name \"([^\"]*)\", alliance code \"([^\"]*)\", default language \"([^\"]*)\" and view the various folders available for storing the documents$")
	public void verifyDocumentPaths(String documentName, String allianceCode, String defaultLanguage)
	{
		lib.WriteReportStep("1", "verify if the required folders are present", "", "", "");
		try
		{
			String result=documentManagement.verifyDocumentPaths(documentName, allianceCode, defaultLanguage);
			if(result.equals("Passed"))
			{
				lib.WriteReportStep("2", "verify if the required folders are present", "the required folders must be present", "the required folders are present", "Passed");
			}
			else
			{
				lib.WriteReportStep("2", "verify if the required folders are present", "the required folders must be present", "the required folders are not present", "Failed");
			}
		}

		catch(Exception e)
		{
			lib.WriteReportStep("2", "verify if the required folders are present", "the required folders must be present", "error while verifying the folder. Reason is:" +e.getLocalizedMessage(), "Failed");
		}
	}

	@Then("^the user can give the alliance code \"([^\"]*)\" and the default language \"([^\"]*)\" and view the various folders available for storing the documents in the language$")
	public void getDocumentPaths(String allianceCode, String defaultLanguage)
	{
		lib.WriteReportStep("1", "display the folders for the language "+defaultLanguage, "", "", "");
		try
		{
			ArrayList<String> result=documentManagement.getDocumentPaths(allianceCode, defaultLanguage);
			if(result.size()> 0)
			{
				lib.WriteReportStep("2", "display the folders for the language "+defaultLanguage, "the required folders for the language "+defaultLanguage+" must be present", "the required folders for the language "+defaultLanguage+" are present. The folders are:"+result, "Passed");
			}
			else
			{
				lib.WriteReportStep("2", "display the folders for the language "+defaultLanguage, "the required folders for the language "+defaultLanguage+" must be present", "the required folders for the language "+defaultLanguage+" are not present", "Failed");
			}
		}

		catch(Exception e)
		{
			lib.WriteReportStep("2", "display the folders for the language "+defaultLanguage, "the required folders for the language "+defaultLanguage+" must be present", " error while displaying the required folders for the language "+defaultLanguage+". Reason is:"+e.getMessage(), "Failed");
		}
	}

	@Then("^the user can view the various FAQ categories and sub-categories after clicking on the Help link under More options$")
	public void verifyFAQCategoriesAndSubcategories()
	{
		lib.WriteReportStep("1","view the various FAQ categories and sub-categories", "", "", "");
		try
		{
			lib.WriteReportStep("2","view the various FAQ categories and sub-categories", "the various FAQ categories and sub-categories must be displayed", "FAQ Categories:"+faqpage.faqCategories+".FAQ SubCategories:"+faqpage.faqCategoriesQuestions, "Failed");

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","view the various FAQ categories and sub-categories", "the various FAQ categories and sub-categories must be displayed", "Error while displaying the various FAQ categories and sub-categories", "Failed");
			e.printStackTrace();
		}

	}

	@Then("^the user can access all the SMS Templates$")
	public void retrieveSmsTemplates()
	{
		lib.WriteReportStep("1","Access all the SMS Templates", "", "", "");
		try
		{
			HashMap<String,String> finalsmstemplates=userManagementPage.getSMSTemplate();
			lib.WriteReportStep("2","Access all the SMS Templates", "The user should be able to access all the SMS Templates", "user is able to access all the SMS Templates successfully. The available SMS templates are: "+finalsmstemplates, "Passed");
		}
		catch (Exception e)
		{
			lib.WriteReportStep("2","Access all the SMS Templates", "The user should be able to access all the SMS Templates", "Error while accessing the SMS templates: Reason is: "+e.getMessage(), "Failed");	
		}
	}

	@Then("^the user can access all the Email Templates$")
	public void retrieveEmailTemplates()
	{
		lib.WriteReportStep("1","Access all the Email Templates", "", "", "");
		try
		{
			HashMap<String,String> finalemailtemplates=userManagementPage.getEmailTemplate();
			lib.WriteReportStep("2","Access all the Email Templates", "The user should be able to access all the Email Templates", "user is able to access all the Email Templates successfully. The available SMS templates are: "+finalemailtemplates, "Passed");
		}
		catch (Exception e)
		{
			lib.WriteReportStep("2","Access all the Email Templates", "The user should be able to access all the Email Templates", "Error while accessing the Email templates: Reason is: "+e.getMessage(), "Failed");	
		}
	}

	@And("^the user can display the list of message along with the message details$")
	public void getMessageDetails()
	{
		lib.WriteReportStep("1","View the list of messages", "", "", "");
		try
		{
			String messageList=messagepage.getListofMessages();
			if(messageList.equals("Passed"))
			{
				lib.WriteReportStep("2","View the list of messages", "The list of messages should be displayed", "Messages are:"+messagepage.messages, "Passed");
			}
			else
			{
				lib.WriteReportStep("2","View the list of messages", "The list of messages should be displayed",messageList, "Failed");
			}
		}
		catch (Exception e)
		{
			lib.WriteReportStep("2","View the list of messages", "The list of messages should be displayed", "Error while retrieving the list of messages.Reason is:"+e.getMessage(), "Failed");
		}
	}

	@And("^clicks on the folder with \"([^\"]*)\" as name$")
	public void clickFolder(String folderName)
	{

		lib.WriteReportStep("1","Click on the folder with the name "+folderName, "", "", "");
		try
		{
			String Result=documentManagement.clickFolder(folderName);
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2","Click on the folder with the name "+folderName, "The folder with the name "+folderName+"must be clicked", "The folder with the name "+folderName+"is clicked successfully", "Passed");
			}
			else
			{
				lib.WriteReportStep("2","Click on the folder with the name "+folderName, "The folder with the name "+folderName+"must be clicked", "The folder with the name "+folderName+"is not clicked", "Failed");	
			}
		}

		catch(Exception e)
		{
			lib.WriteReportStep("2","Click on the folder with the name "+folderName,"The folder with the name "+folderName+"must be clicked", " Error while clicking the folder with the name "+folderName+".Reason is:"+e.getMessage(), "Failed");
		}	
	}

	@Then("^the user can view the documents available in the folder$")
	public void getListOfDocuments()
	{
		lib.WriteReportStep("1","View the list of documents", "", "", "");
		try
		{
			String Result=documentManagement.getListofDocuments();
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2","View the list of documents", "The list of documents should be displayed", "documents are:"+documentManagement.documents, "Passed");
			}
			else
			{
				lib.WriteReportStep("2","View the list of documents", "The list of documents should be displayed", "No documents are present", "Failed");
			}

		}
		catch (Exception e)
		{
			lib.WriteReportStep("2","View the list of documents", "The list of documents should be displayed", "Error while retrieving the list of documents.Reason is:"+e.getMessage(), "Failed");
			e.printStackTrace();
		}
	}

	@Then("^the user can view the first ten documents available in the folder$")
	public void viewFirstTenDocuments()
	{
		lib.WriteReportStep("1","View the first ten documents", "", "", "");
		try
		{
			String Result=documentManagement.displayFirstTenDocuments();
			if(Result.equalsIgnoreCase("Passed"))
			{
				lib.WriteReportStep("2","View the first ten documents", "The first ten documents should be displayed", "The first ten documents are:"+documentManagement.documentTitle, "Passed");
			}
			else if(Result.equalsIgnoreCase("Less Files Present"))
			{
				lib.WriteReportStep("2","View the first ten documents", "The first ten documents should be displayed", "Only "+documentManagement.documentTitle.size()+" are present","Failed");
			}
			else
			{
				lib.WriteReportStep("2","View the first ten documents", "The first ten documents should be displayed", "No documents are present", "Failed");
			}

		}
		catch (Exception e)
		{
			lib.WriteReportStep("2","View the list of documents", "The first ten documents should be displayed", "Error while displaying the first ten documents.Reason is:"+e.getMessage(), "Failed");
		}
	}

	@Then("^the user can verify if the documents by default are sorted in descending order by date$")
	public void verifyDocumentOrderByDate()
	{
		lib.WriteReportStep("1","Verify the Document Order By Date", "", "", "");
		try
		{
			String Result=documentManagement.verifyDocumentOrderByDate();
			if(Result.equalsIgnoreCase("Passed"))
			{
				lib.WriteReportStep("2","Verify the Document Order By Date", "the documents must be sorted in descending order by date", "the documents are sorted in descending order by date","Passed");
			}
			else if(Result.equalsIgnoreCase("Not in Descending order"))
			{
				lib.WriteReportStep("2","Verify the Document Order By Date", "the documents must be sorted in descending order by date", "the documents are sorted in descending order by date","Failed");
			}
			else
			{
				lib.WriteReportStep("2","Verify the Document Order By Date", "the documents must be sorted in descending order by date", "No documents are present", "Failed");
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
			lib.WriteReportStep("2","Verify the Document Order By Date", "the documents must be sorted in descending order by date", "Error while displaying the sorting order.Reason is:"+e.getLocalizedMessage(), "Failed");
		}
	}

	@Then("^the user can sort the documents by \"([^\"]*)\"$")
	public void sortDocuments(String orderBy)
	{
		lib.WriteReportStep("1","Sort Documents", "", "", "");
		try
		{
			String Result=documentManagement.orderDocuments(orderBy);

			if(Result.equalsIgnoreCase("Invalid sort type"))
			{
				lib.WriteReportStep("2","Verify the Document Order By Date", "the documents must be sorted by "+orderBy, "Invalid sort type", "Failed");
			}
			else if(Result.equalsIgnoreCase("Document type is not displayed"))
			{
				lib.WriteReportStep("2","Verify the Document Order By Date", "the documents must be sorted by "+orderBy, "Document type is not displayed", "Failed");
			}
			else if(Result.equalsIgnoreCase("no files"))
			{
				lib.WriteReportStep("2","Verify the Document Order By Date", "the documents must be sorted by "+orderBy, "No files present", "Failed");
			}
			else
			{
				lib.WriteReportStep("2","Verify the Document Order By Date", "the documents must be sorted by "+orderBy, Result, "Passed");
			}

		}
		catch (Exception e)
		{
			lib.WriteReportStep("2","Verify the Document Order By Date", "the documents must be sorted by "+orderBy, e.getMessage(), "Failed");
			e.printStackTrace();
		}
	}

//	@Then("^user should be able to create a new merchant user by giving \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
//	public void user_should_be_able_to_create_a_new_merchant_user_by_giving(String User_Type, String Merchant_ID, String Profile_type, String First_Name, String last_name, String UserName_new_alliance, String email_id, String mobile_number, String Language) throws Throwable {
//		lib.WriteReportStep("1", "Verify Admin should be able to create a merchant", "", "", "");
//		String Result=adminconsolecreateuserpage.Create_new_merchant(User_Type,Merchant_ID,Profile_type,First_Name, last_name, UserName_new_alliance, email_id, mobile_number, Language);
//		if(Result.contains("Passed"))
//		{
//			lib.WriteReportStep("2", "Verify Admin should be able to create a merchant","Verify Admin should be able to create a merchant", "Successfully Created the Merchant"+Result,"Passed");
//		}
//		else
//		{
//			lib.WriteReportStep("2", "Verify Admin should be able to create a merchant","Verify Admin should be able to create a merchant", "Failed to create the Merchant"+Result,"Failed");
//		}
//	}


	@Then("^the user can see the documents$")
	public void getDocuments() throws InterruptedException, ParseException
	{
		lib.WriteReportStep("1", "Display the documents", "", "", "");
		try
		{
			ArrayList<String> documentList=documentManagement.getDocuments();
			if(documentManagement.Result.contains("Passed"))
			{
				lib.WriteReportStep("2","Display the documents","The documents must be displayed","The documents are: "+documentList,"Passed");
			}
			else if(documentManagement.Result.contains("No Files Present"))
			{
				lib.WriteReportStep("2","Display the documents","The documents must be displayed","No Files Pesent","Failed");
			}
			else
			{
				lib.WriteReportStep("2","Display the documents","The documents must be displayed","Could not display the documents","Failed");
			}
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","Display the documents","The documents must be displayed","Error while displaying the documents. Cause is: "+e.getLocalizedMessage(),"Failed");
		}

	}

	@Then("^the user can search for a locked user by giving details like user name \"([^\"]*)\", first name \"([^\"]*)\", last name \"([^\"]*)\", email \"([^\"]*)\", account status \"([^\"]*)\", url \"([^\"]*)\", password \"([^\"]*)\" and check if the user is denied access to the portal$")
	public void checkIfAccessIsBlocked(String username, String firstname, String lastname, String email, String accountstatus, String url, String password)
	{
		lib.WriteReportStep("1", "Check if access to the portal is blocked", "", "", "");
		try
		{
			String Result=userManagementPage.checkIfPortalAccessIsBlocked(firstname, lastname, username, email, accountstatus, url, password);
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2", "Check if access to the portal is blocked", "Access to the portal must be blocked", "Access blocked. Error message: "+signOnObjects.loginErrorMessage.getText(), "Passed");
			}
			else if(Result.contains("Account is not blocked"))
			{
				lib.WriteReportStep("2", "Check if access to the portal is blocked", "Access to the portal must be blocked", Result, "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Check if access to the portal is blocked", "Access to the portal must be blocked", "Access to the portal is not blocked", "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Check if access to the portal is blocked", "Access to the portal must be blocked", e.getLocalizedMessage(), "Failed");
		}
	}

	@Then("^the user can check if the access is denied on account of the user account being expired$")
	public void checkIfAccountHasExpired()
	{
		lib.WriteReportStep("1", "Check if access to the portal is denied", "", "", "");
		try
		{
			String Result=signonpage.checkIfAccountHasExpired();
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2", "Check if access to the portal is denied", "Access to the portal must be denied", "Access denied. Error message: "+signOnObjects.accountExpiredErrorMessage.getText(), "Passed");
			}

			else
			{
				lib.WriteReportStep("2", "Check if access to the portal is denied", "Access to the portal must be denied", "Please check the account status", "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Check if access to the portal is denied", "Access to the portal must be denied", e.getLocalizedMessage(), "Failed");
		}
	}

	@Then("^the user can check if a notification appears regarding the expiration of the account$")
	public void checkAccountExpiryNotification()
	{
		lib.WriteReportStep("1", "check if a notification appears regarding the expiration of the account", "", "", "");
		try
		{
			String Result=dashboardpage.checkAccountExpiryNotification();
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2", "check if a notification appears regarding the expiration of the account", "A notification should appear regarding the expiration of the account", "Notification appeared successfully stating \" "+dashboardpageobject.accountExpiryNotification.getText()+"\" ", "Passed");
			}

			else
			{
				lib.WriteReportStep("2", "check if a notification appears regarding the expiration of the account", "A notification should appear regarding the expiration of the account", "Notification did not appear", "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "check if a notification appears regarding the expiration of the account", "A notification should appear regarding the expiration of the account", e.getLocalizedMessage(), "Failed");
		}
	}

	@And("^the user can give the from date \"([^\"]*)\" and to date \"([^\"]*)\" and verify if the date is in descending order by default in Pre-Authorizations view$")
	public void checkPreAuthorizationsSortingOrder(String fromDate, String toDate)
	{
		lib.WriteReportStep("1", "Verify PreAuthorizations Sorting Order", "", "", "");
		try
		{
			String Result=financialactivity.validatePreAuthorizationsSortOrder(fromDate, toDate);
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2", "Verify PreAuthorizations Sorting Order", "The date must be in descending order by default in Pre-Authorizations view", "The date is in descending order by default in Pre-Authorizations view", "Passed");
			}
			else if(Result.contains("No Records Found"))
			{
				lib.WriteReportStep("2", "Verify PreAuthorizations Sorting Order", "No Records Found", Result, "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Verify PreAuthorizations Sorting Order", "The date must be in descending order by default in Pre-Authorizations view", "The date is not in descending order by default in Pre-Authorizations view", "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Verify PreAuthorizations Sorting Order", "The date must be in descending order by default in Pre-Authorizations view", e.getMessage(), "Failed");
			e.printStackTrace();
		}

	}
	@And("^the user can give the from date \"([^\"]*)\" and to date \"([^\"]*)\" and verify if the date is in descending order by default in Authorizations view$")
	public void checkAuthorizationsSortingOrder(String fromDate, String toDate)
	{
		lib.WriteReportStep("1", "Verify Authorizations Sorting Order", "", "", "");
		try
		{
			String Result=financialactivity.validateAuthorizationsSortOrder(fromDate, toDate);
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2", "Verify Authorizations Sorting Order", "The date must be in descending order by default in Authorizations view", "The date is in descending order by default in Authorizations view", "Passed");
			}
			else if(Result.contains("No Records Found"))
			{
				lib.WriteReportStep("2", "Verify Authorizations Sorting Order", "No Records Found", Result, "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Verify Authorizations Sorting Order", "The date must be in descending order by default in Authorizations view", "The date is not in descending order by default in Authorizations view", "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Verify Authorizations Sorting Order", "The date must be in descending order by default in Authorizations view", e.getLocalizedMessage(), "Failed");
		}
	}
	@And("^the user can give the from date \"([^\"]*)\" and to date \"([^\"]*)\" and verify if the date is in descending order by default in Transactions view$")
	public void checkTransactionsSortingOrder(String fromDate, String toDate)
	{
		lib.WriteReportStep("1", "Verify Transactions Sorting Order", "", "", "");
		try
		{
			String Result=financialactivity.validateTransactionsSortOrder(fromDate, toDate);
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2", "Verify Transactions Sorting Order", "The date must be in descending order by default in Transactions view", "The date is in descending order by default in Transactions view", "Passed");
			}
			else if(Result.contains("No Records Found"))
			{
				lib.WriteReportStep("2", "Verify Transactions Sorting Order", "No Records Found", Result, "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Verify Transactions Sorting Order", "The date must be in descending order by default in Transactions view", "The date is not in descending order by default in Transactions view", "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Verify Transactions Sorting Order", "The date must be in descending order by default in Transactions", e.getLocalizedMessage(), "Failed");
		}
	}
	@And("^the user can give the from date \"([^\"]*)\" and to date \"([^\"]*)\" and verify if the date is in descending order by default in Funding view$")
	public void checkFundingSortingOrder(String fromDate, String toDate)
	{
		lib.WriteReportStep("1", "Verify Funding Sorting Order", "", "", "");
		try
		{
			String Result=financialactivity.validateFundingSortOrder(fromDate, toDate);
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2", "Verify Funding Sorting Order", "The date must be in descending order by default in Funding view", "The date is in descending order by default in Funding view", "Passed");
			}
			else if(Result.contains("No Records Found"))
			{
				lib.WriteReportStep("2", "Verify Funding Sorting Order", "No Records Found", Result, "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Verify Funding Sorting Order", "The date must be in descending order by default in Funding view", "The date is not in descending order by default in Funding view", "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Verify Funding Sorting Order", "The date must be in descending order by default in Funding view", e.getLocalizedMessage(), "Failed");
		}
	}

	@Then("^the user can go to the settings window and verify if the Email Address \"([^\"]*)\" and Mobile Number \"([^\"]*)\" registered to the account is correct or not$")
	public void verifyEmailAndMobileNumber(String eMail, String mobileNumber)
	{
		lib.WriteReportStep("1", "Verify Email And Mobile Number", "", "", "");
		try
		{
			String Result=dashboardpage.verifyEmailAndMobileNumber(eMail, mobileNumber);
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2", "Verify Email And Mobile Number", "The mobile number and email registered to the account must be correct", "The mobile number and email registered to the account is correct", "Passed");
			}
			else
			{
				lib.WriteReportStep("2", "Verify Email And Mobile Number", "The mobile number and email registered to the account must be correct", "The mobile number and email registered to the account is not correct", "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Verify Email And Mobile Number", "The mobile number and email registered to the account must be correct", e.getLocalizedMessage(), "Failed");
		}
	}

	@Then("^the user can enter the username \"([^\"]*)\" to be impersonated and check if the username is available in the current session and not kept for future login by logging to the MP again after giving \"([^\"]*)\" as username and \"([^\"]*)\" as password$")
	public void checkifImpersonatedUserNameisVisible(String impersonationUserName,String userName,String password)
	{
		lib.WriteReportStep("1", "Check if the Impersonated UserName is Visible", "", "", "");
		try
		{
			String Result=dashboardpage.checkifImpersonatedUserNameisVisible(impersonationUserName,userName,password);
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2", "Check if the Impersonated User Name is not kept for future login", "The Impersonated User Name must not be kept for future login", "The Impersonated User Name is not kept for future login", "Passed");
			}
			else if(Result.equals("Failed"))
			{
				lib.WriteReportStep("2", "Check if the Impersonated User Name is not kept for future login", "The Impersonated User Name must not be kept for future login","The Impersonated User Name is available for future login", "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Check if the Impersonated User Name is not kept for future login", "The Impersonated User Name must not be kept for future login",dashboardpageobject.impersonationErrorMessage.getText(), "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Check if the Impersonated User Name is not kept for future login", "The Impersonated User Name must not be kept for future login", e.getLocalizedMessage(), "Failed");
		}
	}

	@Then("^the user can retrieve the data and compare it with the data obtained after impersonating the same user \"([^\"]*)\" by giving \"([^\"]*)\" as username and \"([^\"]*)\" as password$")
	public void validateImpersonatedUserData(String impersonationUserName,String userName,String password)
	{
		lib.WriteReportStep("1", "Impersonate the user", "", "", "");
		try
		{
			String Result=dashboardpage.validateImpersonatedUserData(impersonationUserName,userName,password);
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2", "Impersonate the user", "The User must be impersonated", "User impersonated successfully", "Passed");
			}
			else if(Result.equals("Failed"))
			{
				lib.WriteReportStep("2", "Impersonate the user", "The User must be impersonated", "User not impersonated", "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Impersonate the user", "The User must be impersonated",dashboardpageobject.impersonationErrorMessage.getText(), "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Impersonate the user", "The User must be impersonated", e.getLocalizedMessage(), "Failed");
		}
	}

	@Then("^the user can retrieve the data and functions and compare it after impersonating the same user \"([^\"]*)\" by giving \"([^\"]*)\" as username and \"([^\"]*)\" as password$")
	public void checkImpersonatedUserFunctionsareAvailable(String impersonationUserName,String userName,String password)
	{
		lib.WriteReportStep("1", "Check if data and functions of the user are accessible", "", "", "");
		try
		{
			String Result=dashboardpage.checkImpersonatedUserFunctionsareAvailable(impersonationUserName,userName,password);
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2", "Check if data and functions of the user are accessible", "The data and functions of the impersonated user must be accessible", "The data and functions of the impersonated user are accessible", "Passed");
			}
			else if(Result.equals("Failed"))
			{
				lib.WriteReportStep("2", "Check if data and functions of the user are accessible", "The data and functions of the impersonated user must be accessible", "The data and functions of the impersonated user are not accessible", "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Check if data and functions of the user are accessible", "The data and functions of the impersonated user must be accessible",dashboardpageobject.impersonationErrorMessage.getText(), "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Check if data and functions of the user are accessible", "The data and functions of the impersonated user must be accessible", e.getLocalizedMessage(), "Failed");
		}
	}

	@And("^sets the Session Expiry Time as \"([^\"]*)\" minutes$")
	public void setSessionExpiryTime(String expiryTime)
	{
		lib.WriteReportStep("1", "Set the session expiry time", "", "", "");
		try
		{
			String Result=userManagementPage.changeSessionExpiryTime(expiryTime);
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2", "Set the session expiry time", "Set the session expiry time", "Successfully set the session expiry time", "Passed");
			}
			else if(Result.equals("Failed"))
			{
				lib.WriteReportStep("2", "Set the session expiry time", "Set the session expiry time", "Failed to set the session expiry time", "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Set the session expiry time", "Set the session expiry time",parametersPageObjects.parameterErrorMessage.getText(), "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Set the session expiry time", "Set the session expiry time", e.getLocalizedMessage(), "Failed");
		}

	}

	@And("^sets the Passcode Expiry Time as \"([^\"]*)\" minutes$")
	public void setPasscodeExpiryTime(String passcodeExpiryTime)
	{
		lib.WriteReportStep("1", "Set the passcode expiry time", "", "", "");
		try
		{
			String Result=userManagementPage.changePasscodeExpiryTime(passcodeExpiryTime);
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2", "Set the passcode expiry time", "Set the passcode expiry time", "Successfully set the passcode expiry time", "Passed");
			}
			else if(Result.equals("Failed"))
			{
				lib.WriteReportStep("2", "Set the passcode expiry time", "Set the passcode expiry time", "Failed to set the passcode expiry time", "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Set the passcode expiry time", "Set the passcode expiry time",parametersPageObjects.parameterErrorMessage.getText(), "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Set the passcode expiry time", "Set the passcode expiry time", e.getLocalizedMessage(), "Failed");
		}

	}

	@And("^sets the Password Expiry Duration as \"([^\"]*)\" days$")
	public void setPasswordExpiryDuration(String passwordExpiryDuration)
	{
		lib.WriteReportStep("1", "Set the Password Expiry Duration", "", "", "");
		try
		{
			String Result=userManagementPage.changePasswordExpiryDuration(passwordExpiryDuration);
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2", "Set the Password Expiry Duration", "Set the Password Expiry Duration", "Successfully set the Password Expiry Duration", "Passed");
			}
			else if(Result.equals("Failed"))
			{
				lib.WriteReportStep("2", "Set the Password Expiry Duration", "Set the Password Expiry Duration", "Failed to set the Password Expiry Duration", "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Set the Password Expiry Duration", "Set the Password Expiry Duration",parametersPageObjects.parameterErrorMessage.getText(), "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Set the Password Expiry Duration", "Set the Password Expiry Duration", e.getLocalizedMessage(), "Failed");
		}

	}

	@Then("^the user can check if the session is active in the portal \"([^\"]*)\" for \"([^\"]*)\" minutes$")
	public void verifySessionDuration(String url,String timeout)
	{
		lib.WriteReportStep("1", "Verify is the session is active", "", "", "");
		try
		{
			String Result=dashboardpage.checkIfLoginSessionIsActive(url, timeout);
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2", "Verify is the session is active", "the session must be active for "+timeout+" minutes", "The session is active for "+timeout+" minutes", "Passed");
			}
			else
			{
				lib.WriteReportStep("2", "Verify is the session is active", "the session must be active for "+timeout+" minutes","The session is active for more than "+timeout+" minutes", "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Verify is the session is active", "the session must be active for "+timeout+" minutes", e.getLocalizedMessage(), "Failed");
		}

	}

	@And("^initiates password reset in the login page by giving \"([^\"]*)\" as username$")
	public void initiatePasswordReset(String userName)
	{
		lib.WriteReportStep("1", "initiates password reset", "", "", "");
		try
		{
			String Result=signonpage.sendPasswordResetLink(userName);
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2", "initiates password reset", "Password Reset Link should be sent", "Password Reset Link sent successfully","Passed");
			}
			else
			{
				lib.WriteReportStep("2", "initiates password reset", "Password Reset Link should be sent", "failed to send Password Reset Link","Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "initiates password reset", "Password Reset Link should be sent", e.getMessage(),"Failed");
			e.printStackTrace();
		}

	}

	@Then("^the user can check if a mail has been sent to \"([^\"]*)\" regarding password reset to the \"([^\"]*)\" email address$")
	public void verifyEmailPresent(String userName, String emailAddress)
	{
		lib.WriteReportStep("2", "Verify if email is present", "", "", "");
		try
		{
			String Result=userManagementPage.verifyPasswordResetLink(userName, emailAddress);
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2", "Verify if email is present", "Email should be sent to "+userName+"'s email address regarding the password reset", "Email sent to "+userName+"'s email address successfully","Passed");
			}
			else
			{
				lib.WriteReportStep("2", "Verify if email is present", "Email should be sent to "+userName+"'s email address regarding the password reset", "Email not sent to "+userName+"'s email address","Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Verify if email is present", "Email should be sent to "+userName+"'s email address regarding the password reset", e.getMessage(),"Failed");
			e.printStackTrace();
		}

	}

	@Then("^user should be able to see a guide explaining the portal functionalities and check if the guide is not available after logging in again by giving \"([^\"]*)\" as username and \"([^\"]*)\" as password$")
	public void validateUserGuide(String userName, String password)
	{
		lib.WriteReportStep("1", "Verify if a tour guide is displayed", "", "", "");
		try
		{
			String Result=dashboardpage.validateTourGuide(userName, password);
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2", "Verify if a tour guide is displayed", "A tour guide must be displayed explaining the portal functionalities", "Sections covered in the tour guide are:"+dashboardpage.tourguideSections,"Passed");
			}
			else
			{
				lib.WriteReportStep("2", "Verify if a tour guide is displayed", "A tour guide must be displayed explaining the portal functionalities", "tour guide not displayed","Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Verify if a tour guide is displayed", "A tour guide must be displayed explaining the portal functionalities", e.getMessage(),"Failed");
			e.printStackTrace();
		}

	}

	@Then("^user can view the initialization link sent to \"([^\"]*)\" and to the \"([^\"]*)\" email id$")
	public void accessInitializationLink(String userName, String emailAddress)
	{
		lib.WriteReportStep("1", "Verify if initialization link is present", "", "", "");
		try
		{
			String Result=userManagementPage.acessInitiationLink(userName, emailAddress);
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2", "Verify if initialization link is present", "Initialization link should be sent to "+userName+"'s email address", "Initialization link sent to "+userName+"'s email address successfully","Passed");
			}
			else
			{
				lib.WriteReportStep("2", "Verify if initialization link is present", "Initialization link should be sent to "+userName+"'s email address", "Initialization link sent to "+userName+"'s email address successfully","Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Verify if initialization link is present", "Initialization link should be sent to "+userName+"'s email address", e.getMessage(),"Failed");
			e.printStackTrace();
		}

	}

	@Then("^the user can search for another user by giving details like user name \"([^\"]*)\", first name \"([^\"]*)\", last name \"([^\"]*)\", email \"([^\"]*)\", account status \"([^\"]*)\" and change the email be giving \"([^\"]*)\" as target email$")
	public void change(String userName, String firstName, String lastName, String emailAddress, String accountStatus, String targetEmailAddress)
	{
		lib.WriteReportStep("1", "Verify if email has been changed", "", "", "");
		try
		{
			String Result=userManagementPage.changeEmail(userName, firstName, lastName, emailAddress, accountStatus, targetEmailAddress);
			if(Result.equals(targetEmailAddress))
			{
				lib.WriteReportStep("2", "Verify if email has been changed", "Email must be changed to "+targetEmailAddress, "Email changed to "+targetEmailAddress+" successfully","Passed");
			}
			else
			{
				lib.WriteReportStep("2", "Verify if email has been changed", "Email must be changed to "+targetEmailAddress, "Failed to change the Email Address","Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Verify if email has been changed", "Email must be changed to "+targetEmailAddress, e.getMessage(),"Failed");
			e.printStackTrace();
		}
	}

	@Then("^user can resend the initialization link sent to \"([^\"]*)\" to the \"([^\"]*)\" email id instead of \"([^\"]*)\" email id$")
	public void resendInitializationLink(String userName, String targetEmailAddress,  String emailAddress)
	{
		lib.WriteReportStep("1", "Verify if initialization link is resent", "", "", "");
		try
		{
			String Result=userManagementPage.resendInitiationLink(userName,targetEmailAddress,emailAddress);
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2", "Verify if initialization link is resent", "Initialization link should be sent to "+targetEmailAddress, "Initialization link sent to "+targetEmailAddress+" successfully","Passed");
			}
			else
			{
				lib.WriteReportStep("2", "Verify if initialization link is resent", "Initialization link should be sent to "+targetEmailAddress, "Initialization link sent to "+targetEmailAddress+" successfully","Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Verify if initialization link is resent", "Initialization link should be sent to "+targetEmailAddress, e.getMessage(),"Failed");
			e.printStackTrace();
		}

	}

	@Then("^the user can view the PreAuthorization details in the dashboard along with the expiring preauthorizations")
	public void viewPreAuthorizationDetails()
	{
		lib.WriteReportStep("1", "View PreAuthorization Details", "", "", "");
		try
		{
			String Result=dashboardpage.validatePreAuthorizationsDetails();
			if(Result.equalsIgnoreCase("PreAuthorization details are displayed"))
			{
				lib.WriteReportStep("2", "View PreAuthorization Details","PreAuthorizations details should be available", Result,"Passed");
			}
			else if(Result.contains("the next 3 days"))
			{
				lib.WriteReportStep("2", "View PreAuthorization Details","PreAuthorizations details should be available", Result,"Passed");
			}
			else
			{
				lib.WriteReportStep("2", "View PreAuthorization Details","PreAuthorizations details should be available", Result,"Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "View PreAuthorization Details", "PreAuthorizations details should be available", e.getMessage(),"Failed");
			e.printStackTrace();
		}

	}

	@Then("^the user can view the combined sales and customer details for the last 14 days$")
	public void getCombinedSalesDetails()
	{
		lib.WriteReportStep("1", "View the combined sales and customer details", "", "", "");
		try
		{
			dashboardpage.getSalesDetails();
			lib.WriteReportStep("2", "View the combined sales and customer details","The combined sales and customer details for the last 14 days should be available","Total number of customers in the last 14 days is "+dashboardpage.combinedSalesCustomers+". Total sales amount for the last 14 days is "+dashboardpage.combinedSalesAmount,"Passed");
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "View the combined sales and customer details","The combined sales and customer details for the last 14 days should be available",e.getMessage(),"Failed");
			e.printStackTrace();
		}

	}
	@Then("^the user can see what approval ratio is for the day$")
	public void getApprovalRatioInformation()
	{
		lib.WriteReportStep("1", "View the approval ratio is for the day", "", "", "");
		try
		{
			String Result=dashboardpage.getApprovalRatioInformation();
			if(Result.equals("Passed"))
				lib.WriteReportStep("2", "View the approval ratio for the day","The approval ratio for the current day should be available",dashboardpage.approvalDetails,"Passed");
			else
				lib.WriteReportStep("2", "View the approval ratio for the day","The approval ratio for the current day should be available",Result,"Passed");

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "View the approval ratio for the day","The approval ratio for the current day should be available",e.getMessage(),"Failed");
			e.printStackTrace();
		}

	}
	@Then("^the user can see up to date information of their business activity and performance$")
	public void getDashboardInformation()
	{
		lib.WriteReportStep("1", "View the Dashboard information", "", "", "");
		try
		{
			ArrayList<String> Result=dashboardpage.getDashboardDetails();

			lib.WriteReportStep("2","View the Dashboard information","The dashboard details should be displayed","Dashboard Details:"+Result,"Passed");

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","View the Dashboard information","The dashboard details should be displayed",e.getMessage(),"Failed");
			e.printStackTrace();
		}

	}

	@And("^the user can view the preAuthorization columns and transaction details")
	public void validatePreAuthorizationColumnsAndTransactionDetails()
	{
		lib.WriteReportStep("1", "view the preAuthorization columns and transaction details", "", "", "");
		try
		{
			String Result=financialactivity.validatePreAuthorizationColumnsAndTransactionDetails();
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2","view the preAuthorization columns and transaction details","The preAuthorization columns and transaction details should be displayed","Columns:"+financialactivity.preAuthColumns+"\n Transaction Details:"+financialactivity.transactionDetails,"Passed");
			}
			else
			{
				lib.WriteReportStep("2","view the preAuthorization columns and transaction details","The preAuthorization columns and transaction details should be displayed",Result,"Passed");	
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","view the preAuthorization columns and transaction details","The preAuthorization columns and transaction details should be displayed",e.getMessage(),"Failed");
			e.printStackTrace();
		}

	}

	@And("^the user can view the Pre-authorization transactions Grouped under a single Pre-authorization view")
	public void displayPreAuthorizationTransactionDetails()
	{
		lib.WriteReportStep("1", "View the Pre-authorization transactions grouped under a single Pre-authorization view", "", "", "");
		try
		{
			String Result=financialactivity.displayPreAuthorizationTransactionDetails();
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2","View the Pre-authorization transactions grouped under a single Pre-authorization view","The Pre-authorization transactions must be grouped under a single Pre-authorization view","Transaction Details:"+financialactivity.preAuthtransactionDetails,"Passed");
			}
			else
			{
				lib.WriteReportStep("2","View the Pre-authorization transactions grouped under a single Pre-authorization view","The Pre-authorization transactions must be grouped under a single Pre-authorization view",Result,"Failed");	
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","View the Pre-authorization transactions grouped under a single Pre-authorization view","The preAuthorization columns and transaction details should be displayed",e.getMessage(),"Failed");
			e.printStackTrace();
		}

	}

	@And("^the user can view the Pre-authorization records")
	public void viewPreAuthRecords()
	{
		lib.WriteReportStep("1", "View the Pre-authorization records", "", "", "");
		try
		{
			String Result=financialactivity.displayPreAuthorizationRecords();
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2","View the Pre-authorization records","The Pre-authorization records must be displayed","PreAuth Records:"+financialactivity.preAuthRecords,"Passed");
			}
			else
			{
				lib.WriteReportStep("2","View the Pre-authorization records","The Pre-authorization records must be displayed",Result,"Failed");	
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","View the Pre-authorization records","The Pre-authorization records must be displayed",e.getMessage(),"Failed");
			e.printStackTrace();
		}

	}


	@And("^the user can search for a transaction using the order ID \"([^\"]*)\" and view the number of days left to complete the pre-authorization")
	public void viewPreAuthCompletionDuration(String orderID)
	{
		lib.WriteReportStep("1", "view the number of days left to complete the pre-authorization ", "", "", "");
		try
		{
			String Result=financialactivity.viewPreAuthCompletionDuration(orderID);
			if(Result.equals("Please check the transaction status"))
			{
				lib.WriteReportStep("2","view the number of days left to complete the pre-authorization","The number of days left to complete the pre-authorization should be displayed",Result,"Failed");
			}
			else if(Result.equals("Please enter a valid Order ID"))
			{
				lib.WriteReportStep("2","view the number of days left to complete the pre-authorization","The number of days left to complete the pre-authorization should be displayed",Result,"Failed");	
			}
			else
			{
				lib.WriteReportStep("2","view the number of days left to complete the pre-authorization","The number of days left to complete the pre-authorization should be displayed",Result,"Passed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","view the number of days left to complete the pre-authorization ","The preAuthorization columns and transaction details should be displayed",e.getMessage(),"Failed");
			e.printStackTrace();
		}

	}

	@And("^the user can search for a transaction using the order ID \"([^\"]*)\" and view the transaction status$")
	public void viewPreAuthCompletionStatus(String orderID)
	{
		lib.WriteReportStep("1", "View the pre-authorization transaction status", "", "", "");
		try
		{
			String Result=financialactivity.viewPreAuthTransactionStatus(orderID);
			if(Result.equals("Please enter a valid Order ID"))
			{
				lib.WriteReportStep("2","View the pre-authorization transaction status","The pre-authorization transaction status should be displayed",Result,"Failed");	
			}
			else
			{
				lib.WriteReportStep("2","View the pre-authorization transaction status","The pre-authorization transaction status should be displayed",Result,"Passed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","View the pre-authorization transaction status","The pre-authorization transaction status should be displayed",e.getMessage(),"Failed");
			e.printStackTrace();
		}
	}

	@And("^the user can view the interchange charges and rejects$")
	public void viewcharges()
	{
		lib.WriteReportStep("1", "View the charges", "", "", "");
		try
		{
			String Result=financialactivity.viewInterchangeCharges();
			if(Result.equals("No Records Present"))
			{
				lib.WriteReportStep("2","View the charges","The various additional charges applied should be displayed","Funding Fees:"+financialactivity.fundingFees+"\n EMS Fees:"+financialactivity.emsFees,"Failed");	
			}
			else
			{
				lib.WriteReportStep("2","View the charges","The various additional charges applied should be displayed",Result,"Passed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","View the charges","The various additional charges applied should be displayed",e.getMessage(),"Failed");
			e.printStackTrace();
		}
	}

	@And("^the user can verify if they are able to add new columns \"([^\"]*)\" in the transaction view$")
	public void addNewTransactionColumns(String columnName)
	{
		lib.WriteReportStep("1", "Add new columns", "", "", "");
		try
		{
			String Result=financialactivity.validateTransactionColumns(columnName);
			System.out.println(Result);
			if(Result.equalsIgnoreCase("Passed"))
			{
				lib.WriteReportStep("2", "Add new columns", "The column "+columnName+" must be added", "The column "+columnName+" is added successfully and is available in the transactions view", "Passed");
			}
			else if(Result.equalsIgnoreCase("Column already available in default view"))
			{
				lib.WriteReportStep("2", "Add new columns", "The column "+columnName+" must be added", "The column "+columnName+" is already available in the default view", "Passed");
			}
			else if(Result.equalsIgnoreCase("No Records Present"))
			{
				lib.WriteReportStep("2", "Add new columns", "The column "+columnName+" must be added", Result, "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Add new columns", "The column "+columnName+" must be added", "Failed to add the column "+columnName+" in the transactions view", "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Add new columns", "The column "+columnName+" must be added", e.getMessage(), "Failed");
			e.printStackTrace();
		}

	}

	@And("^the user can verify if they are able to add new columns \"([^\"]*)\" in the authorization view$")
	public void addNewAuthorizationColumns(String columnName)
	{
		lib.WriteReportStep("1", "Add new columns", "", "", "");
		try
		{
			String Result=financialactivity.validateAuthorizationColumns(columnName);
			System.out.println(Result);
			if(Result.equalsIgnoreCase("Passed"))
			{
				lib.WriteReportStep("2", "Add new columns", "The column "+columnName+" must be added", "The column "+columnName+" is added successfully and is available in the authorizations view", "Passed");
			}
			else if(Result.equalsIgnoreCase("Column already available in default view"))
			{
				lib.WriteReportStep("2", "Add new columns", "The column "+columnName+" must be added", "The column "+columnName+" is already available in the default view", "Passed");
			}
			else if(Result.equalsIgnoreCase("Column cannot be added"))
			{
				lib.WriteReportStep("2", "Add new columns", "The column "+columnName+" must be added", "The column "+columnName+" cannot be added", "Failed");
			}
			else if(Result.equalsIgnoreCase("No Records Present"))
			{
				lib.WriteReportStep("2", "Add new columns", "The column "+columnName+" must be added", Result, "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Add new columns", "The column "+columnName+" must be added", "Failed to add the column "+columnName+" in the authorizations view", "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Add new columns", "The column "+columnName+" must be added", e.getMessage(), "Failed");
			e.printStackTrace();
		}

	}

	@Then("^user can launch the link and access the account activation page$")
	public void launchInitiationLink()
	{
		lib.WriteReportStep("1", "Access the account activation page", "", "", "");
		try
		{
			String Result=userManagementPage.launchInitiationLink();
			System.out.println(Result);
			if(Result.equalsIgnoreCase("Passed"))
			{
				lib.WriteReportStep("2", "Access the account activation page", "The account activation page must be displayed", "The account activation page displayed successfully", "Passed");
			}
			else
			{
				lib.WriteReportStep("2", "Access the account activation page", "The account activation page must be displayed", "Failed to display the account activation page", "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Access the account activation page", "The account activation page must be displayed", e.getMessage(), "Failed");
			e.printStackTrace();
		}

	}

	@Then("^the user \"([^\"]*)\" with the query \"([^\"]*)\" can enter the passcode sent to \"([^\"]*)\" mobile number$")
	public void launchInitiationLink(String userName,String sqlQuery,String mobileNumber)
	{
		lib.WriteReportStep("1", "Enter the passcode", "", "", "");
		try
		{
			String Result=userManagementPage.enterPasscode(userName,sqlQuery,mobileNumber);
			System.out.println(Result);
			if(Result.equalsIgnoreCase("Passed"))
			{
				lib.WriteReportStep("2", "Enter the passcode", "The passcode must be entered", "Passcode entered successfully", "Passed");
			}
			else if(Result.equalsIgnoreCase("Phone numbers do not match"))
			{
				lib.WriteReportStep("2", "Enter the passcode", "The passcode must be entered", "The phone numbers do not match", "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Enter the passcode", "The passcode must be entered", Result, "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Enter the passcode", "The passcode must be entered", e.getMessage(), "Failed");
			e.printStackTrace();
		}

	}

	@Then("^the user can set the password as \"([^\"]*)\" and \"([^\"]*)\" as the initial language of the portal$")
	public void setPasswordAndPortalLanguage(String password, String portalLanguage)
	{
		lib.WriteReportStep("1", "Set the password and the portal language", "", "", "");
		try
		{
			String Result=userManagementPage.setPasswordAndPortalLanguage(password,portalLanguage);
			System.out.println(Result);
			if(Result.equalsIgnoreCase("Passed"))
			{
				lib.WriteReportStep("2", "Set the password and the portal language", "Set the password and the portal language", "password and the portal language set successfully", "Passed");
			}
			else if(Result.equalsIgnoreCase("Language not changed"))
			{
				lib.WriteReportStep("2", "Set the password and the portal language", "Set the password and the portal language", "Failed to change the language", "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Set the password and the portal language", "Set the password and the portal language", Result, "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Set the password and the portal language", "Set the password and the portal language", e.getMessage(), "Failed");
			e.printStackTrace();
		}
	}

	@Then("^the user can validate if the account is activated successfully$")
	public void validateAccountStatus()
	{
		lib.WriteReportStep("1", "Check if the account is activated", "", "", "");
		try
		{
			String Result=userManagementPage.validateAccountStatus();
			System.out.println(Result);
			if(Result.equalsIgnoreCase("Passed"))
			{
				lib.WriteReportStep("2", "Check if the account is activated", "The account must be activated", "Account activated successfully", "Passed");
			}
			else
			{
				lib.WriteReportStep("2", "Check if the account is activated", "The account must be activated", "Failed to activate the account", "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Check if the account is activated", "The account must be activated", e.getMessage(), "Failed");
			e.printStackTrace();
		}
	}

	@And("^the user \"([^\"]*)\" can search for an authorization using the order ID \"([^\"]*)\" and void the authorization after providing \"([^\"]*)\"$")
	public void voidAuthorization(String userName,String orderID,String sqlQuery)
	{
		lib.WriteReportStep("1", "Void Authorization", "", "", "");
		try
		{
			String Result=financialactivity.voidAuthorization(userName,orderID,sqlQuery);
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2","Void Authorization","Void Authorization","Voided the authorization successfully","Passed");
			}
			else if(Result.equals("Please check the authorization status"))
			{
				lib.WriteReportStep("2","Void Authorization","Void Authorization",Result,"Failed");
			}
			else if(Result.equals("Please enter a valid Order ID"))
			{
				lib.WriteReportStep("2","Void Authorization","Void Authorization",Result,"Failed");	
			}
			else
			{
				lib.WriteReportStep("2","Void Authorization","Void Authorization","Failed to void the authorization","Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","Void Authorization","Void Authorization",e.getMessage(),"Failed");
			e.printStackTrace();
		}

	}

	@Then("^user \"([^\"]*)\" can access the password reset link \"([^\"]*)\",\"([^\"]*)\" and request resending of the passcode for password reset action$")
	public void enterResentPasscode(String userName,String passwordResetLink, String sqlQuery)
	{
		lib.WriteReportStep("1", "Request resending of passcode for password reset", "", "", "");
		try
		{
			String Result=userManagementPage.resendPasscodeForPasswordReset(userName,passwordResetLink,sqlQuery);
			System.out.println(Result);
			if(Result.equalsIgnoreCase("Passed"))
			{
				lib.WriteReportStep("2", "Request resending of passcode for password reset", "The user must be able to request resending of passcode for password reset", "The user is able to successfully request resending of passcode for password reset", "Passed");
			}
			else if(Result.equalsIgnoreCase("Failed"))
			{
				lib.WriteReportStep("2", "Request resending of passcode for password reset", "The user must be able to request resending of passcode for password reset", "The user is unable to request resending of passcode for password reset", "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Request resending of passcode for password reset", "The user must be able to request resending of passcode for password reset", Result, "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Request resending of passcode for password reset", "The user must be able to request resending of passcode for password reset", e.getMessage(), "Failed");
			e.printStackTrace();
		}

	}

	@And("^the user \"([^\"]*)\" can void an authorization by searching for it using the order ID \"([^\"]*)\" and then check if the authorization has been voided after providing \"([^\"]*)\"$")
	public void voidAuthorizationAndCheckStatus(String userName,String orderID,String sqlQuery)
	{
		lib.WriteReportStep("1", "View Void transactions and Status", "", "", "");
		try
		{
			String Result=financialactivity.voidAuthorization(userName,orderID,sqlQuery);
			if(Result.equals("Passed"))
			{
				lib.WriteReportStep("2","View Void transactions and Status","View Void transactions and Status","The authorization has been voided","Passed");
			}
			else if(Result.equals("Please check the authorization status"))
			{
				lib.WriteReportStep("2","View Void transactions and Status","View Void transactions and Status","The authorization has been voided","Passed");
			}
			else if(Result.equals("Please enter a valid Order ID"))
			{
				lib.WriteReportStep("2","View Void transactions and Status","View Void transactions and Status",Result,"Failed");	
			}
			else
			{
				lib.WriteReportStep("2","View Void transactions and Status","View Void transactions and Status","The authorization has not been voided","Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2","View Void transactions and Status","View Void transactions and Status",e.getMessage(),"Failed");
			e.printStackTrace();
		}
	}

	@And("^the user \"([^\"]*)\" can search for an authorization by searching for it using the order ID \"([^\"]*)\" and request resending of passcode for voiding the authorization after providing \"([^\"]*)\"$")
	public void resendPasscode(String userName,String orderID, String sqlQuery)
	{
		lib.WriteReportStep("1", "Request resending of passcode for voiding the authorization", "", "", "");
		try
		{
			String Result=financialactivity.sendPasscode(userName,orderID,sqlQuery);
			System.out.println(Result);
			if(Result.equalsIgnoreCase("Passed"))
			{
				lib.WriteReportStep("2", "Request resending of passcode for voiding the authorization", "The user must be able to request resending of passcode for voiding the authorization", "The user is able to successfully request resending of passcode for voiding the authorization", "Passed");
			}
			else if(Result.equalsIgnoreCase("Please check the authorization status"))
			{
				lib.WriteReportStep("2", "Request resending of passcode for voiding the authorization", "The user must be able to request resending of passcode for voiding the authorization",Result, "Failed");
			}
			else if(Result.equalsIgnoreCase("Please enter a valid Order ID"))
			{
				lib.WriteReportStep("2", "Request resending of passcode for voiding the authorization", "The user must be able to request resending of passcode for voiding the authorization",Result, "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Request resending of passcode for voiding the authorization", "The user must be able to request resending of passcode for voiding the authorization","The user is unable to request resending of passcode for voiding the authorization","Failed");
			}
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Request resending of passcode for voiding the authorization", "The user must be able to request resending of passcode for voiding the authorization",e.getMessage(),"Failed");
			e.printStackTrace();
		}

	}

	@And("^the user \"([^\"]*)\" can search for an authorization by searching for it using the order ID \"([^\"]*)\" and then enter the passcode for user validation after providing \"([^\"]*)\"$")
	public void validateUserThroughPasscode(String userName,String orderID, String sqlQuery)
	{
		lib.WriteReportStep("1", "Validate user using passcode", "", "", "");
		try
		{
			String Result=financialactivity.validateMobileNumber(userName,orderID,sqlQuery);
			System.out.println(Result);
			if(Result.equalsIgnoreCase("Passed"))
			{
				lib.WriteReportStep("2", "Validate user using passcode", "Validate user using passcode", "Passcode is sent to the correct mobile number", "Passed");
			}
			else if(Result.equalsIgnoreCase("Please check the authorization status"))
			{
				lib.WriteReportStep("2", "Validate user using passcode", "Validate user using passcode",Result, "Failed");
			}
			else if(Result.equalsIgnoreCase("Please enter a valid Order ID"))
			{
				lib.WriteReportStep("2", "Validate user using passcode", "Validate user using passcode",Result, "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Validate user using passcode", "Validate user using passcode","Failed to send the passcode to the correct mobile number","Failed");
			}
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Validate user using passcode", "Validate user using passcode",e.getMessage(),"Failed");
			e.printStackTrace();
		}

	}

	@Then("^the user can give the username as \"([^\"]*)\" and \"([^\"]*)\" as password and verify if the account is locked$")
	public void lockAccount(String userName,String password)
	{
		lib.WriteReportStep("1", "Verify if account is locked", "", "", "");
		try
		{
			String Result=signonpage.lockAccount(userName,password);
			System.out.println(Result);
			if(Result.equalsIgnoreCase("Failed"))
			{
				lib.WriteReportStep("2", "Verify if account is locked", "The account must be locked", "Failed to lock the acocunt","Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Verify if account is locked", "The account must be locked",Result, "Passed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Verify if account is locked", "The account must be locked",e.getMessage(),"Failed");
			e.printStackTrace();
		}
	}

	@Then("^the user \"([^\"]*)\" having the password \"([^\"]*)\" and the query \"([^\"]*)\" can verify if the login attempt count has not been incremented$")
	public void validateLoginAttemptCount(String userName,String password, String sqlQuery)
	{
		lib.WriteReportStep("1", "Validate the login attempt count", "", "", "");
		try
		{
			String Result=signonpage.validateLoginAttemptCount(userName,password,sqlQuery);
			System.out.println(Result);
			if(Result.equalsIgnoreCase("Failed"))
			{
				lib.WriteReportStep("2", "Validate the login attempt count", "The login attempt count must not be incremented", "The login attempt count has not been incremented","Passed");
			}
			else
			{
				lib.WriteReportStep("2", "Validate the login attempt count", "The login attempt count must not be incremented","The login attempt count has been incremented", "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Validate the login attempt count", "The login attempt count must not be incremented",e.getMessage(),"Failed");
			e.printStackTrace();
		}
	}

	@Then("^the user \"([^\"]*)\" having the password \"([^\"]*)\" and the query \"([^\"]*)\" can verify if the login attempt count has been cleared after logging into the portal$")
	public void checkIfLoginAttemptCountIsCleared(String userName,String password, String sqlQuery)
	{
		lib.WriteReportStep("1", "Check if the login attempt count has been cleared", "", "", "");
		try
		{
			String Result=signonpage.checkIfLoginAttemptCountIsCleared(userName,password,sqlQuery);
			System.out.println(Result);
			if(Result.equalsIgnoreCase("Failed"))
			{
				lib.WriteReportStep("2", "Check if the login attempt count has been cleared", "The login attempt count must be cleared", "The login attempt count has been cleared successfully","Passed");
			}
			else
			{
				lib.WriteReportStep("2", "Check if the login attempt count has been cleared", "The login attempt count must be cleared","Failed to clear the login attempt count", "Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Check if the login attempt count has been cleared", "The login attempt count must be cleared",e.getMessage(),"Failed");
			e.printStackTrace();
		}
	}

	@Then("^the user \"([^\"]*)\" can verify if password reset option is not available$")
	public void verifyPasswordResetOptionNotAvailable(String userName)
	{
		lib.WriteReportStep("1", "Verify if the password reset option is not available", "", "", "");
		try
		{
			String Result=signonpage.sendPasswordResetLink(userName);
			if(Result.equals("Failed"))
			{
				lib.WriteReportStep("2", "Verify if the password reset option is not available", "The password reset option must not be available", "The password reset option is not available","Passed");
			}
			else
			{
				lib.WriteReportStep("2", "Verify if the password reset option is not available", "The password reset option must not be available", "The password reset option is available","Failed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Verify if the password reset option is not available", "The password reset option must not be available", e.getMessage(),"Failed");
			e.printStackTrace();
		}
	}

	@Then("^the user \"([^\"]*)\" can reset the password \"([^\"]*)\",\"([^\"]*)\" by accessing the link \"([^\"]*)\",\"([^\"]*)\" and then check if the reset link has expired$")
	public void resendPasscode(String userName,String newPassword,String confirmPassword, String passwordResetLink, String sqlQuery)
	{
		lib.WriteReportStep("1", "check reset link status after changing password", "", "", "");
		try
		{
			String Result=userManagementPage.validatePasswordResetLinkStatus(userName, newPassword, confirmPassword, passwordResetLink, sqlQuery);
			System.out.println(Result);
			if(Result.equalsIgnoreCase("Passed"))
			{
				lib.WriteReportStep("2", "check reset link status after changing password", "The reset link status must expire after changing password", "The reset link status expires after changing password", "Passed");
			}
			else if(Result.equalsIgnoreCase("Failed"))
			{
				lib.WriteReportStep("2", "check reset link status after changing password", "The reset link status must expire after changing password", "The reset link status still active after changing password", "Failed");
			}
			else if(Result.equalsIgnoreCase("Password not changed"))
			{
				lib.WriteReportStep("2", "check reset link status after changing password", "The reset link status must expire after changing password",Result, "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "check reset link status after changing password", "The reset link status must expire after changing password",Result, "Failed");
			}
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "check reset link status after changing password", "The reset link status must expire after changing password",e.getMessage(), "Failed");
			e.printStackTrace();
		}

	}

	@Then("^the user \"([^\"]*)\" initiates password change by giving \"([^\"]*)\"$")
	public void initiatePasswordChange(String userName, String sqlQuery)
	{
		try
		{
			jdbcConnection.resetPasswordExpirationDate(userName,sqlQuery);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	@Then("^the user \"([^\"]*)\" initiates account lock by providing \"([^\"]*)\"$")
	public void initiateAccountLock(String userName, String sqlQuery)
	{
		try
		{
			jdbcConnection.lockAccount(userName,sqlQuery);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	@Then("^the user \"([^\"]*)\" changes the password by giving \"([^\"]*)\" as the new password$")
	public void changePassword(String userName,String newPassword)
	{
		lib.WriteReportStep("1", "change the password", "", "", "");
		try
		{
			String Result=userManagementPage.changePassword(userName, newPassword);
			System.out.println(Result);
			if(Result.equalsIgnoreCase("Passed"))
			{
				lib.WriteReportStep("2", "change the password", "The password must be changed", "Successfully changed the password", "Passed");
			}
			else
			{
				lib.WriteReportStep("2", "change the password", "The password must be changed", "Failed to change the password", "Failed");
			}
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "change the password", "The password must be changed",e.getMessage(), "Failed");
			e.printStackTrace();
		}
	}

	@Then("^the user can attempt login for 3 more times by providing \"([^\"]*)\" and \"([^\"]*)\" and check if the account is locked permanently$")
	public void lockAccountPermanently(String userName,String password)
	{
		lib.WriteReportStep("1", "Verify if account is locked permanently", "", "", "");
		try
		{
			String Result=signonpage.lockAccountPermanently(userName,password);
			System.out.println(Result);
			if(Result.equalsIgnoreCase("Failed"))
			{
				lib.WriteReportStep("2", "Verify if account is locked permanently", "The account must be locked permanently", "Failed to lock the acocunt permanently","Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Verify if account is locked permanently", "The account must be locked permanently",Result, "Passed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Verify if account is locked permanently", "The account must be locked permanently",e.getMessage(),"Failed");
			e.printStackTrace();
		}
	}

	@Then("^the user can attempt login for 2 more times by providing \"([^\"]*)\" and \"([^\"]*)\" and check if a warning message is displayed$")
	public void warnUserAboutLoginAttempt(String userName,String password)
	{
		lib.WriteReportStep("1", "Check if a warning message is displayed", "", "", "");
		try
		{
			String Result=signonpage.warnUserAboutLoginAttempt(userName,password);
			System.out.println(Result);
			if(Result.equalsIgnoreCase("Failed"))
			{
				lib.WriteReportStep("2", "Check if a warning message is displayed", "A warning message must be displayed", "Failed to display a warning message","Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Check if a warning message is displayed", "A warning message must be displayed",Result, "Passed");
			}

		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Check if a warning message is displayed", "A warning message must be displayed",e.getMessage(),"Failed");
			e.printStackTrace();
		}
	}

	@Then("^the user \"([^\"]*)\" can access the link \"([^\"]*)\",\"([^\"]*)\" and then reset the password by giving \"([^\"]*)\",\"([^\"]*)\" as the new password$")
	public void resetPasswordFromPasswordResetLink(String userName,String passwordResetLink,String sqlQuery,String newPassword,String confirmPassword)
	{
		lib.WriteReportStep("1", "Reset the password", "", "", "");
		try
		{
			String Result=userManagementPage.resetPasswordFromPasswordResetLink(userName, passwordResetLink, sqlQuery, newPassword, confirmPassword);
			System.out.println(Result);
			if(Result.equalsIgnoreCase("Passed"))
			{
				lib.WriteReportStep("2", "Reset the password", "The password must be reset",accountActivationPageObjects.passwordReset_resetPasswordSuccessMessage.getText(), "Passed");
			}
			else
			{
				lib.WriteReportStep("2", "Reset the password", "The password must be reset",Result, "Failed");
			}
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Reset the password", "The password must be reset",e.getMessage(), "Failed");
			e.printStackTrace();
		}

	}
	
	@Then("^the user can search for a user by giving details like \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and verify their account status")
	public void getAccountStatus(String firstname,String lastname,String targetusername,String emailaddress)
	{
		lib.WriteReportStep("1", "Verify the account status", "", "", "");
		try
		{
			String Result=userManagementPage.getAccountStatus(targetusername, firstname, lastname, emailaddress);
			System.out.println(Result);
			if(Result.equalsIgnoreCase("Failed"))
			{
				lib.WriteReportStep("2", "Verify the account status", "The account status must be displayed","Could not display the account status", "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Verify the account status", "The account status must be displayed","The account status is:"+Result, "Passed");
			}
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Verify the account status", "The account status must be displayed",e.getMessage(), "Failed");
			e.printStackTrace();
		}
	}
	
	@And("^the user can give the \"([^\"]*)\" and differentiate between credit and debit data in Pre-Authorizations view$")
	public void displayPreAuthCreditAndDebitData(String orderID)
	{
		lib.WriteReportStep("1", "Display the PreAuth credit and debit transaction data", "", "", "");
		try
		{
			String Result=financialactivity.validatePreauthCreditAndDebitTransactionData(orderID);
			System.out.println(Result);
			if(Result.equalsIgnoreCase("No Records Present"))
			{
				lib.WriteReportStep("2", "Display the PreAuth credit and debit transaction data", "The PreAuth credit and debit transaction data must be displayed",Result, "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Display the PreAuth credit and debit transaction data", "The PreAuth credit and debit transaction data must be displayed","Credit Data:"+financialactivity.preauthCreditData+".Debit Data:"+financialactivity.preauthDebitData,"Passed");
				
			}
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Display the PreAuth credit and debit transaction data", "The PreAuth credit and debit transaction data must be displayed",e.getMessage(), "Failed");
			e.printStackTrace();
		}
	}
	
	@And("^the user can give the \"([^\"]*)\" and differentiate between credit and debit data in Authorizations view$")
	public void displayAuthCreditAndDebitData(String orderID)
	{
		lib.WriteReportStep("1", "Display the Authorization credit and debit transaction data", "", "", "");
		try
		{
			String Result=financialactivity.validateAuthorizationCreditAndDebitTransactionData(orderID);
			System.out.println(Result);
			if(Result.equalsIgnoreCase("No Records Present"))
			{
				lib.WriteReportStep("2", "Display the Authorization credit and debit transaction data", "The Authorization credit and debit transaction data must be displayed",Result, "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Display the Authorization credit and debit transaction data", "The Authorization credit and debit transaction data must be displayed","Credit Data:"+financialactivity.authCreditData+".Debit Data:"+financialactivity.authDebitData,"Passed");
				
			}
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Display the Authorization credit and debit transaction data", "The Authorization credit and debit transaction data must be displayed",e.getMessage(), "Failed");
			e.printStackTrace();
		}
	}
	
	@And("^the user can give the \"([^\"]*)\" and differentiate between credit and debit data in Transactions view$")
	public void displayTransactionsCreditAndDebitData(String transactionID)
	{
		lib.WriteReportStep("1", "Display the Transaction credit and debit transaction data", "", "", "");
		try
		{
			String Result=financialactivity.validateTransactionCreditAndDebitTransactionData(transactionID);
			System.out.println(Result);
			if(Result.equalsIgnoreCase("No Records Present"))
			{
				lib.WriteReportStep("2", "Display the Transaction credit and debit transaction data", "The Transaction credit and debit transaction data must be displayed",Result, "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Display the Transaction credit and debit transaction data", "The Transaction credit and debit transaction data must be displayed","Credit Data:"+financialactivity.transactionCreditData+".Debit Data:"+financialactivity.transactionDebitData,"Passed");
				
			}
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Display the Transaction credit and debit transaction data", "The Transaction credit and debit transaction data must be displayed",e.getMessage(), "Failed");
			e.printStackTrace();
		}
	}
	
	@And("^the user can give the \"([^\"]*)\" and differentiate between credit and debit data in Funding view$")
	public void displayFundingCreditAndDebitData(String fundingReferenceNumber)
	{
		lib.WriteReportStep("1", "Display the Funding credit and debit transaction data", "", "", "");
		try
		{
			String Result=financialactivity.validateFundingCreditAndDebitTransactionData(fundingReferenceNumber);
			System.out.println(Result);
			if(Result.equalsIgnoreCase("No Records Present"))
			{
				lib.WriteReportStep("2", "Display the Funding credit and debit transaction data", "The Funding credit and debit transaction data must be displayed",Result, "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Display the Funding credit and debit transaction data", "The Funding credit and debit transaction data must be displayed","Credit Data:"+financialactivity.fundingCreditData+".Debit Data:"+financialactivity.fundingDebitData,"Passed");
				
			}
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Display the Funding credit and debit transaction data", "The Funding credit and debit transaction data must be displayed",e.getMessage(), "Failed");
			e.printStackTrace();
		}
	}
	
	
	
	@Then("^the user can search for a user by giving details like \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and change the account status$")
	public void changeAccountStatus(String url,String username,String password, String firstname, String lastname, String email, String accountstatus,String targetaccountstatus,String sqlQuery)
	{
		lib.WriteReportStep("1", "Change the account status", "", "", "");
		try
		{
			String Result=userManagementPage.changeAccountStatus(url, username, password, firstname, lastname, email, accountstatus, targetaccountstatus, sqlQuery);
			System.out.println(Result);
			if(Result.equalsIgnoreCase("Passed"))
			{
				lib.WriteReportStep("2", "Change the account status", "The account status must be changed to: "+targetaccountstatus,"Successfully changed the account status to: "+targetaccountstatus, "Passed");
			}
			else if(Result.equalsIgnoreCase("No Records Found"))
			{
				lib.WriteReportStep("2", "Change the account status", "The account status must be changed to: "+targetaccountstatus,Result, "Failed");
			}
			else
			{
				lib.WriteReportStep("2", "Change the account status", "The account status must be changed to: "+targetaccountstatus,"Failed to change the account status to: "+targetaccountstatus, "Failed");
			}
		}
		catch(Exception e)
		{
			lib.WriteReportStep("2", "Change the account status", "The account status must be changed to: "+targetaccountstatus,e.getLocalizedMessage(), "Failed");
			e.printStackTrace();
		}
	}
	
	
	
/*-------Sailasuta---------*/	
	
	
	/*	------------------------------------------------------------------------------------------------
	UI Description: Load the respective Browser for the test case 
------------------------------------------------------------------------------------------------*/	
@Given("^the EMS portal and configure \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
public void the_EMS_portal(String report,String dimension,String executionMode) throws Throwable {
	userManagementPage.loadbrowser();
	driver=this.getDriver();
	if(!executionMode.contains("SaucelabsWeb_")&& !executionMode.contains("SaucelabsMobile_"))
	switch(dimension)
	{
	case "mobile": driver.manage().window().setSize(mobile); break;
	case "desktop": driver.manage().window().setSize(desktop); break;
	case "tablet": driver.manage().window().setSize(tablet); break;
	}
	lib.initializeTest("RequestForApplicationUIInfo"+" "+report);
	lib.WriteReportStep("1", "Loading the browser", "", "", "");
}
/*	------------------------------------------------------------------------------------------------
	UI Description: Navigate to the particular URL required for the particular test case
------------------------------------------------------------------------------------------------*/		

@And("^user Navigate to URL \"([^\"]*)\"$")
public void user_Navigate_to_URL(String appurl) throws Throwable {
	lib.WriteReportStep("1", "Get url", "", "", "");
	String Result = userManagementPage.navigate(appurl);
	if(Result.contains("Passed"))
	 {
		lib.WriteReportStep("2", "Verify the URL", "Verify the URL",  "WebPage successfully loaded "+Result, "Passed");
	 }
	 else
	 {
		 lib.WriteReportStep("2", "Verify the URL", "Verify the URL", "Failed to load the webPage "+Result, "Failed");
	 }
}
/*	------------------------------------------------------------------------------------------------
	UI Description: User Management - Login to Merchant Portal
	UI Feature name: MEPOE-5325_User_Management
------------------------------------------------------------------------------------------------*/

@When("^user enter \"([^\"]*)\" as \"([^\"]*)\"$")
public void user_enter_as(String FieldName, String FieldValue) throws Throwable {
	lib.WriteReportStep("1", "Get username", "", "", "");
	String Result = userManagementPage.userInput(FieldName,FieldValue);
	if(Result.contains("Passed"))
	 {
		lib.WriteReportStep("2", "Verify the userid", "Get"+" "+FieldName, FieldName+":"+"UserId Entered correctly", "Passed");
	 }
	 else
	 {
		 lib.WriteReportStep("2", "Verify the userid", "Get"+" "+FieldName, FieldName+":"+"Failed to enter the userID", "Failed");
	 }
	
}
@And("^user entertext \"([^\"]*)\" as \"([^\"]*)\"$")
public void user_entertext_as(String FieldName, String FieldValue) throws Throwable {
	lib.WriteReportStep("1", "Get Password", "", "", "");
    String Result= userManagementPage.userInput(FieldName,FieldValue);
	if(Result.contains("Passed"))
	 {
		lib.WriteReportStep("2", "Verify the Password", "Get"+" "+FieldName, FieldName+":"+"Password entered correctly", "Passed");
	 }
	 else
	 {
		 lib.WriteReportStep("2", "Verify the Password", "Get"+" "+FieldName, FieldName+":"+"Failed to enter the password", "Failed");
	 }
}
@Then("^user click Submit login and verify \"([^\"]*)\", \"([^\"]*)\"$")
public void user_click_Submit_login_and_verify(String Welcome_text,String Device) throws Throwable {
	 lib.WriteReportStep("1", "Login to the application", "", "", "");
	 String Result= userManagementPage.Submitlogin(Welcome_text,Device);
	 Result1=Result;
	 System.out.println(Result);
	 if(Result.contains("Passed"))
	 {
		 lib.WriteReportStep("2", "Verify Submit","Login to the application", "Successfully login to application "+Result,"Passed");
	 }
	 else
	 {
		 lib.WriteReportStep("2", "Verify Submit","Login to the application", "Failed to login to application"+Result,"Failed");
	 }
	 
}

/*	------------------------------------------------------------------------------------------------
	UI Description: User Management - Remember my Merchant Portal login
	UI Feature name: MEPOE-5326_User_Management
------------------------------------------------------------------------------------------------*/
@And("^user click on RememberMe$")
public void user_click_on_RememberMe() throws Throwable {
	userManagementPage.RememberMe();
}

/*	------------------------------------------------------------------------------------------------
	UI Description: Dashboard navigation - Inform visitors about the Merchant Portal cookie use
	UI Feature name: MEPOE-5372_Dashboard_navigation
------------------------------------------------------------------------------------------------*/		

@Then("^user Verify Dashboard cookie information link \"([^\"]*)\"$")
public void user_Verify_Dashboard_cookie_information_link(String Device) throws Throwable {
	 
	if(Result1.contains("Passed"))
	{ 
		 lib.WriteReportStep("1", "Verify Cookie information", "", "", "");
		 String Result=dashboardpage.Dashboard_cookie_information_link(Device);
		 if(Result.contains("Passed"))
		 {
			 lib.WriteReportStep("2", "Verify cookie information Link","Verify cookie information", "Cookie information link is present"+Result,"Passed");
		 }
		 else
		 {
			 lib.WriteReportStep("2", "Verify cookie information Link","Verify cookie information", "Cookie information link is not there"+Result,"Failed");
		 }
	}
	 
}
/*	------------------------------------------------------------------------------------------------
	UI Description: Dashboard navigation  - Show message indicator
	UI Feature name: MEPOE-5373_Dashboard_navigation 
------------------------------------------------------------------------------------------------*/	

@Then("^user Verify Unread message count \"([^\"]*)\"$")
public void user_Verify_Unread_message_count(String Device) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	 lib.WriteReportStep("1", "Verify Unread message count", "", "", "");
	 String Result=dashboardpage.Unread_message_count(Device);
	 if(Result.contains("Passed"))
	 {
		 lib.WriteReportStep("2", "Verify Unread message count","Verify Unread message count", "Unread message count is : "+ Result,"Passed");
	 }
	 else
	 {
		 lib.WriteReportStep("2", "Verify Unread message count","Verify Unread message count", "No unread message are there : "+ Result,"Failed");
	 }
	}
}
/*	------------------------------------------------------------------------------------------------
	UI Description: Dashboard navigation  - Show document indicators
	UI Feature name: MEPOE-5374_Dashboard_navigation 
------------------------------------------------------------------------------------------------*/	

@Then("^user Verify Unread document count \"([^\"]*)\"$")
public void user_Verify_Unread_document_count(String Device) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify unread document count", "", "", "");
	String Result=dashboardpage.Unread_Document_count(Device);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify Unread Document count","Verify Unread Document count", "Unread Document count is : "+ Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify Unread Document count","Verify Unread Document count", "No unread Document are there : "+ Result,"Failed");
	}
	}
}

/*	------------------------------------------------------------------------------------------------
	UI Description: Dashboard navigation  - Portal navigation
	UI Feature name: MEPOE-5377_Dashboard_navigation
------------------------------------------------------------------------------------------------*/	

@Then("^user Verify all the dashboard Panel element and check \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_Verify_all_the_dashboard_Panel_element_and_check(String Preauthorizations_Text, String Authorizations_Text, String Transactions_Text, String Funding_Text, String Messages_Text, String Documents_Text, String Device) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify all the dashboard element", "", "", "");
	String Result=dashboardpage.Verify_dashboard_panel_Navigation(Preauthorizations_Text,Authorizations_Text,Transactions_Text,Funding_Text,Messages_Text,Documents_Text,Device);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify Dashboard navigation","Verify Dashboard Navigation to all the widget", "Successfully navigated to each widget","Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify Dashboard navigation","Verify Dashboard Navigation to all the widget", "Failed to navigate to each widget","Failed");
	}
	}
}

/*	------------------------------------------------------------------------------------------------
	UI Description: Dashboard navigation  - Move from Pre-authorisation Widget to detailed pre-authorisations view
	UI Feature name: MEPOE-6292_Dashboard_navigation
------------------------------------------------------------------------------------------------*/

@Then("^user should navigate from Pre_authorisation Widget to detailed pre_authorisations view and check \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_navigate_from_Pre_authorisation_Widget_to_detailed_pre_authorisations_view_and_check(String PreAuth_Text,String Device) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
		System.out.println(PreAuth_Text);
	lib.WriteReportStep("1", "Verify Navigation from preAuth_widget", "", "", "");
	String Result=dashboardpage.Navigate_Preauth_Widget_to_detailed_preauth_view(PreAuth_Text,Device);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify Navigation from preAuth_widget","Verify Navigation from preAuth_widget", "Successfully navigated to Preauth_View","Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify Navigation from preAuth_widget","Verify Navigation from preAuth_widget", "Failed to navigate to PreAuth_view","Failed");
	}
	}
}

/*	------------------------------------------------------------------------------------------------
	UI Description: Dashboard navigation  - Navigate from Funding Widget to funding_summary view
	UI Feature name: MEPOE-5491_Dashboard_navigation
------------------------------------------------------------------------------------------------*/

@Then("^user should navigate from Funding Widget to funding_summary view and check \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_navigate_from_Funding_Widget_to_funding_summary_view_and_check(String funding_text,String Device) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify Navigation from funding_widget", "", "", "");
	String Result=dashboardpage.Navigate_Funding_Widget_to_detailed_funding_view(funding_text,Device);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify Navigation from Funding Widget","Verify Navigation from Funding Widget", "Successfully navigated to Funding_View","Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify Navigation from preAuth_widget","Verify Navigation from preAuth_widget", "Failed to navigate to PreAuth_view","Failed");
	}
	}
}

/*	------------------------------------------------------------------------------------------------
	UI Description: Dashboard navigation  - Navigate from sales widget to detailed transaction view
	UI Feature name: MEPOE-5486_Dashboard_navigation
------------------------------------------------------------------------------------------------*/

@Then("^user should navigate from Sales Widget to Transaction summary view and check the detailed Transaction view \"([^\"]*)\"$")
public void user_should_navigate_from_Sales_Widget_to_Transaction_summary_view_and_check_the_detailed_Transaction_view(String Device) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify Navigation from sales_widget", "", "", "");
	String Result=dashboardpage.Navigate_sales_to_transaction(Device);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify Navigation from sales Widget","Verify Navigation from sales Widget", "Successfully navigated to Transaction_View","Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify Navigation from sales_widget","Verify Navigation from sales_widget", "Failed to navigate to Transaction_view","Failed");
	}
	}
}

/*	------------------------------------------------------------------------------------------------------------
	UI Description: Dashboard navigation  - Change the currency code and validate in the dashboard page
	UI Feature name: MEPOE-5483_Dashboard_navigation
------------------------------------------------------------------------------------------------------------*/

@Then("^user should change the currency code to \"([^\"]*)\" and validate the dashboard$")
public void user_should_change_the_currency_code_to_and_validate_the_dashboard(String arg1) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify currency_code change", "", "", "");
	String Result=dashboardpage.Change_currency_code(arg1);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify currency_code change","Verify currency_code change", "Successfully Changed to currency_code "+ Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify currency_code change","Verify currency_code change", "Failed to change the currency code","Failed");
	}
	}
}

/*------------------------------------------------------------------------------------------------------------
UI Description: Dashboard navigation  - Change the Language code and validate in the dashboard page
UI Feature name: MEPOE-5358_User_Management
------------------------------------------------------------------------------------------------------------*/
@Then("^user should change the Language code to \"([^\"]*)\" and validate the dashboard by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_change_the_Language_code_to_and_validate_the_dashboard(String Language_Change, String Pre_authorizations_Text, String Authorizations_Text, String Transactions_Text, String Funding_Text, String Device) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify Language_code change", "", "", "");
	String Result=dashboardpage.Change_Language_code(Language_Change,Pre_authorizations_Text,Authorizations_Text,Transactions_Text,Funding_Text,Device);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify Language_code change","Verify Language_code change", "Successfully Changed to Language_code "+ Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify Language_code change","Verify Language_code change", "Failed to Change the language","Failed");
	}
	}
}
/*------------------------------------------------------------------------------------------------------------
UI Description: Dashboard navigation  - Print option should be available in the message Page
UI Feature name: @MEPOE-5566_Messaging
------------------------------------------------------------------------------------------------------------*/
@Then("^User should be able to verify print option is working in messages as \"([^\"]*)\"$")
public void user_should_be_able_to_verify_print_option_is_working_in_messages_as(String arg1) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify Print_option in Message change", "", "", "");
	String Result=messages.Print_option_Message(arg1);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify Print_option in Message change","Verify Print_option in Message change", "Successfully Printed the message  ","Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify Print_option in Message change","Verify Print_option in Message change", "Failed to Print the message ","Failed");
	}
	}
}

/*------------------------------------------------------------------------------------------------------------
UI Description: Dashboard navigation  - Print option should be available in the message Page
UI Feature name: @MEPOE-5566_Messaging
------------------------------------------------------------------------------------------------------------*/
@When("^user enterAlliance \"([^\"]*)\" as \"([^\"]*)\"$")
public void user_enterAlliance_as(String Alliance, String Alliance_code) throws Throwable { 
	lib.WriteReportStep("1", "Verify Alliance_code", "", "", "");
	String Result=userManagementPage.userInput(Alliance, Alliance_code);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify Alliance_code","Verify Alliance_code", "Successfully Entered alliancecode ","Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify Alliance_code","Verify Alliance_code", "Failed to Enter Alliance_code","Failed");
	}	  
}

/*------------------------------------------------------------------------------------------------------------
UI Description: Dashboard navigation  - Print option should be available in the message Page
UI Feature name: @MEPOE-5566_Messaging
------------------------------------------------------------------------------------------------------------*/
@When("^user click login button and enter to the admin console$")
public void user_click_login_button_and_enter_to_the_admin_console() throws Throwable {
	lib.WriteReportStep("1", "Verify Login to Adminconsole", "", "", "");
	String Result=userManagementPage.login_admin_console();
	Result1=Result;
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify Login to Adminconsole","Verify Login to Adminconsole", "Successfully Entered to adminconsole ","Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify Login to Adminconsole","Verify Login to Adminconsole", "Failed to Enter into adminconsole","Failed");
	}
}
@Then("^user should be able to create the new message and give the input as \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_create_the_new_message_and_give_the_input_as(String Alliance_Name, String Language, String Type, String Title, String Sub_title, String Date_received, String Validity_type,String In_days_Validity_days, String message_body) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify create message", "", "", "");
	String Result=messages.Create_message(Alliance_Name,Language,Type,Title,Sub_title,Date_received,Validity_type,In_days_Validity_days,message_body);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify create message","Verify create message", "Successfully created message "+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify create message","Verify create message", "Failed to create message","Failed");
	}
	}
	
}
@Then("^User should be able to Navigate from message notification to the message detail$")
public void User_should_be_able_to_Navigate_from_message_notification_to_the_message_detail(String Device) throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify User should be navigate from message notification to message detail", "", "", "");
	String Result=dashboardpage.Navigate_to_message_view_from_notification();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify User should be navigate from message notification to message detail","Verify User should be navigate from messqage notification to message detail", "Successfully navigate to message detail ","Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify User should be navigate from message notification to message detail","Verify User should be navigate from messqage notification to message detail", "No unread message are there come back later","Failed");
	}
	}
}
@When("^user click Submit login for alert$")
public void user_click_Submit_login() throws Throwable{
	lib.WriteReportStep("1", "Verify submit button for alert testcase", "", "", "");
	String Result=userManagementPage.Submitlogin_for_alert_testcase();
	Result1=Result;
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify submit button for alert testcase","Verify submit button for alert testcase", "Successfully navigate to Home Page ","Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify submit button for alert testcase","Verify submit button for alert testcase", "Failed to navigate to home page","Failed");
	}
}
@Then("^User should be able to view unread alerts it will appear directly after logging in$")
public void User_should_be_able_to_view_unread_alerts_it_will_appear_directly_after_logging_in() throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify User should be able to view unread allert", "", "", "");
	String Result=dashboardpage.Confirm_unread_alert_after_login();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify User should be able to view unread allert","Verify User should be able to view unread allert", "Successfully confirming unread alert ","Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify User should be able to view unread allert","Verify User should be able to view unread allert", "No unread alerts are there come back later","Failed");
	}
	}
}
@Then("^User should be able to close the message notification and check the message will be in read status$")
public void User_should_be_able_to_close_the_message_notification_and_check_the_message_will_be_in_read_status() throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify User should be able to close the notification", "", "", "");
	String Result=dashboardpage.Close_message_notification();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify User should be able to close the notification","Verify User should be able to close the notification", "Successfully closed the notification ","Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify User should be able to close the notification","Verify User should be able to close the notification", "No unread Messages are there for now come back later","Failed");
	}
	}
}
@Then("^User should be able click the unread message/Document count and go to the detailed view \"([^\"]*)\"$")
public void user_should_be_able_click_the_unread_message_Document_count_and_go_to_the_detailed_view(String Device) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify User should be able see the unread message and document", "", "", "");
	String Result=dashboardpage.Navigate_unread_message_detail_view(Device);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify User should be able see the unread message and document","Verify User should be able see the unread message and document", "Successfully Navigate to detailed message and document ","Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify User should be able see the unread message and document","Verify User should be able see the unread message and document", "Failed to navigate the document and message","Failed");
	}
	}
}
@Then("^User should be able to download the attachment of the specific message as \"([^\"]*)\"$")
public void user_should_be_able_to_download_the_attachment_of_the_specific_message_as(String message_Title) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify User should be able to download the attachment from the message", "", "", "");
	String Result=messages.Download_attachment_from_message(message_Title);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify User should be able to download the attachment from the message","Verify User should be able to download the attachment from the message", "Successfully Downloaded the attachment ","Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify User should be able to download the attachment from the message","Verify User should be able to download the attachment from the message", "No Attachment files are there in the particular message","Failed");
	}
	}
}
@Then("^User should be able to validate all the property of the specific message title as \"([^\"]*)\"$")
public void User_should_be_able_to_validate_all_the_property_of_the_specific_message_title_as(String message_Title) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify User should be able to validate all the property of the specific message title", "", "", "");
	String Result=messages.validation_of_message_template(message_Title);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify User should be able to validate all the property of the specific message title","Verify User should be able to validate all the property of the specific message title", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify User should be able to validate all the property of the specific message title","Verify User should be able to validate all the property of the specific message title",Result ,"Failed");
	}
	}
}
@Then("^User should be able to get the permanent link from the message and login through the portal as \"([^\"]*)\" and \"([^\"]*)\" and validate the message title as \"([^\"]*)\"$")
public void user_should_be_able_to_get_the_permanent_link_from_the_message_and_login_through_the_portal_as_and_and_validate_the_message_title_as(String userID_LBC, String password_LBC, String message_Title) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify User should be able to get the permanent link from the message", "", "", "");
	String Result=messages.permanent_link_Retrive(userID_LBC,password_LBC,message_Title);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify User should be able to get the permanent link from the message","Verify User should be able to get the permanent link from the message", "Successfully get the permanent link"+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify User should be able to get the permanent link from the message","Verify User should be able to get the permanent link from the message", "No permanent Link Found","Failed");
	}
	}
}
@Then("^User should be able to Navigate through the message by pagination$")
public void User_should_be_able_to_Navigate_through_the_message_by_pagination() throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify User should be able to navigate through the message pages", "", "", "");
	String Result=messages.pagination_of_message();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify User should be able to navigate through the message pages","Verify User should be able to navigate through the message pages", "Successfully pagination done"+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify User should be able to navigate through the message pages","Verify User should be able to navigate through the message pages", "Failed to do the pagination"+Result,"Failed");
	}
	}
}
@Then("^User should be able to see messages by default displayed in descending order by Date and Time of the message$")
public void User_should_be_able_to_see_messages_by_default_displayed_in_descending_order_by_Date_and_Time_of_the_message() throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify User should be able to see messages by default displayed in descending order by Date and Time of the message", "", "", "");
	String Result=messages.display_message_in_descending_order();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify User should be able to see messages by default displayed in descending order by Date and Time of the message","Verify User should be able to see messages by default displayed in descending order by Date and Time of the message", "Successfully displayed the message by descending order"+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify User should be able to see messages by default displayed in descending order by Date and Time of the message","Verify User should be able to see messages by default displayed in descending order by Date and Time of the message", "Failed to display the message by descending order"+Result,"Failed");
	}
	}
}
@Then("^User should be able to see last login date and time displayed on the home page$")
public void User_should_be_able_to_see_last_login_date_and_time_displayed_on_the_home_page() throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify User should be able to see last login date and time displayed on the home page", "", "", "");
	String Result=userManagementPage.last_login_date_time_in_home_page();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify User should be able to see last login date and time displayed on the home page","Verify User should be able to see last login date and time displayed on the home page", "Successfully displayed the last login date and time in the home page"+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify User should be able to see last login date and time displayed on the home page","Verify User should be able to see last login date and time displayed on the home page", "Failed to display the Last login date and time in the homwe page"+Result,"Failed");
	}
	}
}
@Then("^user should be able to create a new alliance user by giving \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_create_a_new_alliance_user_by_giving(String Language,String User_Type, String Alliance_name, String Profile_type, String First_Name, String last_name, String email_id, String UserName_new_alliance, String mobile_number) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify Admin should be able to Create new Allianz", "", "", "");
	String Result=userManagementPage.create_new_allianz_user(User_Type, Alliance_name, Profile_type, First_Name, last_name, email_id, UserName_new_alliance, mobile_number, Language);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify Admin should be able to Create new Allianz","Verify Admin should be able to Create new Allianz", "Successfully Created the allianz"+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify Admin should be able to Create new Allianz","Verify Admin should be able to Create new Allianz", "Failed to create the allianz"+Result,"Failed");
	}
	}
}
@Then("^user should be able to create a new merchant user by giving \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_create_a_new_merchant_user_by_giving(String User_Type,String Merchant_ID,String Profile_type,String First_Name,String last_name,String UserName_new_alliance,String email_id,String mobile_number,String Language) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify Admin should be able to create a merchant", "", "", "");
	String Result=userManagementPage.Create_new_merchant(User_Type,Merchant_ID,Profile_type,First_Name, last_name, UserName_new_alliance, email_id, mobile_number, Language);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify Admin should be able to create a merchant","Verify Admin should be able to create a merchant", "Successfully Created the Merchant"+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify Admin should be able to create a merchant","Verify Admin should be able to create a merchant", "Failed to create the Merchant"+Result,"Failed");
	}
	}
}
@Then("^user should be able to validate the profile information of the account$")
public void user_should_be_able_to_validate_the_profile_information_of_the_account() throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to validate profile information", "", "", "");
	String Result=userManagementPage.Validate_profile_information();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to validate profile information","Verify BO should be able to validate profile information", "Successfully verified the profile information"+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to validate profile information","Verify BO should be able to validate profile information", "Failed to verify the profile information"+Result,"Failed");
	}
	}
}
@Then("^user should be able to change the password to a new one as \"([^\"]*)\" ,\"([^\"]*)\"$")
public void user_should_be_able_to_change_the_password_to_a_new_one_as(String New_password, String password) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to change the password", "", "", "");
	String Result=userManagementPage.Change_Password_of_BO(New_password,password);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to change the password","Verify BO should be able to change the password", "Successfully Changed the password "+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to change the password","Verify BO should be able to change the password", "Failed to Change the password "+Result,"Failed");
	}
	}
}
@Then("^user should be able to download the terms and conditions in the given path \"([^\"]*)\"$")
public void user_should_be_able_to_download_the_terms_and_conditions_in_the_given_path(String downloaded_Path) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to download the terms and conditions", "", "", "");
	String Result=termsandConditions.download_terms_and_condition(downloaded_Path);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to download the terms and conditions","Verify BO should be able to download the terms and conditions", "Successfully Downloaded the terms and conditions "+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to download the terms and conditions","Verify BO should be able to download the terms and conditions", "Failed to Downloaded the terms and conditions "+Result,"Failed");
	}
	}
}
@Then("^user should be able to accept the terms and conditions$")
public void user_should_be_able_to_accept_the_terms_and_conditions() throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to Accept the terms and conditions", "", "", "");
	String Result=termsandConditions.Accept_terms_and_conditions();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to accept the terms and conditions","Verify BO should be able to accept the terms and conditions", "Successfully accepted the terms and conditions "+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to accept the terms and conditions","Verify BO should be able to accept the terms and conditions", "Failed to accept the terms and conditions "+Result,"Failed");
	}
	}
}
@Then("^user should be able to see the password expiry message and change the password like \"([^\"]*)\" ,\"([^\"]*)\"$")
public void user_should_be_able_to_see_the_password_expiry_message_and_change_the_password_like(String New_password, String password) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to see the expired message and able to change the password", "", "", "");
	String Result=userManagementPage.Password_expire_message(New_password,password);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to see the expired message and able to change the password","Verify BO should be able to see the expired message and able to change the password", "Successfully Changed the password "+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to see the expired message and able to change the password","Verify BO should be able to see the expired message and able to change the password", "Failed to Change the password "+Result,"Failed");
	}
	}
}
@Then("^user should be able to download multiple_documents from document library by providing \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_download_multiple_documents_from_document_library_by_providing(String Alliance_code,String downloaded_Path) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to download multiple documents", "", "", "");
	String Result=documentManagement.Download_document_from_document_library(Alliance_code, downloaded_Path);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to download multiple documents","Verify BO should be able to download multiple documents", "Successfully downloaded the documents "+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to download multiple documents","Verify BO should be able to download multiple documents", "Failed to download the documents "+Result,"Failed");
	}
	}
}
@Then("^Then user should be able to navigate to the preAuthorization page and select any time period filter$")
public void user_should_be_able_to_navigate_to_the_preAuthorization_page_and_select_any_time_period_filter() throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to navigate to the preAuthorization page and select any time period filter", "", "", "");
	String Result=financialactivity.Verify_Time_Period_filter_For_Preauthorization();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to navigate to the preAuthorization page and select any time period filter","Verify BO should be able to navigate to the preAuthorization page and select any time period filter", "Successfully selected and verified every time period filter "+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to navigate to the preAuthorization page and select any time period filter","Verify BO should be able to navigate to the preAuthorization page and select any time period filter", "Failed to Verify the time period filter "+Result,"Failed");
	}
	}
}
@Then("^user should be able to get the xml report downloaded for transaction page and \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_get_the_xml_report_downloaded_for_transaction_page_and(String downloaded_Path, String Alliance_code) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to export the transaction details in xml format", "", "", "");
	String Result=financialactivity.Verify_transaction_xml_file_download(downloaded_Path, Alliance_code);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to export the transaction details in xml format","Verify BO should be able to export the transaction details in xml format", "Successfully exported the transaction detail "+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to export the transaction details in xml format","Verify BO should be able to export the transaction details in xml format", "Failed to export the transaction detail "+Result,"Failed");
	}
	}
}
@Then("^user should be able to modify the message content by giving \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_modify_the_message_content_by_giving(String Message_title, String Sub_title, String message_body, String Upload_file) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify CM should be able to modify the message content", "", "", "");
	String Result=messages.modify_the_Message(Message_title, Sub_title, message_body, Upload_file);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify CM should be able to modify the message content","Verify CM should be able to modify the message content", "Successfully modified a message "+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify CM should be able to modify the message content","Verify CM should be able to modify the message content", "Failed to modify a message "+Result,"Failed");
	}  
	}
}
@Then("^user should be able to delete the message by giving \"([^\"]*)\"$")
public void user_should_be_able_to_delete_the_message_by_giving(String Message_title) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify CM should be able to delete a message", "", "", "");
	String Result=messages.delete_the_Message(Message_title);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify CM should be able to delete a message","Verify CM should be able to delete a message", "Successfully deleted the message from the system "+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify CM should be able to delete a message","Verify CM should be able to delete a message", "Failed to delete the message "+Result,"Failed");
	}
	}
}
@Then("^user should be able to search the user list by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_search_the_user_list_by_providing(String First_Name, String last_name, String UserName_new_alliance) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify Admin will be able to search the user by their name and user name", "", "", "");
	String Result=userManagementPage.Search_User_in_Admin_console(First_Name, last_name, UserName_new_alliance);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify Admin will be able to search the user by their name and user name","Verify Admin will be able to search the user by their name and user name", "Successfully got the user from the system "+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify Admin will be able to search the user by their name and user name","Verify CM Admin will be able to search the user by their name and user name", "Failed to get the user "+Result,"Failed");
	}
	}
}
@Then("^user should be able to get the xls report downloaded for transaction page by providing \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_get_the_xls_report_downloaded_for_transaction_page_by_providing(String downloaded_Path, String Alliance_code) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to export the transaction details in xls format", "", "", "");
	String Result=financialactivity.Verify_transaction_xls_file_download(downloaded_Path, Alliance_code);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to export the transaction details in xls format","Verify BO should be able to export the transaction details in xls format", "Successfully downloaded the transaction file "+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to export the transaction details in xls format","Verify BO should be able to export the transaction details in xls format", "Failed to download the file "+Result,"Failed");
	}
	}
}
@When("^user should be able to get the csv report downloaded from transaction page by providing \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_get_the_csv_report_downloaded_from_transaction_page_by_providing(String downloaded_Path, String Alliance_code) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to export the transaction details in csv format", "", "", "");
	String Result=financialactivity.Verify_transaction_csv_file_download(downloaded_Path, Alliance_code);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to export the transaction details in csv format","Verify BO should be able to export the transaction details in csv format", "Successfully downloaded the transaction file "+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to export the transaction details in csv format","Verify BO should be able to export the transaction details in csv format", "Failed to download the file "+Result,"Failed");
	}
	}
}

@When("^user should be able to export csv report from funding page by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_export_csv_report_from_funding_page_by_providing(String downloaded_Path, String Alliance_code, String Funding_Reference_number) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to export the Funding batch details in csv format", "", "", "");
	String Result=financialactivity.Verify_funding_csv_file_download(downloaded_Path, Alliance_code, Funding_Reference_number);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to export the Funding batch details in csv format","Verify BO should be able to export the Funding batch details in csv format", "Successfully downloaded the Funding file "+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to export the Funding batch details in csv format","Verify BO should be able to export the Funding batch details in csv format", "Failed to download the file "+Result,"Failed");
	}
	}
}

@Then("^user should be able to export csv report from Authorization page by providing \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_export_csv_report_from_Authorization_page_by_providing(String downloaded_Path, String Alliance_code) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to export the Authorization details in csv format", "", "", "");
	String Result=financialactivity.Verify_Authorization_csv_file_download(downloaded_Path, Alliance_code);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to export the Authorization details in csv format","Verify BO should be able to export the Authorization details in csv format", "Successfully downloaded the Authorization file "+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to export the Authorization details in csv format","Verify BO should be able to export the Authorization details in csv format", "Failed to download the file "+Result,"Failed");
	}
	}
}
@Then("^user should be able to provide the \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_provide_the(String From_date, String To_date) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to provide the date", "", "", "");
	String Result=financialactivity.Verify_Time_picker_in_transaction_view(From_date, To_date);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to provide the date","Verify BO should be able to provide the date", "Successfully provided the dates "+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to provide the date","Verify BO should be able to provide the date", "Failed to provide the date "+Result,"Failed");
	}
	}
}
@Then("^user should be able to navigate to the Transaction page and select any time period filter$")
public void user_should_be_able_to_navigate_to_the_Transaction_page_and_select_any_time_period_filter() throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to navigate to the Transaction page and select any time period filter", "", "", "");
	String Result=financialactivity.Verify_Time_Period_filter_For_Transaction();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to navigate to the Transaction page and select any time period filter","Verify BO should be able to navigate to the Transaction page and select any time period filter", "Successfully selected and verified every time period filter "+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to navigate to the Transaction page and select any time period filter","Verify BO should be able to navigate to the Transaction page and select any time period filter", "Failed to Verify the time period filter "+Result,"Failed");
	}
	}
}
@Then("^user should be able to verify the \"([^\"]*)\" should be before \"([^\"]*)\"$")
public void user_should_be_able_to_verify_the_should_be_before(String From_date, String To_date) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able verify from date is before to date", "", "", "");
	String Result=financialactivity.Verify_From_date_should_be_before_to_date(From_date, To_date);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able verify from date is before to date","Verify BO should be able verify from date is before to date", "Successfully verified from date before todate "+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able verify from date is before to date","Verify BO should be able verify from date is before to date", "Failed to verify "+Result,"Failed");
	}
	}
}
@When("^user should be able to export xml report from funding page by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_export_xml_report_from_funding_page_by_providing(String downloaded_Path, String Alliance_code, String Funding_Reference_number) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to export the transaction details in csv format", "", "", "");
	String Result=financialactivity.Verify_funding_xml_file_download(downloaded_Path, Alliance_code, Funding_Reference_number);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to export the Funding batch details in csv format","Verify BO should be able to export the Funding batch details in csv format", "Successfully downloaded the Funding file "+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to export the Funding batch details in csv format","Verify BO should be able to export the Funding batch details in csv format", "Failed to download the file "+Result,"Failed");
	}
	}
}
@Then("^user should be able to provide the \"([^\"]*)\", \"([^\"]*)\" and verify the transaction$")
public void user_should_be_able_to_provide_the_and_verify_the_transaction(String From_date, String To_date) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to provide the dates and verify the transaction detail", "", "", "");
	String Result=financialactivity.Verify_the_transaction_details_after_giving_dates(From_date,To_date);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to provide the dates and verify the transaction detail","Verify BO should be able to provide the dates and verify the transaction detail", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to provide the dates and verify the transaction detail","Verify BO should be able to provide the dates and verify the transaction detail", "Failed to download the file "+Result,"Failed");
	}
	}
}
@Then("^user should be able to retrieve a permanent document link by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_retrieve_a_permanent_document_link_by_providing(String userID_LBC, String password_LBC, String downloaded_Path) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify CM should be able to retrieve a permanent link for document", "", "", "");
	String Result=documentManagement.permanent_link_Retrive(userID_LBC, password_LBC, downloaded_Path);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify CM should be able to retrieve a permanent link for document","Verify CM should be able to retrieve a permanent link for document", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify CM should be able to retrieve a permanent link for document","Verify CM should be able to retrieve a permanent link for document", "Failed"+Result,"Failed");
	}
	}
}
@Then("^user should be able to add by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_add_by_providing(String document_Name, String Alliance_name, String Language, String Upload_file, String attachmentPath, String Description_DocumentText) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify CM should be able to add a new document", "", "", "");
	String Result=documentManagement.Add_a_new_document(document_Name, Alliance_name, Language, Upload_file, attachmentPath, Description_DocumentText);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify CM should be able to add a new document","Verify CM should be able to add a new document", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify CM should be able to add a new document","Verify CM should be able to add a new document", "Failed"+Result,"Failed");
	}
	}
}

@Then("^user should be able to rename a document by providing \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_rename_a_document_by_providing(String Rename_document,String Upload_file) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify CM should be able to rename a document", "", "", "");
	String Result=documentManagement.Rename_a_document(Rename_document, Upload_file);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify CM should be able to rename a document","Verify CM should be able to rename a document", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify CM should be able to rename a document","Verify CM should be able to rename a document", "Failed"+Result,"Failed");
	}
	}
}
@Then("^user should be able to remove a document by providing \"([^\"]*)\"$")
public void user_should_be_able_to_remove_a_document_by_providing(String Upload_file) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify CM should be able to remove a document", "", "", "");
	String Result=documentManagement.Remove_a_document(Upload_file);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify CM should be able to remove a document","Verify CM should be able to remove a document", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify CM should be able to remove a document","Verify CM should be able to remove a document", "Failed"+Result,"Failed");
	}
	}
}
@Then("^user should be able to export xml report from Authorization page by providing \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_export_xml_report_from_Authorization_page_by_providing(String downloaded_Path, String Alliance_code) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to export the Authorization details in xml format", "", "", "");
	String Result=financialactivity.Verify_Authorization_xml_file_download(downloaded_Path, Alliance_code);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to export the Authorization details in xml format","Verify BO should be able to export the Authorization details in xml format", "Successfully downloaded the Authorization file "+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to export the Authorization details in xml format","Verify BO should be able to export the Authorization details in xml format", "Failed to download the file "+Result,"Failed");
	}
	}
}
@Then("^user should be able to navigate to the document and validate the document unread status$")
public void user_should_be_able_to_navigate_to_the_document_and_validate_the_document_unread_status() throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to validate the document unread status", "", "", "");
	String Result=documentManagement.marked_unread_document();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to validate the document unread status","Verify BO should be able to validate the document unread status", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to validate the document unread status","Verify BO should be able to validate the document unread status", "Failed to load the document page "+Result,"Failed");
	}
	}
}
@Then("^user should be able to export the list of alliance users by providing \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_export_the_list_of_alliance_users_by_providing(String Alliance_name, String downloaded_Path) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify User should be able to export the list of alliance user list", "", "", "");
	String Result=userManagementPage.Export_the_alliance_user_list(Alliance_name, downloaded_Path);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify User should be able to export the list of alliance user list","Verify User should be able to export the list of alliance user list", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify User should be able to export the list of alliance user list","Verify User should be able to export the list of alliance user list", Result,"Failed");
	}
	}
}
@Then("^user should be able to search the authorization detail by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_search_the_authorization_detail_by_providing(String Order_ID,String From_date, String To_date) throws Throwable
{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to search the authorization detail by providing order_id", "", "", "");
	String Result=financialactivity.verify_the_authorization_detail(Order_ID,From_date,To_date);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to search the authorization detail by providing order_id","Verify User should be able to search the authorization detail by providing order_id", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify User should be able to search the authorization detail by providing order_id","Verify User should be able to search the authorization detail by providing order_id", Result,"Failed");
	}
	}
}
@Then("^user should be able to search the transaction detail by providing \"([^\"]*)\"$")
public void user_should_be_able_to_search_the_transaction_detail_by_providing(String Merchant_ID_Transaction) throws Throwable
{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to search the transaction detail by providing merchant_id", "", "", "");
	String Result=financialactivity.Search_the_transaction_detail_by_giving_single_search_criteria(Merchant_ID_Transaction);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to search the transaction detail by providing merchant_id","Verify User should be able to search the transaction detail by providing merchant_id", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify User should be able to search the transaction detail by providing merchant_id","Verify User should be able to search the transaction detail by providing merchant_id", Result,"Failed");
	}
	}
}
@Then("^user should be able to validate the text disclaimer for each widget by providing \"([^\"]*)\"$")
public void user_should_be_able_to_validate_the_text_disclaimer_for_each_widget_by_providing(String Device) throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to verify the text disclaimer for each widget", "", "", "");
	String Result=dashboardpage.Validate_Disclaimer_widget(Device);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to verify the text disclaimer for each widget","Verify User should be able to verify the text disclaimer for each widget", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify User should be able to verify the text disclaimer for each widget","Verify User should be able to verify the text disclaimer for each widget", Result,"Failed");
	}
	}
}
@Then("^user should be able to verify the details in funding page by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_verify_the_details_in_funding_page_by_providing(String From_date,String To_date,String Funding_Reference_number) throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to verify the funding page and the store details", "", "", "");
	String Result=financialactivity.verify_the_funding_Activities_view_for_store_details(From_date,To_date,Funding_Reference_number);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to verify the funding page and the store details","Verify user should be able to verify the funding page and the store details", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to verify the funding page and the store details","Verify user should be able to verify the funding page and the store details", Result,"Failed");
	}
	}
}
@Then("^user should be able to verify the details in funding page and in the fees and vat details by providing \"([^\"]*)\"$")
public void user_should_be_able_to_verify_the_details_in_funding_page_and_in_the_fees_and_vat_details_by_providing(String Funding_Reference_number) throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to verify the funding page and the fees and vat details", "", "", "");
	String Result=financialactivity.verify_the_funding_Activities_view_for_feesAndVat_details(Funding_Reference_number);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to verify the funding page and the fees and vat details","Verify user should be able to verify the funding page and the fees and vat details", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to verify the funding page and the fees and vat details","Verify user should be able to verify the funding page and the fees and vat details", Result,"Failed");
	}
	}
}
@Then("^user should be able to export report from PreAuthorization page by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_export_report_from_PreAuthorization_page_by_providing(String downloaded_Path,String Alliance_code,String File_type_Format) throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to export the preauthorization list in "+File_type_Format, "", "", "");
	String Result=financialactivity.Export_PreAuthorization_details(downloaded_Path, Alliance_code, File_type_Format);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to export the preauthorization list in "+File_type_Format,"Verify user should be able to export the preauthorization list in "+File_type_Format, Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to export the preauthorization list in "+File_type_Format,"Verify user should be able to export the preauthorization list in "+File_type_Format, Result,"Failed");
	}
	}
}

@Then("^user should be able to export XML report from PreAuthorization page by providing \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_export_XML_report_from_PreAuthorization_page_by_providing(String downloaded_Path,String Alliance_code) throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to export the preauthorization list in XML format", "", "", "");
	String Result=financialactivity.Export_XML_PreAuthorization_details(downloaded_Path, Alliance_code);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to export the preauthorization list in XML format","Verify user should be able to export the preauthorization list in XML format", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to export the preauthorization list in XML format","Verify user should be able to export the preauthorization list in XML format", Result,"Failed");
	}
	}
}
@Then("^user should be able to verify the batch details in funding page by providing \"([^\"]*)\"$")
public void user_should_be_able_to_verify_the_batch_details_in_funding_page_by_providing(String Funding_Reference_number) throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to view the batch details in funding page", "", "", "");
	String Result=financialactivity.verify_the_funding_Activities_view_for_Batch_details(Funding_Reference_number);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to view the batch details in funding page","Verify user should be able to view the batch details in funding page", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to view the batch details in funding page","Verify user should be able to view the batch details in funding page", Result,"Failed");
	}
	}
}
@Then("^user should be able to verify the payment type details in funding page by providing \"([^\"]*)\"$")
public void user_should_be_able_to_verify_the_payment_type_details_in_funding_page_by_providing(String Funding_Reference_number) throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to view the batch details in funding page", "", "", "");
	String Result=financialactivity.verify_the_funding_Activities_view_for_payment_method(Funding_Reference_number);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to view the payment type details in funding page","Verify user should be able to view the payment type details in funding page", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to view the payment type details in funding page","Verify user should be able to view the payment type details in funding page", Result,"Failed");
	}
	}
}
@Then("^user should be able to verify the \"([^\"]*)\" should be before \"([^\"]*)\" in the pre auth view$")
public void user_should_be_able_to_verify_the_should_be_before_in_the_pre_auth_view(String From_date, String To_date) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able verify from date is before to date", "", "", "");
	String Result=financialactivity.Verify_From_date_should_be_before_to_date_in_preAuth_view(From_date, To_date);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able verify from date is before to date","Verify BO should be able verify from date is before to date", "Successfully verified from date before todate "+Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able verify from date is before to date","Verify BO should be able verify from date is before to date", "Failed to verify "+Result,"Failed");
	}
	}
}

@Then("^user should be able to search and save the search by providing \"([^\"]*)\"$")
public void user_should_be_able_to_verify_the_search_in_each_view(String Merchant_ID) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to search and save the search by providing", "", "", "");
	String Result=financialactivity.set_and_save_search_criteria_for_each_view(Merchant_ID);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to search and save the search by providing","Verify BO should be able to search and save the search by providing", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to search and save the search by providing","Verify BO should be able to search and save the search by providing", Result,"Failed");
	}
	}
}
@Then("^user should be able to navigate from top to buttom without scrolling a lot$")
public void user_should_be_able_to_navigate_from_top_to_buttom_without_scrolling_a_lot() throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to navigate from top to buttom view", "", "", "");
	String Result=financialactivity.Navigate_to_top_and_buttom_view();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to navigate from top to buttom view","Verify BO should be able to navigate from top to buttom view", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to navigate from top to buttom view","Verify BO should be able to navigate from top to buttom view", Result,"Failed");
	}}
}
@Then("^user should be able to verify the webShop details in funding page by providing \"([^\"]*)\"$")
public void user_should_be_able_to_verify_the_webShop_details_in_funding_page_by_providing(String Funding_Reference_number) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to verify webshop details in the funding page", "", "", "");
	String Result=financialactivity.verify_the_funding_Activities_view_for_Webshop_details(Funding_Reference_number);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to verify webshop details in the funding page","Verify BO should be able to verify webshop details in the funding page", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to verify webshop details in the funding page","Verify BO should be able to verify webshop details in the funding page", Result,"Failed");
	}}
}
@Then("^user should be able to verify the summary of fees by card type in funding page by providing \"([^\"]*)\"$")
public void user_should_be_able_to_verify_the_summary_of_fees_by_card_type_in_funding_page_by_providing(String Funding_Reference_number) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to verify summary of fees by each card type in the funding page", "", "", "");
	String Result=financialactivity.summary_of_fees_by_card_type(Funding_Reference_number);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to verify summary of fees by each card type in the funding page","Verify BO should be able to verify summary of fees by each card type in the funding page", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to verify summary of fees by each card type in the funding page","Verify BO should be able to verify summary of fees by each card type in the funding page", Result,"Failed");
	}}
}
@Then("^user should be able to verify the funding summary page in the funding view$")
public void user_should_be_able_to_verify_the_funding_summary_page_in_the_funding_view() throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to verify funding summary view in the funding page", "", "", "");
	String Result=financialactivity.verify_the_funding_summary_view_in_funding_view();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to verify funding summary view in the funding page","Verify BO should be able to verify funding summary view in the funding page", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to verify funding summary view in the funding page","Verify BO should be able to verify funding summary view in the funding page", Result,"Failed");
	}}
}
@Then("^Admin should be able to see the communication summary and the registraion link by providing \"([^\"]*)\"$")
public void Admin_should_be_able_to_see_the_communication_summary_and_the_registraion_link_by_providing(String UserName_new_alliance) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify Admin should able to see the communication summary and the registraion link by providing", "", "", "");
	String Result=userManagementPage.Check_communication_summary_for_registraion_link(UserName_new_alliance);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify Admin should be able to able to see the communication summary and the registraion link by providing","Verify Admin should be able to able to see the communication summary and the registraion link by providing", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify Admin should be able to see the communication summary and the registraion link by providing","Verify Admin should be able to see the communication summary and the registraion link by providing", Result,"Failed");
	}}
}
@Then("^user should be able to view the detailed list of all fees applied to account in the funding view by providing \"([^\"]*)\"$")
public void user_should_be_able_to_view_the_detailed_list_of_all_fees_applied_to_account_in_the_funding_view_by_providing(String Funding_Reference_number) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify business owner should be able to see detailed list of all the fees applied to account ", "", "", "");
	String Result=financialactivity.detailed_list_of_all_fees_applied_to_account(Funding_Reference_number);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify business owner should be able to see detailed list of all the fees applied to account","Verify business owner should be able to see detailed list of all the fees applied to account", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify business owner should be able to see detailed list of all the fees applied to account","Verify business owner should be able to see detailed list of all the fees applied to account", Result,"Failed");
	}}
}
@Then("^user should be able to filter transactions in Funding Summary view by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_filter_transactions_in_Funding_Summary_view_by_providing(String From_date,String To_date,String Funding_Reference_number) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify business owner should be able to filter transactions in Funding Summary view by providing ", "", "", "");
	String Result=financialactivity.filter_transactions_in_Funding_Summary_view(From_date, To_date, Funding_Reference_number);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify business owner should be able to filter transactions in Funding Summary view by providing","Verify business owner should be able to filter transactions in Funding Summary view by providing", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify business owner should be able to filter transactions in Funding Summary view by providing","Verify business owner should be able to filter transactions in Funding Summary view by providing", Result,"Failed");
	}}
}
@Then("^user should be able to see the order id in the authorization page$")
public void user_should_be_able_to_see_the_order_id_in_the_authorization_page() throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify business owner should be able to see the order id in the authorization page ", "", "", "");
	String Result=financialactivity.Display_Order_ID_in_Authorization_view();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify business owner should be able to see the order id in the authorization page","Verify business owner should be able to see the order id in the authorization page", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify business owner should be able to see the order id in the authorization page","Verify business owner should be able to see the order id in the authorization page", Result,"Failed");
	}}
}
@Then("^user should be able to set a filter and view individual stores via searching on \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_set_a_filter_and_view_individual_stores_via_searching_on(String Merchant_ID,String Store_ID) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify business owner should be able to filter the search by MID or TID ", "", "", "");
	String Result=financialactivity.filter_and_view_individual_stores_via_searching_on_MID_or_TID_level(Merchant_ID, Store_ID);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify business owner should be able to filter the search by MID or TID ","Verify business owner should be able to filter the search by MID or TID ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify business owner should be able to filter the search by MID or TID ","Verify business owner should be able to filter the search by MID or TID ", Result,"Failed");
	}}
}
@Then("^user should be able to receive a Registration E-Mail and can landed upon the registration page by providing \"([^\"]*)\"$")
public void user_should_be_able_to_receive_a_Registration_Email_and_can_landed_upon_the_registration_page_by_providing(String UserName_new_alliance) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify new merchant should get the resgistraion link ", "", "", "");
	String Result=userManagementPage.Send_Registration_Email_available_in_communication_summary(UserName_new_alliance);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify new merchant should get the resgistraion link ","Verify new merchant should get the resgistraion link ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify new merchant should get the resgistraion link ","Verify new merchant should get the resgistraion link ", Result,"Failed");
	}}
}
@Then("^user should be able to search the preauth data by providing \"([^\"]*)\"$")
public void user_should_be_able_to_search_the_preauth_data_by_providing(String Merchant_ID) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify business owner should be able to search the preauth data ", "", "", "");
	String Result=financialactivity.search_through_preauth_data_by_entering_single_criteria_into_a_search_field(Merchant_ID);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify business owner should be able to search the preauth data ","Verify business owner should be able to search the preauth data ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify business owner should be able to search the preauth data ","Verify business owner should be able to search the preauth data ", Result,"Failed");
	}} 
}
@Then("^user should be able to search and save the search in the preauth view by providing \"([^\"]*)\"$")
public void user_should_be_able_to_search_and_save_the_search_in_the_preauth_view(String Merchant_ID) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to search and save the search by providing", "", "", "");
	String Result=financialactivity.set_and_save_search_criteria_for_preAuth_view(Merchant_ID);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to search and save the search by providing","Verify BO should be able to search and save the search by providing", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to search and save the search by providing","Verify BO should be able to search and save the search by providing", Result,"Failed");
	}}
}
@Then("^check next time when you login you can see the saved search by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void check_next_time_when_you_login_you_can_see_the_saved_search_by_providing(String appurl,String username,String password) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to see the saved search in preauth view", "", "", "");
	String Result=financialactivity.check_next_time_in_preAuth_view_for_same_search(appurl, username, password);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to see the saved search in preauth view","Verify BO should be able to see the saved search in preauth view", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to see the saved search in preauth view","Verify BO should be able to see the saved search in preauth view", Result,"Failed");
	}}
}
@Then("^user should be able to see the prompt while changing the password to a new one as \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_change_the_password_to_a_new_one_as(String password, String New_password, String Retype_New_password) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to see the error message prompt ", "", "", "");
	String Result=userManagementPage.Change_Password_error_prompt(password, New_password, Retype_New_password);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to see the error message prompt ","Verify BO should be able to see the error message prompt ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to see the error message prompt ","Verify BO should be able to see the error message prompt ", Result,"Failed");
	}}
}
@Then("^user should be able to define and modify email templates by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_define_and_modify_email_templates_by_providing(String email_Type, String Language, String Description_email,String email_subject) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify Admin should be able to modify the email template ", "", "", "");
	String Result=userManagementPage.Define_Modify_email_template(email_Type, Language, Description_email, email_subject);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify Admin should be able to modify the email template ","Verify Admin should be able to modify the email template ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify Admin should be able to modify the email template ","Verify Admin should be able to modify the email template ", Result,"Failed");
	}}
}
@Then("^user should be able to define and modify sms templates by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_define_and_modify_sms_templates_by_providing(String sms_Type, String Language, String Description_sms,String sms_subject) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify Admin should be able to modify the sms template ", "", "", "");
	String Result=userManagementPage.Define_Modify_sms_template(sms_Type, Language, Description_sms, sms_subject);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify Admin should be able to modify the sms template ","Verify Admin should be able to modify the sms template ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify Admin should be able to modify the sms template ","Verify Admin should be able to modify the sms template ", Result,"Failed");
	}}
}
@Then("^user should be able to see all the static and dynamic contents in the prefered \"([^\"]*)\" by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_see_all_the_static_and_dynamic_contents_in_the_prefered_by_providing(String Language_Change,String Device, String Welcome_Text, String Authorizations_Text, String Pre_authorizations_Text, String Transactions_Text, String Funding_Text) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify BO should be able to see the static contents in prefered laguage ", "", "", "");
	String Result=dashboardcustomization.Display_static_manage_content_in_preferred_language(Language_Change,Device,Welcome_Text, Authorizations_Text, Pre_authorizations_Text, Transactions_Text, Funding_Text);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify BO should be able to see the static contents in prefered laguage ","Verify BO should be able to see the static contents in prefered laguage ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify BO should be able to see the static contents in prefered laguage ","Verify BO should be able to see the static contents in prefered laguage ", Result,"Failed");
	}}
}
@Then("^user should be able to verify the batch details for general view in funding page by providing \"([^\"]*)\"$")
public void user_should_be_able_to_verify_the_batch_details_for_general_view_in_funding_page_by_providing(String Funding_Reference_number) throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to view the batch details in funding page", "", "", "");
	String Result=onlineauthorization.verify_the_funding_Activities_view_for_Batch_details_for_online_authorization(Funding_Reference_number);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to view the batch details for general view in funding page","Verify user should be able to view the batch details in funding page", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to view the batch details for general view in funding page","Verify user should be able to view the batch details in funding page", Result,"Failed");
	}}
}
@Then("^user should be able to verify the fees and vat details for general view in funding page by providing \"([^\"]*)\"$")
public void user_should_be_able_to_verify_the_fees_and_vat_details_for_general_view_in_funding_page_by_providing(String Funding_Reference_number) throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to verify the funding page and the fees and vat details", "", "", "");
	String Result=onlineauthorization.verify_the_funding_Activities_view_for_feesAndVat_details_for_online_authorization(Funding_Reference_number);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to verify the funding page in the general view and the fees and vat details","Verify user should be able to verify the funding page and the fees and vat details", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to verify the funding page in the general view and the fees and vat details","Verify user should be able to verify the funding page and the fees and vat details", Result,"Failed");
	}}
}
@Then("^user should be able to verify the transaction details and the EMS and funding fees for general view in transaction page$")
public void user_should_be_able_to_verify_the_transaction_details_and_the_EMS_and_funding_fees_for_general_view_in_transaction_page() throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to verify the transaction page and the funding and ems fees", "", "", "");
	String Result=onlineauthorization.verify_the_transaction_Activities_view_for_online_authorization();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to verify the transaction page in the general view and the funding and the EMS fees ","Verify user should be able to verify the transaction page and the funding and EMS fees ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to verify the transaction page in the general view and the funding and the EMS fees ","Verify user should be able to verify the transaction page and the funding and the EMS fees ", Result,"Failed");
	}}
}
@Then("^user should be able to verify the authorization details for general view in Authorization page$")
public void user_should_be_able_to_verify_the_authorization_details_for_general_view_in_Authorization_page() throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to verify the Authorization page", "", "", "");
	String Result=onlineauthorization.verify_the_Authorization_Activities_view_for_online_authorization();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to verify the Authorization page in the general view ","Verify user should be able to verify the authorization page ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to verify the authorization page in the general view ","Verify user should be able to verify the authorization page ", Result,"Failed");
	}}
}
@Then("^user should be able to verify role based access restriction for each user in pre_authorization view$")
public void user_should_be_able_to_verify_role_based_access_restriction_for_each_user_in_pre_authorization_view() throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to verify the Authorization page", "", "", "");
	String Result=userManagementPage.Role_based_access_restriction_for_BO_and_BA();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to verify role based access restriction for each user in pre_authorization view ","Verify user should be able to verify role based access restriction for each user in pre_authorization view ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to verify role based access restriction for each user in pre_authorization view ","Verify user should be able to verify role based access restriction for each user in pre_authorization view ", Result,"Failed");
	}}
}
@Then("^user should be able to create a sub account by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_create_a_sub_account_by_providing(String First_Name, String last_name, String UserName_new_alliance, String email_id, String mobile_number, String Profile_type) throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to create a sub account in the merchant portal", "", "", "");
	String Result=userManagementPage.Create_sub_account_in_merchant_portal(First_Name, last_name, UserName_new_alliance, email_id, mobile_number, Profile_type);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to create a sub account in the merchant portal ","Verify user should be able to create a sub account in the merchant portal ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to create a sub account in the merchant portal ","Verify user should be able to create a sub account in the merchant portal ", Result,"Failed");
	}}
}
@Then("^user should be able to search a sub account user by giving \"([^\"]*)\"$")
public void user_should_be_able_to_search_a_sub_account_user_by_giving(String UserName_new_alliance) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to search a sub account in the admin portal", "", "", "");
	String Result=userManagementPage.Modify_sub_account_in_Admin_portal(UserName_new_alliance);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to search a sub account in the admin portal ","Verify user should be able to search a sub account in the admin portal ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to search a sub account in the admin portal ","Verify user should be able to search a sub account in the admin portal ", Result,"Failed");
	}}
}
@Then("^user should be able to see no transactions for provided search criteria by providing the \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_see_no_transactions_for_provided_search_criteria_by_providing_the(String From_date, String To_date) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to see an error message while searching in transaction data", "", "", "");
	String Result=financialactivity.no_transactions_for_search_criteria(From_date, To_date);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to see an error message while searching in transaction data ","Verify user should be able to see an error message while searching in transaction data ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to see an error message while searching in transaction data ","Verify user should be able to see an error message while searching in transaction data ", Result,"Failed");
	}}
}
@Then("^user should be able to see no preauth data for provided search criteria by providing the \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_see_no_preauth_data_for_provided_search_criteria_by_providing_the(String From_date, String To_date) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to see an error message while searching in preauth view", "", "", "");
	String Result=financialactivity.no_preAuth_data_for_search_criteria(From_date, To_date);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to see an error message while searching in preauth view ","Verify user should be able to see an error message while searching in preauth view ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to see an error message while searching in preauth view ","Verify user should be able to see an error message while searching in preauth view ", Result,"Failed");
	}}
}
@Then("^user should be able to see data in descending order by Data/Time by default in the pre_authorisation view$")
public void user_should_be_able_to_see_data_in_descending_order_by_Data_Time_by_default_in_the_pre_authorisation_view() throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to see data in descending order in the preauth view", "", "", "");
	String Result=financialactivity.Default_Descending_order_data_in_PreAuth_view();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to see data in descending order in the preauth view ","Verify user should be able to see data in descending order in the preauth view ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to see data in descending order in the preauth view ","Verify user should be able to see data in descending order in the preauth view ", Result,"Failed");
	}}
}
@Then("^user should be able to view and scroll through a detailed list of all authorization data by providing \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_view_and_scroll_through_a_detailed_list_of_all_authorization_data_by_providing(String From_date,String To_date) throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to view and scroll through a detailed list of all authorization data", "", "", "");
	String Result=financialactivity.verify_the_Authorization_data_and_Activities_in_authorization_view(From_date, To_date);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to view and scroll through a detailed list of all authorization data ","Verify user should be able to view and scroll through a detailed list of all authorization data ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to view and scroll through a detailed list of all authorization data ","Verify user should be able to view and scroll through a detailed list of all authorization data ", Result,"Failed");
	}}
}
@Then("^user should be able to view and scroll through a detailed list of all transaction data$")
public void user_should_be_able_to_view_and_scroll_through_a_detailed_list_of_all_transaction_data() throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to view and scroll through a detailed list of all transaction data", "", "", "");
	String Result=financialactivity.verify_the_transaction_details_and_Activities_in_Transaction_view();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to view and scroll through a detailed list of all transaction data ","Verify user should be able to view and scroll through a detailed list of all transaction data ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to view and scroll through a detailed list of all transaction data ","Verify user should be able to view and scroll through a detailed list of all transaction data ", Result,"Failed");
	}}
}
@Then("^user should be able to sort preAuth data into ascending and descending order \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_sort_preAuth_data_into_ascending_and_descending_order(String From_date,String To_date) throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to sort preAuth data into ascending and descending order", "", "", "");
	String Result=financialactivity.sort_preauth_data_into_ascending_and_descending_order(From_date, To_date);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to sort preAuth data into ascending and descending order ","Verify user should be able to sort preAuth data into ascending and descending order ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to sort preAuth data into ascending and descending order ","Verify user should be able to sort preAuth data into ascending and descending order ", Result,"Failed");
	}}
}
@Then("^user should be able to sort transaction data into ascending and descending order$")
public void user_should_be_able_to_sort_transaction_data_into_ascending_and_descending_order() throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to sort transaction data into ascending and descending order", "", "", "");
	String Result=financialactivity.sort_transaction_data_into_ascending_and_descending_order();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to sort transaction data into ascending and descending order ","Verify user should be able to sort transaction data into ascending and descending order ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to sort transaction data into ascending and descending order ","Verify user should be able to sort transaction data into ascending and descending order ", Result,"Failed");
	}}
}
@Then("^user should be able to see data in descending order by Data/Time by default in the transaction view$")
public void user_should_be_able_to_see_data_in_descending_order_by_Data_Time_by_default_in_the_transaction_view() throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to see default transaction data in descending order", "", "", "");
	String Result=financialactivity.Default_view_is_descending_order_in_transaction_view();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to see default transaction data in descending order ","Verify user should be able to see default transaction data in descending order ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to see default transaction data in descending order ","Verify user should be able to see default transaction data in descending order ", Result,"Failed");
	}}
}
@Then("^user should be able to see fee information in the Transaction detail$")
public void user_should_be_able_to_see_fee_information_in_the_Transaction_detail() throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to see fee information in the Transaction detail ", "", "", "");
	String Result=financialactivity.Fee_information_in_the_transaction_detail_of_each_transaction();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to see fee information in the Transaction detail ","Verify user should be able to see fee information in the Transaction detail ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to see fee information in the Transaction detail ","Verify user should be able to see fee information in the Transaction detail ", Result,"Failed");
	}}
}
@Then("^user should verify the date and time in the dashboard page by providing \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_verify_the_date_and_time_in_the_dashboard_page_by_providing(String Welcome_Text,String Device) throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to see fee information in the Transaction detail ", "", "", "");
	String Result=dashboardcustomization.portal_appears_in_my_preferred_locale(Welcome_Text,Device);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to see fee information in the Transaction detail ","Verify user should be able to see fee information in the Transaction detail ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to see fee information in the Transaction detail ","Verify user should be able to see fee information in the Transaction detail ", Result,"Failed");
	}}
}
@Then("^user should be able to validate refunding amount not greater than remaining refund amount by providing \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_validate_refunding_amount_not_greater_than_remaining_refund_amount_by_providing(String Transaction_ID,String Refund_amount) throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to validate refunding amount not greater than remaining refund amount ", "", "", "");
	String Result=financialactivity.Validate_refunding_amount_not_greater_than_remaining_refund_amount(Transaction_ID, Refund_amount);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to validate refunding amount not greater than remaining refund amount ","Verify user should be able to validate refunding amount not greater than remaining refund amount ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to validate refunding amount not greater than remaining refund amount ","Verify user should be able to validate refunding amount not greater than remaining refund amount ", Result,"Failed");
	}}
}
@Then("^user should be able to see view records of all the multiple refunds initiated$")
public void user_should_be_able_to_see_view_records_of_all_the_multiple_refunds_initiated() throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to see view records of all the multiple refunds initiated ", "", "", "");
	String Result=financialactivity.View_records_of_all_the_multiple_refunds_initiated();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to see view records of all the multiple refunds initiated ","Verify user should be able to see view records of all the multiple refunds initiated ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to see view records of all the multiple refunds initiated ","Verify user should be able to see view records of all the multiple refunds initiated ", Result,"Failed");
	}}
}
@Then("^user should be able to manage Portal content in multiple languages and verify it in message page by providing \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_manage_Portal_content_in_multiple_languages_and_verify_it_in_message_page_by_providing(String Language_Change,String Message_title) throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to manage Portal content in multiple languages and verify it in message page ", "", "", "");
	String Result=dashboardcustomization.Manage_the_message_in_portal_specific_Language(Language_Change, Message_title);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to manage Portal content in multiple languages and verify it in message page ","Verify user should be able to manage Portal content in multiple languages and verify it in message page ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to manage Portal content in multiple languages and verify it in message page ","Verify user should be able to manage Portal content in multiple languages and verify it in message page ", Result,"Failed");
	}}
}
@Then("^user should be able to enter correct amount for refund by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_enter_correct_amount_for_refund_by_providing(String From_date,String To_date,String Transaction_ID,String Refund_amount ) throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to enter correct amount for refund ", "", "", "");
	String Result=financialactivity.Validate_Enter_correct_amount_for_refund(From_date,To_date,Transaction_ID, Refund_amount);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to enter correct amount for refund ","Verify user should be able to enter correct amount for refund ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to enter correct amount for refund ","Verify user should be able to enter correct amount for refund ", Result,"Failed");
	}}
}
@Then("^user should be able to provide separate user right for accessing refund functionality$")
public void user_should_be_able_to_provide_separate_user_right_for_accessing_refund_functionality() throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to provide separate user rights for accessing refund functionality ", "", "", "");
	String Result=financialactivity.user_access_right_for_refund_functionality();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to provide separate user rights for accessing refund functionality ","Verify user should be able to provide separate user rights for accessing refund functionality ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to provide separate user rights for accessing refund functionality ","Verify user should be able to provide separate user rights for accessing refund functionality ", Result,"Failed");
	}
	}
}
@Then("^user should be able to validate preauth validity duration from the date of the preauth transaction by providing \"([^\"]*)\"$")
public void user_should_be_able_to_validate_preauth_validity_duration_from_the_date_of_the_preauth_transaction_by_providing(String Order_ID) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to validate preauth validity duration from the date of the preauth transaction ", "", "", "");
	String Result=financialactivity.Pre_auth_validity_duration_from_the_date_of_the_pre_auth_transaction(Order_ID);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to validate preauth validity duration from the date of the preauth transaction ","Verify user should be able to validate preauth validity duration from the date of the preauth transaction ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to validate preauth validity duration from the date of the preauth transaction ","Verify user should be able to validate preauth validity duration from the date of the preauth transaction ", Result,"Failed");
	}
	}
}	
@Then("^user should be able to validate pre_authorisation transaction to be eligible for pre_auth completion \"([^\"]*)\"$")
public void user_should_be_able_to_validate_pre_authorisation_transaction_to_be_eligible_for_pre_auth_completion(String Order_ID) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to validate pre_authorisation transaction to be eligible for pre_auth completion ", "", "", "");
	String Result=financialactivity.Rules_for_pre_auth_completion(Order_ID);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to validate pre_authorisation transaction to be eligible for pre_auth completion ","Verify user should be able to validate pre_authorisation transaction to be eligible for pre_auth completion ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to validate pre_authorisation transaction to be eligible for pre_auth completion ","Verify user should be able to validate pre_authorisation transaction to be eligible for pre_auth completion ", Result,"Failed");
	}}
}
@Then("^user should be able to validate pre-auth completion to be in the same currency as the preauth amount \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_validate_pre_auth_completion_to_be_in_the_same_currency_as_the_preauth_amount(String Order_ID, String sqlQuery) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", " Verify user should be able to validate pre-auth completion to be in the same currency as the preauth amount ", "", "", "");
	String Result=financialactivity.preauth_completion_to_be_in_the_same_currency_as_the_preauth(Order_ID, sqlQuery);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to validate pre-auth completion to be in the same currency as the preauth amount ","Verify user should be able to validate pre-auth completion to be in the same currency as the preauth amount ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to validate pre-auth completion to be in the same currency as the preauth amount ","Verify user should be able to validate pre-auth completion to be in the same currency as the preauth amount ", Result,"Failed");
	}
	}
}
@Then("^user should be able to validate confirmation page of pre-auth completion \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_validate_confirmation_page_of_preauth_completion(String Order_ID, String sqlQuery) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to validate confirmation page of pre-auth completion ", "", "", "");
	String Result=financialactivity.preauth_completion_to_be_in_the_same_currency_as_the_preauth(Order_ID, sqlQuery);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to validate confirmation page of pre-auth completion ","Verify user should be able to validate confirmation page of pre-auth completion ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to validate confirmation page of pre-auth completion ","Verify user should be able to validate confirmation page of pre-auth completion ", Result,"Failed");
	}}
}
@Then("^user should be able to return to the pre-auth view from the auth completion confirmation screen \"([^\"]*)\"$")
public void user_should_be_able_to_return_to_the_preauth_view_from_the_auth_completion_confirmation_screen(String Order_ID) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to return to the pre-auth view from the auth completion confirmation screen ", "", "", "");
	String Result=financialactivity.return_to_the_preauth_view_from_the_auth_completion_confirmation_screen(Order_ID);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to return to the pre-auth view from the auth completion confirmation screen ","Verify user should be able to return to the pre-auth view from the auth completion confirmation screen ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to return to the pre-auth view from the auth completion confirmation screen ","Verify user should be able to return to the pre-auth view from the auth completion confirmation screen ", Result,"Failed");
	}}
}
@Then("^user should be able to request resending of the passcode \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_request_resending_of_the_passcode(String Order_ID, String sqlQuery) throws Throwable {
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to request resending of the passcode ", "", "", "");
	String Result=financialactivity.request_resending_of_the_passcode_in_pre_auth_completion(Order_ID,sqlQuery);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to request resending of the passcode ","Verify user should be able to request resending of the passcode ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to request resending of the passcode ","Verify user should be able to request resending of the passcode ", Result,"Failed");
	}}
}
@Then("^user should be able to preauth completion cannot be initiated once the preauth validity duration has expired by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_preauth_completion_cannot_be_initiated_once_the_preauth_validity_duration_has_expired_by_providing(String From_date,String To_date,String Order_ID )throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to preauth completion cannot be initiated once the preauth validity duration has expired ", "", "", "");
	String Result=financialactivity.Initiating_preauth_completion_after_the_validity_has_expired(From_date,To_date,Order_ID);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to preauth completion cannot be initiated once the preauth validity duration has expired ","Verify user should be able to preauth completion cannot be initiated once the preauth validity duration has expired ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to preauth completion cannot be initiated once the preauth validity duration has expired ","Verify user should be able to preauth completion cannot be initiated once the preauth validity duration has expired ", Result,"Failed");
	}}
}
@Then("^user should be able to view the available preauth completion amount when an auth completion is initiated by providing \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_view_the_available_preauth_completion_amount_when_an_auth_completion_is_initiated_by_providing(String Order_ID,String sqlQuery)throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to view the available preauth completion amount when an auth completion is initiated ", "", "", "");
	String Result=financialactivity.view_the_available_preauth_completion_amount_when_an_auth_completion_is_initiated(Order_ID,sqlQuery);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to view the available preauth completion amount when an auth completion is initiated ","Verify user should be able to view the available preauth completion amount when an auth completion is initiated ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to view the available preauth completion amount when an auth completion is initiated ","Verify user should be able to view the available preauth completion amount when an auth completion is initiated ", Result,"Failed");
	}}
}
@Then("^user should be able to do full preauth completion on preauthorisation by providing \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_do_full_preauth_completion_on_preauthorisation_by_providing(String Order_ID,String sqlQuery)throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to do full preauth completion on preauthorisation ", "", "", "");
	String Result=financialactivity.Full_preauth_completion_on_preauthorisation(Order_ID,sqlQuery);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to do full preauth completion on preauthorisation ","Verify user should be able to do full preauth completion on preauthorisation ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to do full preauth completion on preauthorisation ","Verify user should be able to do full preauth completion on preauthorisation ", Result,"Failed");
	}}
}
@Then("^user should be able to identify refundable transactions and made available for refund$")
public void user_should_be_able_to_identify_refundable_transactions_and_made_available_for_refund()throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to identify refundable transactions and made available for refund ", "", "", "");
	String Result=financialactivity.Identifying_refundable_transaction();
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to identify refundable transactions and made available for refund ","Verify user should be able to identify refundable transactions and made available for refundn ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to identify refundable transactions and made available for refund ","Verify user should be able to identify refundable transactions and made available for refund ", Result,"Failed");
	}}
}
@Then("^user should be able to view remaining refund amount by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_view_remaining_refund_amount_by_providing(String From_date,String To_date,String Order_ID) throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to view remaining refund amount ", "", "", "");
	String Result=financialactivity.Remaining_refund_amount_for_every_refundable_transaction(From_date,To_date,Order_ID);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to view remaining refund amount ","Verify user should be able to view remaining refund amount ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to view remaining refund amount ","Verify user should be able to view remaining refund amount ", Result,"Failed");
	}}
}
@Then("^user should be able to add unsuccessful refund amount to the remaining refund amount by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_add_unsuccessful_refund_amount_to_the_remaining_refund_amount_by_providing(String From_date,String To_date,String Order_ID,String Refund_amount,String sqlQuery)  throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to add unsuccessful refund amount to the remaining refund amount ", "", "", "");
	String Result=financialactivity.Adjusting_unsuccessful_refund_amount_back_to_remaining_refund_amount(From_date,To_date,Order_ID,Refund_amount,sqlQuery);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to add unsuccessful refund amount to the remaining refund amount ","Verify user should be able to add unsuccessful refund amount to the remaining refund amount ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to add unsuccessful refund amount to the remaining refund amount ","Verify user should be able to add unsuccessful refund amount to the remaining refund amount ", Result,"Failed");
	}}
}
@Then("^user should be able to view successful refunded amount by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_view_successful_refunded_amount_by_providing(String From_date,String To_date,String Order_ID,String Refund_amount,String sqlQuery)  throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to add unsuccessful refund amount to the remaining refund amount ", "", "", "");
	String Result=financialactivity.View_successful_refunded_amount(From_date,To_date,Order_ID,Refund_amount,sqlQuery);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to view successful refunded amount ","Verify user should be able to view successful refunded amount ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to view successful refunded amount ","Verify user should be able to view successful refunded amount ", Result,"Failed");
	}}
}
@Then("^user should be able to view status of refund transaction initiated by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_view_status_of_refund_transaction_initiated_by_providing(String From_date,String To_date,String Order_ID,String Refund_amount,String sqlQuery)  throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to view status of refund transaction initiated ", "", "", "");
	String Result=financialactivity.View_successful_refunded_amount(From_date,To_date,Order_ID,Refund_amount,sqlQuery);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to view status of refund transaction initiated ","Verify user should be able to view status of refund transaction initiated ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to view status of refund transaction initiated ","Verify user should be able to view status of refund transaction initiated ", Result,"Failed");
	}}
}
@Then("^user should be able to validate user mobile number perfoming preauth completion by providing \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_validate_user_mobile_number_perfoming_preauth_completion_by_providing(String Order_ID,String sqlQuery) throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to validate user mobile number perfoming preauth completion ", "", "", "");
	String Result=financialactivity.validation_of_user_mobile_number_perfoming_preauth_completion(Order_ID,sqlQuery);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to validate user mobile number perfoming preauth completion ","Verify user should be able to validate user mobile number perfoming preauth completion ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to validate user mobile number perfoming preauth completion ","Verify user should be able to validate user mobile number perfoming preauth completion", Result,"Failed");
	}}
}
@Then("^user should be able to send passcode to user mobile number for performing refund by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_send_passcode_to_user_mobile_number_for_performing_refund_by_providing(String From_date,String To_date,String Order_ID,String Refund_amount,String sqlQuery)  throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to send passcode to user mobile number for performing refund ", "", "", "");
	String Result=financialactivity.validation_of_user_mobile_number_perfoming_refund(From_date,To_date,Order_ID,Refund_amount,sqlQuery);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to send passcode to user mobile number for performing refund ","Verify user should be able to send passcode to user mobile number for performing refund ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to send passcode to user mobile number for performing refund ","Verify user should be able to send passcode to user mobile number for performing refund ", Result,"Failed");
	}}
}

@Then("^user should be able to have an option to enter passcode received for performing refund by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_have_an_option_to_enter_passcode_received_for_performing_refund_by_providing(String From_date,String To_date,String Order_ID,String Refund_amount,String sqlQuery)  throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to have an option to enter passcode received for performing refund ", "", "", "");
	String Result=financialactivity.Option_to_enter_passcode_received_for_performing_refund(From_date,To_date,Order_ID,Refund_amount,sqlQuery);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to have an option to enter passcode received for performing refund ","Verify user should be able to have an option to enter passcode received for performing refund ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to have an option to enter passcode received for performing refund ","Verify user should be able to have an option to enter passcode received for performing refund ", Result,"Failed");
	}}
}
@Then("^user should be able to review and rectify the refund transaction before confirming the refund processing by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_review_and_rectify_the_refund_transaction_before_confirming_the_refund_processing_by_providing(String From_date,String To_date,String Transaction_ID,String Refund_amount ) throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to review and rectify the refund transaction before confirming the refund ", "", "", "");
	String Result=financialactivity.Validate_Enter_correct_amount_for_refund(From_date,To_date,Transaction_ID, Refund_amount);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to review and rectify the refund transaction before confirming the refund ","Verify user should be able to review and rectify the refund transaction before confirming the refund ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to review and rectify the refund transaction before confirming the refund ","Verify user should be able to review and rectify the refund transaction before confirming the refund ", Result,"Failed");
	}}
}
@Then("^user should be able to modify the original transaction to refund to either do full or partial refund by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_modify_the_original_transaction_to_refund_to_either_do_full_or_partial_refund_by_providing(String From_date,String To_date,String Order_ID,String Refund_amount,String sqlQuery)  throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to modify the original transaction to refund to either do full or partial refund ", "", "", "");
	String Result=financialactivity.View_successful_refunded_amount(From_date,To_date,Order_ID,Refund_amount,sqlQuery);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to modify the original transaction to refund to either do full or partial refund ","Verify user should be able to modify the original transaction to refund to either do full or partial refund ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to modify the original transaction to refund to either do full or partial refund ","Verify user should be able to modify the original transaction to refund to either do full or partial refund ", Result,"Failed");
	}}
}
@Then("^user should be able to request resending of passcode by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_request_resending_of_passcode_by_providing(String From_date,String To_date,String Order_ID,String Refund_amount,String sqlQuery)  throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to request resending of passcode ", "", "", "");
	String Result=financialactivity.Request_resending_of_passcode_for_performing_refund(From_date,To_date,Order_ID,Refund_amount,sqlQuery);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to request resending of passcode ","Verify user should be able to request resending of passcode ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to request resending of passcode ","Verify user should be able to request resending of passcode ", Result,"Failed");
	}}
}
@Then("^user should be able to completely void preauthorisation transactions in the preAuth view by providing \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_completely_void_preauthorisation_transactions_in_the_preAuth_view_by_providing(String Order_ID,String sqlQuery)  throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to completely void preauthorisation transactions in the preAuth view ", "", "", "");
	String Result=financialactivity.Void_preauthorisation_Transactions(Order_ID,sqlQuery);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to completely void preauthorisation transactions in the preAuth view ","Verify user should be able to completely void preauthorisation transactions in the preAuth view ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to completely void preauthorisation transactions in the preAuth view ","Verify user should be able to completely void preauthorisation transactions in the preAuth view ", Result,"Failed");
	}}
}
@Then("^user should be able to view status of the preauth completion transaction in preauth view by providing \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_view_status_of_the_preauth_completion_transaction_in_preauth_view_by_providing(String Order_ID,String sqlQuery)  throws Throwable{
	if(Result1.contains("Passed"))
	{ 
	lib.WriteReportStep("1", "Verify user should be able to view status of the preauth completion transaction in preauth view ", "", "", "");
	String Result=financialactivity.View_status_of_the_preauth_completion_transaction_in_the_preauth(Order_ID,sqlQuery);
	if(Result.contains("Passed"))
	{
		 lib.WriteReportStep("2", "Verify user should be able to view status of the preauth completion transaction in preauth view ","Verify user should be able to view status of the preauth completion transaction in preauth view ", Result,"Passed");
	}
	else
	{
		 lib.WriteReportStep("2", "Verify user should be able to view status of the preauth completion transaction in preauth view ","Verify user should be able to view status of the preauth completion transaction in preauth view ", Result,"Failed");
	}
	}
}
@Then("^user should be able to view the PreAuthorization details in the dashboard along with the expiring preauthorizations$")
public void user_should_be_able_to_view_the_PreAuthorization_details_in_the_dashboard_along_with_the_expiring_preauthorizations() throws Throwable{
	if(Result1.contains("Passed"))
	{    
	lib.WriteReportStep("1", "View PreAuthorization Details", "", "", "");
       try
       {
              String Result=financialactivity.validatePreAuthorizationsDetails();
              if(Result.equalsIgnoreCase("PreAuthorization details are displayed"))
              {
                    lib.WriteReportStep("2", "View PreAuthorization Details","PreAuthorizations details should be available", Result,"Passed");
              }
              else if(Result.contains("the next 3 days"))
              {
                    lib.WriteReportStep("2", "View PreAuthorization Details","PreAuthorizations details should be available", Result,"Passed");
              }
              else
              {
                    lib.WriteReportStep("2", "View PreAuthorization Details","PreAuthorizations details should be available", Result,"Failed");
              }

       }
       catch(Exception e)
       {
              lib.WriteReportStep("2", "View PreAuthorization Details", "PreAuthorizations details should be available", e.getMessage(),"Failed");
              e.printStackTrace();
       }
	}
	
}	
	
	///////////////////////////////////////////////////////////Janani/////////////////////////////////////////////////////////


@And("^user Navigate to UserLists \"([^\"]*)\"$")
public void user_Navigate_to_UserLists(String Device) throws Throwable {
	lib.WriteReportStep("1", "Verify Navigation to UsersList", "", "", "");
	//userManagementPage.navigate_to_UserLists();
	String Result=userManagementPage.navigate_to_UserLists(Device);
	if(Result.contains("Passed"))
	{
	lib.WriteReportStep("2", "Click UsersList", "User should be successfuly navigated to UsersList", "Successfuly navigated to UsersList", "Passed");
	}
	else
	{
	lib.WriteReportStep("2", "Click UsersList", "User should be successfuly navigated to UsersList", "Unable to navigate to UsersList", "Failed");
	}
}

@When("^user clicks search icon using searchtext as \"([^\"]*)\"$")
public void user_clicks_search_icon_using_searchtext_as(String User_Name) throws Throwable {
    lib.WriteReportStep("1", "Enter username & click Search", "", "", "");
    String Result = userManagementPage.Search_Userdetails(User_Name);
    Result1=Result;
	if(Result.contains("Passed"))
	 {
		lib.WriteReportStep("2", "Enter User Name & click Search Icon", "User should be able to view search result for User Name: "+User_Name, "Search Result: "+Result, "Passed");
	 }
	 else
	 {
		 lib.WriteReportStep("2", "Enter User Name & click Search Icon", "User should be able to view search result for User Name: "+User_Name, "Search Result: "+Result, "Failed");
	 }
	
}

@Then("^user should be able to modify user details for the desired user for fields \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_modify_user_details_for_the_desired_user_for_fields(String First_Name, String Last_Name, String Email, String Mobile_Phone, String Phone_Number) throws Throwable {
	lib.WriteReportStep("1", "Modify User details", "", "", "");
	if (Result1.contains("Passed"))
	{
		String Result = userManagementPage.Modify_Userdetails(First_Name, Last_Name, Email, Mobile_Phone, Phone_Number);
		if(Result.contains("Passed"))
		 {
			lib.WriteReportStep("2", "Modify User details", "User should be able to modify user details", "User details modified successfully: " + Result, "Passed");
		 }
		 else
		 {
			 lib.WriteReportStep("2", "Modify User details", "User should be able to modify user details", "Unable to modify user details: " + Result, "Failed");
		 }
	}
	else
	 {
		 lib.WriteReportStep("2", "Modify User details", "User should be able to modify user details", "Unable to modify user details, No Result Found", "Failed");
	 }
}
	
@And("^Navigates to User Management$")
public void Navigates_to_User_Management() throws Throwable {
	lib.WriteReportStep("1", "Verify Navigation to User Management", "", "", "");
	String Result=userManagementPage.navigate_to_User_Management();
	Result1=Result;
	if(Result.contains("Passed"))
	{
	lib.WriteReportStep("2", "Click User Management", "User should be successfuly navigated to User Management", Result, "Passed");
	}
	else
	{
	lib.WriteReportStep("2", "Click User Management", "User should be successfuly navigated to User Management", Result, "Failed");
	}
}

@And("^Navigates to Manage user access for the user \"([^\"]*)\" , \"([^\"]*)\"$")
public void navigates_to_Manage_user_access_for_the_user(String User_Name , String Device) throws Throwable {
	if (Result1.contains("Passed"))
	{
		lib.WriteReportStep("1", "Verify Navigation to Manage user access", "", "", "");
		String Result=userManagementPage.navigate_to_Manage_user_access(User_Name, Device);
		Result1=Result;
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Search for User Name and navigate to Manage user access", "User should be successfuly navigated to Manage user access", "Successfuly navigated to Manage user access", "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Search for User Name and navigate to Manage user access", "User should be successfuly navigated to Manage user access", "Unable to navigate to Manage user access; "+Result, "Failed");
		}
	}
}

@Then("^user should be able to provide reason \"([^\"]*)\" for blocking sub-account$")
public void user_should_be_able_to_provide_reason_for_blocking_sub_account(String reason) throws Throwable {
	lib.WriteReportStep("1", "Block the user with approriate reason", "", "", "");
	if (Result1.contains("Passed"))
	{
	String Result=userManagementPage.user_should_be_able_to_provide_reason_for_blocking_sub_account(reason);
	
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Update Profile access and Reason for change in access", "User should successfuly be able to Update Profile access and Reason for change in access", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Update Profile access and Reason for change in access", "User should successfuly be able to Update Profile access and Reason for change in access", Result, "Failed");
		}
	}
	else
	 {
		 lib.WriteReportStep("2", "Modify User details", "User should be able to modify user details", "Unable to modify user details, No Result Found", "Failed");
	 }

}

@Then("^user should be able to view revenue for each payment type$")
public void user_should_be_able_to_view_revenue_for_each_payment_type() throws Throwable {
	lib.WriteReportStep("1", "View revenue for each payment type", "", "", "");
	String Result=dashboardpage.user_should_be_able_to_view_revenue_for_each_payment_type();
	if(Result.contains("Passed"))
	{
	lib.WriteReportStep("2", "View revenue for each payment type", "User should successfuly be able to view revenue for each payment type", Result, "Passed");
	}
	else
	{
	lib.WriteReportStep("2", "View revenue for each payment type", "User should successfuly be able to view revenue for each payment type", Result, "Failed");
	}
}

@Then("^user should be able to view payment details$")
public void user_should_be_able_to_view_payment_details() throws Throwable {
	lib.WriteReportStep("1", "View payment details", "", "", "");
	String Result=dashboardpage.user_should_be_able_to_view_payment_details();
	if(Result.contains("Passed"))
	{
	lib.WriteReportStep("2", "Click View details link", "User should successfuly be able to view payment details", Result, "Passed");
	}
	else
	{
	lib.WriteReportStep("2", "Click View details link", "User should successfuly be able to view payment details", Result, "Failed");
	}
}

@Then("^user should not be able to view Mark for Expiry$")
public void user_should_not_be_able_to_view_Mark_for_Expiry() throws Throwable {
	lib.WriteReportStep("1", "Verify if user is not be able to view Mark for Expiry", "", "", "");
	if (Result1.contains("Passed"))
	{
	String Result=userManagementPage.user_should_not_be_able_to_view_Mark_for_Expiry();
	
		if(Result.equals("Passed"))
		{
		lib.WriteReportStep("2", "Verify if user is not be able to view Mark for Expiry", "User should not be able to view Mark for Expiry", "User is not able to view Mark for Expiry", "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Verify if user is not be able to view Mark for Expiry", "User should not be able to view Mark for Expiry", "User is able to view Mark for Expiry", "Failed");
		}
	}
	else
	 {
		 lib.WriteReportStep("2", "Verify if user is not be able to view Mark for Expiry", "User should not be able to view Mark for Expiry", "Unable to verify, No Result Found", "Failed");
	 }
}

@Then("^user should not be able to view option to terminate all additional users$")
public void user_should_not_be_able_to_view_option_to_terminate_all_additional_users() throws Throwable {
	if (Result1.contains("Passed"))
	{
	lib.WriteReportStep("1", "View Checkbox to select all users", "", "", "");
	String Result=userManagementPage.user_should_not_be_able_to_view_option_to_terminate_all_additional_users();
	if(Result.contains("Passed"))
	{
	lib.WriteReportStep("2", "Verify if Checkbox exist in the page", "Checkbox should not be available in the page and hence user should have no option to terminate all additional users", Result, "Passed");
	}
	else
	{
	lib.WriteReportStep("2", "Verify if Checkbox exist in the page", "Checkbox should not be available in the page and hence user should have no option to terminate all additional users", Result, "Failed");
	}
	}
}

@Then("^access should be restricted for additional BO user to modify \"([^\"]*)\", \"([^\"]*)\"$")
public void access_should_be_restricted_for_additional_BO_user_to_modify(String original_BO_accounts, String Device) throws Throwable {
	if (Result1.contains("Passed"))
	{
	lib.WriteReportStep("1", "Search for Original BO Accounts", "", "", "");
	String Result=userManagementPage.access_should_be_restricted_for_additional_BO_user_to_modify(original_BO_accounts, Device);
	if(Result.contains("Passed"))
	{
	lib.WriteReportStep("2", "Search for Original BO Accounts", "User should not find Original BO Accounts in search result", Result, "Passed");
	}
	else
	{
	lib.WriteReportStep("2", "Search for Original BO Accounts", "User should not find Original BO Accounts in search result", Result, "Failed");
	}
	}
}
 
@Then("^user clicks submit and should be logged in as call center agent$")
public void user_clicks_submit_and_should_be_logged_in_as_call_center_agent() throws Throwable {
	 lib.WriteReportStep("1", "Login to the application", "", "", "");
	 String Result= signonpage.user_clicks_submit_and_should_be_logged_in_as_call_center_agent();
	 if(Result.contains("Passed"))
	 {
		 lib.WriteReportStep("2", "Verify Login","User should be logged in Call center agent", Result,"Passed");
	 }
	 else
	 {
		 lib.WriteReportStep("2", "Verify Login","User should be logged in Call center agent", Result,"Failed");
	 }
	 
}

@And("^Navigates to Settings$")
public void Navigates_to_Settings() throws Throwable {
	lib.WriteReportStep("1", "Verify Navigation to Settings", "", "", "");
	String Result=userManagementPage.Navigates_to_Settings();
	Result1=Result;
	if(Result.contains("Passed"))
	{
	lib.WriteReportStep("2", "Click Settings", "User should be successfuly navigated to Settings", "Successfuly navigated to Settings", "Passed");
	}
	else
	{
	lib.WriteReportStep("2", "Click Settings", "User should be successfuly navigated to Settings", "Unable to navigate to Settings", "Failed");
	}
}
@Then("^username should be same as email address$")
public void username_should_be_same_as_email_address() throws Throwable {
	lib.WriteReportStep("1", "Verify if username is same as email address", "", "", "");
	String Result=userManagementPage.username_should_be_same_as_email_address();
	if(Result1.contains("Passed"))
	{
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Verify if username is same as Email address", "Username should be same as Email address", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Verify if username is same as Email address", "Username should be same as Email address", Result, "Failed");
		}
	}
}
@And("^user Navigate to Communication summary \"([^\"]*)\"$")
public void user_Navigate_to_Communication_summary(String Device) throws Throwable {
	lib.WriteReportStep("1", "Verify Navigation to Communication Summary", "", "", "");
	String Result=userManagementPage.user_Navigate_to_Communication_summary(Device);
	Result1=Result;
	if(Result.contains("Passed"))
	{
	lib.WriteReportStep("2", "Click Communication Summary", "User should be successfuly navigated to Communication Summary", "Successfuly navigated to Communication Summary", "Passed");
	}
	else
	{
	lib.WriteReportStep("2", "Click Communication Summary", "User should be successfuly navigated to Communication Summary", "Unable to navigate to Communication Summary", "Failed");
	}
}
@Then("^user should be able to view communication history for Email and SMS \"([^\"]*)\"$")
public void user_should_be_able_to_view_communication_history_for_Email_and_SMS(String Device) throws Throwable {
	lib.WriteReportStep("1", "View Communication History for Email and SMS", "", "", "");
	String Result=userManagementPage.user_should_be_able_to_view_communication_history_for_Email_and_SMS(Device);
	if(Result.contains("Passed"))
	{
	lib.WriteReportStep("2", "Verify if user is able to view communication History for Email and SMS", "User should be able to view communication History for Email and SMS", "User is able to view communication History for Email and SMS", "Passed");
	}
	else
	{
	lib.WriteReportStep("2", "Verify if user is able to view communication History for Email and SMS", "User should be able to view communication History for Email and SMS", "User is not able to view communication History for Email and SMS", "Failed");
	}
}
@Then("^user should be able to Resend previous communications via email$")
public void user_should_be_able_to_Resend_previous_communications_via_email() throws Throwable {
	if(Result1.contains("Passed"))
	{
		lib.WriteReportStep("1", "Resend previous communications via e-mail", "", "", "");
		String Result=userManagementPage.user_should_be_able_to_Resend_previous_communications_via_email();
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Verify if user is able to Resend previous communications via e-mail", "User should be able to Resend previous communications via e-mail", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Verify if user is able to Resend previous communications via e-mail", "User should be able to Resend previous communications via e-mail", "User is not able to Resend previous communications via e-mail", "Failed");
		}
	}
}
@When("^agent enter merchant user name \"([^\"]*)\"$")
public void agent_enter_merchant_user_name(String BOusername) throws Throwable {
	lib.WriteReportStep("1", "Impersonate as Merchant", "", "", "");
	String Result=financialactivity.agent_enter_merchant_user_name(BOusername);
	if(Result.contains("Passed"))
	{
	lib.WriteReportStep("2", "Impersonate as Merchant", "Agent should successfully be able to impersonate as merchant", Result, "Passed");
	}
	else
	{
	lib.WriteReportStep("2", "Impersonate as Merchant", "Agent should successfully be able to impersonate as merchant", Result, "Failed");
	}
}
@And("^Navigate to Preauthorization$")
public void Navigate_to_Preauthorization() throws Throwable {
	lib.WriteReportStep("1", "Verify Navigation to Pre-authorization", "", "", "");
	String Result=financialactivity.Navigate_to_Preauthorization();
	Result1=Result;
	if(Result.contains("Passed"))
	{
	lib.WriteReportStep("2", "Click Pre-authorization", "User should be successfuly navigated to Pre-authorization", "Successfuly navigated to Pre-authorization", "Passed");
	}
	else
	{
	lib.WriteReportStep("2", "Click Pre-authorization", "User should be successfuly navigated to Pre-authorization", "Unable to navigate to Pre-authorization", "Failed");
	}
}
@Then("^user should not be able to view Complete preauthorization and Void button$")
public void user_should_not_be_able_to_view_Complete_preauthorization_and_Void_button() throws Throwable {
	lib.WriteReportStep("1", "Verify if Call center agent access the portal in read only mode ", "", "", "");
	String Result=financialactivity.user_should_not_be_able_to_view_Complete_preauthorization_and_Void_button();
	if(Result.contains("Passed"))
	{
	lib.WriteReportStep("2", "Verify if Complete preauthorization and Void buttons are not present", "Complete preauthorization and Void buttons should not be present", "Complete preauthorization and Void buttons is not present", "Passed");
	}
	else
	{
	lib.WriteReportStep("2", "Verify if Complete preauthorization and Void buttons are not present", "Complete preauthorization and Void buttons should not be present", Result, "Failed");
	}
}
@Then("^user should be able to view Approval widget for the day$")
public void user_should_be_able_to_view_Approval_widget_for_the_day() throws Throwable {
	lib.WriteReportStep("1", "View Approval widget for the day", "", "", "");
	String Result=dashboardpage.user_should_be_able_to_view_Approval_widget_for_the_day();
	if(Result.contains("Passed"))
	{
	lib.WriteReportStep("2", "View Approval widget for the day", "User should successfuly be able to view Approval widget for the day", Result, "Passed");
	}
	else
	{
	lib.WriteReportStep("2", "View Approval widget for the day", "User should successfuly be able to view Approval widget for the day", Result, "Failed");
	}
}
@And("^Navigates to Edit user details for the user \"([^\"]*)\", \"([^\"]*)\"$")
public void navigates_to_Edit_user_details_for_the_user(String User_Name, String Device) throws Throwable {
	lib.WriteReportStep("1", "Verify Navigation to Edit user details", "", "", "");
	String Result=userManagementPage.navigate_to_Edit_user_details(User_Name, Device);
	Result1=Result;
	if(Result.contains("Passed"))
	{
	lib.WriteReportStep("2", "Search for User Name and navigate to Edit user details", "User should be successfuly navigated to Edit user details", "Successfuly navigated to Edit user details", "Passed");
	}
	else
	{
	lib.WriteReportStep("2", "Search for User Name and navigate to Edit user details", "User should be successfuly navigated to Edit user details", "Unable to navigate to Edit user details; "+Result, "Failed");
	}
}

@Then("^user should be able to edit \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_edit(String Firstname, String Lastname, String Email, String mobileno, String telphoneno, String Profile) throws Throwable {
	if (Result1.contains("Passed"))
	{
	lib.WriteReportStep("1", "Edit User Details", "", "", "");
	String Result=userManagementPage.user_should_be_able_to_edit(Firstname, Lastname, Email, mobileno, telphoneno, Profile);
	
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Edit User details", "User should successfuly be able to edit user details", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Edit User details", "User should successfuly be able to edit user details", Result, "Failed");
		}
	}
	else
	 {
		 lib.WriteReportStep("2", "Modify User details", "User should be able to modify user details", "Unable to modify user details, No Result Found", "Failed");
	 }

}

@And("^Click Create User$")
public void Click_Create_User() throws Throwable {
	if (Result1.contains("Passed"))
	{
		lib.WriteReportStep("1", "Verify Navigation to Create User", "", "", "");
		String Result=userManagementPage.Click_Create_User();
		Result1=Result;
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Click Create User", "User should be successfuly navigated to Create new user page", "Successfuly navigated to Create new user page", "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Click Create User", "User should be successfuly navigated to Create new user page", "Unable to navigate to Create new user page", "Failed");
		}
	}
}

@Then("^user should be able to provide BO Profile to additional users \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_provide_BO_Profile_to_additional_users(String Firstname, String Lastname, String User_name, String Email, String mobileno, String telphoneno) throws Throwable {
	if (Result1.contains("Passed"))
	{
	lib.WriteReportStep("1", "Create additional user and provide BO Profile", "", "", "");
	String Result=userManagementPage.user_should_be_able_to_provide_BO_Profile_to_additional_users(Firstname, Lastname, User_name, Email, mobileno, telphoneno);
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Create additional user and provide BO Profile", "User should successfuly be able to Create additional user and provide BO Profile", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Create additional user and provide BO Profile", "User should successfuly be able to Create additional user and provide BO Profile", Result, "Failed");
		}
	}
}

@And("^Navigate to Transactions$")
public void Navigate_to_Transactions() throws Throwable {
	lib.WriteReportStep("1", "Verify Navigation to Transactions", "", "", "");
	String Result=financialactivity.Navigate_to_Transactions();
	Result1=Result;
	if(Result.contains("Passed"))
	{
	lib.WriteReportStep("2", "Click Transactions", "User should be successfuly navigated to Transactions", Result, "Passed");
	}
	else
	{
	lib.WriteReportStep("2", "Click Transactions", "User should be successfuly navigated to Transactions", Result, "Failed");
	}
}

@Then("^user should be able to navigate to top and bottom of transaction list$")
public void user_should_be_able_to_navigate_to_top_and_bottom_of_transaction_list() throws Throwable {
	if(Result1.contains("Passed"))
	{
	lib.WriteReportStep("1", "Verify Navigation to top and bottom of transaction list", "", "", "");
	String Result=financialactivity.user_should_be_able_to_navigate_to_top_and_bottom_of_transaction_list();
	if(Result.contains("Passed"))
	{
	lib.WriteReportStep("2", "Navigate to Top and bottom of transaction list", "User should be successfuly navigated to Top & bottom of transaction list", Result, "Passed");
	}
	else
	{
	lib.WriteReportStep("2", "Navigate to Top and bottom of transaction list", "User should be successfuly navigated to Top & bottom of transaction list", Result, "Failed");
	}
	}
}

@And("^save column preference in Transactions \"([^\"]*)\"$")
public void save_column_preference(String Device) throws Throwable {
	lib.WriteReportStep("1", "Save column preference in Transactions", "", "", "");
	String Result=financialactivity.save_column_preference_in_Transactions(Device);
	if(Result.contains("Passed"))
	{
	lib.WriteReportStep("2", "Save column preference in Transactions", "User should successfuly be able to Save column preference", Result, "Passed");
	}
	else
	{
	lib.WriteReportStep("2", "Save column preference in Transactions", "User should successfuly be able to Save column preference", Result, "Failed");
	}
}

@And("^Navigate to Authorization$")
public void Navigate_to_Authorization() throws Throwable {
	lib.WriteReportStep("1", "Verify Navigate to Authorization", "", "", "");
	String Result=financialactivity.Navigate_to_Authorization();
	Result1=Result;
	if(Result.contains("Passed"))
	{
	lib.WriteReportStep("2", "Click Authorization", "User should be successfuly navigated to Authorization", Result, "Passed");
	}
	else
	{
	lib.WriteReportStep("2", "Click Authorization", "User should be successfuly navigated to Authorization", Result, "Failed");
	}
}
@And("^save column preference in Authorization \"([^\"]*)\"$")
public void save_column_preference_in_Authorization(String Device) throws Throwable {
	lib.WriteReportStep("1", "Save column preference in Authorization", "", "", "");
	String Result=financialactivity.save_column_preference_in_Authorization(Device);
	if(Result.contains("Passed"))
	{
	lib.WriteReportStep("2", "Save column preference in Authorization", "User should successfuly be able to Save column preference", Result, "Passed");
	}
	else
	{
	lib.WriteReportStep("2", "Save column preference in Authorization", "User should successfuly be able to Save column preference", Result, "Failed");
	}
}
@And("^Logout of the applciation$")
public void Logout_of_the_applciation() throws Throwable {
	lib.WriteReportStep("1", "Logout of the applciation", "", "", "");
	String Result=dashboardpage.Logout_of_the_applciation();
	if(Result.contains("Passed"))
	{
	lib.WriteReportStep("2", "Logout of the applciation", "User should successfuly be Logged out of the applciation", Result, "Passed");
	}
	else
	{
	lib.WriteReportStep("2", "Logout of the applciation", "User should successfuly be Logged out of the applciation", Result, "Failed");
	}
}
@Then("^user should able to view Choosen column in Authorization \"([^\"]*)\"$")
public void user_should_able_to_view_Choosen_column_in_Authorization(String Device) throws Throwable {
	lib.WriteReportStep("1", "Verify if saved column preference is displayed in future login", "", "", "");
	String Result=financialactivity.user_should_able_to_view_Choosen_column_in_Authorization(Device);
	if(Result.contains("Passed"))
	{
	lib.WriteReportStep("2", "Verify if saved column preference is displayed in future login", "User should successfuly be able to view saved column preference in future login", Result, "Passed");
	}
	else
	{
	lib.WriteReportStep("2", "Verify if saved column preference is displayed in future login", "User should successfuly be able to view saved column preference in future login", Result, "Failed");
	}
}
@Then("^user should able to view Choosen column in Transactions \"([^\"]*)\"$")
public void user_should_able_to_view_Choosen_column_in_Transactions(String Device) throws Throwable {
	lib.WriteReportStep("1", "Verify if saved column preference is displayed in future login", "", "", "");
	String Result=financialactivity.user_should_able_to_view_Choosen_column_in_Transactions(Device);
	if(Result.contains("Passed"))
	{
	lib.WriteReportStep("2", "Verify if saved column preference is displayed in future login", "User should successfuly be able to view saved column preference in future login", Result, "Passed");
	}
	else
	{
	lib.WriteReportStep("2", "Verify if saved column preference is displayed in future login", "User should successfuly be able to view saved column preference in future login", Result, "Failed");
	}
}
@Then("^user should be able to Create new user \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_Create_new_user(String Firstname, String Lastname, String User_name, String Email, String mobileno, String telphoneno, String Profile) throws Throwable {
	if (Result1.contains("Passed"))
	{
	lib.WriteReportStep("1", "Create New User", "", "", "");
	String Result=userManagementPage.user_should_be_able_to_Create_new_user(Firstname, Lastname, User_name, Email, mobileno, telphoneno, Profile);
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Create New User", "User should successfuly be able to Create new user", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Create new User", "User should successfuly be able to Create new user", Result, "Failed");
		}
	}
}

@Then("^should be able to view User \"([^\"]*)\", \"([^\"]*)\" created by the BO$")
public void should_be_able_to_view_User_created_by_the_BO(String AdditionalUser, String Device) throws Throwable {
	if (Result1.contains("Passed"))
	{
		lib.WriteReportStep("1", "View the user", "", "", "");
		String Result=userManagementPage.should_be_able_to_view_User_created_by_the_BO(AdditionalUser, Device);
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Search for User Name and view user", "User should successfuly be able to view user", "Successfuly viewed user", "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Search for User Name and view user", "User should successfuly be able to view user", "Unable to view user; "+Result, "Failed");
		}
	}
}

@Then("^user should be able to unblock sub-account$")
public void user_should_be_able_to_unblock_sub_account() throws Throwable {
	if (Result1.contains("Passed"))
	{
		lib.WriteReportStep("1", "Unblock the user", "", "", "");
		String Result=userManagementPage.user_should_be_able_to_unblock_sub_account();
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Modify User details", "User should successfuly be able to Unblock the user", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Modify User details", "User should successfuly be able to Unblock the user", Result, "Failed");
		}
	}
	else
	 {
		 lib.WriteReportStep("2", "Modify User details", "User should be able to modify user details", "Unable to modify user details, No Result Found", "Failed");
	 }
}

@Then("^user should be able to Terminate sub-account$")
public void user_should_be_able_to_Terminate_sub_account() throws Throwable {
	if (Result1.contains("Passed"))
	{
		lib.WriteReportStep("1", "Terminate the user", "", "", "");
		String Result=userManagementPage.user_should_be_able_to_Terminate_sub_account();
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Modify User details", "User should successfuly be able to Terminate the user", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Modify User details", "User should successfuly be able to Terminate the user", Result, "Failed");
		}
	}
	else
	 {
		 lib.WriteReportStep("2", "Modify User details", "User should be able to modify user details", "Unable to modify user details, No Result Found", "Failed");
	 }
}
@Then("^validate Preauth confirmation screen for OrderID \"([^\"]*)\", \"([^\"]*)\"$")
public void validate_Preauth_confirmation_screen_for_OrderID(String Order_ID, String Device) throws Throwable {
	if (Result1.contains("Passed"))
	{
		lib.WriteReportStep("1", "Validate Preauth confirmation screen", "", "", "");
		String Result=financialactivity.validate_Preauth_confirmation_screen_for_OrderID(Order_ID, Device);
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Validate Preauth confirmation screen", "User should successfuly be able to validate Preauth confirmation screen", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Validate Preauth confirmation screen", "User should successfuly be able to validate Preauth confirmation screen", Result, "Failed");
		}
	}
}
@Then("^validate auth confirmation screen for OrderID \"([^\"]*)\", \"([^\"]*)\"$")
public void validate_auth_confirmation_screen_for_OrderID(String OrderID, String Device) throws Throwable {
	if (Result1.contains("Passed"))
	{
		lib.WriteReportStep("1", "Validate Auth confirmation screen", "", "", "");
		String Result=financialactivity.validate_auth_confirmation_screen_for_OrderID(OrderID, Device);
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Validate Auth confirmation screen", "User should successfuly be able to validate Auth confirmation screen", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Validate Auth confirmation screen", "User should successfuly be able to validate Auth confirmation screen", Result, "Failed");
		}
	}
}
@Then("^Return from void confirmation back to preauth view for OrderID \"([^\"]*)\", \"([^\"]*)\"$")
public void Return_from_void_confirmation_back_to_preauth_view_for_OrderID(String Order_ID, String Device) throws Throwable {
	if (Result1.contains("Passed"))
	{
		lib.WriteReportStep("1", "Validate Return from void confirmation back to preauth view", "", "", "");
		String Result=financialactivity.Return_from_void_confirmation_back_to_preauth_view_for_OrderID(Order_ID, Device);
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Validate Return from void confirmation back to preauth view", "User should successfuly be able to Return from void confirmation back to preauth view", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Validate Return from void confirmation back to preauth view", "User should successfuly be able to Return from void confirmation back to preauth view", Result, "Failed");
		}
	}
}
@Then("^Return from void confirmation back to authorization view for OrderID \"([^\"]*)\", \"([^\"]*)\"$")
public void Return_from_void_confirmation_back_to_authorization_view_for_OrderID (String OrderID, String Device) throws Throwable {
	if (Result1.contains("Passed"))
	{
		lib.WriteReportStep("1", "Validate Return from void confirmation back to authorization view", "", "", "");
		String Result=financialactivity.Return_from_void_confirmation_back_to_authorization_view_for_OrderID(OrderID, Device);
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Validate Return from void confirmation back to authorization view", "User should successfuly be able to Return from void confirmation back to authorization view", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Validate Return from void confirmation back to authorization view", "User should successfuly be able to Return from void confirmation back to authorization view", Result, "Failed");
		}
	}
}

@Then("^verify void on transaction past today in authorization view for OrderID \"([^\"]*)\", \"([^\"]*)\"$")
public void verify_void_on_transaction_past_today_in_authorization_view_for_OrderID (String OrderID, String Device) throws Throwable {
	if (Result1.contains("Passed"))
	{
		lib.WriteReportStep("1", "verify void on transaction past today in authorization view", "", "", "");
		String Result=financialactivity.verify_void_on_transaction_past_today_in_authorization_view_for_OrderID(OrderID, Device);
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "verify void on transaction past today in authorization view", "Void should not be available for transaction past today in authorization view", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "verify void on transaction past today in authorization view", "Void should not be available for transaction past today in authorization view", Result, "Failed");
		}
	}
}

@Then("^user should be able to filter transaction in transaction view \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_filter_transaction_in_transaction_view (String OrderID, String MerchantID, String StoreID, String Authcode, String txnID, String CardNumber, String ChannelType, String Txntype, String AmtFrom, String AmtTo, String Device) throws Throwable {
	if (Result1.contains("Passed"))
	{
		lib.WriteReportStep("1", "verify filter of transaction in transaction view", "", "", "");
		String Result=financialactivity.user_should_be_able_to_filter_transaction_in_transaction_view(OrderID, MerchantID, StoreID, Authcode, txnID, CardNumber, ChannelType, Txntype, AmtFrom, AmtTo, Device);
		if(Result.contains("Failed"))
		{
		lib.WriteReportStep("2", "verify if user is able to filter transaction in transaction view", "User should be able to filter transaction in transaction view", Result, "Failed");
		}
		else
		{
		lib.WriteReportStep("2", "verify if user is able to filter transaction in transaction view", "User should be able to filter transaction in transaction view", Result, "Passed");
		}
	}
}

@Then("^user should be able to view refund button in transaction view \"([^\"]*)\" , \"([^\"]*)\"$")
public void user_should_be_able_to_view_refund_button_in_transaction_view (String txnID, String Device) throws Throwable {
	if (Result1.contains("Passed"))
	{
		lib.WriteReportStep("1", "verify Refund button transaction view", "", "", "");
		String Result=financialactivity.user_should_be_able_to_view_refund_button_in_transaction_view(txnID, Device);
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "verify if user is able to view Refund button in transaction view", "User should be able to view Refund button in transaction view", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "verify if user is able to view Refund button in transaction view", "User should be able to view Refund button in transaction view", Result, "Failed");
		}
	}
}

@Then("^validate presence of void button in Preauth view for OrderID \"([^\"]*)\", \"([^\"]*)\"$")
public void validate_presence_of_void_button_in_Preauth_view_for_OrderID(String Order_ID, String Device) throws Throwable {
	if (Result1.contains("Passed"))
	{
		lib.WriteReportStep("1", "Validate presence of void button in Preauth view", "", "", "");
		String Result=financialactivity.validate_presence_of_void_button_in_Preauth_view_for_OrderID(Order_ID, Device);
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Validate presence of void button in Preauth view", "User should successfuly be able to validate presence of void button in Preauth view", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Validate presence of void button in Preauth view", "User should successfuly be able to validate presence of void button in Preauth view", Result, "Failed");
		}
	}
}

@Then("^validate presence of void button in auth view for OrderID \"([^\"]*)\", \"([^\"]*)\"$")
public void validate_presence_of_void_button_in_auth_view_for_OrderID(String OrderID, String Device) throws Throwable {
	if (Result1.contains("Passed"))
	{
		lib.WriteReportStep("1", "Validate presence of void button in Authorization view", "", "", "");
		String Result=financialactivity.validate_presence_of_void_button_in_auth_view_for_OrderID(OrderID, Device);
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Validate presence of void button in Authorization view", "User should successfuly be able to validate presence of void button in Authorization view", Result, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Validate presence of void button in Authorization view", "User should successfuly be able to validate presence of void button in Authorization view", Result, "Failed");
		}
	}
}

@Then("^user should be able to filter transaction in Authorisation view \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_filter_transaction_in_Authorisation_view (String OrderID, String MerchantID, String StoreID, String Authcode, String CardNumber, String ChannelType, String Authtype, String AmtFrom, String AmtTo, String Device) throws Throwable {
	if (Result1.contains("Passed"))
	{
		lib.WriteReportStep("1", "verify filter of transaction in Authorisation view", "", "", "");
		String Result=financialactivity.user_should_be_able_to_filter_transaction_in_Authorisation_view(OrderID, MerchantID, StoreID, Authcode, CardNumber, ChannelType, Authtype, AmtFrom, AmtTo, Device);
		if(Result.contains("Failed"))
		{
		lib.WriteReportStep("2", "verify if user is able to filter transaction in Authorisation view", "User should be able to filter transaction in Authorisation view", Result, "Failed");
		}
		else
		{
		lib.WriteReportStep("2", "verify if user is able to filter transaction in Authorisation view", "User should be able to filter transaction in Authorisation view", Result, "Passed");
		}
	}
}

@Then("^user should be able to filter transaction in Preauthorisation view \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\",\"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_be_able_to_filter_transaction_in_Preauthorisation_view (String OrderID, String MerchantID, String StoreID, String Preauthcode, String Reservationno, String CardNumber, String ChannelType, String Txntype, String AmtFrom, String AmtTo, String Device) throws Throwable {
	if (Result1.contains("Passed"))
	{
		lib.WriteReportStep("1", "verify filter of transaction in Preauthorisation view", "", "", "");
		String Result=financialactivity.user_should_be_able_to_filter_transaction_in_Preauthorisation_view(OrderID, MerchantID, StoreID, Preauthcode, Reservationno, CardNumber, ChannelType, Txntype, AmtFrom, AmtTo, Device);
		if(Result.contains("Failed"))
		{
		lib.WriteReportStep("2", "verify if user is able to filter transaction in Preauthorisation view", "User should be able to filter transaction in Authorisation view", Result, "Failed");
		}
		else
		{
		lib.WriteReportStep("2", "verify if user is able to filter transaction in Preauthorisation view", "User should be able to filter transaction in Authorisation view", Result, "Passed");
		}
	}
}

@Then("^user should change the Language code to \"([^\"]*)\" and validate the dashboard$")
public void user_should_change_the_Language_code_to_and_validate_the_dashboard(String arg1) throws Throwable {
       lib.WriteReportStep("1", "Verify Language_code change", "", "", "");
       System.out.println(arg1);
       String Result=dashboardpage.Change_Language_code(arg1);
       if(Result.contains("Passed"))
       {
              lib.WriteReportStep("2", "Verify Language_code change","Verify Language_code change", Result,"Passed");
       }
       else
       {
              lib.WriteReportStep("2", "Verify Language_code change","Verify Language_code change", Result,"Failed");
       }
}

@Then("^user should see Portal transaction data in corresponding language \"([^\"]*)\", \"([^\"]*)\"$")
public void user_should_see_Portal_transaction_data_in_corresponding_language (String PortalLanguage , String Device) throws Throwable {
	lib.WriteReportStep("1", "Verify display of transaction data in corresponding language", "", "", "");
	String Result=financialactivity.user_should_see_Portal_transaction_data_in_corresponding_language(PortalLanguage, Device);
	if(Result.contains("Passed"))
	{
	lib.WriteReportStep("2", "Verify display of transaction data in corresponding language", "User should be able to view transaction data in corresponding language", Result, "Passed");
	}
	else
	{
	lib.WriteReportStep("2", "Verify display of transaction data in corresponding language", "User should be able to view transaction data in corresponding language", Result, "Failed");
	}
}

@Then("^view Fees displayed in 3 decimal format in Transaction view \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
public void view_Fees_displayed_in_3_decimal_format_in_Transaction_view (String FromDate, String ToDate, String TxnID, String Device) throws Throwable {
	if (Result1.contains("Passed"))
	{
		lib.WriteReportStep("1", "verify if Fees is displayed in 3 decimal format in Transaction view for Maestor / Visa Brand", "", "", "");
		String Result=financialactivity.view_Fees_displayed_in_3_decimal_format_in_Transaction_view(FromDate, ToDate, TxnID, Device);
		if(Result.contains("Failed"))
		{
		lib.WriteReportStep("2", "verify if Fees is displayed in 3 decimal format in Transaction view for Maestor / Visa Brand", "User should be able to view Fees displayed in 3 decimal format in Transaction view for Maestor / Visa Brand", Result, "Failed");
		}
		else
		{
		lib.WriteReportStep("2", "verify if Fees is displayed in 3 decimal format in Transaction view for Maestor / Visa Brand", "User should be able to view Fees displayed in 3 decimal format in Transaction view for Maestor / Visa Brand", Result, "Passed");
		}
	}
}

@Then("^user should be able to view Preauthorisations in Preauth view$")
public void user_should_be_able_to_view_Preauthorisations_in_Preauth_view() throws Throwable {
	if (Result1.contains("Passed"))
	{
		lib.WriteReportStep("1", "Verify if user is be able to view Preauthorisations in Preauth view", "", "", "");
		String Result=financialactivity.user_should_be_able_to_view_Preauthorisations_in_Preauth_view();
		if(Result.contains("Passed"))
		{
		lib.WriteReportStep("2", "Verify if user is be able to view Preauthorisations in Preauth view", "User should be able to view Preauthorisations in Preauth view","The PreAuth Details are:"+financialactivity.TempResult, "Passed");
		}
		else
		{
		lib.WriteReportStep("2", "Verify if user is be able to view Preauthorisations in Preauth view", "User should be able to view Preauthorisations in Preauth view", Result, "Failed");
		}
	}
}
}

