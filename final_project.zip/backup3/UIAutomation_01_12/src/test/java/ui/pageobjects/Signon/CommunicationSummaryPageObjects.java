package ui.pageobjects.Signon;

import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class CommunicationSummaryPageObjects extends PageObject{
	
	@FindBy(css="div#mainPanel > div:nth-child(4) > table[class='dataTable'] > tbody > tr[class='even']:nth-child(1) > td[class='column0']:nth-child(1) > div")
	public WebElementFacade emailSearchResult_latest;
	
	@FindBy(css="div#mainPanel > div:nth-child(3) > form > div[class='searchPanelHeader'] > input[type='text']")
	public WebElementFacade emailSearchBox;
	
	@FindBy(css="div#mainPanel > div:nth-child(3) > form > div[class='searchPanelHeader'] > input[type='submit'][name='search-button']")
	public WebElementFacade emailSearchButton;
	
	@FindBy(css="table[class='layoutTable'] > tbody > tr:nth-child(3) > td >span")
	public WebElementFacade manualEmailNotification_emailType;
	
	@FindBy(css="table[class='layoutTable'] > tbody > tr:nth-child(1) > td >span")
	public WebElementFacade manualEmailNotification_resendLink;
	
	@FindBy(css="span#emailAddress")
	public WebElementFacade emailCommunicationDetails_emailAddress;
	
	@FindBy(css="span#username")
	public WebElementFacade emailCommunicationDetails_userName;
	
	@FindBy(css="a[class*='action-link']")
	public WebElementFacade resendEmail;
	
	@FindBy(css="a[href='${RESET_LINK}']")
	public WebElementFacade passwordResetLink;
	
@FindBy(css="div[class='home-menu'] > div > div> a[href*='./comm-summary']")
public WebElementFacade Communication_Summary__link;

@FindBy(css="[name*=search-keyword]")
public WebElementFacade search_text_box;

@FindBy(css="[name*=search-button]")
public WebElementFacade search_button;

@FindBy(css="[id*=id] > tbody > tr > td.column0 > div")
public WebElementFacade selected_row;

@FindBy(css="[id*=id] > table > tbody > tr:nth-child(3) > td:nth-child(2) > span")
public WebElementFacade Email_Type;

@FindBy(css="[id*=id] > table > tbody > tr:nth-child(2) > td > table > tbody > tr > td:nth-child(2) > table > tbody > tr > td:nth-child(1) > table > tbody > tr > td > a")
public WebElementFacade Activate_account_link;;

@FindBy(css="span[id*=id]")
public WebElementFacade Resend_link;

public WebElement Resend_link(){
	return Resend_link;
}
public WebElement Activate_account_link(){
	return Activate_account_link;
}
public WebElement selected_row(){
	return selected_row;
}
public WebElement search_button(){
	return search_button;
}
public WebElement Communication_Summary__link(){
	return Communication_Summary__link;
}
public WebElement search_text_box(){
	return search_text_box;
}
public WebElement Email_Type() {
	return Email_Type;
}






}
