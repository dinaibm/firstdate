package ui.pageobjects.Signon;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class DashboardPage_Objects extends PageObject {
	
	
@FindBy(css="body#merchant-portal")
public WebElementFacade merchantPortalBody;



@FindBy(css="div[class='swiper-pagination swiper-pagination-clickable swiper-pagination-bullets'] >span")
public List<WebElementFacade> swipeButton_mobile;



@FindBy(css="#main > div:nth-child(1) > div > div:nth-child(3) > div > button.close > span")
public WebElement close_cookie;

@FindBy(css="a[class='ng-binding'][href*='financial/funding']")
public WebElementFacade viewdetails_Funding;

@FindBy(css="#merchant-portal > div.container.ng-isolate-scope > div > navigation > div > ul > li.ng-scope.messages > a > span > span")
public WebElementFacade messagesLink_dashboard;

@FindBy(css="#merchant-portal > div.container.ng-isolate-scope > div > navigation > div > ul > li.ng-scope.more > ul > li.ng-scope.settings > a") 
public WebElementFacade settingsLink_dashboard;

@FindBy(css="#merchant-portal > div.container.ng-isolate-scope > div > navigation > div > ul > li.ng-scope.more > a > span")
public WebElementFacade more_options_dashboard;

@FindBy(css="#merchant-portal > div.container.ng-isolate-scope > div > navigation > div > ul > li.ng-scope.documents > a > span > span")
public WebElementFacade documentsLink_dashboard;

@FindBy(css="#merchant-portal > div.container.ng-isolate-scope > div > navigation > div > ul > li.ng-scope.more > ul > li.ng-scope.users > a")
public WebElementFacade userManagementLink_dashboard;

@FindBy(css="#merchant-portal > div.container.ng-isolate-scope > div > navigation > div > ul > li.ng-scope.more > ul > li.ng-scope.faq > a")
public WebElementFacade faqLink_dashboard;


@FindBy(css="div[class='notification-container system-information'] > p[class='ng-binding']")
public WebElementFacade accountExpiryNotification;

@FindBy(css="payments >div[class='content'] > div[class='heading'] > div[class*='title ng-binding']")
public WebElementFacade todayPaymentAmount;

@FindBy(css="payments >div[class='content'] > div[class='heading'] > div[class*='sub-title'] > span:nth-child(1)")
public WebElementFacade todayPaymentCustomers;

@FindBy(css="section >div[class='content'] > div[class='heading'] > div[class*='title ng-binding']")
public WebElementFacade todaySalesAmount;

@FindBy(css="section >div[class='content'] > div[class='heading'] > div[class*='sub-title'] > span:nth-child(1)")
public WebElementFacade todaySalesCustomers;

@FindBy(css="div[class='input-container'] > input#username")
public WebElementFacade impersonationUserName;

@FindBy(css="p[class='validation-error ng-binding ng-scope']")
public WebElementFacade impersonationErrorMessage;

@FindBy(css="div[class='header-conatiner horizontal-fixed ng-scope'] > div > a")
public WebElementFacade impersonatedUserNameText;

@FindBy(css="button[translate='IMPERSONATION.LOGIN']")
public WebElementFacade impersonationLogin;

@FindBy(css="button[class='dark ng-binding']")
public WebElementFacade endImpersonationSession;

@FindBy(css="button[translate='NAVIGATION.LOGOUT']")
public WebElementFacade impersonationLogout;

@FindBy(css="button[translate='TOUR.START']")
public WebElementFacade startTheTour;

@FindBy(css="h3[class='popover-title tour-step-title ng-binding ng-scope']")
public WebElementFacade tourGuide_Sections;

//button[translate='GLOBAL.NEXT']
@FindBy(css="button[translate='GLOBAL.NEXT']")
public WebElementFacade tourGuide_Next;

@FindBy(css="button[translate='TOUR.END_TOUR']")
public WebElementFacade endTheTour;



@FindBy(css="canvas#sales-canvas")
public WebElementFacade salesGraph;

@FindBy(css="sales > section > div.content > div.legend > a.arr-left > i")
public WebElementFacade salesDetails_PreviousButton;

@FindBy(css="a.prev.ng-scope > i")
public WebElementFacade dashboardPage_PreviousButton;

@FindBy(css="table[class='payment-type'] > tbody > tr > td:nth-child(2) ")
public List<WebElementFacade> paymentType;

@FindBy(css="table[class='payment-type'] > tbody > tr > td:nth-child(3) ")
public List<WebElementFacade> paymentValue;

@FindBy(css="div[class='current ng-binding']")
public WebElementFacade currentDate;

@FindBy(css="div[class='footer success'] > div")
public WebElementFacade paymentSuccess;

@FindBy(css="div[class='footer decline'] > div")
public WebElementFacade paymentDecline;

@FindBy(css="div[class='no-data-text ng-scope']")
public WebElementFacade noTransactionsProcessed;

/*@FindBy(css="canvas#preauth-canvas")
public WebElementFacade preAuthorizationsGraph;*/

@FindBy(css="button[translate='GLOBAL.CONFIRM']")
public WebElementFacade confirmButton;

/*@FindBy(css="p[translate='DASHBOARD.WIDGETS.PREAUTH.NO_DATA']")
public List<WebElementFacade> noExpiringPreAuthorizations;

@FindBy(css="profile-information > div > span.hidden-xs.ng-binding")
public WebElementFacade Welcome_message;*/


/*@FindBy(css="profile-information > div > span:nth-child(2)")
public WebElementFacade login_date;*/


/*@FindBy(css="li.ng-scope.messages > a > span > i")
public WebElementFacade message_indicator_count;

@FindBy(css="li.ng-scope.documents > a > span > i")
public WebElementFacade document_indicator_count ;

@FindBy(css="#main > div:nth-child(1) > div > div:nth-child(3) > div > span")
public WebElementFacade Portal_cookie_message;

@FindBy(css="#main > div:nth-child(1) > div > div:nth-child(3) > div > a > span")
public WebElementFacade portal_cookie_details;

@FindBy(css="#block-views-header-block > div > div > div > section > section > h1 > span")
public WebElementFacade cookie_page;

@FindBy(css="li.ng-scope.preauthorisations > a > span > span")
public WebElementFacade preauthorization_Link;

@FindBy(css="div.col-lg-12.header-container.horizontal-fixed > h3")
public WebElementFacade preauthorization_text;

@FindBy(css="li.ng-scope.authorisations > a > span > span")
public WebElementFacade Authorizations_Link;

@FindBy(css="div.col-lg-12.header-container.horizontal-fixed > h3")
public WebElementFacade Authorizations_text;

@FindBy(css="li.ng-scope.transaction > a > span > span")
public WebElementFacade transaction_Link;

@FindBy(css="div.col-lg-12.header-container.horizontal-fixed > h3")
public WebElementFacade transaction_text;

@FindBy(css="li.ng-scope.funding > a > span > span")
public WebElementFacade funding_Link;

@FindBy(css="div.col-lg-12.header-container.horizontal-fixed > h3")
public WebElementFacade funding_text;*/

/*@FindBy(css="li.ng-scope.logout > a > span > span")
public WebElementFacade logout;*/


/*@FindBy(css="payments > div.header > span")
public WebElementFacade payment_dashboard_text;*/














public WebElement viewdetails_Funding(){
    return viewdetails_Funding;
  }

public WebElement messagesLink_dashboard(){
    return messagesLink_dashboard;
  }

public WebElement settingsLink_dashboard(){
    return settingsLink_dashboard;
  }

public WebElement more_options_dashboard(){
    return more_options_dashboard;
  }

public WebElement documentsLink_dashboard(){
    return documentsLink_dashboard;
  }

public WebElement userManagementLink_dashboard(){
    return userManagementLink_dashboard;
  }

public WebElement faqLink_dashboard(){
    return faqLink_dashboard;
  }

@FindBy(css="canvas#preauth-canvas")
public WebElementFacade preAuthorizationsGraph;

@FindBy(css="button[class='toggle-button']")
public WebElementFacade toggleButton_mobile;

@FindBy(css="p[translate='DASHBOARD.WIDGETS.PREAUTH.NO_DATA']")
public List<WebElementFacade> noExpiringPreAuthorizations;

@FindBy(css="profile-information > div > span.hidden-xs.ng-binding")
public WebElementFacade Welcome_message;

@FindBy(css="#main > div:nth-child(1) > div > system-information > div > div:nth-child(2) > p")
public WebElementFacade passwordExpireMessage;

@FindBy(css="#main > div:nth-child(1) > div > system-information > div > div:nth-child(2) > p > a")
public WebElementFacade passwordExpirelink;

@FindBy(css="profile-information > div > span:nth-child(2)")
public WebElementFacade login_date;

@FindBy(css="profile-information > div > span:nth-child(3) > time")
public WebElementFacade last_login_date_time;

@FindBy(css="li.ng-scope.messages > a > span > i")
public WebElementFacade message_indicator_count;

@FindBy(css="li.ng-scope.documents > a > span > i")
public WebElementFacade document_indicator_count ;

@FindBy(css="#main > div:nth-child(1) > div > div:nth-child(3) > div > span")
public WebElementFacade Portal_cookie_message;

@FindBy(css="#main > div:nth-child(1) > div > div:nth-child(3) > div > a > span")
public WebElementFacade portal_cookie_details;

@FindBy(css="#block-views-header-block > div > div > div > section > section > h1 > span")
public WebElementFacade cookie_page;

@FindBy(css="li.ng-scope.preauthorisations > a > span > span")
public WebElementFacade preauthorization_Link;

@FindBy(css="div.col-lg-12.header-container.horizontal-fixed > h3")
public WebElementFacade preauthorization_text;

@FindBy(css="li.ng-scope.authorisations > a > span > span")
public WebElementFacade Authorizations_Link;

@FindBy(css="div.col-lg-12.header-container.horizontal-fixed > h3")
public WebElementFacade Authorizations_text;

@FindBy(css="li.ng-scope.transaction > a > span > span")
public WebElementFacade transaction_Link;

@FindBy(css="div.col-lg-12.header-container.horizontal-fixed > h3")
public WebElementFacade transaction_text;

@FindBy(css="li.ng-scope.funding > a > span > span")
public WebElementFacade funding_Link;

@FindBy(css="div.col-lg-12.header-container.horizontal-fixed > h3")
public WebElementFacade funding_text;

@FindBy(css="li.ng-scope.messages > a > span > span")
public WebElementFacade messages_Link;

@FindBy(css="div:nth-child(1) > div > div:nth-child(1) > div > h3")
public WebElementFacade messages_text;

@FindBy(css="ul > li.ng-scope.documents > a > span > span")
public WebElementFacade documents_Link;

@FindBy(css="div:nth-child(1) > div > div:nth-child(1) > div > h3")
public WebElementFacade documents_text;

@FindBy(css="navigation > div > ul > li.ng-scope.more > a")
public WebElementFacade more_option;

@FindBy(css="ul > li.ng-scope.more.hover > ul > li.ng-scope.users > a > span > span")
public WebElementFacade User_management;

@FindBy(css="ul > li.ng-scope.more > ul > li.ng-scope.faq > a > span > span")
public WebElementFacade help_option;

@FindBy(css="div:nth-child(1) > div > div:nth-child(1) > div > h3")
public WebElementFacade help_text;

@FindBy(css="preauth > section > div.content > div > div.manage > a")
public WebElementFacade Navigate_Pre_auth_view;

@FindBy(css="div.swiper-slide.flex-order-3.sw-left > transfers > div.header > a")
public WebElementFacade view_details_funding;

@FindBy(css="transaction-search > no-records > div > div > div.header > span:nth-child(2)")
public WebElementFacade Couldnot_find_result_text;

@FindBy(css="div.swiper-slide.flex-order-2.sw-left > sales > section > div.header > a")
public WebElementFacade Sales_dashboard_link;

@FindBy(css="transaction-search > form > div.date-picker > div > span.input-group-btn > button > i")
public WebElementFacade date_dropdown;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(2)")
public WebElementFacade Last_7_days_link;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > div > button.info.ng-scope")
public WebElementFacade Apply_button;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-1 > span > span.header-label.ng-binding.ng-scope > span:nth-child(1)")
public WebElementFacade posting_date;

@FindBy(css="section > div.header-chart > div > currency-selector > a > i.fa.fa-angle-down")
public WebElementFacade currency_drop_down;

@FindBy(css="section > div.header-chart > div > currency-selector > ul > li:nth-child(1)")
public WebElementFacade EUR_currency;


@FindBy(css="section > div.header-chart > div > currency-selector > ul > li:nth-child(2)")
public WebElementFacade USD_currency;

@FindBy(css="payments > div.content > div.heading > div.title.ng-binding")
public WebElementFacade payment_currency_Text_Validation;


@FindBy(css="li.ng-scope.more.hover > ul > li.ng-scope.settings > a > span > span")
public WebElementFacade settings;

@FindBy(css="form > div:nth-child(2) > div > div > button")
public WebElementFacade Continue_dashboard_button;


@FindBy(css="#main > div:nth-child(1) > div > div:nth-child(2) > div > button > span:nth-child(1)")
public WebElementFacade message_notofication_cross_symbol;

@FindBy(css="#main > div:nth-child(1) > div > div:nth-child(2) > div > a")
public WebElementFacade Read_more_message_notofication;

@FindBy(css="#main > div:nth-child(1) > div > div:nth-child(2) > div > h4")
public WebElementFacade Message_Title_Notification;

@FindBy(css="#main > div:nth-child(1) > div > div:nth-child(2) > div > p:nth-child(4)")
public WebElementFacade Message_subtitle_notification;	

@FindBy(css="#merchant-portal > div.modal.fade.ng-isolate-scope.popup.new-alerts.in > div > div > button")
public WebElementFacade unread_alerts;

@FindBy(css="#merchant-portal > div.modal.fade.ng-isolate-scope.popup.new-alerts.in > div > div > p:nth-child(1)")
public WebElementFacade unread_alerts_title;

@FindBy(css="ul > li:nth-child(7) > a > h3 > span")
public WebElementFacade document_unread_count;

@FindBy(css="a.all-documents > span.ng-binding")
public WebElementFacade all_document;

@FindBy(css="li.ng-scope.logout > a > span > span")
public WebElementFacade logout;

@FindBy(css="payments > widget-disclaimer > div > a > i")
public WebElementFacade TextDisclaimer_payment_icon;

@FindBy(css="payments > widget-disclaimer > div > p")
public WebElementFacade Payment_Disclaimer_text;

@FindBy(css="sales > section > widget-disclaimer > div > a > i")
public WebElementFacade TextDisclaimer_sales_icon;

@FindBy(css="sales > section > widget-disclaimer > div > p")
public WebElementFacade sales_Disclaimer_text;

@FindBy(css="preauth > section > widget-disclaimer > div > a > i")
public WebElementFacade TextDisclaimer_preauth_icon;

@FindBy(css="preauth > section > widget-disclaimer > div > p")
public WebElementFacade preauth_Disclaimer_text;

@FindBy(css="transfers > widget-disclaimer > div > a > i")
public WebElementFacade TextDisclaimer_transafer_icon;

@FindBy(css="transfers > widget-disclaimer > div > p")
public WebElementFacade transafer_Disclaimer_text;

@FindBy(css="preauth > section > div.header > h1")
public WebElementFacade pre_authorization_widget;

@FindBy(css="payments > div.header > span")
public WebElementFacade payment_dashboard_text;

@FindBy(css="sales > section > div.header > h1")
public WebElementFacade sales_dashboard_text;

@FindBy(css="transfers > div.header > span")
public WebElementFacade funding_Dashboard_Text;

@FindBy(css="payments > div.content > div.heading > div.sub-title")
public WebElementFacade payment_customer_text;

@FindBy(css="sales > section > div.content > div.heading > div.title.ng-binding")
public WebElementFacade sale_currency_text;

@FindBy(css="sales > section > div.content > div.heading > div.sub-title")
public WebElementFacade sales_customer_text;

@FindBy(css="div.payment-type-container > table > tbody > tr:nth-child(1) > td.type.ng-binding")
public WebElementFacade Visa;

@FindBy(css="div.payment-type-container > table > tbody > tr:nth-child(1) > td.value > span")
public WebElementFacade Visa_Percentage;

@FindBy(css="div.payment-type-container > table > tbody > tr:nth-child(2) > td.type.ng-binding")
public WebElementFacade MasterCard;

@FindBy(css="payments > div.content > div.info.ng-scope > div.payment-type-container > table > tbody > tr:nth-child(2) > td.value > span")
public WebElementFacade MasterCard_Percentage;

@FindBy(css="span[class='swiper-pagination-bullet']")
public List<WebElement> swipe_option;

@FindBy(css="recpay > section > div.header > h1")
public WebElementFacade reccuringpay;

@FindBy(css="div > button.default-button.x-small.ng-scope")
public WebElementFacade understood_cookie_policy;

@FindBy(css="#footer > nav > a:nth-child(2)")
public WebElementFacade privacy_policy_link;

public WebElement Visa(){
	return Visa;
}
public WebElement Visa_Percentage(){
	return Visa_Percentage;
}
public WebElement MasterCard(){
	return MasterCard;
}
public WebElement MasterCard_Percentage(){
	return MasterCard_Percentage;
}

public WebElement sales_customer_text(){
	return sales_customer_text;
}
public WebElement sale_currency_text(){
	return sale_currency_text;
}
public WebElement payment_customer_text(){
	return payment_customer_text;
}
public WebElement sales_dashboard_text(){
	return sales_dashboard_text;
}
public WebElement TextDisclaimer_transafer_icon(){
	return TextDisclaimer_transafer_icon;
}
public WebElement transafer_Disclaimer_text(){
	return transafer_Disclaimer_text;
}
public WebElement preauth_Disclaimer_text(){
	return preauth_Disclaimer_text;
}
public WebElement TextDisclaimer_preauth_icon(){
	return TextDisclaimer_preauth_icon;
}
public WebElement TextDisclaimer_sales_icon(){
	return TextDisclaimer_sales_icon;
}
public WebElement sales_Disclaimer_text(){
	return sales_Disclaimer_text;
}
public WebElement TextDisclaimer_payment_icon(){
	return TextDisclaimer_payment_icon;
}
public WebElement Payment_Disclaimer_text(){
	return Payment_Disclaimer_text;
}
public WebElement User_management(){
	return User_management;
}
public WebElement Welcome_message(){
    return Welcome_message;
  }
public WebElement passwordExpireMessage(){
    return passwordExpireMessage;
  }
public WebElement passwordExpirelink(){
	return passwordExpirelink;
}
public WebElement login_date(){
    return login_date;
  }
public WebElement last_login_date_time(){
	return last_login_date_time;
}
public WebElement message_indicator_count(){
    return message_indicator_count;
  }
public WebElement document_indicator_count(){
    return document_indicator_count;
  }

public WebElement Portal_cookie_message(){
    return Portal_cookie_message;
  }
public WebElement portal_cookie_details(){
    return portal_cookie_details;
  }
 
public WebElement cookie_page(){
    return cookie_page;
  }
public WebElement preauthorization_Link(){
    return preauthorization_Link;
  }
public WebElement preauthorization_text(){
    return preauthorization_text;
  }
public WebElement transaction_Link(){
    return transaction_Link;
  }
public WebElement transaction_text(){
    return transaction_text;
  }
public WebElement Authorizations_text(){
    return Authorizations_text;
  }
public WebElement Authorizations_Link(){
    return Authorizations_Link;
  }
public WebElement funding_text(){
    return funding_text;
  }
public WebElement funding_Link(){
    return funding_Link;
  }
public WebElement messages_text(){
    return messages_text;
  }
public WebElement messages_Link(){
    return messages_Link;
  }
public WebElement documents_text(){
    return documents_text;
  }
public WebElement documents_Link(){
    return documents_Link;
  }

public WebElement more_option(){
    return more_option;
  }
public WebElement help_option(){
    return help_option;
  }

public WebElement help_text(){
    return help_text;
  }
public WebElement pre_authorization_widget(){
	return pre_authorization_widget;	
}
public WebElement Navigate_Pre_auth_view(){
	return Navigate_Pre_auth_view;	
}
public WebElement funding_Dashboard_Text(){
	return funding_Dashboard_Text;	
}
public WebElement view_details_funding(){
	return view_details_funding;	
}
public WebElement Sales_dashboard_link(){
	return Sales_dashboard_link;
}
public WebElement date_dropdown(){
	return date_dropdown;
}
public WebElement Last_7_days_link(){
	return Last_7_days_link;
}
public WebElement Apply_button(){
	return Apply_button;
}	
public WebElement Couldnot_find_result_text(){
	return Couldnot_find_result_text;
}
public WebElement posting_date(){
	return posting_date;
	
}
public WebElement currency_drop_down(){
    return currency_drop_down;
  }
public WebElement EUR_currency(){
    return EUR_currency;
  }
public WebElement USD_currency(){
    return USD_currency;
  }

public WebElement settings(){
    return settings;
  }

public WebElement Continue_dashboard_button(){
    return Continue_dashboard_button;
  }
public WebElement payment_dashboard_text(){
    return payment_dashboard_text;
  }

public WebElement payment_currency_Text_Validation(){
    return payment_currency_Text_Validation;
  }
public WebElement message_notofication_cross_symbol(){
	return message_notofication_cross_symbol;
}
public WebElement Read_more_message_notofication(){
	return Read_more_message_notofication;
}
public WebElement Message_Title_Notification(){
    return Message_Title_Notification;
  }
public WebElement Message_subtitle_notification(){
    return Message_subtitle_notification;
  }
public WebElement unread_alerts(){
	return unread_alerts;
}
public WebElement unread_alerts_title(){
	return unread_alerts_title;
}
public WebElement document_unread_count(){
	return document_unread_count;
}
public WebElement all_document(){
	return all_document;
}
public WebElement logout(){
	return logout;
}




































@FindBy(css="payments > div.content > div.info.ng-scope > div.no-data-text.ng-scope")
public WebElementFacade No_Transactions;

@FindBy(css="div.header-chart > div > a.week.ng-binding")
public WebElementFacade Week;

@FindBy(css="div.header-chart > div > date-selector > div > a > i")
public WebElementFacade Previous_Week;

@FindBy(css="payments > div.content > div.date.ng-binding")
public WebElementFacade Date;

@FindBy(css="payments > div.content > div.info.ng-scope > div.payment-type-container > table > tbody ")
public WebElementFacade Payment_Type_Value;

@FindBy(css="#payments-canvas")
public WebElementFacade Page_load_image;

@FindBy(css="payments > div.header > a")
public WebElementFacade view_details_link;

@FindBy(css="button[translate='DIRECTIVES.SEARCH.SEARCH_BUTTON']")
public WebElementFacade View_Details_resultpg_Search_button;

@FindBy(css="button[class='default-button x-small blue mobile-only']")
public WebElementFacade mobile_View_Details_resultpg_Search_button;

@FindBy(css="authorization-search > no-records > div > div > div.header > span:nth-child(2)")
public WebElementFacade View_Details_NoResult_text;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > authorization-search > form > div.date-picker > div > span.form-control.date-range.ng-binding")
public WebElementFacade View_Details_Date;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-col-id-0.more-icon-column.no-overflow.sticky > span")
public WebElementFacade View_Details_Result_Expand;

@FindBy(css="#main > div.row.content > div > div.row.ng-scope > div > div.impersonation-logout > span")
public WebElementFacade Impersonation_Welcome_Text;

@FindBy(css="payments > div.content > div.footer.success > p")
public WebElementFacade Dashboard_Successful;

@FindBy(css="payments > div.content > div.footer.decline > p")
public WebElementFacade Dashboard_Declined;

@FindBy(css="payments > div.content > div.footer.success > div")
public WebElementFacade Dashboard_Successful_percent;

@FindBy(css="payments > div.content > div.footer.decline > div")
public WebElementFacade Dashboard_Declined_percent;

@FindBy(css="#merchant-portal > div.container.ng-isolate-scope > div > navigation > div > ul > li.ng-scope.logout > a > span > span")
public WebElementFacade Logout;

@FindBy(css="li.ng-scope.dashboard > a > span > span")
public WebElementFacade Dashboard_link;

public WebElement No_Transactions(){
	return No_Transactions;
}
public WebElement Week(){
	return Week;
}

public WebElement Previous_Week(){
	return Previous_Week;
}
public WebElement Date(){
	return Date;
}

public WebElement Payment_Type_Value(){
	return Payment_Type_Value;
}

public WebElement Page_load_image(){
	return Page_load_image;
}

public WebElement view_details_link(){
	return view_details_link;
}

public WebElement View_Details_resultpg_Search_button(){
	return View_Details_resultpg_Search_button;
}

public WebElement mobile_View_Details_resultpg_Search_button(){
	return mobile_View_Details_resultpg_Search_button;
}


public WebElement View_Details_NoResult_text(){
	return View_Details_NoResult_text;
}

public WebElement View_Details_Date(){
	return View_Details_Date;
}

public WebElement View_Details_Result_Expand(){
	return View_Details_Result_Expand;
}

public WebElement Impersonation_Welcome_Text(){
	return Impersonation_Welcome_Text;
}

public WebElement Dashboard_Successful(){
	return Dashboard_Successful;
}

public WebElement Dashboard_Declined(){
	return Dashboard_Declined;
}

public WebElement Dashboard_Successful_percent(){
	return Dashboard_Successful_percent;
}

public WebElement Dashboard_Declined_percent(){
	return Dashboard_Declined_percent;
}

public WebElement Logout(){
	return Logout;
}

public WebElement Dashboard_link(){
	return Dashboard_link;
}























}
