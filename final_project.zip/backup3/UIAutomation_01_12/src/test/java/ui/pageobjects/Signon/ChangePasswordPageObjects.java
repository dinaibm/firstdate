package ui.pageobjects.Signon;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class ChangePasswordPageObjects extends PageObject{
	
@FindBy(css="input[placeholder='Enter your new password']")
public WebElementFacade newPassword;

@FindBy(css="input[placeholder='Repeat your new password']")
public WebElementFacade repeatPassword;

@FindBy(css="button[translate='GLOBAL.PASSWORD.CHANGE_YOUR_PASSWORD']")
public WebElementFacade changePassword;

@FindBy(css="button[translate='GLOBAL.PASSWORD.CONTINUE_TO_MY_DASHBOARD']")
public WebElementFacade continueToDashboard;

}
