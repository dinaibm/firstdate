package ui.pageobjects.Signon;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class FundingPageObjects extends PageObject{


	@FindBy(css="div[class*='amount']")
	public WebElementFacade amountDepositedToday_Funding;

	@FindBy(css=".btn.flat-button")
	public WebElementFacade date_dropdown;

	@FindBy(css="div.extended-interface > button:nth-child(5) > span.date > input")
	public WebElementFacade FromDate;

	@FindBy(css="div.extended-interface > button:nth-child(6) > span.date > input")
	public WebElementFacade ToDate;

	@FindBy(css="button[type='button'][translate*='DIRECTIVES.DATE_PICKER.APPLY']")
	public WebElementFacade applyDate;

	@FindBy(css="span[translate='DIRECTIVES.SEARCH.NORECORDS.HEADER']")
	public WebElementFacade noRecordsPresent;

	@FindBy(css=" div > div:nth-child(1) > div > div > div.col-lg-12.header-container.horizontal-fixed > h3")
	public WebElementFacade Funding_text;

	@FindBy(css="div[class='in-row date-container pull-right'] > span[class='bold ng-binding ng-scope']")
	public List<WebElementFacade> fundingDate;
	
	@FindBy(css="div[class='in-row date-container'] > span[class='bold ng-binding ng-scope']")
	public List<WebElementFacade> fundingDate_mobile;
	
	@FindBy(css="button[class='default-button x-small blue mobile-only']")
	public WebElementFacade search_button_mobile;

	@FindBy(css="h4 > div > span > div > div.in-row.date-container")
	public List<WebElement> funding_date_list_mobile;

	@FindBy(css="td[class*='value ng-binding']")
	public List<WebElement> payment_method_value;
	
	@FindBy(css="div[class='in-row legend'] >table>tbody>tr>td>a[class*='ng-binding']")
	public List<WebElement> payment_method;

	public WebElement  Funding_text(){
		return  Funding_text;
	}
	public WebElement  amountDepositedToday_Funding(){
		return  amountDepositedToday_Funding;   
	}
	
	@FindBy(css="[name*=oneSearchField]")
	public WebElementFacade searchFieldText;

	@FindBy(css="form-search-input > div > button.default-button.x-small.blue.search-button.desktop-tablet.ng-scope")
	public WebElementFacade search_button;

	@FindBy(css="div[class=more-icon]")
	public WebElementFacade plus_icon;

	@FindBy(css="funding-search > form > no-records > div > div > div.header > span:nth-child(2)")
	public WebElementFacade no_results_found;

	@FindBy(css="div > span > div > div:nth-child(2) > span.bold.ng-binding")
	public WebElementFacade funding_refrence_number;

	@FindBy(css=".table > div:nth-child(1) > a:nth-child(2)")
	public WebElementFacade view_batch_details;

	@FindBy(css="button.default-button:nth-child(1)")
	public WebElementFacade Export_button;

	@FindBy(css="div.modal-body.ng-scope > div:nth-child(2) > p > span:nth-child(3)")
	public WebElementFacade csvFile_option;

	@FindBy(css="div.modal-body.ng-scope > div:nth-child(3) > p")
	public WebElementFacade xmlFile_option;

	@FindBy(css="div.modal-footer.ng-scope > button:nth-child(1)")
	public WebElementFacade Download_button;

	@FindBy(css="funding-search > form > no-records > div > div > div.header > span:nth-child(2)")
	public WebElementFacade search_error_message;

	@FindBy(css="funding-chart-directive > div > div.labels > a:nth-child(2)")
	public WebElementFacade store_link;

	@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-1 > span > span.header-label.ng-binding.ng-scope")
	public WebElementFacade posting_date_text;

	@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-2 > span > span.header-label.ng-binding.ng-scope")
	public WebElementFacade transaction_ID_text;

	@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-3 > span > span.header-label.ng-binding.ng-scope")
	public WebElementFacade merchantID_text;

	@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-4 > span > span.header-label.ng-binding.ng-scope")
	public WebElementFacade orderID_text;

	@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-5 > span > span.header-label.ng-binding.ng-scope")
	public WebElementFacade Type_text;

	@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-6 > span > span.header-label.ng-binding.ng-scope")
	public WebElementFacade Gross_Amount_text;

	@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-7 > span > span.header-label.ng-binding.ng-scope")
	public WebElementFacade Net_Amount_text;

	@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-8 > span > span.header-label.ng-binding.ng-scope")
	public WebElementFacade EMS_fees_text;

	@FindBy(css="ng-transclude > batch-details > div:nth-child(1) > p.ng-binding")
	public WebElementFacade Transaction_details_text;

	@FindBy(css="batch-details > div:nth-child(1) > p:nth-child(2) > span.detail-column.ng-binding.ng-scope.full-width")
	public WebElementFacade DCC_Indicator;

	@FindBy(css="batch-details > div:nth-child(1) > p:nth-child(4) > span.detail-column.ng-binding.ng-scope.full-width")
	public WebElementFacade Transaction_id;

	@FindBy(css="ng-transclude > batch-details > div:nth-child(2) > p.ng-binding")
	public WebElementFacade payment_method_details;

	@FindBy(css="batch-details > div:nth-child(2) > p:nth-child(2) > span.detail-column.ng-binding.ng-scope.full-width.big")
	public WebElementFacade card_number_details;

	@FindBy(css="batch-details > div:nth-child(2) > p.detail-row.clearfix.ng-scope.image-paragraph > span.ng-binding.ng-scope.image-label")
	public WebElementFacade Card_type;

	@FindBy(css="batch-details > div.details-info.col-width-30 > p:nth-child(1)")
	public WebElementFacade EMS_fees_text_inside;

	@FindBy(css="batch-details > div.details-info.col-width-30 > p.detail-row.border-top > span.detail-column.ng-binding.red")
	public WebElementFacade ems_fees_value;

	@FindBy(css="div.tg-column.ng-scope.tg-w-5.tg-fixed-w-5.tg-col-id-0.more-icon-column.no-overflow.sticky > span")
	public WebElementFacade plus_icon_inside_store_details;

	@FindBy(css="span[class='date-desktop']")
	public List<WebElement> postingDate;

	@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-col-id-2.tg-w-11.tg-fixed-w-11 > span")
	public List<WebElement> transactionId;

	@FindBy(css="funding-details > div.in-row.legend > table > tbody > tr.vat.ng-scope > td:nth-child(2) > a")
	public WebElementFacade fees_vat_link;

	@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-col-id-1.tg-w-8.tg-fixed-w-8 > span")
	public List<WebElement> posting_date_list_fees_and_vat;

	@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-1 > span > span.header-label.ng-binding.ng-scope")
	public WebElementFacade postingDate_text_fees_vat;

	@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-2 > span > span.header-label.ng-binding.ng-scope")
	public WebElementFacade MerchantId_text_fees_vat;

	@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-3 > span > span.header-label.ng-binding.ng-scope")
	public WebElementFacade Type_fees_and__vat;

	@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-4 > span > span.header-label.ng-binding.ng-scope")
	public WebElementFacade EMS_fees_and_vat;

	@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-5 > span > span.header-label.ng-binding.ng-scope")
	public WebElementFacade vat_text;

	@FindBy(css="div.tg-column.ng-scope.tg-col-id-4.no-overflow.negative.scaleable.align-right > span")
	public List<WebElement> Ems_fees_value_in_vat_details;

	@FindBy(css="div.tg-column.ng-scope.tg-col-id-5.no-overflow.negative.align-right > span")
	public WebElementFacade Vat_value;

	@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-col-id-3 > span")
	public WebElementFacade type_value_fees_and_vat;

	@FindBy(css="div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > div.no-results-only-batch > p.ng-scope")
	public WebElementFacade No_records_found;

	@FindBy(css="funding-details > div.in-row.legend > table > tbody > tr:nth-child(1) > td:nth-child(2) > a")
	public WebElementFacade Payment_method_MC_visa;

	@FindBy(css="funding-details > div:nth-child(1) > funding-chart-directive > div > div.labels > a:nth-child(4)")
	public WebElementFacade WebShop_link;

	@FindBy(css="ng-transclude > batch-details > div > p > span.detail-column.ng-binding.ng-scope.full-width")
	public List<WebElement> detailed_view;

	@FindBy(css="funding-details > div.in-row.legend > table > tbody > tr:nth-child(1) > td:nth-child(2) > a")
	public WebElementFacade maestro_card_link;

	@FindBy(css="funding-details > div.in-row.legend > table > tbody > tr:nth-child(1) > td.value.ng-binding")
	public WebElementFacade maestro_card_fees;

	@FindBy(css="funding-details > div.in-row.legend > table > tbody > tr:nth-child(2) > td:nth-child(2) > a")
	public WebElementFacade mastercard_link;

	@FindBy(css="funding-details > div.in-row.legend > table > tbody > tr:nth-child(2) > td.value.ng-binding")
	public WebElementFacade master_card_fees;

	@FindBy(css="funding-details > div.in-row.legend > table > tbody > tr:nth-child(3) > td:nth-child(2) > a")
	public WebElementFacade visa_link;

	@FindBy(css="funding-details > div.in-row.legend > table > tbody > tr:nth-child(3) > td.value.ng-binding")
	public WebElementFacade visa_card_fees;

	@FindBy(css="div.swiper-container.today-funding.clearfix > div.swiper-wrapper > div:nth-child(1) > p.huge > span")
	public WebElementFacade Todays_curency;

	@FindBy(css="h4 > div > span > div > div:nth-child(2)")
	public List<WebElement> reference_number_list;

	@FindBy(css="h4 > div > span > div > div.in-row.date-container.pull-right")
	public List<WebElement> funding_date_list;

	@FindBy(css="h4 > div > span > div > div.in-row.big.pull-right")
	public List<WebElement> funding_amount_list;

	@FindBy(css="batch-details > div.details-info.col-width-30 > p:nth-child(2) > span:nth-child(1)")
	public WebElementFacade issuer_fees;

	@FindBy(css="batch-details > div.details-info.col-width-30 > p:nth-child(3) > span:nth-child(1)")
	public WebElementFacade EMS_service_charges;

	@FindBy(css="batch-details > div.details-info.col-width-30 > p:nth-child(4) > span:nth-child(1)")
	public WebElementFacade card_scheme_fees;

	@FindBy(css="batch-details > div.details-info.col-width-30 > p:nth-child(5) > span:nth-child(1)")
	public WebElementFacade EMS_fixed_transaction_fees;

	@FindBy(css="batch-details > div.details-info.col-width-30 > p:nth-child(2) > span:nth-child(2)")
	public WebElementFacade Issuer_fees_value;

	@FindBy(css="batch-details > div.details-info.col-width-30 > p:nth-child(3)")
	public WebElementFacade EMS_service_charge_value;

	@FindBy(css="batch-details > div.details-info.col-width-30 > p:nth-child(4) > span:nth-child(2)")
	public WebElementFacade card_service_charge_value;;

	@FindBy(css="batch-details > div.details-info.col-width-30 > p:nth-child(5) > span:nth-child(2)")
	public WebElementFacade ems_fixed_transaction_value;

	@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(5) > span.date > input")
	public WebElementFacade from_date;

	@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(6) > span.date > input")
	public WebElementFacade To_date;

	@FindBy(css="#extended-datepicker-popup > div.extended-interface > div > button.info.ng-scope")
	public WebElementFacade Apply_button;

	@FindBy(css="funding-search > form > div > div > div > span.input-group-btn > button > i")
	public WebElementFacade date_drop_down;

	@FindBy(css="div.col-lg-12.header-container.horizontal-fixed > h3")
	public WebElementFacade batch_detail_header;

	public WebElement batch_detail_header(){
		return batch_detail_header;
	}
	public WebElement date_drop_down(){
		return date_drop_down;
	}
	public WebElement Apply_button(){
		return Apply_button;
	}
	public WebElement To_date(){
		return To_date;
	}
	public WebElement from_date(){
		return from_date;
	}
	public WebElement Issuer_fees_value(){
		return Issuer_fees_value;
	}
	public WebElement EMS_service_charge_value(){
		return EMS_service_charge_value;
	}
	public WebElement card_service_charge_value(){
		return card_service_charge_value;
	}
	public WebElement ems_fixed_transaction_value(){
		return ems_fixed_transaction_value;
	}
	public WebElement EMS_fixed_transaction_fees(){
		return EMS_fixed_transaction_fees;
	}
	public WebElement card_scheme_fees(){
		return card_scheme_fees;
	}
	public WebElement issuer_fees(){
		return issuer_fees;
	}
	public WebElement EMS_service_charges(){
		return EMS_service_charges;
	}
	public WebElement Todays_curency(){
		return Todays_curency;
	}
	public WebElement visa_card_fees(){
		return visa_card_fees;
	}
	public WebElement visa_link(){
		return visa_link;
	}
	public WebElement master_card_fees(){
		return master_card_fees;
	}
	public WebElement mastercard_link(){
		return mastercard_link;
	}
	public WebElement maestro_card_fees(){
		return maestro_card_fees;
	}
	public WebElement maestro_card_link(){
		return maestro_card_link;
	}
	public WebElement Payment_method_MC_visa(){
		return Payment_method_MC_visa;
	}
	public WebElement WebShop_link(){
		return WebShop_link;
	}
	public WebElement No_records_found(){
		return No_records_found;
	}
	public WebElement postingDate_text_fees_vat(){
		return postingDate_text_fees_vat;
	}
	public WebElement type_value_fees_and_vat(){
		return type_value_fees_and_vat;
	}

	public WebElement Vat_value(){
		return Vat_value;
	}
	public WebElement vat_text(){
		return vat_text;
	}
	public WebElement EMS_fees_and_vat(){
		return EMS_fees_and_vat;
	}
	public WebElement Type_fees_and__vat(){
		return Type_fees_and__vat;
	}
	public WebElement MerchantId_text_fees_vat(){
		return MerchantId_text_fees_vat;
	}
	public WebElement fees_vat_link(){
		return fees_vat_link;
	}
	public WebElement Transaction_details_text(){
		return Transaction_details_text;
	}
	public WebElement payment_method_details(){
		return payment_method_details;
	}
	public WebElement Transaction_id(){
		return Transaction_id;
	}
	public WebElement DCC_Indicator(){
		return DCC_Indicator;
	}
	public WebElement card_number_details(){
		return card_number_details;
	}
	public WebElement EMS_fees_text_inside(){
		return EMS_fees_text_inside;
	}
	public WebElement Card_type(){
		return Card_type;
	}
	public WebElement ems_fees_value(){
		return ems_fees_value;
	}
	public WebElement plus_icon_inside_store_details(){
		return plus_icon_inside_store_details;
	}
	public WebElement store_link(){
		return store_link;
	}
	public WebElement posting_date_text(){
		return posting_date_text;
	}
	public WebElement transaction_ID_text(){
		return transaction_ID_text;
	}
	public WebElement merchantID_text(){
		return merchantID_text;
	}
	public WebElement orderID_text(){
		return orderID_text;
	}
	public WebElement Type_text(){
		return Type_text;
	}
	public WebElement Gross_Amount_text(){
		return Gross_Amount_text;
	}
	public WebElement Net_Amount_text(){
		return Net_Amount_text;
	}
	public WebElement EMS_fees_text(){
		return EMS_fees_text;
	}
	public WebElement search_error_message(){
		return search_error_message;
	}
	public  WebElement searchFieldText(){
	    return searchFieldText;
	}
	public  WebElement search_button(){
	    return search_button;
	}
	public  WebElement plus_icon(){
	    return plus_icon;
	}
	public  WebElement no_results_found(){
	    return no_results_found;
	}
	public  WebElement funding_refrence_number(){
	    return funding_refrence_number;
	}
	public  WebElement view_batch_details(){
	    return view_batch_details;
	}
	public  WebElement Export_button(){
	    return Export_button;
	}
	public  WebElement csvFile_option(){
	    return csvFile_option;
	}
	public WebElement xmlFile_option(){
		return xmlFile_option;
	}
	public  WebElement Download_button(){
	    return Download_button;
	}
	}

