package ui.pageobjects.Signon;

import java.util.List;

import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class FAQPageObjects extends PageObject {

	
	@FindBy(css="span[class='category-name ng-binding']")
	public List<WebElement> faqCategories;
	
	@FindBy(css="span[class='ng-binding ng-scope']")
	public List<WebElement> faqCategoriesQuestions;
	
	public List<WebElement> faqCategories(){
	    return faqCategories;
	  }
	public List<WebElement> faqCategoriesQuestions(){
	    return faqCategoriesQuestions;
	  }
}
