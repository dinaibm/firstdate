package ui.pageobjects.Signon;

import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class UsersListPageObjects extends PageObject {
	
	@FindBy(css="td[class='column0']")
	public WebElementFacade activedocuments_list;
	
	@FindBy(css="div.searchPanelHeader > input.search-keyword")
	public WebElementFacade usersearch_searchbox;
	
	@FindBy(css="input[name='search-button']")
	public WebElementFacade usersearch_submitbutton;
	
	@FindBy(css="input[class='button filter-button']")
	public WebElementFacade useradvancedsearch_button;
	
	@FindBy(css="#contactFirstName")
	public WebElementFacade filterfirstname;
	
	@FindBy(css="#contactLastName")
	public WebElementFacade filterlastname;
	
	@FindBy(css="#username")
	public WebElementFacade filterusername;
	
	@FindBy(css="#userEmail")
	public WebElementFacade filteruseremail;
	
	@FindBy(css="#statusDropDown")
	public WebElementFacade filterstatusdropdown;
	
	@FindBy(css="input[value='Apply']")
	public WebElementFacade applyfilter;
	
	@FindBy(css="a[class='action-link button-small'][href*='resetFilters']")
	public WebElementFacade advancedsearchreset_button;
	
	@FindBy(css="tr.even > td.column1 > div")
	public WebElementFacade usersearch_firstresult;
	
	@FindBy(css="tr:nth-child(21) > td.right > span")
	public WebElementFacade termsandconditionsid;
	
	@FindBy(css="#markForExpiry")
	public WebElementFacade markForExpiry;
	
	@FindBy(css="select[name='accountExpirationDatePanel:day']")
	public WebElementFacade accountexpiryday;
	
	@FindBy(css="select[name='accountExpirationDatePanel:month']")
	public WebElementFacade accountexpirymonth;
	
	@FindBy(css="select[name='accountExpirationDatePanel:year']")
	public WebElementFacade accountexpiryyear;
	
	@FindBy(css="input#emailAddress")
	public WebElementFacade userEmailAddress;
	
	@FindBy(css="select[name='accountStatus']")
	public WebElementFacade useraccountstatus;
	
	@FindBy(css="select[name='blockCode']")
	public WebElementFacade blockreason;
	
	@FindBy(css="input[name='submitButton'][type='submit'][value='Save']")
	public WebElementFacade saveButton;
	
	@FindBy(css="span[class='feedbackPanelINFO']")
	public WebElementFacade feedbackpanelinfo;
	
	@FindBy(css="td[class='norecords-td'] > div")
	public WebElementFacade noRecordsPresent;
	
	public WebElement markForExpiry(){
	    return markForExpiry;
	  }
	public WebElement accountexpiryday(){
	    return accountexpiryday;
	  }
	public WebElement accountexpirymonth(){
	    return accountexpirymonth;
	  }
	public WebElement accountexpiryyear(){
	    return accountexpiryyear;
	  }
	
			
	public WebElement activedocuments_list(){
	    return activedocuments_list;
	  }
	public WebElement usersearch_searchbox(){
	    return usersearch_searchbox;
	  }
	public WebElement usersearch_submitbutton(){
	    return usersearch_searchbox;
	  }
	public WebElement usersearch_firstresult(){
	    return usersearch_firstresult;
	  }
	public WebElement termsandconditionsid(){
		return termsandconditionsid;
	}
	public WebElement useraccountstatus(){
		return useraccountstatus;
	}
	public WebElement blockreason(){
		return blockreason;
	}
	public WebElement useradvancedsearch_button(){
		return useradvancedsearch_button;
	}
	
	public WebElement advancedsearchreset_button(){
		return advancedsearchreset_button;
	}
	public WebElement filterfirstname(){
		return filterfirstname;
	}
	public WebElement filterlastname(){
		return filterlastname;
	}
	public WebElement filterusername(){
		return filterusername;
	}
	public WebElement filteruseremail(){
		return filteruseremail;
	}
	public WebElement filterstatusdropdown(){
		return filterstatusdropdown;
	}
	public WebElement applyfilter(){
		return applyfilter;
	}
	public WebElement saveButton(){
		return saveButton;
	}
	public WebElement feedbackpanelinfo(){
		return feedbackpanelinfo;
	}

}
