package ui.pageobjects.Signon;

import java.util.List;

import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class AdminPage_object extends PageObject{
	
	@FindBy(css="#menu-links > div:nth-child(4) > a")
	public WebElementFacade Email_template;

	@FindBy(css="[name*=templateId]")
	public WebElementFacade email_type;

	@FindBy(css="[name*=templateDescr]")
	public WebElementFacade email_description;

	@FindBy(css="[name*=allianceName]")
	public WebElementFacade allianceType;

	@FindBy(css="[name*=fromEmailAddress]")
	public WebElementFacade fromEmailAddress;

	@FindBy(css="[name*=emailSubject]")
	public WebElementFacade emailSubject;

	@FindBy(css="#tinymce")
	public WebElementFacade emailbody;

	@FindBy(css="[name*=fileInput]")
	public WebElementFacade email_attachment;

	@FindBy(css="[name*=uploadButton]")
	public WebElementFacade uploadbutton_attachment_email;

	@FindBy(css="[id^='id'] table > tbody > tr:nth-child(1) > td.column3 > div")
	public WebElementFacade selected_email;

	@FindBy(css="div[class='home-menu'] > div > div> a[href*='./create-user']")
	public WebElementFacade create_user;

	@FindBy(css="[name*=userType]")
	public WebElementFacade user_type;

	@FindBy(css="select[name*='roleTypePanel']")
	public WebElementFacade profile_type;

	@FindBy(css="[name*=foreName]")
	public WebElementFacade firstName;

	@FindBy(css="[name*=lastName]")
	public WebElementFacade lastName;

	@FindBy(css="[name*=email]")
	public WebElementFacade email_id;

	@FindBy(css="[name*=userName]")
	public WebElementFacade UserName_new_alliance;

	@FindBy(css="[name*=mobileNumber]")
	public WebElementFacade mobileNUmber;


	//LBC and EMS

			//#menu-links > div:nth-child(4) > a
	@FindBy(css="div[class='home-menu'] > div > div> a[href*='./gui-messages']")
	public WebElementFacade GUI_Message;

	@FindBy(css="div[class='home-menu'] > div > div> a[href*='create']")
	public WebElementFacade create_user_boardingagent;

	@FindBy(css="div[class*=field-message]")
	public WebElementFacade Field_error_message;

	@FindBy(css="input[id*=merchantName]")
	public WebElementFacade merchantID;


	//EMS and LBC content manager login both
	@FindBy(css="#mainPanel > div.command-panel > a")
	public WebElementFacade Add_button;

	@FindBy(css="#id19 > h4 > span:nth-child(1)")
	public WebElementFacade NewMessage_text;

	@FindBy(css="[name*=allianceCode]")
	public WebElementFacade allianceCode_dropdown;

	//EMS and LBC content manager login both
	@FindBy(css="[id*=language]")
	public WebElementFacade Language_msg_dropdown;

	@FindBy(css="[name*=type]")
	public WebElementFacade type_dropdown;

	@FindBy(css="[name*=title]")
	public WebElementFacade message_title;

	@FindBy(css="[name*=subTitle]")
	public WebElementFacade message_subTitle;

	@FindBy(css="[name*=date]")
	public WebElementFacade date_picker;


	@FindBy(css="[name*=checkFlag]")
	public WebElementFacade Flag_notification;

	@FindBy(css="[name*=checkValidityInDays]")
	public WebElementFacade Indays_validity;


	@FindBy(css="[name*=checkUnlimitedValidity]")
	public WebElementFacade unlimited_validity;


	@FindBy(css="#textarea_ifr")
	public WebElementFacade messagebody;

	@FindBy(css="[name*=sample]")
	public WebElement Indays_validity_days;
	//[id*=id] > fieldset:nth-child(3) > table > tbody > tr:nth-child(11) > td.right > span
	@FindBy(css="[id*=id]> fieldset:nth-child(3) > table > tbody > tr:nth-child(11) > td.right > span")
	public WebElementFacade message_link;

	@FindBy(css="#feedbackPanel > ul > li > span")
	public WebElementFacade Created_successfully_text;

	@FindBy(css="[class*=action-link]")
	public WebElementFacade cancel_button;

	@FindBy(css="[id^='id'] table > tbody > tr > td.column0 > div")
	public WebElementFacade selected_message;

	@FindBy(css="[id*=id] > table > tbody > tr.even > td.column0 > div")
	public WebElementFacade message_title_selected;

	@FindBy(css="#menu-links > div:nth-child(6) > a")
	public WebElementFacade document_link;

	//EMS and LBC content manager login both
	@FindBy(css="[name*=search-keyword]")
	public WebElementFacade search_box;

	//EMS and LBC content manager login both
	@FindBy(css="[name*=search-button]")
	public WebElementFacade search_button;

	@FindBy(css="[id*=id] > table > tfoot > tr > td > div")
	public WebElementFacade no_records_found;

	//[id*=id] > table > tbody > tr > td.column0 > div
	@FindBy(css="[name*=fileInput]")
	public WebElementFacade AttachmentLink;


	@FindBy(css="[id*=id] > table > tbody > tr > td.column5 > div > span > span:nth-child(2) > a > img")
	public WebElementFacade deletebutton;
	//#id7 > table > tbody > tr:nth-child(1) > td.column3 > div > span > span:nth-child(2) > a > img
	@FindBy(css="[name*=documentname]")
	public WebElementFacade document_name;

	@FindBy(css="input[type='file']")
	public WebElementFacade document_attachment;

	@FindBy(css="[name*=uploadButton]")
	public WebElementFacade upload_button;

	@FindBy(css="[name*=attachmentPath]")
	public WebElementFacade document_path;

	@FindBy(css="[name*=description]")
	public WebElementFacade description;

	@FindBy(css="[name*=priorityCheckFlag]")
	public WebElementFacade prioritycheck;

	//EMS And LBC Content Manager both
	@FindBy(css="[name*=submitButton]")
	public WebElementFacade save_button;

	@FindBy(css="#feedbackPanel > ul > li")
	public WebElementFacade PanelError;

	@FindBy(css="[class*=filter-button]")
	public WebElementFacade Filter_button;

	@FindBy(css="[id*=contactFirstName]")
	public WebElementFacade firstname_filter;

	@FindBy(css="[id*=contactLastName]")
	public WebElementFacade lastname_filter;

	@FindBy(css="[id*=username]")
	public WebElementFacade username_filter;

	@FindBy(css="[name*=filterButton]")
	public WebElementFacade Applybutton_filter;

	@FindBy(css="div[class='home-menu'] > div > div> a[href*='./users-list']")
	public WebElementFacade users_list;

	@FindBy(css="[id*=id] > table > tbody > tr > td.column1 > div")
	public WebElement username_text;

	@FindBy(css="li[class='ui-menu-item']")
	public List<WebElement> merchantList;

	@FindBy(css="span[class*=error-title]")
	public WebElementFacade error_title_sub_account;

	@FindBy(css="[id^=id]> table > tbody > tr > td.column1 > div")
	public WebElementFacade selected_UserName;

	@FindBy(css="[id*=id] > fieldset > table > tbody > tr > td.right > div")
	public List<WebElementFacade> error_message_field;

	@FindBy(css="#menu-control")
	public WebElementFacade hidden_button;

	@FindBy(css="a[id*='home-link']")
	public WebElementFacade home_link_admin;

	
	public WebElement selected_UserName(){
		return selected_UserName;
	}
	public List<WebElement> merchantList(){
		return merchantList;
	}
	public WebElement error_title_sub_account(){
		return error_title_sub_account;
	}
	public WebElement username_text(){
		return username_text;
	}
	public WebElement users_list(){
		return users_list;
	}
	public WebElement Filter_button(){
		return Filter_button;
	}
	public WebElement firstname_filter(){
		return firstname_filter;
	}
	public WebElement lastname_filter(){
		return lastname_filter;
	}
	public WebElement username_filter(){
		return username_filter;
	}
	public WebElement message_title_selected(){
		return message_title_selected;
	}

	public WebElement Applybutton_filter(){
		return Applybutton_filter;
	}
	public WebElement AttachmentLink(){
		return AttachmentLink;
	}
	public WebElement cancel_button(){
		return cancel_button;
	}
	public WebElementFacade deletebutton(){
		return deletebutton;
	}
	public WebElement no_records_found(){
		return no_records_found;
	}
	public WebElement create_user_boardingagent(){
		return create_user_boardingagent;
	}
	public WebElement Field_error_message(){
		return Field_error_message;
	}
	public WebElement upload_button(){
		return upload_button;
	}

	public WebElement merchantID(){
		return merchantID;
	}
	public WebElement create_user(){
		return create_user;
	}
	public WebElement user_type(){
		return user_type;
	}
	public WebElement profile_type(){
		return profile_type;
	}
	public WebElementFacade firstName(){
		return firstName;
	}
	public WebElementFacade lastName(){
		return lastName;
	}
	public WebElementFacade email_id(){
		return email_id;
	}
	public WebElementFacade UserName_new_alliance(){
		return UserName_new_alliance;
	}
	public WebElementFacade mobileNUmber(){
		return mobileNUmber;
	}
	public WebElement selected_email(){
		return selected_email;
	}
	public WebElement email_attachment(){
		return email_attachment();
	}
	public WebElement uploadbutton_attachment_email(){
		return uploadbutton_attachment_email;
	}
	public WebElement emailbody(){
		return emailbody;
	}
	public WebElementFacade emailSubject(){
		return emailSubject;
	}
	public WebElement fromEmailAddress(){
		return fromEmailAddress;
	}
	public WebElement allianceType(){
		return allianceType;
	}
	public WebElement email_description(){
		return email_description;
	}
	public WebElement email_type(){
		return email_type;
	}
	public WebElement Email_template(){
		return Email_template;
	}
	public WebElement prioritycheck(){
		return prioritycheck;
	}

	public WebElement description(){
		return description;
	}
	public WebElement document_path(){
		return document_path;
	}
	public WebElement document_attachment(){
		return document_attachment;
	}
	public WebElement document_name(){
		return document_name;	
	}
	public WebElement document_link(){
		return document_link;
	}
	public  WebElement selected_message(){
	    return selected_message;
	}
	public  WebElement search_box(){
	    return search_box;
	}
	public  WebElement search_button(){
	    return search_button;
	}
	public  WebElement GUI_Message(){
	    return GUI_Message;
	}
	public  WebElement Add_button(){
	    return Add_button;
	}
	public  WebElement NewMessage_text(){
	    return NewMessage_text;
	}
	public  WebElement allianceCode_dropdown(){
	    return allianceCode_dropdown;
	}
	public  WebElement Language_msg_dropdown(){
	    return Language_msg_dropdown;
	}
	public  WebElement type_dropdown(){
	    return type_dropdown;
	}
	public  WebElement message_title(){
	    return message_title;
	}
	public  WebElement message_subTitle(){
	    return message_subTitle;
	}
	public  WebElement date_picker(){
	    return date_picker;
	}
	public  WebElement Flag_notification(){
	    return Flag_notification;
	}
	public  WebElement Indays_validity(){
	    return Indays_validity;
	}
	public  WebElement Indays_validity_days(){
	    return Indays_validity_days;
	}

	public  WebElement unlimited_validity(){
	    return unlimited_validity;
	}
	public WebElement messagebody(){
		return messagebody;	
	}
	public WebElement save_button(){
		return save_button;
	}
	public WebElement Created_successfully_text(){
		return Created_successfully_text;
	}
	public WebElement message_link(){
		return message_link;
	}
	public WebElement PanelError(){
		return PanelError;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@FindBy(css="#menu-links > div:nth-child(3) > a")
	public WebElementFacade Users_List;

	@FindBy(css="[name*=search-keyword]")
	public WebElementFacade Search_Text;

	@FindBy(css="[name*=search-button]")
	public WebElementFacade Search_button;

	@FindBy(css="[id*=id] > table > tfoot > tr > td > div")
	public WebElementFacade No_Result_Found;

	@FindBy(css="[id*=id] > table > tbody > tr > td.column1 > div")
	public WebElementFacade Result_Found;

	@FindBy(css="[id*=id] > h4 > span:nth-child(1)")
	public WebElementFacade Edit_User_header;

	@FindBy(css="[name*=firstName]")
	public WebElementFacade First_Name;

	@FindBy(css="[name*=lastName]")
	public WebElementFacade Last_Name;

	@FindBy(css="[name*=emailAddress]")
	public WebElementFacade Email;

	@FindBy(css="[name*=mobileNumber]")
	public WebElementFacade Mobile_Phone;

	@FindBy(css="[name*=phoneNumber]")
	public WebElementFacade Phone_Number;

	@FindBy(css="[name*=submitButton]")
	public WebElementFacade submitButton;

	@FindBy(css="span[class='feedbackPanelINFO']")
	public WebElementFacade Save_message;

	@FindBy(css="span[class='feedbackPanelERROR']")
	public WebElementFacade Save_error;

	@FindBy(css="#menu-links > div:nth-child(6) > a")
	public WebElementFacade Communication_summary;

	@FindBy(css="[id*=id] > tbody > tr:nth-child(1) > td.column0 > div")
	public List<WebElement> communication_summary_Table;

	@FindBy(css="#menu-control > span")
	public WebElementFacade Page_Header;

	@FindBy(css="#username")
	public WebElementFacade comm_summary_username;

	@FindBy(css="a[href*='manualEmailCommunicationPanel']")
	public WebElementFacade Send_button;

	@FindBy(css="#feedbackPanel > ul > li > span")
	public WebElementFacade Mail_Sent_message;

	@FindBy(css="#menu-control")
	public WebElementFacade Tab_Mob_3barmenu;

	public  WebElement Users_List(){
	    return Users_List;
	}

	public  WebElement Search_Text(){
	    return Search_Text;
	}

	public  WebElement Search_button(){
	    return Search_button;
	}
	public  WebElement No_Result_Found(){
	    return No_Result_Found;
	}

	public  WebElement Result_Found(){
	    return Result_Found;
	}

	public  WebElement Edit_User_header(){
	    return Edit_User_header;
	}

	public  WebElement First_Name(){
	    return First_Name;
	}

	public  WebElement Last_Name(){
	    return Last_Name;
	}

	public  WebElement Email(){
	    return Email;
	}

	public  WebElement Mobile_Phone(){
	    return Mobile_Phone;
	}

	public  WebElement Phone_Number(){
	    return Phone_Number;
	}

	public  WebElement submitButton(){
	    return submitButton;
	}

	public  WebElement Save_message(){
	    return Save_message;
	}

	public WebElementFacade Save_error(){
		return Save_error;
	}

	public  WebElement Communication_summary(){
	    return Communication_summary;
	}

	public  List<WebElement> communication_summary_Table(){
	    return communication_summary_Table;
	}

	public  WebElement Page_Header(){
	    return Page_Header;
	}

	public WebElement comm_summary_username(){
		return comm_summary_username;
	}

	public WebElement Send_button(){
		return Send_button;
	}

	public WebElement Mail_Sent_message(){
		return Mail_Sent_message;
	}

	public WebElementFacade Tab_Mob_3barmenu(){
		return Tab_Mob_3barmenu;
	}

	
}
