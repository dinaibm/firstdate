package ui.pageobjects.Signon;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class EmailTemplatePageObjects extends PageObject{


@FindBy(css="table > tbody > tr > td.column0 > div")
public List<WebElement> email_id;

@FindBy(css="table > tbody > tr > td.column1 > div")
public List<WebElement> emailTemplate_id;

@FindBy(css="h4 > span:nth-child(2)")
public WebElementFacade editEmailTemplateValue;

@FindBy(css="a[class='next']")
public WebElementFacade nextButton;

@FindBy(css="span[class='next'] > em")
public List<WebElement> nextButtondisabled;

@FindBy(css="a[class='action-link']")
public WebElementFacade cancelButton;

@FindBy(css="span[class='goto'] > span > em > span")
public WebElementFacade currentPage;

public List<WebElement> email_id(){
    return email_id;
}
public List<WebElement>emailTemplate_id(){
    return emailTemplate_id;
}
public WebElement nextButton(){
    return nextButton;
}

public List<WebElement> nextButtondisabled(){
	return nextButtondisabled;
}
public WebElement cancelButton(){
    return cancelButton;
}

public WebElement editEmailTemplateValue(){
    return editEmailTemplateValue;
}

public WebElement currentPage(){
    return currentPage;
}
















































@FindBy(css="div[class='home-menu'] > div > div> a[href*='./email-templates']")
public WebElementFacade Email_template;

@FindBy(css="[name*=search-keyword]")
public WebElementFacade search_text_box;

@FindBy(css="[name*=search-button]")
public WebElementFacade search_button;

@FindBy(css="[id*=id] > table > tbody > tr > td.column2 > div")
public List<WebElement> selected_row_Language;

@FindBy(css="[id*=id] > table > tbody > tr > td.column1 > div")
public List<WebElement> selected_row_email_type;

@FindBy(css="[name*=templateDescr]")
public WebElementFacade Description_emeil_template;

@FindBy(css="[name*=emailSubject]")
public WebElementFacade Subject_email_template;

@FindBy(css="[name*=submitButton]")
public WebElementFacade submit_button;

@FindBy(css="#feedbackPanel > ul > li > span")
public WebElementFacade Panel_message_success_error;

@FindBy(css="[id*=id] > table > tfoot > tr > td > div")
public WebElementFacade No_data_found;

public WebElement submit_button(){
	return submit_button;
}
public WebElement No_data_found(){
	return No_data_found;
}
public WebElement Panel_message_success_error(){
	return Panel_message_success_error;
}
public WebElement search_text_box(){
	return search_text_box;
}
public WebElement search_button(){
	return search_button;
}
public WebElement Description_emeil_template(){
	return Description_emeil_template;
}
public WebElement Subject_email_template(){
	return Subject_email_template;
}
public WebElement Email_template(){
	return Email_template;
}

}

