package ui.pageobjects.Signon;

import java.util.List;

import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class DocumentsPageObjects extends PageObject {


	@FindBy(css="li > a > h3")
	public List<WebElement> documentfolders;

	@FindBy(css="p[class*='no-files']")
	public WebElementFacade noFileAvailability;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div > files-tile-view > a > i")
	public WebElementFacade listView;
	
	@FindBy(css="#cleckbox-all")
	public WebElement selectall;

	@FindBy(css="th[colspan='2'] > a > p[class*='up-arrow']")
	public WebElementFacade title_Ascending;

	@FindBy(css="th[colspan='2'] > a > p[class*='down-arrow']")
	public WebElementFacade title_Descending;

	@FindBy(css="th[class='type-column'] > a > p[class*='up-arrow']")
	public WebElementFacade type_Ascending;

	@FindBy(css="th[class='type-column'] > a > p[class*='down-arrow']")
	public WebElementFacade type_Descending;

	@FindBy(css="th:nth-child(4) > a > p[class*='up-arrow']")
	public WebElementFacade date_Ascending;

	@FindBy(css="th:nth-child(4) > a > p[class*='down-arrow']")
	public WebElementFacade date_Descending;

	@FindBy(css="p[class*='title']")
	public List<WebElement> documentTitles;

	@FindBy(css="p[class*='description']")
	public List<WebElement> documentSummaries;

	@FindBy(css="td[class*='date']")
	public List<WebElement> documentReceivedDate;

	@FindBy(css="td[class*='type']")
	public List<WebElement> documentType;

	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div > ul > li.pagination-next.ng-scope")
	public WebElementFacade nextButtonStatus;
	
	@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div > ul > li.pagination-next.ng-scope > a")
	public WebElementFacade nextButton;
	
	@FindBy(css="th:nth-child(2) > a > span")
	public WebElementFacade nameTitle;
	
	@FindBy(css="th:nth-child(3) > a > span")
	public WebElementFacade typeTitle;
	
	@FindBy(css="th:nth-child(4) > a > span")
	public WebElementFacade dateTitle;
	

	public List<WebElement> documentfolders(){
		return documentfolders;
	}
	public List<WebElement> documentSummaries(){
		return documentSummaries;
	}
	public List<WebElement> documentReceivedDate(){
		return documentReceivedDate;
	}
	public List<WebElement> documentType(){
		return documentType;
	}
	public WebElement nextButton(){
		return nextButton;
	}
	public WebElement nextButtonStatus(){
		return nextButtonStatus;
	}
	public WebElement listView(){
		return listView;
	}
	public WebElement noFileAvailability(){
		return noFileAvailability;
	}
	public WebElement title_Ascending(){
		return title_Ascending;
	}
	public WebElement title_Descending(){
		return title_Descending;
	}
	public WebElement type_Ascending(){
		return type_Ascending;
	}
	public WebElement type_Descending(){
		return type_Descending;
	}
	public WebElement date_Ascending(){
		return date_Ascending;
	}
	public WebElement date_Descending(){
		return date_Descending;
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@FindBy(css="li:nth-child(1) > a > h3")
	public WebElementFacade ENDemo_Link;

	@FindBy(css="li:nth-child(2) > a > h3")
	public WebElementFacade ENMarketingInfo_Link;

	@FindBy(css="li:nth-child(3) > a > h3")
	public WebElementFacade ENNewsLetter_Link;

	@FindBy(css="li:nth-child(4) > a > h3")
	public WebElementFacade ENVideo_Link;

	@FindBy(css="li:nth-child(5) > a > h3")
	public WebElementFacade ENManuals_Link;

	@FindBy(css="li:nth-child(6) > a > h3")
	public WebElementFacade ENOthers_Link;

	@FindBy(css="li:nth-child(7) > a > h3")
	public WebElementFacade ENTest_Link;

	@FindBy(css="files-tile-view > a > i")
	public WebElementFacade listwiseView;
	//label[for$=cleckbox-0]
	//input[type^=checkbox][id*=cleckbox-1]

	@FindBy(css="input#cleckbox-all")
	public WebElement selectedCheckbox;

	@FindBy(css="li > a[href*='#/documents/folder/']")
	public List<WebElement> folderslist;

	@FindBy(css="ul > li > a > h3 > span")
	public List<WebElement> unreadList;

	@FindBy(css="ul > li > div > p")
	public List<WebElementFacade> DocumentList;

	@FindBy(css="div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > ul > li > a > h3")
	public List<WebElementFacade> AllDocumentListView;

	@FindBy(css="div:nth-child(1) > div > div:nth-child(2) > div > a.all-documents > span.ng-binding")
	public WebElementFacade all_document_link;

	@FindBy(css="div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > p")
	public WebElementFacade no_files_text;

	@FindBy(css="a.btn.btn-default.download-all-documents.ng-scope")
	public WebElementFacade download_selected;

	@FindBy(css="div:nth-child(2) > div > a.all-documents > span.ng-binding")
	public WebElementFacade all_documnets_link;

	@FindBy(css="div:nth-child(2) > div > div > ul > li.pagination-page.ng-scope.active > a")
	public WebElementFacade no_of_document;

	@FindBy(css="files-table-view > table > tbody > tr > td.download")
	public WebElementFacade download_button;

	public  WebElement download_button(){
	    return download_button;
	}
	public  WebElement no_of_document(){
	    return no_of_document;
	}
	public  WebElement all_documnets_link(){
	    return all_documnets_link;
	}
	public  WebElement download_selected(){
	    return download_selected;
	}
	public  WebElement no_files_text(){
	    return no_files_text;
	}
	public  WebElement all_document_link(){
	    return all_document_link;
	}
	public  List<WebElement> unreadList(){
	    return unreadList;
	}
	public  List<WebElement> folderslist(){
	    return folderslist;
	}
	//public  List<WebElement> DocumentList(){
//	    return DocumentList;
	//}
	public  WebElement ENDemo_Link(){
	    return ENDemo_Link;
	}
	public  WebElement ENMarketingInfo_Link(){
	    return ENMarketingInfo_Link;
	}
	public  WebElement ENNewsLetter_Link(){
	    return ENNewsLetter_Link;
	}
	public  WebElement ENVideo_Link(){
	    return ENVideo_Link;
	}
	public  WebElement ENManuals_Link(){
	    return ENManuals_Link;
	}
	public  WebElement ENOthers_Link(){
	    return ENOthers_Link;
	}
	public  WebElement ENTest_Link(){
	    return ENTest_Link;
	}
	public  WebElement selectedCheckbox(){
	    return selectedCheckbox;
	}
	public WebElement listwiseView() {
		return listwiseView;
	}

}
