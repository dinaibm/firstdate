package ui.pageobjects.Signon;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class AccountActivationPageObjects extends PageObject{
	
@FindBy(css="button[translate='REGISTRATION.WELCOME.LETS_GO']")
public WebElementFacade letsGo;

@FindBy(css="button[translate='REGISTRATION.CODE.PROCEED']")
public WebElementFacade proceed;

@FindBy(css="p >strong")
public WebElementFacade mobileNumber;

@FindBy(css="input#verificationCode")
public WebElementFacade verificationCodeTextBox;

@FindBy(css="a[translate='REGISTRATION.CODE.SEND_NEW_CODE']")
public WebElementFacade resendPasscode;

@FindBy(css="p[class='hint second'] >span")
public WebElementFacade resendPasscodeNotification;

@FindBy(css="div[class='validation-error'] > p")
public WebElementFacade passcodeErrorMessage;

@FindBy(css="input#password")
public WebElementFacade password;

@FindBy(css="input#passwordConfirm")
public WebElementFacade confirmPassword;

@FindBy(css="div[class='validation-error'] > p")
public WebElementFacade passwordErrorMessage;

@FindBy(css="div[class='btn-group dropdown'] > button[class='btn dropdown-toggle']")
public WebElementFacade languageDropDown;

public By languageList=By.cssSelector("div[class*='btn-group dropdown'] >ul > li > a");

@FindBy(css="button#split-button[type='button']")
public WebElementFacade acceptTermsAndConditions;

@FindBy(css="button#split-button[type='button']")
public WebElementFacade continueButton;

@FindBy(css="div[class='button-container'] > button")
public WebElementFacade navigateToLoginPage;

@FindBy(css="a[translate='LOGIN.RESETPASS2.CODENOTARRIVE']")
public WebElementFacade passwordReset_resendPasscode;

@FindBy(css="p[class='ng-binding ng-scope']")
public WebElementFacade passwordReset_passcodeErrorMessage;

@FindBy(css="h4[translate='LOGIN.RESETPASS2.VERIFICATION']")
public WebElementFacade passwordReset_verificationText;

@FindBy(css="input#verificationCode")
public WebElementFacade passwordReset_passcodeTextBox;

@FindBy(css="button[translate='LOGIN.RESETPASS2.DONE']")
public WebElementFacade passwordReset_done;

@FindBy(css="h4[translate='LOGIN.CHANGEPASS.TEXT']")
public WebElementFacade passwordReset_newPasswordText;

@FindBy(css="input[placeholder='New password']")
public WebElementFacade passwordReset_newPassword;

@FindBy(css="input[placeholder='Repeat new password']")
public WebElementFacade passwordReset_confirmPassword;

@FindBy(css="button[translate='LOGIN.CHANGEPASS.CHANGE']")
public WebElementFacade passwordReset_changePasswordButton;

@FindBy(css="div[class='inside-table'] > p")
public WebElementFacade passwordReset_resetPasswordErrorMessage;

@FindBy(css="div[class='inside-table'] > p:nth-child(1)")
public WebElementFacade passwordReset_resetPasswordSuccessMessage;

@FindBy(css="#verificationCode")
public WebElementFacade verification_code;

@FindBy(css="section > div > form > div > div > div.row > div > button")
public WebElementFacade lets_go_link;

@FindBy(css="div:nth-child(2) > section > div > form > div > div > p.title.ng-scope")
public WebElementFacade Enter_passcode_text;

@FindBy(css="section > div > form > div > div > p.hint.third > a")
public WebElementFacade send_new_code_link;

@FindBy(css="section > div > form > div > div > div.button-container > button")
public WebElementFacade proceed_button;

@FindBy(css="div:nth-child(2) > section > div > form > div > div > div > p.title.ng-scope")
public WebElementFacade create_password_text;

@FindBy(css="section > div > form > div > div > div > p.username.ng-binding")
public WebElementFacade userName_textbox;

@FindBy(css="#password")
public WebElementFacade password_textbox;

@FindBy(css="#passwordConfirm")
public WebElementFacade repeatPassword_textbox;

@FindBy(css="button.btn.dropdown-toggle > span.glyphicon.glyphicon-chevron-down")
public WebElementFacade language_selection;

@FindBy(css="section > div > form > div > div > div > div:nth-child(9) > label")
public WebElementFacade accept_terms_link;

@FindBy(css="section > div > form > div > div > div > div.button-container > button")
public WebElementFacade continue_button;

public WebElement lets_go_link(){
	return lets_go_link;
}
public WebElement verification_code(){
	return verification_code;
}

}
