/*package ui.Signon;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptExecutor;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.AdminPage_object;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.FundingPageObjects;
import ui.pageobjects.Signon.MessagesPageObjects;
import ui.pageobjects.Signon.SettingsPageObjects;
import ui.pageobjects.Signon.SignonObjects;
import ui.pageobjects.Signon.UserManagementPageObjects;



public class AdminConsoleCreateUserPage extends PageObject {

	WebDriver driver =null;

	String Result=null;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	MessagesPageObjects messagespageobjects;
	FundingPageObjects fundingpageobjects;
	SettingsPageObjects settingspageobjects;
	UserManagementPageObjects usermanagementpageobjects;
	AdminPage_object adminPageobjects;
	
	@Step
	public String Create_new_merchant(String User_Type,String Merchant_ID,String Profile_type,String First_Name,String last_name,String UserName_new_alliance,String email_id,String mobile_number,String Language) throws Throwable{
	      driver=this.getDriver();
		WebDriverWait wait = new WebDriverWait(driver, 100);
	       //JavascriptExecutor executor = (JavascriptExecutor)driver;
	       wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.create_user_boardingagent()));
	       adminPageobjects.create_user_boardingagent.click();
	       wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.user_type()));
	       adminPageobjects.user_type().sendKeys(User_Type);
//	       adminPageobjects.merchantID.isCurrentlyVisible();
//	       System.out.println(adminPageobjects.merchantID.isCurrentlyVisible());
	      // wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.merchantID()));
	       waitFor(adminPageobjects.merchantID());
	       adminPageobjects.merchantID().sendKeys(Merchant_ID);
	       for(WebElement element:adminPageobjects.merchantList)
	       {
	    	   if(element.getText().contains(Merchant_ID))
	    		   waitFor(element).click();
	       }
	       //new Select(adminPageobjects.merchantID).selectByVisibleText(Merchant_ID);
	       
	       //adminPageobjects.merchantID().sendKeys(Merchant_ID);
	       wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.profile_type()));
	       adminPageobjects.profile_type().sendKeys(Profile_type);
	       wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.firstName()));
	       adminPageobjects.firstName().sendKeys(First_Name);
	       adminPageobjects.lastName().sendKeys(last_name);
	       adminPageobjects.email_id().sendKeys(email_id);
	       if(UserName_new_alliance.length()==8 || !(UserName_new_alliance.length()<8) || !(UserName_new_alliance.length()>25))
	       {
	              adminPageobjects.mobileNUmber().sendKeys(mobile_number);
	              wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Language_msg_dropdown()));
	              adminPageobjects.Language_msg_dropdown().sendKeys(Language);
	              wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.UserName_new_alliance()));
	              adminPageobjects.merchantID.isCurrentlyVisible();
	              System.out.println(adminPageobjects.UserName_new_alliance.isCurrentlyVisible());
	              adminPageobjects.UserName_new_alliance().sendKeys(UserName_new_alliance);  
	       }
	       else
	       {
	              Result="Failed  ";
	       }
	              adminPageobjects.save_button().click();
	              if(adminPageobjects.Field_error_message.isCurrentlyVisible())
	              {
	                     Result="Failed "+"User cannot be created suceesfully "+adminPageobjects.Field_error_message().getText();
	              }
	              else if(adminPageobjects.PanelError.isCurrentlyVisible())
	              {
	                     Result="Failed "+"User cannot be created suceesfully "+adminPageobjects.PanelError().getText();
	              }
	              else
	              {
	                     wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Created_successfully_text()));
	                     if(adminPageobjects.Created_successfully_text().getText().contains("User"))
	                     {
	                           Result="passed  "+adminPageobjects.Created_successfully_text().getText();
	                     }
	                     else
	                     {
	                           Result="Failed  "+adminPageobjects.Created_successfully_text().getText();
	                     }
	              }
	return Result;       
	}


}*/