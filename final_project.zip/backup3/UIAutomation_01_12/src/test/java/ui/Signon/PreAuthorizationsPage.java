/*package ui.Signon;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptExecutor;
import com.thoughtworks.selenium.webdriven.commands.WaitForPageToLoad;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.locators.WaitForWebElementCollection;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.FundingPageObjects;
import ui.pageobjects.Signon.MessagesPageObjects;
import ui.pageobjects.Signon.PreAuthorizationsPageObjects;
import ui.pageobjects.Signon.SignonObjects;



public class PreAuthorizationsPage extends PageObject {

	WebDriver driver =null;

	String Result=null;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	MessagesPageObjects messagespageobjects;
	FundingPageObjects fundingpageobjects;
	PreAuthorizationsPageObjects preAuthorizationsPageObjects;
	public String transactionDetails;

	ArrayList<Date> preAuthorizationDateAndTime=new ArrayList<Date>();
	public ArrayList<String> preAuthColumns=new ArrayList<String>();
	public ArrayList<String> preAuthtransactionDetails= new ArrayList<String>();
	public ArrayList<String> preAuthRecords=new ArrayList<String>();
	public ArrayList<String> preauthCreditData=new ArrayList<String>();
	public ArrayList<String> preauthDebitData=new ArrayList<String>();


	public void checkIfPageIsReady()
	{
		JavascriptExecutor js = (JavascriptExecutor)driver;
		for (int i=0; i<100; i++){ 
			if (js.executeScript("return document.readyState").toString().equals("complete")){ 
				break; 
			}

			System.out.println("Page Is loaded.");
		}
	}

	@Step
	public String validatePreAuthorizationsSortOrder(String fromDate, String toDate) throws IOException, ParseException, InterruptedException{

		driver=this.getDriver();
		
		for(int i=0;i<30;i++)
		{
		waitFor(ExpectedConditions.elementToBeClickable(preAuthorizationsPageObjects.searchFieldText));
		}

		System.out.println("\n Inside PreAuthorizations");

		waitFor(preAuthorizationsPageObjects.date_dropdown).click();
		waitFor(preAuthorizationsPageObjects.FromDate).click();
		waitFor(preAuthorizationsPageObjects.FromDate).clear();
		waitFor(preAuthorizationsPageObjects.FromDate).sendKeys(fromDate);
		waitFor(preAuthorizationsPageObjects.ToDate).click();
		waitFor(preAuthorizationsPageObjects.ToDate).clear();
		waitFor(preAuthorizationsPageObjects.ToDate).sendKeys(toDate);
		waitFor(preAuthorizationsPageObjects.applyDate).click();


		for(int i=0;i<30;i++)
		{
		waitFor(ExpectedConditions.elementToBeClickable(preAuthorizationsPageObjects.searchFieldText));
		}

		if(!preAuthorizationsPageObjects.noRecordsPresent.isCurrentlyVisible())
		{

			SimpleDateFormat sdf= new SimpleDateFormat("dd/MM/yyyy HH:mm");

			for(int i=0;i<preAuthorizationsPageObjects.preAuthorizationDate.size() && i<preAuthorizationsPageObjects.preAuthorizationTime.size();i++)
			{
				String dateAndTime= preAuthorizationsPageObjects.preAuthorizationDate.get(i).getText()+" "+preAuthorizationsPageObjects.preAuthorizationTime.get(i).getText();
				System.out.println("Date And Time value is:"+dateAndTime);
				preAuthorizationDateAndTime.add(sdf.parse(dateAndTime));
			}

			System.out.println("The Date and Time are:"+preAuthorizationDateAndTime);

			ArrayList<Date> duplicateDateAndTime=new ArrayList<Date>();
			duplicateDateAndTime=(ArrayList<Date>) preAuthorizationDateAndTime.clone();
			Collections.sort(duplicateDateAndTime);
			Collections.reverse(duplicateDateAndTime);

			System.out.println("The duplicate Date and Time are:"+duplicateDateAndTime);

			if(preAuthorizationDateAndTime.equals(duplicateDateAndTime))
			{
				Result="Passed";
			}
			else
			{
				Result="Failed";
			}
		}
		else
		{
			Result="No Records found";
		}


		return Result;

	}

	public String validatePreAuthorizationColumnsAndTransactionDetails() throws InterruptedException
	{
		driver=this.getDriver();
		WebDriverWait wait=new WebDriverWait(driver,10);

		checkIfPageIsReady();

		if(!preAuthorizationsPageObjects.noRecordsPresent.isCurrentlyVisible())
		{
			StringBuilder sb=new StringBuilder();
			Thread.sleep(5000);
			List<WebElementFacade> preAuthorizationColumns=preAuthorizationsPageObjects.preAuthorizationColumns;
			System.out.println("NUMBER OF COLUMNS IS:"+preAuthorizationColumns.size());
			for(int i=1;i<preAuthorizationColumns.size();i++)
			{

				if(preAuthorizationColumns.get(i).getText().isEmpty())
				{
					preAuthColumns.add("ECommerce/POS transaction");
				}
				else
				{
					preAuthColumns.add(preAuthorizationColumns.get(i).getText());
				}

			}

			System.out.println("the preauth columns are:"+preAuthColumns);

			waitFor(preAuthorizationsPageObjects.preAuthorizationDate.get(0)).click();

			for(int j=0;j<preAuthorizationsPageObjects.preAuthorizationHistory_AuthType.size();j++)
			{

				sb.append("Authorization Date:").append(preAuthorizationsPageObjects.preAuthorizationHistory_AuthDate.get(j).getText())
				.append("Authorization Time:").append(preAuthorizationsPageObjects.preAuthorizationHistory_AuthTime.get(j).getText())
				.append("Authorization Type:").append(preAuthorizationsPageObjects.preAuthorizationHistory_AuthType.get(j).getText())
				.append("Authorization Amount:").append(preAuthorizationsPageObjects.preAuthorizationHistory_AuthAmount.get(j).getText())
				.append("Authorization Status:").append(preAuthorizationsPageObjects.preAuthorizationHistory_AuthStatus.get(j).getText());
			}


			sb.append("Total Amount:").append(preAuthorizationsPageObjects.preAuthorizationHistory_TotalAmount.getText());

			String preAuthorizationHistory=sb.toString();
			System.out.println("PreAuth History:1     "+preAuthorizationHistory);

			transactionDetails="Transaction Details:"+preAuthorizationsPageObjects.transactionsDetails.getText()+
					"Pre-Authorization Code:"+preAuthorizationsPageObjects.preAuthorizationCode.getText()+
					"Card Number:"+preAuthorizationsPageObjects.preAuthorizationCardNumber.getText()+
					"Payment Type:"+preAuthorizationsPageObjects.preAuthorizationPaymentType.getText()+
					preAuthorizationHistory;

			Result="Passed";

		}
		else
		{
			Result=preAuthorizationsPageObjects.noRecordsPresent.getText();
		}

		return Result;

	}

	public String displayPreAuthorizationTransactionDetails() throws InterruptedException
	{
		driver=this.getDriver();
		checkIfPageIsReady();

		JavascriptExecutor executor=(JavascriptExecutor)driver;
		if(!preAuthorizationsPageObjects.noRecordsPresent.isCurrentlyVisible())
		{

			for(int i=0;i<preAuthorizationsPageObjects.preAuthorizationDate.size();i++)
			{
				executor.executeScript("arguments[0].click()",preAuthorizationsPageObjects.preAuthorizationDate.get(i));

				StringBuilder sb=new StringBuilder();


				System.out.println("No.of preauth "+preAuthorizationsPageObjects.preAuthorizationHistory_AuthType.size());

				for(int j=0;j<preAuthorizationsPageObjects.preAuthorizationHistory_AuthType.size();j++)
				{

					sb.append("Authorization Date:").append(preAuthorizationsPageObjects.preAuthorizationHistory_AuthDate.get(j).getText())
					.append("Authorization Time:").append(preAuthorizationsPageObjects.preAuthorizationHistory_AuthTime.get(j).getText())
					.append("Authorization Type:").append(preAuthorizationsPageObjects.preAuthorizationHistory_AuthType.get(j).getText())
					.append("Authorization Amount:").append(preAuthorizationsPageObjects.preAuthorizationHistory_AuthAmount.get(j).getText())
					.append("Authorization Status:").append(preAuthorizationsPageObjects.preAuthorizationHistory_AuthStatus.get(j).getText());
				}


				sb.append("Total Amount:").append(preAuthorizationsPageObjects.preAuthorizationHistory_TotalAmount.getText());

				String preAuthorizationHistory=sb.toString();
				System.out.println("PreAuth History:1     "+preAuthorizationHistory);

				transactionDetails="Transaction Details:"+preAuthorizationsPageObjects.transactionsDetails.getText()+
						"Pre-Authorization Code:"+preAuthorizationsPageObjects.preAuthorizationCode.getText()+
						"Card Number:"+preAuthorizationsPageObjects.preAuthorizationCardNumber.getText()+
						"Payment Type:"+preAuthorizationsPageObjects.preAuthorizationPaymentType.getText()+
						preAuthorizationHistory;

				System.out.println("PreAuth History2:"+preAuthorizationHistory);
				preAuthtransactionDetails.add(transactionDetails);
				executor.executeScript("arguments[0].click()",preAuthorizationsPageObjects.preAuthorizationDate.get(i));

			}

			Result="Passed";

		}
		else
		{
			Result=preAuthorizationsPageObjects.noRecordsPresent.getText();
		}

		return Result;

	}

	public String viewPreAuthCompletionDuration(String orderID)
	{
		driver=this.getDriver();
		checkIfPageIsReady();

		WebDriverWait wait=new WebDriverWait(driver,10);
		JavascriptExecutor executor=(JavascriptExecutor)driver;

		preAuthorizationsPageObjects.searchFieldText.sendKeys( orderID);
		executor.executeScript("arguments[0].click()",preAuthorizationsPageObjects.search_orderId);
		wait.until(ExpectedConditions.elementToBeClickable(preAuthorizationsPageObjects.search_button));
		executor.executeScript("arguments[0].click()",preAuthorizationsPageObjects.search_button);
		checkIfPageIsReady();
		for(int i=0;i<50;i++){}
		if(!preAuthorizationsPageObjects.noRecordsPresent.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(preAuthorizationsPageObjects.preAuthorizationDate.get(0)));
			executor.executeScript("arguments[0].click()",preAuthorizationsPageObjects.preAuthorizationDate.get(0));

			waitFor(preAuthorizationsPageObjects.completePreAuthorizationButton);
			if(preAuthorizationsPageObjects.completePreAuthorizationButton.isCurrentlyVisible())
			{
				executor.executeScript("arguments[0].click()",preAuthorizationsPageObjects.completePreAuthorizationButton);
				waitFor(preAuthorizationsPageObjects.preAuthorizationCompletionDuration);

				if(preAuthorizationsPageObjects.preAuthorizationCompletionDuration.isCurrentlyVisible())
				{
					Result=preAuthorizationsPageObjects.preAuthorizationCompletionDuration.getText();
				}
			}
			else
			{
				Result="Please check the transaction status";
			}
		}
		else
		{
			Result="Please enter a valid Order ID";
		}

		return Result;
	}

	public String viewPreAuthTransactionStatus(String orderID)
	{
		driver=this.getDriver();
		checkIfPageIsReady();

		WebDriverWait wait=new WebDriverWait(driver,10);
		JavascriptExecutor executor=(JavascriptExecutor)driver;

		preAuthorizationsPageObjects.searchFieldText.sendKeys( orderID);
		executor.executeScript("arguments[0].click()",preAuthorizationsPageObjects.search_orderId);
		wait.until(ExpectedConditions.elementToBeClickable(preAuthorizationsPageObjects.search_button));
		executor.executeScript("arguments[0].click()",preAuthorizationsPageObjects.search_button);
		while(!preAuthorizationsPageObjects.preAuthCompletionDate.get(0).isCurrentlyVisible())
		{
			waitFor(preAuthorizationsPageObjects.preAuthCompletionDate.get(0));
		}
		if(!preAuthorizationsPageObjects.noRecordsPresent.isCurrentlyVisible())
		{
			String status=preAuthorizationsPageObjects.preAuthCompletionDate.get(0).getText();
			if(status.equalsIgnoreCase("Completed") || status.equalsIgnoreCase("Declined"))
			{
				Result=status;
			}
			else
			{
				Result="To be completed before/Will expire on:"+status;
			}


		}
		else
		{
			Result="Please enter a valid Order ID";
		}

		return Result;
	}


	public String displayPreAuthorizationRecords()
	{
		driver=this.getDriver();

//		while(!preAuthorizationsPageObjects.searchFieldText.isCurrentlyVisible())
//		{
//			waitFor(preAuthorizationsPageObjects.searchFieldText);
//		}

		if(!preAuthorizationsPageObjects.noRecordsPresent.isCurrentlyVisible())
		{
			for(WebElement record:preAuthorizationsPageObjects.preAuthorizationRecords)
			{
				System.out.println(record.getText());
				preAuthRecords.add(record.getText());
			}

			System.out.println("The records are:"+preAuthRecords);
			Result="Passed";

		}

		else
		{
			Result="No Records Present";
		}
		
		return Result;
	}
	
	public String validatePreauthCreditAndDebitTransactionData(String orderID)
	{
		driver=this.getDriver();

		WebDriverWait wait=new WebDriverWait(driver,10);
		JavascriptExecutor executor=(JavascriptExecutor)driver;

		preAuthorizationsPageObjects.searchFieldText.sendKeys(orderID);
		executor.executeScript("arguments[0].click()",preAuthorizationsPageObjects.search_orderId);
		wait.until(ExpectedConditions.elementToBeClickable(preAuthorizationsPageObjects.search_button));
		executor.executeScript("arguments[0].click()",preAuthorizationsPageObjects.search_button);

		for(int i=0;i<50;i++){}
		if(!preAuthorizationsPageObjects.noRecordsPresent.isCurrentlyVisible())
		{
			for(int i=0;i<preAuthorizationsPageObjects.preAuthorizationDate.size();i++)
			{
				executor.executeScript("arguments[0].click()",preAuthorizationsPageObjects.preAuthorizationDate.get(i));
				

				for(int j=0;j<preAuthorizationsPageObjects.preAuthorizationHistory_AuthType.size() && j<preAuthorizationsPageObjects.preAuthorizationHistory_AuthAmount.size();j++)
				{
					if(preAuthorizationsPageObjects.preAuthorizationHistory_AuthAmount.get(j).getText().startsWith("-") && preAuthorizationsPageObjects.preAuthorizationHistory_AuthAmount.get(j).getCssValue("color").equals("rgba(240, 4, 4, 1)"))
					{
						System.out.println("Color is:"+preAuthorizationsPageObjects.preAuthorizationHistory_AuthAmount.get(j).getCssValue("color"));
						String combined=preAuthorizationsPageObjects.preAuthorizationHistory_AuthType.get(j).getText()+":"+preAuthorizationsPageObjects.preAuthorizationHistory_AuthAmount.get(j).getText();
						preauthDebitData.add(combined);
					}
					else
					{
						System.out.println("Color is:"+preAuthorizationsPageObjects.preAuthorizationHistory_AuthAmount.get(j).getCssValue("color"));
						String combined=preAuthorizationsPageObjects.preAuthorizationHistory_AuthType.get(j).getText()+":"+preAuthorizationsPageObjects.preAuthorizationHistory_AuthAmount.get(j).getText();
						preauthCreditData.add(combined);
					}
				}
			}


			Result="Passed";
		}
		else
		{
		
		Result="No Records Present";
		}

		
		return Result;
	}

}

















































*/