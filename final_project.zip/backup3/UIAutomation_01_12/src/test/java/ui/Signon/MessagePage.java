package ui.Signon;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptExecutor;
import com.thoughtworks.selenium.webdriven.JavascriptLibrary;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.AdminPage_object;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.FundingPageObjects;
import ui.pageobjects.Signon.MessagesPageObjects;
import ui.pageobjects.Signon.SignonObjects;



public class MessagePage extends PageObject {

	WebDriver driver =null;

	String Result=null;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	MessagesPageObjects messagespageobjects;
	FundingPageObjects fundingpageobjects;
	boolean Status=false;
	AdminPage_object adminpageObjects;
	String message_link=null;
	public String device;
	
	long small_wait_time=50;
	long medium_wait_time=100;
	long large_wait_time=500;

	public ArrayList<String> messageTitle=new ArrayList<String>();
	public ArrayList<String> messageSubtitle=new ArrayList<String>();
	public ArrayList<String> receivedDate=new ArrayList<String>();
	public ArrayList<String> archivedStatus=new ArrayList<String>();
	public ArrayList<String> readStatus=new ArrayList<String>();
	public ArrayList<String> messageType=new ArrayList<String>();
	public ArrayList<String> messages=new ArrayList<String>();

	//JavascriptExecutor executor=(JavascriptExecutor)driver;


	@Step
	public String displayArchivedMessages() throws IOException{

		driver=this.getDriver();

		System.out.println(messagespageobjects.messagelist_ul().getAttribute("ui-view"));
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.archivedMessages_Link()));

		messagespageobjects.archivedMessages_Link().click();
		if(messagespageobjects.noMessagesFound.isCurrentlyVisible())
		{
			Result=messagespageobjects.noMessagesFound.getText();
		}
		else
		{
		System.out.println(messagespageobjects.messagelist_ul().getAttribute("ui-view"));
		Result=messagespageobjects.messagelist_ul().getAttribute("ui-view");
		}

		return Result;
	}

	public String displayIntialMessageCount(){

		driver=this.getDriver();
		List <WebElement> checkboxes= driver.findElements(messagespageobjects.inboxMessagesCheckBox);
		if(checkboxes.size()==10)
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}

		return Result;
	}

	public String verifySearchOptionPresent(){

		String searchBox=null;
		driver=this.getDriver();
		if(messagespageobjects.search_Button().isDisplayed())
		{
			searchBox=messagespageobjects.search_Button().getText();
		}

		return searchBox;
	}

	public String verifySearchResultCoverTitle(String title) throws IOException, InterruptedException{
		driver=this.getDriver();
		messagespageobjects.search_Textbox().clear();
		messagespageobjects.search_Textbox().sendKeys(title);
		messagespageobjects.search_Button().click();
		if(!messagespageobjects.noMessagesFound.isCurrentlyVisible())
		{
		for(int i=0;i<50;i++){waitFor(ExpectedConditions.elementToBeClickable(messagespageobjects.messageTitles.get(0)));}
		System.out.println("Title is:"+messagespageobjects.messageTitles.get(0).getText());
		Result=messagespageobjects.messageTitles.get(0).getText();
		}
		else
		{
			Result=messagespageobjects.noMessagesFound.getText();	
		}
		return Result;
	}

	public String verifySearchResultCoverSubtitle(String subtitle) throws IOException, InterruptedException{
		driver=this.getDriver();
		messagespageobjects.search_Textbox().clear();
		messagespageobjects.search_Textbox().sendKeys(subtitle);
		messagespageobjects.search_Button().click();
		if(!messagespageobjects.noMessagesFound.isCurrentlyVisible())
		{
		for(int i=0;i<50;i++){waitFor(ExpectedConditions.elementToBeClickable(messagespageobjects.messageSubtitles.get(0)));}
		System.out.println("Subtitle is:"+messagespageobjects.messageSubtitles.get(0).getText());
		Result=messagespageobjects.messageSubtitles.get(0).getText();
		}
		else
		{
			Result=messagespageobjects.noMessagesFound.getText();	
		}
		
		return Result;
	}

	public String verifySearchResultCoverMessageBody(String messagebody) throws IOException, InterruptedException{
		driver=this.getDriver();
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		messagespageobjects.search_Textbox().clear();
		messagespageobjects.search_Textbox().sendKeys(messagebody);
		messagespageobjects.search_Button().click();
		if(!messagespageobjects.noMessagesFound.isCurrentlyVisible())
		{
		for(int i=0;i<50;i++){waitFor(ExpectedConditions.elementToBeClickable(messagespageobjects.messageTitles.get(0)));}
		executor.executeScript("arguments[0].click()",messagespageobjects.messageTitles.get(0));
		driver.switchTo().frame("message-content-object");
		waitFor(messagespageobjects.message_bodyText());
		System.out.println("Message Body is:"+messagespageobjects.message_bodyText().getText());
		Result= messagespageobjects.message_bodyText().getText();
		}
		else
		{
			Result=messagespageobjects.noMessagesFound.getText();
		}
		
		return Result;
	}
	
	public String archiveFirstSearchResult(String messagetitle) throws IOException, InterruptedException{
		driver=this.getDriver();
		messagespageobjects.search_Textbox().sendKeys(messagetitle);
		System.out.println("Typed the text "+messagetitle+" in the search inbox");
		messagespageobjects.search_Button().click();
		System.out.println("clicked the search button");
		String archivedmessagetitle=messagespageobjects.inboxsearch_firstresulttitle().getText();
		System.out.println("the title of the message to be archived is:"+archivedmessagetitle);
		messagespageobjects.archive_Button().click();
		System.out.println("clicked the archive button");
		messagespageobjects.archivedMessages_Link().click();
		System.out.println("clicked the archived link");
		messagespageobjects.search_Textbox().sendKeys(archivedmessagetitle);
		System.out.println("Typed the text "+archivedmessagetitle+" in the search inbox");
		messagespageobjects.search_Button().click();
		System.out.println("clicked the search button");
		String title=messagespageobjects.inboxsearch_firstresulttitle().getText();
		System.out.println("the title of the archived message is:"+title);

		return title;
	}

	public String markUnreadMessageAsRead() throws IOException, InterruptedException{
		driver=this.getDriver();
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		int count=0;
		String attributeAfterClick=null;
		boolean flag=true;
		boolean unreadMessagePresence=false;

		if(!messagespageobjects.noMessagesFound.isCurrentlyVisible())
		{

			while(flag==true)
			{

				if((messagespageobjects.nexButtonStatus.getAttribute("class").contains("disabled")))
				{
					flag=false;
				}


				for(int i=0;i<messagespageobjects.listOfMessages.size() && unreadMessagePresence==false;i++)
				{
					if(messagespageobjects.listOfMessages.get(i).getAttribute("class").contains("unread"))
					{
						count++;
						System.out.println("Attribute before click:"+messagespageobjects.listOfMessages.get(i).getAttribute("class"));
						waitFor(messagespageobjects.listOfMessages.get(i)).click();
						attributeAfterClick=messagespageobjects.listOfMessages.get(i).getAttribute("class");
						unreadMessagePresence=true;
					}
				}

				System.out.println(flag);
				if(flag==true)
				{

					//Actions actions=new Actions(driver);
					new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(messagespageobjects.nexButton()));
					//actions.moveToElement(messagespageobjects.nexButton()).click().build().perform();
					executor.executeScript("arguments[0].click()",messagespageobjects.nexButton());

				}
			}

			if(count==0)
			{
				Result="No Unread Messages Found";
			}

			if(count!=0 && !attributeAfterClick.contains("unread"))
			{
				Result="Passed";
			}
		}
		else
		{
			Result="No Messages Found";
		}

		return Result;

	}

	public String archiveMultipleMessages() throws InterruptedException, AWTException
	{
		driver=this.getDriver();
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebDriverWait wait = new WebDriverWait(driver,60);

		if(!messagespageobjects.noMessagesFound.isCurrentlyVisible())
		{

			//wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.inbox_messages_list()));
			//messagespageobjects.inbox_messages_list().click();
			//System.out.println("text is:"+messagespageobjects.inbox_messages_list().getText());
			List<WebElement> messageList=driver.findElements(messagespageobjects.inboxMessagesCheckBox);
			System.out.println(messageList.size());
			while( messageList.size()==0)
			{
				messageList=driver.findElements(messagespageobjects.inboxMessagesCheckBox);
			}
			System.out.println(messageList.size());
			for(int i=0;i<3 && i<messageList.size() ;i++)
			{
				String id=messageList.get(i).getAttribute("id");
				System.out.println(id);
				executor.executeScript("document.getElementById('"+id+"').click()");
			}
			executor.executeScript("arguments[0].click()",messagespageobjects.addToArchive);
			if(messagespageobjects.archivedNotification.isCurrentlyVisible())
			{
				Result="Passed";
			}
			else
			{
				Result="Failed";
			}
		}
		else
		{
			Result="No messages found";
		}
		
		return Result;
	}


	public String getListofMessages() throws InterruptedException
	{
		driver=this.getDriver();
		JavascriptExecutor executor= (JavascriptExecutor)driver;

		boolean flag=true;

		if(!messagespageobjects.noMessagesFound.isCurrentlyVisible())
		{
			while(flag==true)
			{

				System.out.println("the status of the next button is:"+messagespageobjects.nexButtonStatus.getAttribute("class"));	
				if((messagespageobjects.nexButtonStatus.getAttribute("class").contains("disabled")))
				{
					flag=false;
				}

				System.out.println(messagespageobjects.messageTitles.size());
				System.out.println(messagespageobjects.messageSubtitles.size());
				System.out.println(messagespageobjects.messageReceivedDate.size());
				System.out.println(messagespageobjects.messageReadStatusAndArchivedFlag.size());
				System.out.println(messagespageobjects.messageType.size());


				for(int i=0;i<10 && i<messagespageobjects.messageTitles.size();i++)
				{
					System.out.println("title is : "+messagespageobjects.messageTitles.get(i).getText());
					messageTitle.add(messagespageobjects.messageTitles.get(i).getText());
					System.out.println("subtitle is : "+messagespageobjects.messageSubtitles.get(i).getText());
					messageSubtitle.add(messagespageobjects.messageSubtitles.get(i).getText());
					System.out.println("Received Date is : "+messagespageobjects.messageReceivedDate.get(i).getText());
					receivedDate.add(messagespageobjects.messageReceivedDate.get(i).getText());
					System.out.println("type is : "+messagespageobjects.messageType.get(i).getAttribute("class"));
					if(messagespageobjects.messageType.get(i).getAttribute("class").contains("fa-info-circle"))
					{
						messageType.add("Alert");
					}
					else
					{
						messageType.add("Notification");
					}
					System.out.println("read status is : "+messagespageobjects.messageReadStatusAndArchivedFlag.get(i).getAttribute("class"));
					if(messagespageobjects.messageReadStatusAndArchivedFlag.get(i).getAttribute("class").contains("unread"))
					{
						readStatus.add("Unread");
					}
					else
					{
						readStatus.add("read");
					}
					System.out.println("archived flag is : "+messagespageobjects.messageReadStatusAndArchivedFlag.get(i).getAttribute("class"));
					if(messagespageobjects.messageReadStatusAndArchivedFlag.get(i).getAttribute("class").contains("un-checked"))
					{
						archivedStatus.add("unchecked");
					}
					else
					{
						archivedStatus.add("checked");
					}
				}

				System.out.println(flag);
				if(flag==true)
				{
					waitFor(messagespageobjects.nexButton());
					executor.executeScript("arguments[0].click()",messagespageobjects.nexButton());
				}

			}

			System.out.println(messageTitle.size());
			System.out.println(messageSubtitle.size());
			System.out.println(receivedDate.size());
			System.out.println(readStatus.size());
			System.out.println(archivedStatus.size());
			System.out.println(messageType.size());

			for(int i=0;i<messageTitle.size();i++)
			{
				String combined=messageTitle.get(i)+"||"+messageSubtitle.get(i)+"||"+receivedDate.get(i)+"||"+readStatus.get(i)+"||"+archivedStatus.get(i)+"||"+messageType.get(i);
				messages.add(combined);
			}

			Result="Passed";

		}
		else
		{
			Result="No Messages Found";
		}

		return Result;

	}
	
	
	/*------------------------Sailasuta----------------------------------*/
	
	
	@Step	
	public String Print_option_Message(String Message_text){
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver, small_wait_time);
		messagespageobjects.messages_Link().click();
		wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.messages_text()));
		if(messagespageobjects.messages_text().getText().equals(Message_text))
		{
			wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.print_option()));
			messagespageobjects.print_option().click();
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}
		return Result;
		}
	@Step	
	public String Create_message(String Alliance_Name, String language, String type, String title, String sub_title, String date_received, String Validity_type, String In_days_Validity_days, String message_body) throws InterruptedException{
			driver = this.getDriver();	
			WebDriverWait wait = new WebDriverWait(driver,medium_wait_time);
			/*if(!adminpageObjects.GUI_Message.isCurrentlyVisible())
			{adminpageObjects.hidden_button.click();*/
			wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.GUI_Message()));
			adminpageObjects.GUI_Message().click();
			wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.Add_button()));
			adminpageObjects.Add_button().click();
			for(int i=0;i<=80;i++)
			{checkPageIsReady();waitForWithRefresh();		
			wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.allianceCode_dropdown()));}
			adminpageObjects.allianceCode_dropdown().sendKeys(Alliance_Name);
			System.out.println(Alliance_Name+"Donef0");
			waitForWithRefresh();
			for(int i=0;i<=100;i++)
			{checkPageIsReady();waitForWithRefresh();		
			waitFor(adminpageObjects.Language_msg_dropdown());}
			//new Select(adminpageObjects.Language_msg_dropdown()).selectByVisibleText(language);
			adminpageObjects.Language_msg_dropdown().sendKeys(language);
			adminpageObjects.type_dropdown().sendKeys(type);
			adminpageObjects.message_title().sendKeys(title);
			adminpageObjects.message_subTitle().sendKeys(sub_title);
			adminpageObjects.date_picker().sendKeys(date_received);
			adminpageObjects.Flag_notification().click();
			if(Validity_type.equals("In days"))
			{
				adminpageObjects.Indays_validity().click();
				adminpageObjects.Indays_validity_days().sendKeys(In_days_Validity_days);
			}
			else if(Validity_type.equals("Unlimited"))
			{
				adminpageObjects.unlimited_validity().click();
			}
			adminpageObjects.messagebody().sendKeys(message_body);
			adminpageObjects.save_button().click();
			wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.Created_successfully_text()));
			System.out.println(adminpageObjects.Created_successfully_text().getText());
			if(adminpageObjects.Created_successfully_text().getText().contains("Message "+'"'+title+'"'+" has been added successfully."))
			{
				wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.Created_successfully_text()));
				Result="Passed "+adminpageObjects.Created_successfully_text().getText();
			}
			else
			{
				wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.Created_successfully_text()));
				Result="Failed"+adminpageObjects.Created_successfully_text().getText();
			}

		return Result;
	}
	@Step
	public String Download_attachment_from_message(String message_Title) throws Throwable{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver,20);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		if(dasboardpageObjects.toggleButton_mobile.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.toggleButton_mobile));
			executor.executeScript("arguments[0].click()",dasboardpageObjects.toggleButton_mobile);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messages_Link));
			dasboardpageObjects.messages_Link().click();
			wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.searchbox_message()));
			messagespageobjects.searchbox_message().sendKeys(message_Title);
			executor.executeScript("arguments[0].click()",messagespageobjects.search_Button());
			wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.Message_Title()));
			if(messagespageobjects.Message_Title().getText().equals(message_Title))
			{
				if(messagespageobjects.Download_all_attachment.isCurrentlyVisible())
				{
					
					wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.Download_all_attachment()));
					executor.executeScript("arguments[0].click()", messagespageobjects.Download_all_attachment());
					for(int i=0;i<=100;i++)
					{
						checkPageIsReady();
					}
					Result = "Passed";
				}
				else
				{
					Result="Failed";
				}
			}
			else
			{
				Result="Failed";
			}
		}
		else
		{
			dasboardpageObjects.messages_Link().click();
			wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.searchbox_message()));
			messagespageobjects.searchbox_message().sendKeys(message_Title);
			messagespageobjects.search_Button().click();
			wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.Message_Title()));
			if(messagespageobjects.Message_Title().getText().equals(message_Title))
			{
				if(messagespageobjects.Download_all_attachment.isCurrentlyVisible())
				{
					
					wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.Download_all_attachment()));
					executor.executeScript("arguments[0].click()", messagespageobjects.Download_all_attachment());
					Result = "Passed";
				}
				else
				{
					Result="Failed";
				}
			}
			else
			{
				Result="Failed";
			}
		}
		return Result;
	}
	@Step
	public String validation_of_message_template(String message_Title) throws Throwable{
		driver = this.getDriver();	
		String message_type=null;
		WebDriverWait wait = new WebDriverWait(driver,small_wait_time);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		if(dasboardpageObjects.toggleButton_mobile.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.toggleButton_mobile));
			executor.executeScript("arguments[0].click()",dasboardpageObjects.toggleButton_mobile);
			wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.messages_Link()));
			messagespageobjects.messages_Link().click();
			wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.searchbox_message()));
			messagespageobjects.searchbox_message().sendKeys(message_Title);
			executor.executeScript("arguments[0].click()",messagespageobjects.search_Button());
			wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.Message_Title()));
			if(messagespageobjects.Message_Title().getText().equals(message_Title))
			{
						
						if(messagespageobjects.message_subTitle.isCurrentlyVisible() && messagespageobjects.date_time.isCurrentlyVisible())
						{
							//System.out.println(messagepageObjects.message_bodyText().getText());
							
							driver.switchTo().frame("message-content-object");
							System.out.println(messagespageobjects.message_bodyText().getText());
							System.out.println(messagespageobjects.Download_all_attachment.isCurrentlyVisible());
							if(messagespageobjects.message_bodyText().getText()!=null && messagespageobjects.Download_all_attachment.isCurrentlyVisible()){

								Result="Passed"+":"+message_type+","+"Attachement and message body text is available";
							}
							else if (messagespageobjects.message_bodyText().getText()!=null || messagespageobjects.Download_all_attachment.isCurrentlyVisible())
							{
								Result="Passed"+":"+message_type+","+"Attachement or message body text is available";
							}
							else
							{
								Result="Passed"+" "+"Both are not available";
							}
						}	
				}
		
					
				else
				{
					Result="Failed"+" "+"No message found";
				}
		}
		else
		{
			messagespageobjects.messages_Link().click();
			wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.searchbox_message()));
			messagespageobjects.searchbox_message().sendKeys(message_Title);
			messagespageobjects.search_Button().click();
			wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.Message_Title()));
			if(messagespageobjects.Message_Title().getText().equals(message_Title))
			{
				if(messagespageobjects.notification_flag_type.isCurrentlyVisible() && messagespageobjects.notification_flag_type().getAttribute("class").equals("fa  fa-bullhorn"))
				{
						message_type="Notification";
						String status[]=messagespageobjects.message_status_readunread().getAttribute("class").split(" ");
						if(messagespageobjects.message_subTitle.isCurrentlyVisible() && messagespageobjects.date_time.isCurrentlyVisible() && messagespageobjects.archieve_button.isCurrentlyEnabled())
						{
							//System.out.println(messagepageObjects.message_bodyText().getText());
							
							driver.switchTo().frame("message-content-object");
							System.out.println(messagespageobjects.message_bodyText().getText());
							System.out.println(messagespageobjects.Download_all_attachment.isCurrentlyVisible());
							if(messagespageobjects.message_bodyText().getText()!=null && messagespageobjects.Download_all_attachment.isCurrentlyVisible()){
								Result="Passed"+":"+message_type+","+status[1]+"Attachement and message body text is available";
							}
							else if (messagespageobjects.message_bodyText().getText()!=null || messagespageobjects.Download_all_attachment.isCurrentlyVisible())
							{
								Result="Passed"+":"+message_type+","+status[1]+"Attachement or message body text is available";
							}
							else
							{
								Result="Passed"+" "+"Both are not available";
							}
						}	
				}
				else if(messagespageobjects.alert_flag_type.isCurrentlyVisible() && messagespageobjects.alert_flag_type().getAttribute("class").equals("fa  fa-info-circle"))
				{
					message_type="Alert";
					String status[]=messagespageobjects.message_status_readunread().getAttribute("class").split(" ");
					if(messagespageobjects.message_subTitle.isCurrentlyVisible() && messagespageobjects.date_time.isCurrentlyVisible() && messagespageobjects.archieve_button.isCurrentlyEnabled())
					{
						if(messagespageobjects.message_bodyText().getText()!=null && messagespageobjects.Download_all_attachment.isCurrentlyVisible()){
							Result="Passed"+":"+message_type+","+status[1]+"Attachement and message body text is available";
						}
						else if (messagespageobjects.message_bodyText().getText()!=null || messagespageobjects.Download_all_attachment.isCurrentlyVisible())
						{
							Result="Passed"+":"+message_type+","+status[1]+"Attachement or message body text is available";
						}
						else
						{
							Result="Passed"+" "+"Both are not available";
						}
					}
				}
				
				
			}
			
				else
				{
					Result="Failed"+" "+"No message found";
				}
		}
		
		return Result;
		
	}
	@Step
	public String permanent_link_Retrive(String userID_LBC,String password_LBC,String message_Title) throws Throwable{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver,medium_wait_time);
		wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.GUI_Message()));
		adminpageObjects.GUI_Message().click();
		wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.search_box));
		adminpageObjects.search_box().sendKeys(message_Title);
		adminpageObjects.search_button().click();
		for(int i=0;i<=50;i++)
		{checkPageIsReady();}
		if(adminpageObjects.selected_message().getText().equals(message_Title))
		{
			System.out.println(adminpageObjects.selected_message().getText());
			adminpageObjects.selected_message().click();
			if(adminpageObjects.message_link.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.message_link()));
				message_link=adminpageObjects.message_link().getText();
				driver.get(message_link);
				wait.until(ExpectedConditions.elementToBeClickable(signonObjects.UserName()));
				signonObjects.UserName().sendKeys(userID_LBC);
				wait.until(ExpectedConditions.elementToBeClickable(signonObjects.Password()));
				signonObjects.Password().sendKeys(password_LBC);
				signonObjects.Submit().click();
				wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.Message_Title()));
				if(messagespageobjects.Message_Title().getText().equals(message_Title))
				{
					Result="Passed"+message_Title;
				}
				else{
					Result="Failed";
				}	
			}
			else{
				Result="Failed";
			}
		}
		else
		{
			Result="Failed"+" "+"No message found";
		}
		
		return Result;
	}
	@Step
	public String pagination_of_message() throws Throwable{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver,small_wait_time);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		if(dasboardpageObjects.toggleButton_mobile.isCurrentlyVisible())
		{
			executor.executeScript("arguments[0].click()",dasboardpageObjects.toggleButton_mobile);
			wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.messages_Link()));
			messagespageobjects.messages_Link().click();
			wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.inbox_link));
			executor.executeScript("arguments[0].click()",messagespageobjects.inbox_link);
			for(int i=0;i<=25;i++){checkPageIsReady();}
			if(messagespageobjects.more_message_pagination.isCurrentlyVisible())
			{
				
				wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.more_message_pagination()));
				executor.executeScript("arguments[0].click()", messagespageobjects.more_message_pagination());
				Result="Passed " ;
				
			 }
			else
			{
				Result="Failed "+ "no paging is available";
			}
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.messages_Link()));
			messagespageobjects.messages_Link().click();
			wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.inbox_message_count()));
			String convertmessagecount=messagespageobjects.inbox_message_count().getText().toString();
			System.out.println(messagespageobjects.inbox_message_count().getText());
			wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.inbox_message_count()));
			//System.out.println(messagepageObjects.inbox_message_count().getText().toString());
			int read_message_count=Integer.parseInt(convertmessagecount);
			System.out.println(read_message_count);
			if(messagespageobjects.more_message_pagination.isCurrentlyVisible())
			{
				for(int i=0; i<=read_message_count/10; i++)
			 {
				wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.more_message_pagination()));
				executor.executeScript("arguments[0].click()", messagespageobjects.more_message_pagination());
				
			 }
				Result="Passed "+ read_message_count ;
			}
			else
			{
				Result="Failed "+ "no paging is available";
			}
		}
		return Result;
	}

	@Step
	public String display_message_in_descending_order() throws Throwable{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver,small_wait_time);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		if(dasboardpageObjects.toggleButton_mobile.isCurrentlyVisible())
		{
			executor.executeScript("arguments[0].click()",dasboardpageObjects.toggleButton_mobile);
			wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.messages_Link()));
			messagespageobjects.messages_Link().click();
			wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.inbox_link));
			executor.executeScript("arguments[0].click()",messagespageobjects.inbox_link);
			for(int i=0;i<=25;i++){checkPageIsReady();}
			wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.message_start_date_list));
			String current_date_of_message=messagespageobjects.message_start_date_list.getText();
			if(messagespageobjects.more_message_pagination.isCurrentlyVisible())
			{
				
				wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.more_message_pagination()));
				executor.executeScript("arguments[0].click()", messagespageobjects.more_message_pagination());
				wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.message_end_date_list()));
				String Last_date_of_message=messagespageobjects.message_end_date_list().getText();
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		        Date date1 = sdf.parse(current_date_of_message);
		        Date date2 = sdf.parse(Last_date_of_message);
		
		        System.out.println("Date1"+sdf.format(date1));
		        System.out.println("Date2"+sdf.format(date2));
		        if(date1.after(date2)){
		            System.out.println("Date1 is after Date2");
		            Result="Passed "+" The display order is in descending mode ";
		        }
		        // before() will return true if and only if date1 is before date2
		        else if(date1.before(date2)){
		            System.out.println("Date1 is before Date2");
		            Result="Failed "+" The display order is in Ascending mode ";
		        }
		
		        //equals() returns true if both the dates are equal
		        else if(date1.equals(date2)){
		            System.out.println("Date1 is equal Date2");
		            Result="Failed "+" Both the messages are created in same time. ";
		            
		        }
			}
			else
			{
				wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.message_end_date_list()));
				String Last_date_of_message=messagespageobjects.message_end_date_list().getText();
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		        Date date1 = sdf.parse(current_date_of_message);
		        Date date2 = sdf.parse(Last_date_of_message);
		
		        System.out.println("Date1"+sdf.format(date1));
		        System.out.println("Date2"+sdf.format(date2));
		        if(date1.after(date2)){
		            System.out.println("Date1 is after Date2");
		            Result="Passed "+" The display order is in descending mode ";
		        }
		        // before() will return true if and only if date1 is before date2
		        else if(date1.before(date2)){
		            System.out.println("Date1 is before Date2");
		            Result="Failed "+" The display order is in Ascending mode ";
		        }
		
		        //equals() returns true if both the dates are equal
		        else if(date1.equals(date2)){
		            System.out.println("Date1 is equal Date2");
		            Result="Failed "+" Both the messages are created in same time. ";
		        }
			}
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.messages_Link()));
			messagespageobjects.messages_Link().click();
			wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.inbox_message_count()));
			String messagecount=messagespageobjects.inbox_message_count().getText();
			System.out.println("messagecount "+messagespageobjects.inbox_message_count().getText());
			int read_message_count=Integer.valueOf(messagecount);
			wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.message_start_date_list));
			String current_date_of_message=messagespageobjects.message_start_date_list.getText();
			if(messagespageobjects.more_message_pagination.isCurrentlyVisible())
			{
				for(int i=0; i<=read_message_count/10; i++)
			 {
				wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.more_message_pagination()));
				executor.executeScript("arguments[0].click()", messagespageobjects.more_message_pagination());
			 }	
				wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.message_end_date_list()));
				String Last_date_of_message=messagespageobjects.message_end_date_list().getText();
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		        Date date1 = sdf.parse(current_date_of_message);
		        Date date2 = sdf.parse(Last_date_of_message);
		
		        System.out.println("Date1"+sdf.format(date1));
		        System.out.println("Date2"+sdf.format(date2));
		        if(date1.after(date2)){
		            System.out.println("Date1 is after Date2");
		            Result="Passed "+" The display order is in descending mode ";
		        }
		        // before() will return true if and only if date1 is before date2
		        else if(date1.before(date2)){
		            System.out.println("Date1 is before Date2");
		            Result="Failed "+" The display order is in Ascending mode ";
		        }
		
		        //equals() returns true if both the dates are equal
		        else if(date1.equals(date2)){
		            System.out.println("Date1 is equal Date2");
		            Result="Failed "+" Both the messages are created in same time. ";
		            
		        }
			}
			else
			{
				wait.until(ExpectedConditions.elementToBeClickable(messagespageobjects.message_end_date_list()));
				String Last_date_of_message=messagespageobjects.message_end_date_list().getText();
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		        Date date1 = sdf.parse(current_date_of_message);
		        Date date2 = sdf.parse(Last_date_of_message);
		
		        System.out.println("Date1"+sdf.format(date1));
		        System.out.println("Date2"+sdf.format(date2));
		        if(date1.after(date2)){
		            System.out.println("Date1 is after Date2");
		            Result="Passed "+" The display order is in descending mode ";
		        }
		        // before() will return true if and only if date1 is before date2
		        else if(date1.before(date2)){
		            System.out.println("Date1 is before Date2");
		            Result="Failed "+" The display order is in Ascending mode ";
		        }
		
		        //equals() returns true if both the dates are equal
		        else if(date1.equals(date2)){
		            System.out.println("Date1 is equal Date2");
		            Result="Failed "+" Both the messages are created in same time. ";
		        }
			}
		}
		
		return Result;
		
	}
	@Step
	public String modify_the_Message(String Message_title,String Sub_title,String message_body,String Upload_file) throws Throwable{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver,medium_wait_time);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.GUI_Message()));
		adminpageObjects.GUI_Message().click();
		wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.search_box()));
		adminpageObjects.search_box().sendKeys(Message_title);
		wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.search_button()));
		adminpageObjects.search_button().click();
		waitForWithRefresh();
		wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.message_title_selected()));
		System.out.println(adminpageObjects.message_title_selected.isCurrentlyVisible());
		if(!adminpageObjects.no_records_found.isCurrentlyVisible())
		{
			waitForWithRefresh();
			//System.out.println(adminpageObjects.selected_message().getText());
			waitFor(adminpageObjects.message_title_selected());
			if(adminpageObjects.message_title_selected().getText().equals(Message_title))
			{
				adminpageObjects.selected_message().click();
				wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.message_title()));
				adminpageObjects.message_subTitle.clear();
				adminpageObjects.message_subTitle().sendKeys(Sub_title);
				wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.messagebody()));
				//adminpageObjects.messagebody().clear();
				adminpageObjects.messagebody.sendKeys(message_body);
				wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.AttachmentLink()));
				File f = new File(Upload_file);
				System.out.println(f.getName());
				String filename=f.getName();
				
				if(f.getName().endsWith(".pdf"))
				{
					adminpageObjects.AttachmentLink().sendKeys(Upload_file);
					wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.upload_button()));
					adminpageObjects.upload_button().click();
					wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.Created_successfully_text()));
					System.out.println(adminpageObjects.Created_successfully_text().getText()+filename);
					if(adminpageObjects.Created_successfully_text().getText().contains('"'+filename+'"'+" was uploaded. Please save to continue"))
					{
						//wait.until(ExpectedConditions.elementToBeSelected(adminpageObjects.save_button()));
						adminpageObjects.save_button().click();
						wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.Created_successfully_text()));
						//wait.until((ExpectedConditions.elementToBeSelected(adminpageObjects.search_button())));
						Result="Passed "+adminpageObjects.Created_successfully_text().getText();
					}
					else
					{
						Result="Failed "+"File cannot be uploaded";
						wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.cancel_button()));
						adminpageObjects.cancel_button().click();
					}
				}
				else
				{
					Result="Failed "+"File extensions is not applicable only require .pdf";
				}
			}
			else
			{
				Result="Failed "+"No Message is there..failed to fetch the message";
			}	
		}
		else
		{
			Result="Failed "+adminpageObjects.no_records_found().getText();
		}
		return Result;
	}
	@Step
	public String delete_the_Message(String Message_title) throws Throwable{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver,small_wait_time);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.home_link_admin));
		adminpageObjects.home_link_admin.click();
		wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.GUI_Message()));
		adminpageObjects.GUI_Message().click();
		wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.search_box()));
		adminpageObjects.search_box().sendKeys(Message_title);
		wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.search_button()));
		executor.executeScript("arguments[0].click()",adminpageObjects.search_button());
		for(int i=0;i<=60;i++){wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.selected_message()));}
		if(!adminpageObjects.no_records_found.isCurrentlyVisible())
		{
			for(int i=0;i<=50;i++)
			{waitFor(adminpageObjects.selected_message());}
			if(adminpageObjects.selected_message.getText().equals(Message_title))
			{	
				for(int i=0;i<=50;i++)
				{wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.deletebutton()));}
				adminpageObjects.deletebutton().click();
				for(int i=0;i<=50;i++)
				{wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.Created_successfully_text()));}
				System.out.println(adminpageObjects.Created_successfully_text().getText());
				if(adminpageObjects.Created_successfully_text().getText().contains("Message "+'"'+Message_title+'"'+" was deleted."))
				{
					wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.Created_successfully_text()));
					Result="Passed "+adminpageObjects.Created_successfully_text().getText();
				}
				else
				{
					Result="Failed "+"Message was not deleted";
				}
			}
			else
			{
			Result="Failed "+"No Message is there..failed to fetch the message";
			}
		}	

		else
		{
			Result="Failed "+adminpageObjects.no_records_found().getText();
		}
		return Result;
		}
	public void checkPageIsReady() throws InterruptedException {

		  JavascriptExecutor js = (JavascriptExecutor)driver;


		  //Initially bellow given if condition will check ready state of page.
		/*  if (js.executeScript("return document.readyState").toString().equals("complete")){ 
		
		   return; 
		  } 
	*/
		  //This loop will rotate for 25 times to check If page Is ready after every 1 second.
		  //You can replace your value with 25 If you wants to Increase or decrease wait time.
		  for (int i=0; i<100; i++){ 
		   //To check page ready state.
		   if (js.executeScript("return document.readyState").toString().equals("complete")){ 
			   
		    break; 
		   }
		   System.out.println("Page Is loaded.");
		  }
		 }


}







































































