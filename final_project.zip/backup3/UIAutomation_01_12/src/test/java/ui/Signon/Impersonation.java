package ui.Signon;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.AccountActivationPageObjects;
import ui.pageobjects.Signon.AdminPage_object;
import ui.pageobjects.Signon.ChangePasswordPageObjects;
import ui.pageobjects.Signon.CommunicationSummaryPageObjects;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.EmailTemplatePageObjects;
import ui.pageobjects.Signon.ExportEmailPageObjects;
import ui.pageobjects.Signon.FundingPageObjects;
import ui.pageobjects.Signon.MerchantAdminPageObjects;
import ui.pageobjects.Signon.MessagesPageObjects;
import ui.pageobjects.Signon.ParametersPageObjects;
import ui.pageobjects.Signon.PreAuthorizationsPageObjects;
import ui.pageobjects.Signon.SMSTemplatePageObjects;
import ui.pageobjects.Signon.SettingsPageObjects;
import ui.pageobjects.Signon.SignonObjects;
import ui.pageobjects.Signon.UserManagementPageObjects;
import ui.pageobjects.Signon.UsersListPageObjects;

public class Impersonation extends PageObject{

	WebDriver driver =null;

	String Result=null;
	boolean Status=false;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	AdminPage_object adminPageobjects;
	UserManagementPageObjects usermanagePageobjects;
	SettingsPageObjects settingspageobjects;
	ExportEmailPageObjects exportemailadminPageobjects;
	CommunicationSummaryPageObjects comsummaryadminPageobjects;
	EmailTemplatePageObjects emailtemplatePageobjects;
	SMSTemplatePageObjects smstemplatePageobjects;
	PreAuthorizationsPageObjects preauthobjects;
	MessagesPageObjects messagespageobjects;
	FundingPageObjects fundingpageobjects;
	UserManagementPageObjects usermanagementpageobjects;
	CommunicationSummaryPageObjects communicationSummaryPageObjects;
	AccountActivationPageObjects accountActivationPageObjects;
	ChangePasswordPageObjects changePasswordPageObjects; 
	MerchantAdminPageObjects merchantAdminPageObjects;
	UsersListPageObjects usersListPageObjects; 
	ParametersPageObjects parametersPageObjects;
	
	long small_wait_time=50;
	long medium_wait_time=100;
	long large_wait_time=500;
	
	public String device;
	
	@Step
	public String user_clicks_submit_and_should_be_logged_in_as_call_center_agent() throws InterruptedException{
		WebDriverWait wait = new WebDriverWait(driver, small_wait_time);
		signonObjects.Submit().click();
		wait.until(ExpectedConditions.or(ExpectedConditions.visibilityOf(dasboardpageObjects.Impersonation_Welcome_Text()),ExpectedConditions.visibilityOf(signonObjects.Login_error())));
		if(dasboardpageObjects.Impersonation_Welcome_Text.isCurrentlyVisible())
		{
			Result="Passed"+"::"+"Successful Login; Welcome Text:"+dasboardpageObjects.Impersonation_Welcome_Text.getText();
		}
		else if(signonObjects.Login_error.isDisplayed())
		{
			Result="Failed"+"::"+signonObjects.Login_error.getText();
		}
		else 
		{
			Result="Failed";	
		}
		return Result;
	}
}
