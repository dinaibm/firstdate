/*package ui.Signon;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.MerchantAdminPageObjects;
import ui.pageobjects.Signon.SignonObjects;
import ui.pageobjects.Signon.TermsAndConditionsPageObjects;

public class TermsAndConditionsPage extends PageObject{

	WebDriver driver =null;
	public String newTermsAndConditionsID;

	TermsAndConditionsPageObjects termsandconditionspageobjects;

	@Step
	public String uploadTermsAndConditions(String alliancename,String type, String language,String TCName, String description, String htmlfilepath, String pdffilepath) throws AWTException, InterruptedException
	{
		driver= this.getDriver();
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.addnewtermsandcondtions())).click();
		System.out.println("Clicked on Add----------------");
		
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.alliancename()));
		Select TCalliancename=new Select(termsandconditionspageobjects.alliancename());
		TCalliancename.selectByValue(alliancename);
		System.out.println("Selected Alliance name as EMS-------------");
		
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.type()));
		Select TCtype=new Select(termsandconditionspageobjects.type());
		TCtype.selectByVisibleText(type);
		System.out.println("Selected type as REGISTRATION-------------");
		
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.defaultlanguage()));
		Select defaultlanguage=new Select(termsandconditionspageobjects.defaultlanguage());
		defaultlanguage.selectByVisibleText(language);
		System.out.println("Selected default language as ENGLISH-------------");
		
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.name()));
		termsandconditionspageobjects.name().click();
		termsandconditionspageobjects.name().sendKeys(TCName);
		System.out.println("Name is:"+termsandconditionspageobjects.name().getText());
		
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.description()));
		termsandconditionspageobjects.description().click();
		termsandconditionspageobjects.description().sendKeys(description);
		System.out.println("Description is:"+termsandconditionspageobjects.description().getText());
		
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.htmlfileinput()));
		termsandconditionspageobjects.htmlfileinput().sendKeys(htmlfilepath);
		

		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.htmlfileupload()));
		termsandconditionspageobjects.htmlfileupload().click();
		for(int i=0;i<50;i++){};
		
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.pdffileinput()));
		termsandconditionspageobjects.pdffileinput().sendKeys(pdffilepath);

		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.pdffileupload()));
		termsandconditionspageobjects.pdffileupload().click();
		for(int i=0;i<50;i++){};
		
		String uploadedfiles=termsandconditionspageobjects.uploadedtermsandconditions().getText();
		String[] filenames=uploadedfiles.split(",");
		System.out.println("HTML File name:"+filenames[0]);
		System.out.println("PDF File name:"+filenames[1]);
		
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.savetermsandconditions()));
		termsandconditionspageobjects.savetermsandconditions().click();
		for(int i=0;i<50;i++){};
		
		System.out.println("clicked on Save");
		
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.newtermsandconditions()));
		
		System.out.println("The namE of the Latest T&C is:"+termsandconditionspageobjects.newtermsandconditions().getText());
		newTermsAndConditionsID=termsandconditionspageobjects.newtermsandconditionsid().getText();
		
		
		return termsandconditionspageobjects.newtermsandconditions().getText();
		
		

	}
	
	
}
*/