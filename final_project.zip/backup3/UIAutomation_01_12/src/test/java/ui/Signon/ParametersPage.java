/*package ui.Signon;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.ParametersPageObjects;

public class ParametersPage extends PageObject{

	WebDriver driver =null;
	ParametersPageObjects parametersPageObjects;
	String Result;
	
	
	@Step
	public String changeSessionExpiryTime(String expiryTime)
	{
		driver= this.getDriver();
		waitFor(parametersPageObjects.sessionExpiryTime).click();
		String originalValue=waitFor(parametersPageObjects.sessionExpiryTime).getAttribute("value");
		waitFor(parametersPageObjects.sessionExpiryTime).clear();
		waitFor(parametersPageObjects.sessionExpiryTime).sendKeys(expiryTime);
		waitFor(parametersPageObjects.saveButton).click();
		if(parametersPageObjects.parameterErrorMessage.isCurrentlyVisible())
		{
			Result=parametersPageObjects.parameterErrorMessage.getText();
		}
		else
		{
			waitFor(parametersPageObjects.activeParameters).click();
			String duration=waitFor(parametersPageObjects.sessionExpiryTime).getAttribute("value");
			if(duration.equals(expiryTime))
			{
				Result="Passed";
				waitFor(parametersPageObjects.sessionExpiryTime).click();
				waitFor(parametersPageObjects.sessionExpiryTime).clear();
				waitFor(parametersPageObjects.sessionExpiryTime).sendKeys(originalValue);
				waitFor(parametersPageObjects.saveButton).click();
			}
			else
			{
				Result="Failed";
			}
			
		}
		
		return Result;
	}
	
	public String changePasscodeExpiryTime(String passcodeExpiryTime)
	{
		driver= this.getDriver();
		String originalValue=waitFor(parametersPageObjects.sessionExpiryTime).getAttribute("value");
		waitFor(parametersPageObjects.passcodeExpiryTime).click();
		waitFor(parametersPageObjects.passcodeExpiryTime).clear();
		waitFor(parametersPageObjects.passcodeExpiryTime).sendKeys(passcodeExpiryTime);
		waitFor(parametersPageObjects.saveButton).click();
		if(parametersPageObjects.parameterErrorMessage.isCurrentlyVisible())
		{
			Result=parametersPageObjects.parameterErrorMessage.getText();
		}
		else
		{
			waitFor(parametersPageObjects.activeParameters).click();
			String duration=waitFor(parametersPageObjects.passcodeExpiryTime).getAttribute("value");
			if(duration.equals(passcodeExpiryTime))
			{
				Result="Passed";
				waitFor(parametersPageObjects.passcodeExpiryTime).click();
				waitFor(parametersPageObjects.passcodeExpiryTime).clear();
				waitFor(parametersPageObjects.passcodeExpiryTime).sendKeys(originalValue);
				waitFor(parametersPageObjects.saveButton).click();
			}
			else
			{
				Result="Failed";
			}
			
		}
		
		return Result;
	}
	
	public String changePasswordExpiryDuration(String passwordExpiryDuration)
	{
		driver= this.getDriver();
		String originalValue=waitFor(parametersPageObjects.passwordExpiryDays).getAttribute("value");
		waitFor(parametersPageObjects.passwordExpiryDays).click();
		waitFor(parametersPageObjects.passwordExpiryDays).clear();
		waitFor(parametersPageObjects.passwordExpiryDays).sendKeys(passwordExpiryDuration);
		waitFor(parametersPageObjects.saveButton).click();
		if(parametersPageObjects.parameterErrorMessage.isCurrentlyVisible())
		{
			Result=parametersPageObjects.parameterErrorMessage.getText();
		}
		else
		{
			waitFor(parametersPageObjects.activeParameters).click();
			String duration=waitFor(parametersPageObjects.passwordExpiryDays).getAttribute("value");
			if(duration.equals(passwordExpiryDuration))
			{
				Result="Passed";
				waitFor(parametersPageObjects.passwordExpiryDays).click();
				waitFor(parametersPageObjects.passwordExpiryDays).clear();
				waitFor(parametersPageObjects.passwordExpiryDays).sendKeys(originalValue);
				waitFor(parametersPageObjects.saveButton).click();
			}
			else
			{
				Result="Failed";
			}
			
		}
		
		return Result;
	}
	
	public String changePasswordResetLinkExpiryTime(String passwordResetLinkExpiryTime)
	{
		driver= this.getDriver();
		String originalValue=waitFor(parametersPageObjects.passwordResetLinkExpiryTime).getAttribute("value");
		waitFor(parametersPageObjects.passwordResetLinkExpiryTime).click();
		waitFor(parametersPageObjects.passwordResetLinkExpiryTime).clear();
		waitFor(parametersPageObjects.passwordResetLinkExpiryTime).sendKeys(passwordResetLinkExpiryTime);
		waitFor(parametersPageObjects.saveButton).click();
		if(parametersPageObjects.parameterErrorMessage.isCurrentlyVisible())
		{
			Result=parametersPageObjects.parameterErrorMessage.getText();
		}
		else
		{
			waitFor(parametersPageObjects.activeParameters).click();
			String duration=waitFor(parametersPageObjects.passwordResetLinkExpiryTime).getAttribute("value");
			if(duration.equals(passwordResetLinkExpiryTime))
			{
				Result="Passed";
//				waitFor(parametersPageObjects.passcodeExpiryTime).click();
//				waitFor(parametersPageObjects.passcodeExpiryTime).clear();
//				waitFor(parametersPageObjects.passcodeExpiryTime).sendKeys(originalValue);
//				waitFor(parametersPageObjects.saveButton).click();
			}
			else
			{
				Result="Failed";
			}
			
		}
		
		return Result;
	}
}
*/