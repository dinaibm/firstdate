/*package ui.Signon;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.paulhammant.ngwebdriver.NgWebDriver;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.DocumentsPageObjects;
import ui.pageobjects.Signon.FundingPageObjects;
import ui.pageobjects.Signon.SignonObjects;

public class DocumentsPage extends PageObject{

	WebDriver driver =null;

	public String Result=null,Result1=null;


	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	FundingPageObjects fundingpageobjects;
	DocumentsPageObjects documentspageobjects;


	public ArrayList<String> documentTitle=new ArrayList<String>();
	public ArrayList<String> documentSummary=new ArrayList<String>();
	public ArrayList<String> receivedDate=new ArrayList<String>();
	public ArrayList<String> documentType=new ArrayList<String>();
	public ArrayList<String> documents=new ArrayList<String>();


	@Step
	public ArrayList<String> getDocumentsFolderList(){
		driver = this.getDriver();
		ArrayList<String> folderlist=new ArrayList<String>();

		int count=documentspageobjects.documentfolders().size();
		System.out.println("Number of folders is:"+count);
		for(WebElement element:documentspageobjects.documentfolders())
		{
			System.out.println("Folder name is:"+element.getText());
			folderlist.add(element.getText());
		}

		return folderlist;
	}

	public String clickFolder(String folderName)
	{
		driver=this.getDriver();
		int count=documentspageobjects.folderslist.size();
		System.out.println("Number of folders is:"+count);
		for(WebElement element:documentspageobjects.folderslist)
		{
			if(element.getText().equalsIgnoreCase(folderName))
			{
				System.out.println("Folder name is:"+element.getText());
				waitFor(element).click();
				Result="Passed";
			}	
		}

		return Result;

	}

	public String getListofDocuments() throws InterruptedException
	{

		driver=this.getDriver();	
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		boolean flag=true;

		if(!documentspageobjects.noFileAvailability.isCurrentlyVisible())
		{

			waitFor(documentspageobjects.listView()).click();



			while(flag==true)
			{
				for(int i=0;i<10;i++)
				{
					waitFor(ExpectedConditions.elementToBeClickable(documentspageobjects.nameTitle));
				}


				if((documentspageobjects.nextButtonStatus.getAttribute("class").contains("disabled")))
				{
					flag=false;
				}

				System.out.println(documentspageobjects.documentTitles.size());
				System.out.println(documentspageobjects.documentSummaries.size());
				System.out.println(documentspageobjects.documentReceivedDate.size());
				System.out.println(documentspageobjects.documentType.size());


				for(int i=0;i<documentspageobjects.documentTitles.size();i++)
				{
					for(int j=0;j<10;j++)
					{
						waitFor(documentspageobjects.documentTitles.get(i));
						waitFor(documentspageobjects.documentSummaries.get(i));
						waitFor(documentspageobjects.documentReceivedDate.get(i));
						waitFor(documentspageobjects.documentType.get(i));

					}
					System.out.println("title is : "+documentspageobjects.documentTitles.get(i).getText());
					documentTitle.add(documentspageobjects.documentTitles.get(i).getText());
					System.out.println("summary is : "+documentspageobjects.documentSummaries.get(i).getText());
					documentSummary.add(documentspageobjects.documentSummaries.get(i).getText());
					System.out.println("Received Date is : "+documentspageobjects.documentReceivedDate.get(i).getText());
					receivedDate.add(documentspageobjects.documentReceivedDate.get(i).getText());
					System.out.println("type is : "+documentspageobjects.documentType.get(i).getText());
					documentType.add(documentspageobjects.documentType.get(i).getText());
				}
				System.out.println(flag);
				if(flag==true)
				{

					executor.executeScript("arguments[0].click()", documentspageobjects.nextButton());

				}

			}

			System.out.println(documentTitle.size());
			System.out.println(documentSummary.size());
			System.out.println(receivedDate.size());
			System.out.println(documentType.size());

			for(int i=0;i<documentTitle.size();i++)
			{
				String combined=documentTitle.get(i)+"||"+documentSummary.get(i)+"||"+receivedDate.get(i)+"||"+documentType.get(i);
				documents.add(combined);
			}


			Result="Passed";

		}
		else
		{
			Result="Failed";
		}

		return Result;
	}
	public String displayFirstTenDocuments() throws InterruptedException
	{

		driver=this.getDriver();	

		if(!documentspageobjects.noFileAvailability.isCurrentlyVisible())
		{

			waitFor(documentspageobjects.listView()).click();


			System.out.println(documentspageobjects.documentTitles.size());


			for(int i=0;i<10 && i<documentspageobjects.documentTitles.size();i++)
			{
				System.out.println("title is : "+documentspageobjects.documentTitles.get(i).getText());
				documentTitle.add(documentspageobjects.documentTitles.get(i).getText());
			}

			System.out.println(documentTitle.size());


			if(documentTitle.size()==10)
			{

				Result="Passed";
			}
			else
			{
				Result= "Less Files Present";
			}

		}
		else
		{
			Result="No Files Present";
		}

		return Result;
	}

	public String verifyDocumentOrderByDate() throws InterruptedException, ParseException
	{

		driver=this.getDriver();	
		boolean flag=true;

		if(!documentspageobjects.noFileAvailability.isCurrentlyVisible())
		{

			waitFor(documentspageobjects.listView()).click();

			while(flag==true)
			{

				if((documentspageobjects.nextButtonStatus.getAttribute("class").contains("disabled")))
				{
					flag=false;
				}

				System.out.println(documentspageobjects.documentReceivedDate.size());

				for(int i=0;i<10 && i<documentspageobjects.documentReceivedDate.size();i++)
				{

					System.out.println("Received Date is : "+documentspageobjects.documentReceivedDate.get(i).getText());
					receivedDate.add(documentspageobjects.documentReceivedDate.get(i).getText());


					System.out.println(flag);
					if(flag==true)
					{
						Actions actions=new Actions(driver);
						new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(documentspageobjects.nextButton()));
						actions.moveToElement(documentspageobjects.nextButton()).click().build().perform();
					}

				}
			}

			System.out.println("Count is:"+receivedDate.size());
			SimpleDateFormat format=new SimpleDateFormat("dd/MM/yyyy");
			ArrayList<Date> duplicateReceivedDate1= new ArrayList<Date>();
			ArrayList<Date> duplicateReceivedDate2= new ArrayList<Date>();
			for(int i=0;i<receivedDate.size();i++)
			{
				duplicateReceivedDate1.add(format.parse(receivedDate.get(i)));
				duplicateReceivedDate2.add(format.parse(receivedDate.get(i)));

			}
			Collections.sort(duplicateReceivedDate1);
			Collections.sort(duplicateReceivedDate2);
			Collections.reverse(duplicateReceivedDate1);
			Collections.reverse(duplicateReceivedDate2);

			System.out.println("Received Date:"+receivedDate);
			System.out.println("Duplicate Received Date1:"+duplicateReceivedDate1);
			System.out.println("Duplicate Received Date1:"+duplicateReceivedDate2);

			if(duplicateReceivedDate1.equals(duplicateReceivedDate2))
			{
				Result="Passed";
			}
			else
			{
				Result="Not in Descending order";
			}
		}
		else
		{
			Result="No Files Present";
		}

		return Result;
	}


	public String orderDocuments(String orderBy) throws ParseException
	{

		String order=orderBy;
		String orderStatus;

		driver=this.getDriver();	
		//boolean flag=true;
		JavascriptExecutor executor=(JavascriptExecutor)driver;

		if(!documentspageobjects.noFileAvailability.isCurrentlyVisible())
		{

			waitFor(documentspageobjects.listView()).click();

			if(order.equalsIgnoreCase("title"))
			{
				orderStatus=orderDocumentsByTitle();
				if(orderStatus.equals("ascending"))
				{
					Result="Documents are intially in ascending order";
				}
				else if(orderStatus.equals("descending"))
				{
					Result="Documents are intially in descending order";
				}
				else
				{
					Result="Documents are intially in an unknown order";
				}

				executor.executeScript("arguments[0].click()",documentspageobjects.nameTitle);
				orderStatus=orderDocumentsByTitle();
				if(orderStatus.equals("ascending"))
				{
					Result=Result+" and then they have been sorted in ascending order";
				}
				else
				{
					Result=Result+" and then they have been sorted in descending order";
				}
				
				executor.executeScript("arguments[0].click()",documentspageobjects.nameTitle);
				orderStatus=orderDocumentsByTitle();
				if(orderStatus.equals("ascending"))
				{
					Result=Result+" and then they have been sorted in ascending order";
				}
				else
				{
					Result=Result+" and then they have been sorted in descending order";
				}
				
				
			}

			else if(order.equalsIgnoreCase("type"))
			{
				orderStatus=orderDocumentsByType();
				if(orderStatus.equals("ascending"))
				{
					Result="Documents are intially in ascending order";
				}
				else if(orderStatus.equals("descending"))
				{
					Result="Documents are intially in descending order";
				}
				else
				{
					Result="Documents are intially in an unknown order";
				}
				executor.executeScript("arguments[0].click()",documentspageobjects.typeTitle);
				orderStatus=orderDocumentsByType();
				if(orderStatus.equals("ascending"))
				{
					Result=Result+" and then they have been sorted in ascending order";
				}
				else
				{
					Result=Result+" and then they have been sorted in descending order";
				}
				
				executor.executeScript("arguments[0].click()",documentspageobjects.typeTitle);
				orderStatus=orderDocumentsByType();
				if(orderStatus.equals("ascending"))
				{
					Result=Result+" and then they have been sorted in ascending order";
				}
				else
				{
					Result=Result+" and then they have been sorted in descending order";
				}	
			

			}
			else if(order.equalsIgnoreCase("date"))
			{
				orderStatus=orderDocumentsByDate();
				if(orderStatus.equals("ascending"))
				{
					Result="Documents are intially in ascending order";
				}
				else if(orderStatus.equals("descending"))
				{
					Result="Documents are intially in descending order";
				}
				else
				{
					Result="Documents are intially in an unknown order";
				}

				executor.executeScript("arguments[0].click()",documentspageobjects.dateTitle);
				orderStatus=orderDocumentsByDate();
				if(orderStatus.equals("ascending"))
				{
					Result=Result+" and then they have been sorted in ascending order";
				}
				else
				{
					Result=Result+" and then they have been sorted in descending order";
				}
				
				executor.executeScript("arguments[0].click()",documentspageobjects.dateTitle);
				orderStatus=orderDocumentsByDate();
				if(orderStatus.equals("ascending"))
				{
					Result=Result+" and then they have been sorted in ascending order";
				}
				else
				{
					Result=Result+" and then they have been sorted in descending order";
				}	

			}
			else
			{
				Result="Invalid sort type";
			}

		}
		else
		{
			Result="no files";
		}

		return Result;
	}

	public String orderDocumentsByDate() throws ParseException
	{
		String result;
		driver=this.getDriver();

		for(int i=0;i<10;i++)
		{
			waitFor(ExpectedConditions.elementToBeClickable(documentspageobjects.dateTitle));
		}
		System.out.println(documentspageobjects.documentReceivedDate.size());

		for(int i=0;i<documentspageobjects.documentReceivedDate.size();i++)
		{
			System.out.println("Document Received Date is : "+documentspageobjects.documentReceivedDate.get(i).getText());
			receivedDate.add(documentspageobjects.documentReceivedDate.get(i).getText());
		}

		ArrayList<Date> duplicateDate1= new ArrayList<Date>();
		ArrayList<Date> duplicateDate2= new ArrayList<Date>();
		SimpleDateFormat format=new SimpleDateFormat("dd/MM/yyyy");

		for(int i=0;i<receivedDate.size();i++)
		{
			duplicateDate1.add(format.parse(receivedDate.get(i)));
			duplicateDate2.add(format.parse(receivedDate.get(i)));

		}
		Collections.sort(duplicateDate1);
		Collections.sort(duplicateDate2);
		Collections.reverse(duplicateDate2);

		if(receivedDate.equals(duplicateDate1))	
		{
			result="ascending";
		}
		else if(receivedDate.equals(duplicateDate2))
		{
			result="descending";
		}
		else
		{
			result="unknown";
		}
		return result;
	}

	public String orderDocumentsByType()
	{
		String result;
		driver=this.getDriver();
		
		for(int i=0;i<10;i++)
		{
			waitFor(ExpectedConditions.elementToBeClickable(documentspageobjects.typeTitle));
		}


			System.out.println(documentspageobjects.documentType.size());

			for(int i=0;i<documentspageobjects.documentType.size();i++)
			{

				System.out.println("Document Type is : "+documentspageobjects.documentType.get(i).getText());
				documentType.add(documentspageobjects.documentType.get(i).getText());

			}

		ArrayList<String> duplicateType1= new ArrayList<String>();
		ArrayList<String> duplicateType2= new ArrayList<String>();
		for(int i=0;i<documentType.size();i++)
		{
			duplicateType1.add(documentType.get(i));
			duplicateType2.add(documentType.get(i));

		}
		Collections.sort(duplicateType1);
		Collections.sort(duplicateType2);
		Collections.reverse(duplicateType2);

		if(documentType.equals(duplicateType1))	
		{
			result="ascending";
		}
		else if(documentType.equals(duplicateType2))
		{
			result="descending";
		}
		else
		{
			result="unknown";
		}
		return result;
	}

	public String orderDocumentsByTitle()
	{
		String result;
		driver=this.getDriver();
		
		for(int i=0;i<10;i++)
		{
			waitFor(ExpectedConditions.elementToBeClickable(documentspageobjects.nameTitle));
		}


			System.out.println(documentspageobjects.documentTitles.size());

			for(int i=0;i<documentspageobjects.documentTitles.size();i++)
			{

				System.out.println("Document Type is : "+documentspageobjects.documentTitles.get(i).getText());
				documentTitle.add(documentspageobjects.documentTitles.get(i).getText());

			}

		ArrayList<String> duplicateTitle1= new ArrayList<String>();
		ArrayList<String> duplicateTitle2= new ArrayList<String>();
		for(int i=0;i<documentTitle.size();i++)
		{
			duplicateTitle1.add(documentTitle.get(i));
			duplicateTitle2.add(documentTitle.get(i));

		}
		Collections.sort(duplicateTitle1);
		Collections.sort(duplicateTitle2);
		Collections.reverse(duplicateTitle2);

		if(documentTitle.equals(duplicateTitle1))	
		{
			result="ascending";
		}
		else if(documentTitle.equals(duplicateTitle2))
		{
			result="descending";
		}
		else
		{
			result="unknown";
		}
		return result;
	}


	public ArrayList<String> getDocuments() throws InterruptedException, ParseException
	{

		driver=this.getDriver();
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		boolean flag=true;

		if(!documentspageobjects.noFileAvailability.isCurrentlyVisible())
		{

			waitFor(documentspageobjects.listView()).click();

			while(flag==true)
			{
				
				for(int i=0;i<10;i++)
				{
					waitFor(ExpectedConditions.elementToBeClickable(documentspageobjects.nameTitle));
				}

				if((documentspageobjects.nextButtonStatus.getAttribute("class").contains("disabled")))
				{
					flag=false;
				}

				System.out.println(documentspageobjects.documentTitles.size());

				for(int i=0;i<10 && i<documentspageobjects.documentTitles.size();i++)
				{

					System.out.println("Docement Title is : "+documentspageobjects.documentTitles.get(i).getText());
					documentTitle.add(documentspageobjects.documentTitles.get(i).getText());
				}

				System.out.println(flag);
				if(flag==true)
				{
					executor.executeScript("arguments[0].click()",documentspageobjects.nextButton);
				}

			}

			System.out.println("Count is:"+documentTitle.size());
			Result="Passed";
		}

		else
		{
			Result="No Files Present";
		}

		return documentTitle;	
	}

}

































*/