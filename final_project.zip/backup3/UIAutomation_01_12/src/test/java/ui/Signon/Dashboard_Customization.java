package ui.Signon;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.MessagesPageObjects;
import ui.pageobjects.Signon.SettingsPageObjects;
import ui.pageobjects.Signon.SignonObjects;

public class Dashboard_Customization extends PageObject{

	WebDriver driver =null;
	long small_wait_time=50;
	long medium_wait_time=100;
	long large_wait_time=500;
	String Result=null;
	boolean Status=false;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	//MessagePage_Objects messagepageobjects;
	MessagesPageObjects messagepageObjects;
	SettingsPageObjects settingspageobjects;
	
@Step
public String Display_static_manage_content_in_preferred_language(String Language_Change,String Device,String Welcome_Text, String Authorizations_Text,String Pre_authorizations_Text,String Transactions_Text,String Funding_Text) throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, medium_wait_time);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	if(Device.equalsIgnoreCase("desktop"))
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Welcome_message()));
		if(dasboardpageObjects.Welcome_message().getText().contains(Welcome_Text))
		{
			System.out.println(dasboardpageObjects.payment_dashboard_text().getText().contains(Authorizations_Text));
			System.out.println(		dasboardpageObjects.sales_dashboard_text().getText().contains(Transactions_Text));
					System.out.println(		dasboardpageObjects.pre_authorization_widget().getText().contains(Pre_authorizations_Text) );
							System.out.println(		dasboardpageObjects.funding_Dashboard_Text().getText().contains(Funding_Text));
			
			if(dasboardpageObjects.payment_dashboard_text().getText().contains(Authorizations_Text) && 
					dasboardpageObjects.sales_dashboard_text().getText().contains(Transactions_Text) &&
					dasboardpageObjects.pre_authorization_widget().getText().contains(Pre_authorizations_Text) &&
					dasboardpageObjects.funding_Dashboard_Text().getText().contains(Funding_Text))
			{
				Result="Passed "+"Prefered Language is : "+Language_Change+
				"Currency for the payment type : "+dasboardpageObjects.payment_currency_Text_Validation.getText()+System.lineSeparator()
				+"No.of customer for the payment widget : "+dasboardpageObjects.payment_customer_text().getText()+System.lineSeparator()+
				"Currency for the sale type : "+dasboardpageObjects.sale_currency_text().getText()+"No. of customer for the sale widget : "+
				dasboardpageObjects.sales_customer_text().getText()+System.lineSeparator();
			}
			else
			{
				Result="Failed "+"Dashboard Language is not prefered language for the merchant please change the language";
			}
		}
		else
		{
			Result="Failed "+"Dashboard Language is not prefered language for the merchant please change the language";
		}
	}
	else if(Device.equalsIgnoreCase("tablet"))
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Welcome_message()));
		if(dasboardpageObjects.Welcome_message().getText().contains(Welcome_Text))
		{
			System.out.println(dasboardpageObjects.payment_dashboard_text().getText().contains(Authorizations_Text));
			System.out.println(		dasboardpageObjects.sales_dashboard_text().getText().contains(Transactions_Text));
					System.out.println(		dasboardpageObjects.pre_authorization_widget().getText().contains(Pre_authorizations_Text) );
							System.out.println(		dasboardpageObjects.funding_Dashboard_Text().getText().contains(Funding_Text));
			
			if(dasboardpageObjects.payment_dashboard_text().getText().contains(Authorizations_Text) && 
					dasboardpageObjects.sales_dashboard_text().getText().contains(Transactions_Text) &&
					dasboardpageObjects.pre_authorization_widget().getText().contains(Pre_authorizations_Text) &&
					dasboardpageObjects.funding_Dashboard_Text().getText().contains(Funding_Text))
			{
				Result="Passed "+"Prefered Language is : "+Language_Change+
				"Currency for the payment type : "+dasboardpageObjects.payment_currency_Text_Validation.getText()+System.lineSeparator()
				+"No.of customer for the payment widget : "+dasboardpageObjects.payment_customer_text().getText()+System.lineSeparator()+
				"Currency for the sale type : "+dasboardpageObjects.sale_currency_text().getText()+"No. of customer for the sale widget : "+
				dasboardpageObjects.sales_customer_text().getText()+System.lineSeparator();
			}
			else
			{
				Result="Failed "+"Dashboard Language is not prefered language for the merchant please change the language";
			}
		}
		else
		{
			Result="Failed "+"Dashboard Language is not prefered language for the merchant please change the language";
		}
	}
	else if(Device.equalsIgnoreCase("mobile"))
	{
						
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.last_login_date_time()));
		if(dasboardpageObjects.payment_dashboard_text.isDisplayed())
		{
			if(dasboardpageObjects.payment_dashboard_text.getText().contains(Authorizations_Text))
			{
				String payment_Text=dasboardpageObjects.payment_dashboard_text.getText();
				for(int i=0;i<dasboardpageObjects.swipe_option.size()-1;i++)
				{
					wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.swipe_option.get(i)));
					executor.executeScript("arguments[0].click()",dasboardpageObjects.swipe_option.get(i));
					wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.swipe_option.get(i)));
				}
				Result="Passed "+": "+ Language_Change +"_"+payment_Text;

			}
			else
			{
				Result="Failed "+" : "+Language_Change+" The Language has not been changed ";
			}
		}
		else
		{
			Result="Failed "+"The payment text : "+Authorizations_Text+"is not visible";
		}
	}
	return Result;

}

@Step
public String portal_appears_in_my_preferred_locale(String Welcome_Text,String Device) throws InterruptedException, ParseException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, medium_wait_time);
	if(Device.equalsIgnoreCase("desktop"))
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Welcome_message()));
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.last_login_date_time()));
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy,HH:mm");
		String dateTime=dasboardpageObjects.last_login_date_time().getText();
		if(dateTime.contains("-") && dasboardpageObjects.Welcome_message().getText().contains(Welcome_Text))
		{
			Result="Passed "+Welcome_Text +" " + dasboardpageObjects.login_date.getText()+" "  + dateTime;
		}
		else if(dateTime.contains("/") && dasboardpageObjects.Welcome_message().getText().contains(Welcome_Text))
		{
			Result="Passed "+Welcome_Text +" " + dasboardpageObjects.login_date.getText() +" " + dateTime;
		}
		else if(dateTime.contains(".") && dasboardpageObjects.Welcome_message().getText().contains(Welcome_Text))
		{
			Result="Passed "+Welcome_Text +" "+ dasboardpageObjects.login_date.getText()+" " + dateTime;
		}
		else
		{
			Result="Failed";
		}
	}
	else if(Device.equalsIgnoreCase("tablet"))
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Welcome_message()));
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.last_login_date_time()));
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy,HH:mm");
		String dateTime=dasboardpageObjects.last_login_date_time().getText();
		if(dateTime.contains("-") && dasboardpageObjects.Welcome_message().getText().contains(Welcome_Text))
		{
			Result="Passed "+Welcome_Text +" " + dasboardpageObjects.login_date.getText()+" "  + dateTime;
		}
		else if(dateTime.contains("/") && dasboardpageObjects.Welcome_message().getText().contains(Welcome_Text))
		{
			Result="Passed "+Welcome_Text +" " + dasboardpageObjects.login_date.getText() +" " + dateTime;
		}
		else if(dateTime.contains(".") && dasboardpageObjects.Welcome_message().getText().contains(Welcome_Text))
		{
			Result="Passed "+Welcome_Text +" "+ dasboardpageObjects.login_date.getText()+" " + dateTime;
		}
		else
		{
			Result="Failed";
		}
	}
	else if(Device.equalsIgnoreCase("mobile"))
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.last_login_date_time()));
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy,HH:mm");
		String dateTime=dasboardpageObjects.last_login_date_time().getText();
		if(dateTime.contains("-") && dasboardpageObjects.last_login_date_time.isCurrentlyVisible())
		{
			Result="Passed "+" " + dasboardpageObjects.login_date.getText()+" "  + dateTime;
		}
		else if(dateTime.contains("/") && dasboardpageObjects.last_login_date_time.isCurrentlyVisible())
		{
			Result="Passed "+" " + dasboardpageObjects.login_date.getText() +" " + dateTime;
		}
		else if(dateTime.contains(".") && dasboardpageObjects.last_login_date_time.isCurrentlyVisible())
		{
			Result="Passed "+" "+ dasboardpageObjects.login_date.getText()+" " + dateTime;
		}
		else
		{
			Result="Failed";
		}
	}
	return Result;	
}

@Step
public String Manage_the_message_in_portal_specific_Language(String Language_Change,String Message_title) throws InterruptedException, ParseException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, medium_wait_time);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	if(dasboardpageObjects.toggleButton_mobile.isCurrentlyVisible())
	 {		
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.toggleButton_mobile));
		executor.executeScript("arguments[0].click()",dasboardpageObjects.toggleButton_mobile);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messages_Link()));
		dasboardpageObjects.messages_Link().click();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messages_text()));
		if(messagepageObjects.searchbox_message.isCurrentlyVisible())
		{
			messagepageObjects.searchbox_message().sendKeys(Message_title);
			messagepageObjects.search_Button().click();
			wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.Message_Title()));
			System.out.println(messagepageObjects.Message_Title().equals(Message_title));
			System.out.println(messagepageObjects.Message_Title().getText().contains(Message_title));
			if(messagepageObjects.Message_Title().getText().equals(Message_title))
			{
				wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.Message_Title()));
				Result="Passed "+Message_title;
			}
			else
			{
				Result="Passed "+messagepageObjects.no_message_found().getText();
			}
		}
		else
		{
			Result="Passed "+messagepageObjects.no_message_found().getText();
		}
	 }
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messages_Link()));
		dasboardpageObjects.messages_Link().click();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messages_text()));
		if(messagepageObjects.searchbox_message.isCurrentlyVisible())
		{
			messagepageObjects.searchbox_message().sendKeys(Message_title);
			messagepageObjects.search_Button().click();
			wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.Message_Title()));
			System.out.println(messagepageObjects.Message_Title().equals(Message_title));
			System.out.println(messagepageObjects.Message_Title().getText().contains(Message_title));
			if(messagepageObjects.Message_Title().getText().equals(Message_title))
			{
				wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.Message_Title()));
				Result="Passed "+Message_title;
			}
			else
			{
				Result="Passed "+messagepageObjects.no_message_found().getText();
			}
		}
		else
		{
			Result="Passed "+messagepageObjects.no_message_found().getText();
		}
	}
	return Result;
	
}
}