package ui.Signon;

import java.util.ArrayList;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.AdminPage_object;
import ui.pageobjects.Signon.AuthorizationsPageObjects;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.DocumentsPageObjects;
import ui.pageobjects.Signon.FundingPageObjects;
import ui.pageobjects.Signon.MessagesPageObjects;
import ui.pageobjects.Signon.PreAuthorizationsPageObjects;
import ui.pageobjects.Signon.SettingsPageObjects;
import ui.pageobjects.Signon.SignonObjects;
import ui.pageobjects.Signon.TransactionsPageObjects;
import ui.pageobjects.Signon.UserManagementPageObjects;

public class Online_Authorization extends PageObject{
	WebDriver driver =null;
	String Result=null;
	boolean Status=false;
	
	MessagesPageObjects messagepageObjects;
	AdminPage_object adminpageObjects;
	DashboardPage_Objects dasboardpageobjects;
	SignonObjects signonObjects;
	DocumentsPageObjects documentpageobjects;
	PreAuthorizationsPageObjects preauthorizationpageobjects;
	TransactionsPageObjects transactionpageobjects;
	FundingPageObjects fundingpageobjects;
	AuthorizationsPageObjects authorizationpageobjects;
	SettingsPageObjects settingsuserpageobjects;
	UserManagementPageObjects usermanagementpageobject;
	User_management userManagement;
	public String device;
	
	long small_wait_time=50;
	long medium_wait_time=100;
	long large_wait_time=500;
	
	String message_link=null;
	ArrayList<WebElement> postingDate=new ArrayList<WebElement>();
	ArrayList<WebElement> transactionID=new ArrayList<WebElement>();
	ArrayList<WebElement> postingDate_fees_and_vat=new ArrayList<WebElement>();
	ArrayList<WebElement> Payment_method_MC_visa=new ArrayList<WebElement>();
	ArrayList<WebElement> orderIDValue=new ArrayList<WebElement>();
	ArrayList<WebElement> MerchantID=new ArrayList<WebElement>();
	public ArrayList<String> Funding_fees_list=new ArrayList<String>();
	public ArrayList<String> EMS_fees_list=new ArrayList<String>();
	public ArrayList<String> transaction_details=new ArrayList<String>();

	@Step	
	public String verify_the_funding_Activities_view_for_Batch_details_for_online_authorization(String Funding_Reference_number) throws Throwable{
		driver = this.getDriver();
		String Result1=null,Result2=null;
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebDriverWait wait = new WebDriverWait(driver, medium_wait_time);
		if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
		 {		
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
			executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_Link()));
			dasboardpageobjects.funding_Link().click();
			for(int i=0;i<=50;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_text()));
			checkPageIsReady();
			}
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText()));
			fundingpageobjects.searchFieldText().sendKeys(Funding_Reference_number);
			fundingpageobjects.search_button().click();
			for(int i=0;i<=50;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
			checkPageIsReady();
			}
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
			if(fundingpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_error_message()));
				Result="Failed "+"No record found for this refrence number ";
			}
			else
			{
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon()));
				executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon());
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.view_batch_details()));
				executor.executeScript("arguments[0].click()",fundingpageobjects.view_batch_details());
				for(int i=0;i<=50;i++)
				{
					wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Export_button()));
					wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.posting_date_text()));
					checkPageIsReady();
				}
				if(fundingpageobjects.posting_date_text.isCurrentlyVisible() && fundingpageobjects.transaction_ID_text.isCurrentlyVisible()
						&& fundingpageobjects.merchantID_text.isCurrentlyVisible() && fundingpageobjects.orderID_text.isCurrentlyVisible()
						&& fundingpageobjects.Type_text.isCurrentlyVisible() && fundingpageobjects.Gross_Amount_text.isCurrentlyVisible()
						&& fundingpageobjects.Net_Amount_text.isCurrentlyVisible() && fundingpageobjects.EMS_fees_text.isCurrentlyVisible())
				{
					
					
					for(WebElement element:fundingpageobjects.postingDate)
					{
						if(!element.getText().equalsIgnoreCase("Sub totals"))
								{
									postingDate.add(element);
								}
					}
					System.out.println("Size of the posting Date is:"+fundingpageobjects.postingDate.size());
						for(int i=0;i<postingDate.size();i++)
						{
							
							executor.executeScript("arguments[0].click()",postingDate.get(i));
				//			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon_inside_store_details()));
				//			executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon_inside_store_details());
							if(fundingpageobjects.Transaction_details_text.isCurrentlyVisible() && fundingpageobjects.payment_method_details.isCurrentlyVisible())
							{
								String DCC_indicator=fundingpageobjects.DCC_Indicator().getText();
								String transaction_id=fundingpageobjects.Transaction_id().getText();
								String cardNumber=fundingpageobjects.card_number_details().getText();
								String Card_type=fundingpageobjects.Card_type().getText();
								String emsFees=fundingpageobjects.ems_fees_value().getText();
								Result1="Passed "+"DCC_indicator : "+DCC_indicator+" transaction_id : "+transaction_id+" cardNumber : "+cardNumber+" Card_type : "+Card_type+"emsFees : "+emsFees;
							}
							else
							{
								Result1="Failed "+"No Details are available right now ";
							}
						}
						Result2=Result1;
					}
				
		
				else
				{
					Result="Failed "+"No Data are available right now Come back later "+fundingpageobjects.No_records_found();
				}
				if(Result2.contains("Passed"))
				{
					Result=Result2;
				}
			}
		 }
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_Link()));
			dasboardpageobjects.funding_Link().click();
			for(int i=0;i<=50;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_text()));
			checkPageIsReady();
			}
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText()));
			fundingpageobjects.searchFieldText().sendKeys(Funding_Reference_number);
			fundingpageobjects.search_button().click();
			for(int i=0;i<=50;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
			checkPageIsReady();
			}
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
			if(fundingpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_error_message()));
				Result="Failed "+"No record found for this refrence number ";
			}
			else
			{
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon()));
				executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon());
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.view_batch_details()));
				executor.executeScript("arguments[0].click()",fundingpageobjects.view_batch_details());
				for(int i=0;i<=50;i++)
				{
					wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Export_button()));
					wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.posting_date_text()));
					checkPageIsReady();
				}
				if(fundingpageobjects.posting_date_text.isCurrentlyVisible() && fundingpageobjects.transaction_ID_text.isCurrentlyVisible()
						&& fundingpageobjects.merchantID_text.isCurrentlyVisible() && fundingpageobjects.orderID_text.isCurrentlyVisible()
						&& fundingpageobjects.Type_text.isCurrentlyVisible() && fundingpageobjects.Gross_Amount_text.isCurrentlyVisible()
						&& fundingpageobjects.Net_Amount_text.isCurrentlyVisible() && fundingpageobjects.EMS_fees_text.isCurrentlyVisible())
				{
					
					
					for(WebElement element:fundingpageobjects.postingDate)
					{
						if(!element.getText().equalsIgnoreCase("Sub totals"))
								{
									postingDate.add(element);
								}
					}
					System.out.println("Size of the posting Date is:"+fundingpageobjects.postingDate.size());
						for(int i=0;i<postingDate.size();i++)
						{
							
							executor.executeScript("arguments[0].click()",postingDate.get(i));
				//			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon_inside_store_details()));
				//			executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon_inside_store_details());
							if(fundingpageobjects.Transaction_details_text.isCurrentlyVisible() && fundingpageobjects.payment_method_details.isCurrentlyVisible())
							{
								String DCC_indicator=fundingpageobjects.DCC_Indicator().getText();
								String transaction_id=fundingpageobjects.Transaction_id().getText();
								String cardNumber=fundingpageobjects.card_number_details().getText();
								String Card_type=fundingpageobjects.Card_type().getText();
								String emsFees=fundingpageobjects.ems_fees_value().getText();
								Result1="Passed "+"DCC_indicator : "+DCC_indicator+" transaction_id : "+transaction_id+" cardNumber : "+cardNumber+" Card_type : "+Card_type+"emsFees : "+emsFees;
							}
							else
							{
								Result1="Failed "+"No Details are available right now ";
							}
						}
						Result2=Result1;
					}
				
		
				else
				{
					Result="Failed "+"No Data are available right now Come back later "+fundingpageobjects.No_records_found();
				}
				if(Result2.contains("Passed"))
				{
					Result=Result2;
				}
			}
		}
		return Result;
	}
	@Step	
	public String verify_the_funding_Activities_view_for_feesAndVat_details_for_online_authorization(String Funding_Reference_number) throws Throwable{
		driver = this.getDriver();
		//int count1=0;
		String Result1=null,Result2=null;
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebDriverWait wait = new WebDriverWait(driver, medium_wait_time);
		if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
		 {		
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
			executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_Link()));
			dasboardpageobjects.funding_Link().click();
			for(int i=0;i<=50;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_text()));
			checkPageIsReady();
			}
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText()));
			fundingpageobjects.searchFieldText().sendKeys(Funding_Reference_number);
			fundingpageobjects.search_button().click();
			for(int i=0;i<=50;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
			checkPageIsReady();
			}
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
			if(fundingpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_error_message()));
				Result="Failed "+"No record found for this refrence number ";
			}
			else
			{
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon()));
				executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon());
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.fees_vat_link()));
				executor.executeScript("arguments[0].click()",fundingpageobjects.fees_vat_link());
				for(int i=0;i<=100;i++)
				{
					wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Export_button()));
					wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.postingDate_text_fees_vat()));
					checkPageIsReady();
				}
				if(fundingpageobjects.postingDate_text_fees_vat.isCurrentlyVisible() && fundingpageobjects.MerchantId_text_fees_vat.isCurrentlyVisible()
						&& fundingpageobjects.Type_fees_and__vat.isCurrentlyVisible() && fundingpageobjects.EMS_fees_and_vat.isCurrentlyVisible()
						&& fundingpageobjects.vat_text.isCurrentlyVisible())
				{
					for(WebElement element:fundingpageobjects.posting_date_list_fees_and_vat)
					{
						if(!element.getText().equalsIgnoreCase("Sub totals") && !element.getText().equalsIgnoreCase("Posting date"))
								{
									postingDate_fees_and_vat.add(element);
								}
					}
					System.out.println("Size of the posting Date is:"+postingDate_fees_and_vat.size());
						for(int i=0;i<postingDate_fees_and_vat.size();i++)
						{
							
							executor.executeScript("arguments[0].click()",postingDate_fees_and_vat.get(i));
							wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Vat_value()));
								String vat=fundingpageobjects.Vat_value().getText();
								String type=fundingpageobjects.type_value_fees_and_vat().getText();
								String emsFees=fundingpageobjects.Ems_fees_value_in_vat_details.get(i).getText();
								Result1="Passed "+" Type : "+type+"emsFees : "+emsFees+"vat : "+vat;
		
							
						}
						Result=Result1;
				}
				else
				{
					Result="Failed "+"No Data are available right now Come back later ";
				}
			}
		 }
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_Link()));
			dasboardpageobjects.funding_Link().click();
			for(int i=0;i<=50;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_text()));
			checkPageIsReady();
			}
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText()));
			fundingpageobjects.searchFieldText().sendKeys(Funding_Reference_number);
			fundingpageobjects.search_button().click();
			for(int i=0;i<=50;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
			checkPageIsReady();
			}
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
			if(fundingpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_error_message()));
				Result="Failed "+"No record found for this refrence number ";
			}
			else
			{
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon()));
				executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon());
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.fees_vat_link()));
				executor.executeScript("arguments[0].click()",fundingpageobjects.fees_vat_link());
				for(int i=0;i<=100;i++)
				{
					wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Export_button()));
					wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.postingDate_text_fees_vat()));
					checkPageIsReady();
				}
				if(fundingpageobjects.postingDate_text_fees_vat.isCurrentlyVisible() && fundingpageobjects.MerchantId_text_fees_vat.isCurrentlyVisible()
						&& fundingpageobjects.Type_fees_and__vat.isCurrentlyVisible() && fundingpageobjects.EMS_fees_and_vat.isCurrentlyVisible()
						&& fundingpageobjects.vat_text.isCurrentlyVisible())
				{
					for(WebElement element:fundingpageobjects.posting_date_list_fees_and_vat)
					{
						if(!element.getText().equalsIgnoreCase("Sub totals") && !element.getText().equalsIgnoreCase("Posting date"))
								{
									postingDate_fees_and_vat.add(element);
								}
					}
					System.out.println("Size of the posting Date is:"+postingDate_fees_and_vat.size());
						for(int i=0;i<postingDate_fees_and_vat.size();i++)
						{
							
							executor.executeScript("arguments[0].click()",postingDate_fees_and_vat.get(i));
							wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Vat_value()));
								String vat=fundingpageobjects.Vat_value().getText();
								String type=fundingpageobjects.type_value_fees_and_vat().getText();
								String emsFees=fundingpageobjects.Ems_fees_value_in_vat_details.get(i).getText();
								Result1="Passed "+" Type : "+type+"emsFees : "+emsFees+"vat : "+vat;

							
						}
						Result=Result1;
				}
				else
				{
					Result="Failed "+"No Data are available right now Come back later ";
				}
			}
		}
		return Result;
	}
	@Step	
	public String verify_the_transaction_Activities_view_for_online_authorization() throws Throwable{
		driver = this.getDriver();
		//int count1=0;
		String Result1=null,Status=null;
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebDriverWait wait = new WebDriverWait(driver, medium_wait_time);
		if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
		 {		
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
			executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
			dasboardpageobjects.transaction_Link().click();
			for(int i=0;i<=150;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
			checkPageIsReady();
			}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
				Result="Failed "+transactionpageobjects.search_error_message().getText();	
			}
			else
			{
				/*if(transactionpageobjects.postingDate_text.isCurrentlyVisible() && transactionpageobjects.MerchantId_text.isCurrentlyVisible() 
						)
				{*/
				for(int j=0;j<transactionpageobjects.allColumn_list.size();j++)
				{
					if(transactionpageobjects.allColumn_list.get(j).isCurrentlyVisible())
					{
						Status="True";
					}
				}
				if(Status.equals("True"))
				{
					for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
					{
						executor.executeScript("arguments[0].click()",transactionpageobjects.plus_icon.get(i));
						for(int i1=0;i1<transactionpageobjects.funding_fees_text.size();i1++)
						{
							String funding_fees_value=transactionpageobjects.funding_fees_text.get(i1).getText()+" : "+transactionpageobjects.funding_fees_value.get(i1).getText()+System.lineSeparator();
							Funding_fees_list.add(funding_fees_value);
						}
						for(int i1=0;i1<transactionpageobjects.ems_fees_text.size();i1++)
						{
							String EMS_fees=transactionpageobjects.ems_fees_text.get(i1).getText()+" : "+transactionpageobjects.ems_fees_Value.get(i1).getText()+System.lineSeparator();
							EMS_fees_list.add(EMS_fees);
						}
						Result1=transactionpageobjects.trans_amount_value.get(i).getText()+System.lineSeparator()+Funding_fees_list+System.lineSeparator()+EMS_fees_list;
					}
					Result="Passed "+Result1;
					
				}
			}
		 }
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
			dasboardpageobjects.transaction_Link().click();
			for(int i=0;i<=150;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
			checkPageIsReady();
			}
			if(transactionpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
				Result="Failed "+transactionpageobjects.search_error_message().getText();	
			}
			else
			{
				/*if(transactionpageobjects.postingDate_text.isCurrentlyVisible() && transactionpageobjects.MerchantId_text.isCurrentlyVisible()
				&& transactionpageobjects.ecom_pos_image.isCurrentlyVisible() && transactionpageobjects.storeId_text.isCurrentlyVisible()
				&& transactionpageobjects.orderID_text.isCurrentlyVisible() && transactionpageobjects.status_text.isCurrentlyVisible() 
				&& transactionpageobjects.trans_date_text.isCurrentlyVisible() && transactionpageobjects.trans_type_text.isCurrentlyVisible()
				&& transactionpageobjects.Brand_text.isCurrentlyVisible() && transactionpageobjects.Trans_Amount_text.isCurrentlyVisible())
				{*/
				for(int j=0;j<transactionpageobjects.allColumn_list.size();j++)
				{
					if(transactionpageobjects.allColumn_list.get(j).isCurrentlyVisible())
					{
						Status="True";
					}
				}
				if(Status.equals("True"))
				{
					for(int i=0;i<transactionpageobjects.plus_icon.size();i++)
					{
						executor.executeScript("arguments[0].click()",transactionpageobjects.plus_icon.get(i));
						for(int i1=0;i1<transactionpageobjects.funding_fees_text.size();i1++)
						{
							String funding_fees_value=transactionpageobjects.funding_fees_text.get(i1).getText()+" : "+transactionpageobjects.funding_fees_value.get(i1).getText()+System.lineSeparator();
							Funding_fees_list.add(funding_fees_value);
						}
						for(int i1=0;i1<transactionpageobjects.ems_fees_text.size();i1++)
						{
							String EMS_fees=transactionpageobjects.ems_fees_text.get(i1).getText()+" : "+transactionpageobjects.ems_fees_Value.get(i1).getText()+System.lineSeparator();
							EMS_fees_list.add(EMS_fees);
						}
						Result1=transactionpageobjects.trans_amount_value.get(i).getText()+System.lineSeparator()+Funding_fees_list+System.lineSeparator()+EMS_fees_list;
					}
					Result="Passed "+Result1;
					
				}
			}
		}
		return Result;
	}
	@Step	
	public String verify_the_Authorization_Activities_view_for_online_authorization() throws Throwable{
		driver = this.getDriver();
		String Status=null;
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebDriverWait wait = new WebDriverWait(driver, medium_wait_time);
		if(dasboardpageobjects.toggleButton_mobile.isCurrentlyVisible())
		 {		
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.toggleButton_mobile));
			executor.executeScript("arguments[0].click()",dasboardpageobjects.toggleButton_mobile);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_Link()));
			dasboardpageobjects.Authorizations_Link().click();
			for(int i=0;i<=150;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_text()));
			checkPageIsReady();
			}
			if(authorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.search_error_message()));
				Result="Failed "+authorizationpageobjects.search_error_message().getText();	
			}
			else
			{
				/*if(authorizationpageobjects.Authorization_date.isCurrentlyVisible() && authorizationpageobjects.merchant_id_text.isCurrentlyVisible())
				{*/
				for(int j=0;j<authorizationpageobjects.AllColumnList.size();j++)
				{
					if(authorizationpageobjects.AllColumnList.get(j).isCurrentlyVisible())
					{
						Status="True";
					}
				}
				if(Status.equals("True"))
				{
					for(int i=0;i< authorizationpageobjects.plus_icon.size();i++)
					{	
						executor.executeScript("arguments[0].click()", authorizationpageobjects.plus_icon.get(i));
						wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.auth_code.get(i)));
						System.out.println(authorizationpageobjects.auth_code.get(i).getText());
						System.out.println(authorizationpageobjects.card_number.get(i).getText());
						String details_each_transaction="Auth code : "+authorizationpageobjects.auth_code.get(i).getText()
								+"Card number : "+authorizationpageobjects.card_number.get(i).getText()+"Card type : "+authorizationpageobjects.card_type.get(i).getText();
						transaction_details.add(details_each_transaction);
					}
					Result="Passed "+transaction_details;	
				}
			}
		 }
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_Link()));
			dasboardpageobjects.Authorizations_Link().click();
			for(int i=0;i<=150;i++)
			{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_text()));
			checkPageIsReady();
			}
			if(authorizationpageobjects.search_error_message.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.search_error_message()));
				Result="Failed "+authorizationpageobjects.search_error_message().getText();	
			}
			else
			{
				/*if(authorizationpageobjects.Authorization_date.isCurrentlyVisible() && authorizationpageobjects.ecom_pos_image.isCurrentlyVisible()
					&& authorizationpageobjects.merchant_id_text.isCurrentlyVisible() && authorizationpageobjects.store_id_text.isCurrentlyVisible()
					&& authorizationpageobjects.orderID_text.isCurrentlyVisible() && authorizationpageobjects.Brand_text.isCurrentlyVisible() 
					&& authorizationpageobjects.auth_type_text.isCurrentlyVisible() && authorizationpageobjects.status_text.isCurrentlyVisible()
					&& authorizationpageobjects.auth_code_text.isCurrentlyVisible() && authorizationpageobjects.amount_text.isCurrentlyEnabled()
					&& authorizationpageobjects.dcc_transaction.isCurrentlyVisible() && authorizationpageobjects.card_number_text.isCurrentlyVisible()
					&& authorizationpageobjects.currency_text.isCurrentlyVisible())
				{*/
				for(int j=0;j<authorizationpageobjects.AllColumnList.size();j++)
				{
					if(authorizationpageobjects.AllColumnList.get(j).isCurrentlyVisible())
					{
						Status="True";
					}
				}
				if(Status.equals("True"))
				{
					for(int i=0;i< authorizationpageobjects.plus_icon.size();i++)
					{	
						executor.executeScript("arguments[0].click()", authorizationpageobjects.plus_icon.get(i));
						wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.auth_code.get(i)));
						System.out.println(authorizationpageobjects.auth_code.get(i).getText());
						System.out.println(authorizationpageobjects.card_number.get(i).getText());
						String details_each_transaction="Auth code : "+authorizationpageobjects.auth_code.get(i).getText()
								+"Card number : "+authorizationpageobjects.card_number.get(i).getText()+"Card type : "+authorizationpageobjects.card_type.get(i).getText();
						transaction_details.add(details_each_transaction);
					}
					Result="Passed "+transaction_details;
					
				}
			}
		}
		return Result;
	}
	public void checkPageIsReady() throws InterruptedException {
		  JavascriptExecutor js = (JavascriptExecutor)driver;
		  for (int i=0; i<100; i++){ 
		   if (js.executeScript("return document.readyState").toString().equals("complete")){    
		    break; 
		   }
		   System.out.println("Page Is loaded.");
		  }
		 }
	}
