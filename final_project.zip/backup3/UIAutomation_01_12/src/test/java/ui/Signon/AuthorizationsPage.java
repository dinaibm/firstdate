/*package ui.Signon;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptExecutor;

import common.JDBCConnection;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.AuthorizationsPageObjects;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.FundingPageObjects;
import ui.pageobjects.Signon.MessagesPageObjects;
import ui.pageobjects.Signon.PreAuthorizationsPageObjects;
import ui.pageobjects.Signon.SettingsPageObjects;
import ui.pageobjects.Signon.SignonObjects;



public class AuthorizationsPage extends PageObject {

	WebDriver driver =null;

	String Result=null;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	MessagesPageObjects messagespageobjects;
	FundingPageObjects fundingpageobjects;
	AuthorizationsPageObjects authorizationsPageObjects;
	SettingsPageObjects settingsPageObjects;
	SettingsPage settingsPage;
	
	JDBCConnection jdbcConnection;

	ArrayList<Date> authorizationDateAndTime=new ArrayList<Date>();
	public ArrayList<String> authorizationcolumns=new ArrayList<String>();
	public ArrayList<String> authCreditData=new ArrayList<String>();
	public ArrayList<String> authDebitData=new ArrayList<String>();


	@Step
	public String validateAuthorizationsSortOrder(String fromDate, String toDate) throws IOException, ParseException{

		for(int i=0;i<30;i++)
		{
		waitFor(ExpectedConditions.elementToBeClickable(authorizationsPageObjects.searchFieldText));
		}
		
		
		driver=this.getDriver();
		
		System.out.println("\n Inside Authorizations");

		waitFor(authorizationsPageObjects.date_dropdown).click();
		waitFor(authorizationsPageObjects.FromDate).click();
		waitFor(authorizationsPageObjects.FromDate).clear();
		waitFor(authorizationsPageObjects.FromDate).sendKeys(fromDate);
		waitFor(authorizationsPageObjects.ToDate).click();
		waitFor(authorizationsPageObjects.ToDate).clear();
		waitFor(authorizationsPageObjects.ToDate).sendKeys(toDate);
		waitFor(authorizationsPageObjects.applyDate).click();
		
		for(int i=0;i<30;i++)
		{
		waitFor(ExpectedConditions.elementToBeClickable(authorizationsPageObjects.searchFieldText));
		}

		if(!authorizationsPageObjects.noRecordsPresent.isCurrentlyVisible())
		{

			SimpleDateFormat sdf= new SimpleDateFormat("dd/MM/yyyy HH:mm");

			for(int i=0;i<authorizationsPageObjects.authorizationDate.size() && i<authorizationsPageObjects.authorizationTime.size();i++)
			{
				String dateAndTime= authorizationsPageObjects.authorizationDate.get(i).getText()+" "+authorizationsPageObjects.authorizationTime.get(i).getText();
				System.out.println("Date And Time value is:"+dateAndTime);
				authorizationDateAndTime.add(sdf.parse(dateAndTime));
			}

			System.out.println("The Date and Time are:"+authorizationDateAndTime);

			ArrayList<Date> duplicateDateAndTime=new ArrayList<Date>();
			duplicateDateAndTime=(ArrayList<Date>) authorizationDateAndTime.clone();
			Collections.sort(duplicateDateAndTime);
			Collections.reverse(duplicateDateAndTime);

			System.out.println("The duplicate Date and Time are:"+duplicateDateAndTime);

			if(authorizationDateAndTime.equals(duplicateDateAndTime))
			{
				Result="Passed";
			}
			else
			{
				Result="Failed";
			}
		}
		else
		{
			Result="No Records found";
		}

		
	return Result;
	
	}
	
	public String validateAuthorizationColumns(String columnName) throws InterruptedException
	{
		driver=this.getDriver();
		WebDriverWait wait=new WebDriverWait(driver,10);
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		boolean defaultColumnAvailability=false;

		if(!authorizationsPageObjects.noRecordsPresent.isCurrentlyVisible())
		{
			StringBuilder sb=new StringBuilder();
//			wait.until(ExpectedConditions.elementToBeClickable(transactionsPageObjects.showMoreColumns));
//			executor.executeScript("arguments[0].click()",transactionsPageObjects.showMoreColumns);
//			wait.until(ExpectedConditions.elementToBeClickable(transactionsPageObjects.restoreDefault));
//			executor.executeScript("arguments[0].click()",transactionsPageObjects.restoreDefault);
//			wait.until(ExpectedConditions.elementToBeClickable(transactionsPageObjects.apply));
//			executor.executeScript("arguments[0].click()",transactionsPageObjects.apply);
			
			List<WebElement> authorizationColumns=driver.findElements(authorizationsPageObjects.authorizationColumns);
			for(int i=0;i<30;i++)
			{
				authorizationColumns=driver.findElements(authorizationsPageObjects.authorizationColumns);
			}
			System.out.println("NUMBER OF COLUMNS IS:"+authorizationColumns.size());
			for(int i=1;i<authorizationColumns.size();i++)
			{

				if(authorizationColumns.get(i).getText().isEmpty())
				{
					authorizationcolumns.add("ECommerce/POS transaction");
				}
				else
				{
					authorizationcolumns.add(authorizationColumns.get(i).getText());
				}

			}


			System.out.println("the default authorization columns are:"+authorizationcolumns);
			System.out.println("The name of the column to be clicked is:"+columnName);

			for(int j=0;j<authorizationcolumns.size();j++)
			{
				System.out.println(authorizationcolumns.get(j));
				if(authorizationcolumns.get(j).contains(columnName))
				{
					defaultColumnAvailability=true;
				}
			}
			
			System.out.println("is column available:"+defaultColumnAvailability);
			if(defaultColumnAvailability==false)
			{
				wait.until(ExpectedConditions.elementToBeClickable(authorizationsPageObjects.showMoreColumns));
				executor.executeScript("arguments[0].scrollIntoView();",authorizationsPageObjects.showMoreColumns);
				executor.executeScript("arguments[0].click()",authorizationsPageObjects.showMoreColumns);
				for(WebElement additionalColumns:authorizationsPageObjects.additionalAuthorizationColumns)
				{
					System.out.println("the name of the column is:"+additionalColumns.getText());
					if(additionalColumns.getText().equalsIgnoreCase(columnName))
					{
						wait.until(ExpectedConditions.visibilityOf(additionalColumns));
						executor.executeScript("arguments[0].click()",additionalColumns);
					}
				}

				wait.until(ExpectedConditions.elementToBeClickable(authorizationsPageObjects.apply));
				executor.executeScript("arguments[0].scrollIntoView();",authorizationsPageObjects.apply);
				executor.executeScript("arguments[0].click()",authorizationsPageObjects.apply);
				
				authorizationColumns=driver.findElements(authorizationsPageObjects.authorizationColumns);
				for(int i=0;i<30;i++)
				{
					authorizationColumns=driver.findElements(authorizationsPageObjects.authorizationColumns);
				}
				System.out.println("Size of the columns after adding a new column is:"+authorizationColumns.size());
				
				for(int i=0;i<authorizationColumns.size();i++)
				{
					System.out.println(authorizationColumns.get(i).getText());
					if(authorizationColumns.get(i).getText().contains(columnName))
					{
						System.out.println("Inside the loop");
						Result="Passed";
					}
				}

			}
			else
			{
				Result="Column already available in default view";
			}
		}
		else
		{
			Result="No Records Present";
		}
		return Result;
	}
	
	public String voidAuthorization(String userName, String orderID,String sqlQuery) throws ClassNotFoundException, SQLException
	{
		driver=this.getDriver();
		WebDriverWait wait=new WebDriverWait(driver,10);
		JavascriptExecutor executor=(JavascriptExecutor)driver;

		authorizationsPageObjects.searchFieldText.sendKeys(orderID);
		executor.executeScript("arguments[0].click()",authorizationsPageObjects.search_orderId);
		wait.until(ExpectedConditions.elementToBeClickable(authorizationsPageObjects.search_button));
		executor.executeScript("arguments[0].click()",authorizationsPageObjects.search_button);
		for(int i=0;i<100;i++){wait.until(ExpectedConditions.elementToBeClickable(authorizationsPageObjects.searchFieldText));}
		if(!authorizationsPageObjects.noRecordsPresent.isCurrentlyVisible())
		{

			for(int i=0;i<100;i++){wait.until(ExpectedConditions.elementToBeClickable(authorizationsPageObjects.authorizationDate.get(0)));}
			executor.executeScript("arguments[0].click()",authorizationsPageObjects.authorizationDate.get(0));

			waitFor(authorizationsPageObjects.voidButton);
			if(authorizationsPageObjects.voidButton.isCurrentlyVisible())
			{
				executor.executeScript("arguments[0].click()",authorizationsPageObjects.voidButton);
				waitFor(authorizationsPageObjects.voidAuthorizationButton);

				if(authorizationsPageObjects.voidAuthorizationButton.isCurrentlyVisible())
				{				
					executor.executeScript("arguments[0].click()",authorizationsPageObjects.voidAuthorizationButton);
					//String passcode=jdbcConnection.getPasscode(userName,sqlQuery);
					String passcode=JOptionPane.showInputDialog("Enter the passcode:");
					System.out.println("The entered passcode is:"+passcode);
					authorizationsPageObjects.oneTimePasscode.sendKeys(passcode);
					executor.executeScript("arguments[0].click()",authorizationsPageObjects.confirmButton);
					waitFor(authorizationsPageObjects.closeButton);
					if(authorizationsPageObjects.closeButton.isCurrentlyVisible())
					{
						executor.executeScript("arguments[0].click()",authorizationsPageObjects.closeButton);
					}
					
					authorizationsPageObjects.searchFieldText.clear();
					authorizationsPageObjects.searchFieldText.sendKeys(orderID);
					executor.executeScript("arguments[0].click()",authorizationsPageObjects.search_orderId);
					wait.until(ExpectedConditions.elementToBeClickable(authorizationsPageObjects.search_button));
					executor.executeScript("arguments[0].click()",authorizationsPageObjects.search_button);
					for(int i=0;i<100;i++){wait.until(ExpectedConditions.elementToBeClickable(authorizationsPageObjects.searchFieldText));}
					
					for(int i=0;i<100;i++){wait.until(ExpectedConditions.elementToBeClickable(authorizationsPageObjects.authorizationDate.get(0)));}
					executor.executeScript("arguments[0].click()",authorizationsPageObjects.authorizationDate.get(0));
					if(!authorizationsPageObjects.voidButton.isCurrentlyVisible())
					{
						Result="Passed";
					}
					else
					{
						Result="Failed";
					}	
				}
			}
			else
			{
				Result="Please check the authorization status";
			}
		}
		else
		{
			Result="Please enter a valid Order ID";
		}

		return Result;
	}
	
	public String sendPasscode(String userName,String orderID,String sqlQuery) throws ClassNotFoundException, SQLException
	{
		driver=this.getDriver();
		WebDriverWait wait=new WebDriverWait(driver,10);
		JavascriptExecutor executor=(JavascriptExecutor)driver;

		authorizationsPageObjects.searchFieldText.sendKeys(orderID);
		executor.executeScript("arguments[0].click()",authorizationsPageObjects.search_orderId);
		wait.until(ExpectedConditions.elementToBeClickable(authorizationsPageObjects.search_button));
		executor.executeScript("arguments[0].click()",authorizationsPageObjects.search_button);
		for(int i=0;i<100;i++){wait.until(ExpectedConditions.elementToBeClickable(authorizationsPageObjects.searchFieldText));}
		if(!authorizationsPageObjects.noRecordsPresent.isCurrentlyVisible())
		{

			for(int i=0;i<100;i++){wait.until(ExpectedConditions.elementToBeClickable(authorizationsPageObjects.authorizationDate.get(0)));}
			executor.executeScript("arguments[0].click()",authorizationsPageObjects.authorizationDate.get(0));

			waitFor(authorizationsPageObjects.voidButton);
			if(authorizationsPageObjects.voidButton.isCurrentlyVisible())
			{
				executor.executeScript("arguments[0].click()",authorizationsPageObjects.voidButton);
				waitFor(authorizationsPageObjects.voidAuthorizationButton);

				if(authorizationsPageObjects.voidAuthorizationButton.isCurrentlyVisible())
				{				
					executor.executeScript("arguments[0].click()",authorizationsPageObjects.voidAuthorizationButton);
					
					while(!authorizationsPageObjects.sentPasscodeText.isCurrentlyVisible())
					{
						wait.until(ExpectedConditions.visibilityOf(authorizationsPageObjects.sentPasscodeText));
					}
					
					//String firstPasscode=jdbcConnection.getPasscode(userName,sqlQuery);
					String firstPasscode=JOptionPane.showInputDialog("Enter the passcode:");
					System.out.println("The first passcode is:"+firstPasscode);
					
					executor.executeScript("arguments[0].click()",authorizationsPageObjects.resendPasscode);
					
					while(!authorizationsPageObjects.resendPasscodeText.isCurrentlyVisible())
					{
						wait.until(ExpectedConditions.visibilityOf(authorizationsPageObjects.resendPasscodeText));
					}
					
					//String secondPasscode=jdbcConnection.getPasscode(userName,sqlQuery);
					String secondPasscode=JOptionPane.showInputDialog("Enter the passcode:");
					System.out.println("The second passcode is:"+secondPasscode);
					authorizationsPageObjects.oneTimePasscode.sendKeys(secondPasscode);
					//executor.executeScript("arguments[0].click()",authorizationsPageObjects.confirmButton);
					//waitFor(authorizationsPageObjects.closeButton);
					if(!firstPasscode.equals(secondPasscode))
					{
						Result="Passed";
					}
					else
					{
						Result="Failed";
					}	
				}
			}
			else
			{
				Result="Please check the authorization status";
			}
		}
		else
		{
			Result="Please enter a valid Order ID";
		}

		return Result;
	}
	
	public String validateMobileNumber(String userName,String orderID,String sqlQuery) throws ClassNotFoundException, SQLException
	{
		driver=this.getDriver();
		WebDriverWait wait=new WebDriverWait(driver,10);
		JavascriptExecutor executor=(JavascriptExecutor)driver;

		authorizationsPageObjects.searchFieldText.sendKeys(orderID);
		executor.executeScript("arguments[0].click()",authorizationsPageObjects.search_orderId);
		wait.until(ExpectedConditions.elementToBeClickable(authorizationsPageObjects.search_button));
		executor.executeScript("arguments[0].click()",authorizationsPageObjects.search_button);
		for(int i=0;i<100;i++){wait.until(ExpectedConditions.elementToBeClickable(authorizationsPageObjects.searchFieldText));}
		if(!authorizationsPageObjects.noRecordsPresent.isCurrentlyVisible())
		{

			for(int i=0;i<100;i++){wait.until(ExpectedConditions.elementToBeClickable(authorizationsPageObjects.authorizationDate.get(0)));}
			executor.executeScript("arguments[0].click()",authorizationsPageObjects.authorizationDate.get(0));

			waitFor(authorizationsPageObjects.voidButton);
			if(authorizationsPageObjects.voidButton.isCurrentlyVisible())
			{
				executor.executeScript("arguments[0].click()",authorizationsPageObjects.voidButton);
				waitFor(authorizationsPageObjects.voidAuthorizationButton);

				if(authorizationsPageObjects.voidAuthorizationButton.isCurrentlyVisible())
				{				
					executor.executeScript("arguments[0].click()",authorizationsPageObjects.voidAuthorizationButton);
					
					while(!authorizationsPageObjects.sentPasscodeText.isCurrentlyVisible())
					{
						wait.until(ExpectedConditions.visibilityOf(authorizationsPageObjects.sentPasscodeText));
					}
					
					//String firstPasscode=jdbcConnection.getPasscode(userName,sqlQuery,sqlQuery);
//					String firstPasscode=JOptionPane.showInputDialog("Enter the passcode:");
//					System.out.println("The first passcode is:"+firstPasscode);
//					
//					executor.executeScript("arguments[0].click()",authorizationsPageObjects.resendPasscode);
//					
//					while(!authorizationsPageObjects.resendPasscodeText.isCurrentlyVisible())
//					{
//						wait.until(ExpectedConditions.visibilityOf(authorizationsPageObjects.resendPasscodeText));
//					}
//					
//					//String secondPasscode=jdbcConnection.getPasscode(userName,sqlQuery);
//					String secondPasscode=JOptionPane.showInputDialog("Enter the passcode:");
//					System.out.println("The second passcode is:"+secondPasscode);
//					authorizationsPageObjects.oneTimePasscode.sendKeys(secondPasscode);
//					executor.executeScript("arguments[0].click()",authorizationsPageObjects.confirmButton);
//					waitFor(authorizationsPageObjects.closeButton);
					
					String firstMobileNumber=authorizationsPageObjects.voidAuthorizationMobileNumber.getText().replaceAll("\\s","");
					System.out.println("The first mobile number is:"+firstMobileNumber);
					
					executor.executeScript("arguments[0].click()",authorizationsPageObjects.backButton);
					executor.executeScript("arguments[0].click()",authorizationsPageObjects.cancelButton);
					
					settingsPage.moveToSettingsWindow();
					
					String secondMobileNumber=settingsPageObjects.mobileNumber.getText();
					
					if(firstMobileNumber.equals(secondMobileNumber))
					{
						Result="Passed";
					}
					else
					{
						Result="Failed";
					}	
				}
			}
			else
			{
				Result="Please check the authorization status";
			}
		}
		else
		{
			Result="Please enter a valid Order ID";
		}

		return Result;
	}
	
	public String validateAuthorizationCreditAndDebitTransactionData(String orderID)
	{
		driver=this.getDriver();

		WebDriverWait wait=new WebDriverWait(driver,10);
		JavascriptExecutor executor=(JavascriptExecutor)driver;

		authorizationsPageObjects.searchFieldText.sendKeys(orderID);
		executor.executeScript("arguments[0].click()",authorizationsPageObjects.search_orderId);
		wait.until(ExpectedConditions.elementToBeClickable(authorizationsPageObjects.search_button));
		executor.executeScript("arguments[0].click()",authorizationsPageObjects.search_button);

		for(int i=0;i<50;i++){}
		if(!authorizationsPageObjects.noRecordsPresent.isCurrentlyVisible())
		{
		
			for(int i=0;i<authorizationsPageObjects.authorizationDate.size();i++)
			{
				executor.executeScript("arguments[0].click()",authorizationsPageObjects.authorizationDate.get(i));
				for(int j=0;j<authorizationsPageObjects.amount.size();j++)
				{
					if(authorizationsPageObjects.amount.get(j).getText().startsWith("-") && authorizationsPageObjects.amount.get(j).getCssValue("color").equals("rgba(240, 4, 4, 1)"))
					{
						System.out.println("Color is:"+authorizationsPageObjects.amount.get(j).getCssValue("color"));
						String combined="Amount:"+authorizationsPageObjects.amount.get(j).getText();
						authDebitData.add(combined);
					}
					else
					{
						System.out.println("Color is:"+authorizationsPageObjects.amount.get(j).getCssValue("color"));
						String combined="Amount:"+authorizationsPageObjects.amount.get(j).getText();
						authCreditData.add(combined);
					}
				}
			}


			Result="Passed";
		}
		else
		{
		
		Result="No Records Present";
		}

		
		return Result;
	}
	
	
	
	

}

















































*/