/*package ui.Signon;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.SMSTemplatePageObjects;
import ui.pageobjects.Signon.SignonObjects;

public class SMSTemplatePage extends PageObject{


	String Result=null;
	String loginStatus=null;
	WebDriver driver =null;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	SMSTemplatePageObjects smstemplatepageobjects;

	@Step
	public HashMap<String,String> getSMSTemplate(){

		driver = this.getDriver();	
		String currentPage;
		//HashMap<WebElement,WebElement> combine=new HashMap<WebElement,WebElement>();
		HashMap<String,String> finalSmsTemplate=new HashMap<String,String>();
		boolean flag=true;
		
		
		while(flag==true)
		{
			System.out.println("Size of the disabled link is: "+smstemplatepageobjects.nextButtondisabled().size());
			if(smstemplatepageobjects.nextButtondisabled().size()>0)
			{
				flag=false;
			}
			
			System.out.println("Flag value is:"+flag);
			currentPage=smstemplatepageobjects.currentPage().getText();
			System.out.println("Current Page is:"+currentPage);
			List<WebElement> sms_id=smstemplatepageobjects.sms_id();
			System.out.println("number of ids is:"+sms_id.size());
			List<WebElement> smsTemplate_id=smstemplatepageobjects.smsTemplate_id();	
			System.out.println("number of template ids is:"+sms_id.size());
			for(int i=0;i<10 && i<sms_id.size();i++)
			{

				String templateid=sms_id.get(i).getText();
				//System.out.println("template id:"+templateid);
				String templatename=smsTemplate_id.get(i).getText();
				//System.out.println("template name:"+templatename);

				new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(sms_id.get(i))).click();
				if(driver.getCurrentUrl().contains(templateid) && smstemplatepageobjects.editSmsTemplateValue().getText().equals(templatename))
				{
					finalSmsTemplate.put(templateid,templatename);
					//System.out.println(finalSmsTemplate);
					new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(smstemplatepageobjects.cancelButton())).click();
				}
				
				while(!smstemplatepageobjects.currentPage().getText().equals(currentPage))
				{
					new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(smstemplatepageobjects.nextButton())).click();
				}
			}
			
			if(flag==true)
			{
				System.out.println("Next Button status:"+smstemplatepageobjects.nextButton().isEnabled());
				new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(smstemplatepageobjects.nextButton())).click();
			}
			//System.out.println("Next Button status:"+smstemplatepageobjects.nextButton().isEnabled());
			
		}
		
		
		System.out.println("Total number of SMS templates is"+finalSmsTemplate.size());
		System.out.println(finalSmsTemplate);

		return finalSmsTemplate;
	}
}
*/