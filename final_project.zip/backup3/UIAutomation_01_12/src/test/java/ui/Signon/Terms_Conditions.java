package ui.Signon;

import java.awt.AWTException;
import java.io.File;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.scheduling.ExpectedBackendCondition;
import ui.pageobjects.Signon.AccountActivationPageObjects;
import ui.pageobjects.Signon.AdminPage_object;
import ui.pageobjects.Signon.ChangePasswordPageObjects;
import ui.pageobjects.Signon.CommunicationSummaryPageObjects;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.EmailTemplatePageObjects;
import ui.pageobjects.Signon.ExportEmailPageObjects;
import ui.pageobjects.Signon.FundingPageObjects;
import ui.pageobjects.Signon.MerchantAdminPageObjects;
import ui.pageobjects.Signon.MessagesPageObjects;
import ui.pageobjects.Signon.ParametersPageObjects;
import ui.pageobjects.Signon.PreAuthorizationsPageObjects;
import ui.pageobjects.Signon.SMSTemplatePageObjects;
import ui.pageobjects.Signon.SettingsPageObjects;
import ui.pageobjects.Signon.SignonObjects;
import ui.pageobjects.Signon.TermsAndConditionsPageObjects;
import ui.pageobjects.Signon.UserManagementPageObjects;
import ui.pageobjects.Signon.UsersListPageObjects;

public class Terms_Conditions extends PageObject{

	WebDriver driver =null;

	String Result=null;
	boolean Status=false;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	AdminPage_object adminPageobjects;
	UserManagementPageObjects usermanagePageobjects;
	SettingsPageObjects settingspageobjects;
	ExportEmailPageObjects exportemailadminPageobjects;
	CommunicationSummaryPageObjects comsummaryadminPageobjects;
	EmailTemplatePageObjects emailtemplatePageobjects;
	SMSTemplatePageObjects smstemplatePageobjects;
	PreAuthorizationsPageObjects preauthobjects;
	MessagesPageObjects messagespageobjects;
	FundingPageObjects fundingpageobjects;
	UserManagementPageObjects usermanagementpageobjects;
	CommunicationSummaryPageObjects communicationSummaryPageObjects;
	AccountActivationPageObjects accountActivationPageObjects;
	ChangePasswordPageObjects changePasswordPageObjects; 
	MerchantAdminPageObjects merchantAdminPageObjects;
	UsersListPageObjects usersListPageObjects; 
	ParametersPageObjects parametersPageObjects;
	TermsAndConditionsPageObjects termsandconditionspageobjects;
	
	User_management userManagement;
	public String newTermsAndConditionsID;
	public String device;
	long small_wait_time=50;
	long medium_wait_time=100;
	long large_wait_time=500;
	
	public String getTermsAndConditionsId(String firstname, String lastname, String username, String email, String accountstatus) throws InterruptedException, AWTException
	{
		driver=this.getDriver();

		userManagement.filterUser(firstname, lastname, username, email, accountstatus);

		String termsandconditionsid=new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(usersListPageObjects.termsandconditionsid())).getText();

		System.out.println("Terms and conditons ID is :"+termsandconditionsid);

		return termsandconditionsid;

	}
	
	@Step
	public String download_terms_and_condition(String downloaded_Path) throws InterruptedException{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver, small_wait_time);
		wait.until(ExpectedConditions.elementToBeClickable(signonObjects.download_TermsConditions()));
		if(signonObjects.download_TermsConditions.isCurrentlyVisible())
		{
		wait.until(ExpectedConditions.elementToBeClickable(signonObjects.download_TermsConditions()));
		signonObjects.download_TermsConditions().click();
		wait.until(ExpectedConditions.elementToBeClickable(signonObjects.Accept_TermsAndCondition()));
		File getLatestFile = getLatestFilefromDir(downloaded_Path);
	    String fileName = getLatestFile.getName();
	    long length = getLatestFile.length();
	    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0))
	    	{
	    		Result="Passed "+fileName;
	    	}
	    else
	    	{
	    	Result="Failed "+"We didnot find the document in the folder";
	    	}
		}
		return Result;	
	}
	@Step
	public String Accept_terms_and_conditions() throws InterruptedException{
		driver = this.getDriver();
		WebDriverWait wait = new WebDriverWait(driver, small_wait_time);
		wait.until(ExpectedConditions.elementToBeClickable(signonObjects.Accept_TermsAndCondition()));
		if(signonObjects.Accept_TermsAndCondition.isCurrentlyVisible())
		{
			signonObjects.Accept_TermsAndCondition().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Welcome_message()));
			Result="Passed "+"Successfully accepted the terms and conditions ";
		}
		else
		{
			Result="Failed "+" There is no terms and conditions available come back later ";
		}
		return Result;
		
	}
public boolean isFileDownloaded(String downloadPath, String fileName) {
	boolean flag = false;
    File dir = new File(downloadPath);
    File[] dir_contents = dir.listFiles();
  	    
    for (int i = 0; i < dir_contents.length; i++) {
        if (dir_contents[i].getName().contains(fileName))
            return flag=true;
            }

    return flag;
}
private File getLatestFilefromDir(String dirPath){
    File dir = new File(dirPath);
    File[] files = dir.listFiles();
    if (files == null || files.length == 0) {
        return null;
    }

    File lastModifiedFile = files[0];
    for (int i = 1; i < files.length; i++) {
       if (lastModifiedFile.lastModified() < files[i].lastModified()) {
           lastModifiedFile = files[i];
       }
    }
    return lastModifiedFile;
}

@Step
public String uploadTermsAndConditions(String alliancename,String type, String language,String TCName, String description, String htmlfilepath, String pdffilepath) throws AWTException, InterruptedException
{
	driver= this.getDriver();
	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.addnewtermsandcondtions())).click();
	System.out.println("Clicked on Add----------------");
	
	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.alliancename()));
	Select TCalliancename=new Select(termsandconditionspageobjects.alliancename());
	TCalliancename.selectByValue(alliancename);
	System.out.println("Selected Alliance name as EMS-------------");
	
	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.type()));
	Select TCtype=new Select(termsandconditionspageobjects.type());
	TCtype.selectByVisibleText(type);
	System.out.println("Selected type as REGISTRATION-------------");
	
	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.defaultlanguage()));
	Select defaultlanguage=new Select(termsandconditionspageobjects.defaultlanguage());
	defaultlanguage.selectByVisibleText(language);
	System.out.println("Selected default language as ENGLISH-------------");
	
	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.name()));
	termsandconditionspageobjects.name().click();
	termsandconditionspageobjects.name().sendKeys(TCName);
	System.out.println("Name is:"+termsandconditionspageobjects.name().getText());
	
	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.description()));
	termsandconditionspageobjects.description().click();
	termsandconditionspageobjects.description().sendKeys(description);
	System.out.println("Description is:"+termsandconditionspageobjects.description().getText());
	
	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.htmlfileinput()));
	termsandconditionspageobjects.htmlfileinput().sendKeys(htmlfilepath);
	

	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.htmlfileupload()));
	termsandconditionspageobjects.htmlfileupload().click();
	for(int i=0;i<50;i++){};
	
	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.pdffileinput()));
	termsandconditionspageobjects.pdffileinput().sendKeys(pdffilepath);

	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.pdffileupload()));
	termsandconditionspageobjects.pdffileupload().click();
	for(int i=0;i<50;i++){};
	
	String uploadedfiles=termsandconditionspageobjects.uploadedtermsandconditions().getText();
	String[] filenames=uploadedfiles.split(",");
	System.out.println("HTML File name:"+filenames[0]);
	System.out.println("PDF File name:"+filenames[1]);
	
	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.savetermsandconditions()));
	termsandconditionspageobjects.savetermsandconditions().click();
	for(int i=0;i<50;i++){};
	
	System.out.println("clicked on Save");
	
	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(termsandconditionspageobjects.newtermsandconditions()));
	
	System.out.println("The namE of the Latest T&C is:"+termsandconditionspageobjects.newtermsandconditions().getText());
	newTermsAndConditionsID=termsandconditionspageobjects.newtermsandconditionsid().getText();
	
	
	return termsandconditionspageobjects.newtermsandconditions().getText();
	

}

}
