/*package ui.Signon;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptExecutor;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.FundingPageObjects;
import ui.pageobjects.Signon.MessagesPageObjects;
import ui.pageobjects.Signon.SignonObjects;



public class FundingPage extends PageObject {

	WebDriver driver =null;

	String Result=null;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	MessagesPageObjects messagespageobjects;
	FundingPageObjects fundingpageobjects;
	

	ArrayList<Date> fundingDateAndTime=new ArrayList<Date>();
	ArrayList<WebElement> postingDate_fees_and_vat=new ArrayList<WebElement>();
	public ArrayList<String> fundingCreditData=new ArrayList<String>();
	public ArrayList<String> fundingDebitData=new ArrayList<String>();


	@Step
	public String validateFundingSortOrder(String fromDate, String toDate) throws IOException, ParseException{

		for(int i=0;i<30;i++)
		{
		waitFor(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText));
		}
		
		driver=this.getDriver();
		
		System.out.println("\n Inside Funding");

		waitFor(fundingpageobjects.date_dropdown).click();
		waitFor(fundingpageobjects.FromDate).click();
		waitFor(fundingpageobjects.FromDate).clear();
		waitFor(fundingpageobjects.FromDate).sendKeys(fromDate);
		waitFor(fundingpageobjects.ToDate).click();
		waitFor(fundingpageobjects.ToDate).clear();
		waitFor(fundingpageobjects.ToDate).sendKeys(toDate);
		waitFor(fundingpageobjects.applyDate).click();
		
		for(int i=0;i<30;i++)
		{
		waitFor(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText));
		}
		
		if(!fundingpageobjects.noRecordsPresent.isCurrentlyVisible())
		{

			SimpleDateFormat sdf= new SimpleDateFormat("dd MMM yyyy");

			for(int i=0;i<fundingpageobjects.fundingDate.size();i++)
			{
				System.out.println("Date And Time value is:"+fundingpageobjects.fundingDate.get(i).getText());
				//String dateAndTime= fundingpageobjects.fundingDate.get(i).getText()+" "+fundingpageobjects.fundingTime.get(i).getText();
				fundingDateAndTime.add(sdf.parse(fundingpageobjects.fundingDate.get(i).getText()));
			}

			System.out.println("The Date and Time are:"+fundingDateAndTime);

			ArrayList<Date> duplicateDateAndTime=new ArrayList<Date>();
			duplicateDateAndTime=(ArrayList<Date>) fundingDateAndTime.clone();
			Collections.sort(duplicateDateAndTime);
			Collections.reverse(duplicateDateAndTime);

			System.out.println("The duplicate Date and Time are:"+duplicateDateAndTime);

			if(fundingDateAndTime.equals(duplicateDateAndTime))
			{
				Result="Passed";
			}
			else
			{
				Result="Failed";
			}
		}
		else
		{
			Result="No Records found";
		}

		
	return Result;
	
	}

	
	public String verify_the_funding_Activities_view_for_feesAndVat_details(String Funding_Reference_number) throws Throwable{
		driver = this.getDriver();
		//int count1=0;
		String Result1=null,Result2=null;
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		WebDriverWait wait = new WebDriverWait(driver, 100);
		
		for(int i=0;i<=50;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.funding_text));
		checkPageIsReady();
		}
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText()));
		fundingpageobjects.searchFieldText().sendKeys(Funding_Reference_number);
		fundingpageobjects.search_button().click();
		for(int i=0;i<=50;i++)
		{
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
		checkPageIsReady();
		}
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button()));
		if(fundingpageobjects.search_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_error_message()));
			Result="Failed "+"No record found for this refrence number ";
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon()));
			executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon());
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.fees_vat_link()));
			executor.executeScript("arguments[0].click()",fundingpageobjects.fees_vat_link());
			for(int i=0;i<=100;i++)
			{
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Export_button()));
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.postingDate_text_fees_vat()));
				checkPageIsReady();
			}
			if(fundingpageobjects.postingDate_text_fees_vat.isCurrentlyVisible() && fundingpageobjects.MerchantId_text_fees_vat.isCurrentlyVisible()
					&& fundingpageobjects.Type_fees_and__vat.isCurrentlyVisible() && fundingpageobjects.EMS_fees_and_vat.isCurrentlyVisible()
					&& fundingpageobjects.vat_text.isCurrentlyVisible())
			{
				for(WebElement element:fundingpageobjects.posting_date_list_fees_and_vat)
				{
					if(!element.getText().equalsIgnoreCase("Sub totals") && !element.getText().equalsIgnoreCase("Posting date"))
							{
								postingDate_fees_and_vat.add(element);
							}
				}
				System.out.println("Size of the posting Date is:"+postingDate_fees_and_vat.size());
					for(int i=0;i<postingDate_fees_and_vat.size();i++)
					{
						
						executor.executeScript("arguments[0].click()",postingDate_fees_and_vat.get(i));
						wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Vat_value()));
							String vat=fundingpageobjects.Vat_value().getText();
							String type=fundingpageobjects.type_value_fees_and_vat().getText();
							String emsFees=fundingpageobjects.Ems_fees_value_in_vat_details.get(i).getText();
							Result1="Passed "+" Type : "+type+"emsFees : "+emsFees+"vat : "+vat;

						
					}
					Result=Result1;
				}
			

			else
			{
				Result="Failed "+"No Data are available right now Come back later ";
			}
		}
		return Result;
	}
	
	
	
	public String validateFundingCreditAndDebitTransactionData(String fundingReferenceNumber)
	{
		driver=this.getDriver();

		WebDriverWait wait=new WebDriverWait(driver,10);
		JavascriptExecutor executor=(JavascriptExecutor)driver;

		fundingpageobjects.searchFieldText.sendKeys(fundingReferenceNumber);
		//executor.executeScript("arguments[0].click()",fundingpageobjects.search_transactionId());
		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.search_button));
		executor.executeScript("arguments[0].click()",fundingpageobjects.search_button);

		for(int i=0;i<50;i++){}
		if(!fundingpageobjects.noRecordsPresent.isCurrentlyVisible())
		{
			for(int i=0;i<fundingpageobjects.funding_date_list.size();i++)
			{
				executor.executeScript("arguments[0].click()",fundingpageobjects.funding_date_list.get(i));
				

				for(int j=0;j<fundingpageobjects.payment_method_value.size() && j<fundingpageobjects.payment_method.size();j++)
				{
					if(fundingpageobjects.payment_method_value.get(j).getText().startsWith("-") && fundingpageobjects.payment_method_value.get(j).getCssValue("color").equals("rgba(240, 4, 4, 1)"))
					{
						System.out.println("Color is:"+fundingpageobjects.payment_method_value.get(j).getCssValue("color"));
						String combined=fundingpageobjects.payment_method.get(j).getText()+":"+fundingpageobjects.payment_method_value.get(j).getText();
						fundingDebitData.add(combined);
					}
					else
					{
						System.out.println("Color is:"+fundingpageobjects.payment_method_value.get(j).getCssValue("color"));
						String combined=fundingpageobjects.payment_method.get(j).getText()+":"+fundingpageobjects.payment_method_value.get(j).getText();
						fundingCreditData.add(combined);
					}
				}
			}


			Result="Passed";
		}
		else
		{
		
		Result="No Records Present";
		}

		
		return Result;
	}
	

}

*/