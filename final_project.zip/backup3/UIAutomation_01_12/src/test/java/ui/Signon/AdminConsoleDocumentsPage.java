/*package ui.Signon;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptExecutor;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.AdminConsoleDocumentsPageObjects;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.FundingPageObjects;
import ui.pageobjects.Signon.MessagesPageObjects;
import ui.pageobjects.Signon.SignonObjects;



public class AdminConsoleDocumentsPage extends PageObject {

	WebDriver driver =null;

	String Result=null;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	MessagesPageObjects messagespageobjects;
	FundingPageObjects fundingpageobjects;
	AdminConsoleDocumentsPageObjects adminconsoledocumentspageobjects;


	@Step
	public String verifyDocumentPaths(String documentName, String allianceCode, String defaultLanguage) throws IOException{

		driver=this.getDriver();
		String[] paths={"Marketing Information","Newsletters","Video Tutorials","Manuals","Other"};
		int filecount=0;
		String Result;

		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(adminconsoledocumentspageobjects.addDocument_button())).click();
		System.out.println("clicked on Add");
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(adminconsoledocumentspageobjects.documentName())).sendKeys(documentName);
		System.out.println("Document Name is"+adminconsoledocumentspageobjects.documentName().getAttribute("value"));
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(adminconsoledocumentspageobjects.allianceCode())).sendKeys(allianceCode);
		System.out.println("Selected the alliance code");
		waitFor(adminconsoledocumentspageobjects.defaultLanguage());
		adminconsoledocumentspageobjects.defaultLanguage().sendKeys(defaultLanguage);
		//new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(adminconsoledocumentspageobjects.defaultLanguage())).sendKeys(defaultLanguage);
		System.out.println("Selected the default language");
		new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(adminconsoledocumentspageobjects.documentfilepath()));

		Select select=new Select(adminconsoledocumentspageobjects.documentfilepath());
		List<WebElement> pathoptions=select.getOptions();
		int count=pathoptions.size();
		System.out.println("Number of options is:"+count);

		for(int i=0;i<paths.length;i++)
		{
			for(WebElement element:pathoptions)
			{
				System.out.println("Folder name is:"+element.getText());
				if(element.getText().contains(paths[i]))
				{
					filecount++;
					System.out.println("filecount is:"+filecount);
				}
			}
		}

		System.out.println("Total numbe of paths available in the options is:"+filecount);
		if(filecount==5)
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}


		return Result;


	}

	public ArrayList<String> getDocumentPaths(String allianceCode, String defaultLanguage) throws IOException{

		driver=this.getDriver();
		ArrayList<String> folderlist=new ArrayList<String>();

		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(adminconsoledocumentspageobjects.addDocument_button())).click();
		System.out.println("clicked on Add");
		new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(adminconsoledocumentspageobjects.allianceCode())).sendKeys(allianceCode);
		System.out.println("Selected the alliance code");
		waitFor(adminconsoledocumentspageobjects.defaultLanguage());
		adminconsoledocumentspageobjects.defaultLanguage().sendKeys(defaultLanguage);
		//new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(adminconsoledocumentspageobjects.defaultLanguage())).sendKeys(defaultLanguage);
		System.out.println("Selected the default language");
		Select select=new Select(adminconsoledocumentspageobjects.documentfilepath());
		List<WebElement> pathoptions=select.getOptions();
		int count=pathoptions.size();
		System.out.println("Number of options is:"+count);
		for(WebElement element:pathoptions)
		{
			folderlist.add(element.getText());
		}
		
		System.out.println("The folders are:"+folderlist);

		return folderlist;


	}

}




*/