/*package ui.Signon;

import java.awt.AWTException;
import java.io.File;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.thoughtworks.selenium.webdriven.JavascriptLibrary;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.screenplay.questions.JavaScript;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.FundingPageObjects;
import ui.pageobjects.Signon.SignonObjects;
public class dashboardPage extends PageObject{

	WebDriver driver =null;
	public ArrayList<String> tourguideSections=new ArrayList<String>();

	public Double combinedSalesAmount=0.0;
	public Double combinedSalesCustomers=0.0;
	public String approvalDetails;
	ArrayList<String> dashboardInformation=new ArrayList<String>();

	String Result=null;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	FundingPageObjects fundingpageobjects;


	@Step
	public String Dashboard_cookie_information_link() throws InterruptedException{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver, 10);
		if(dasboardpageObjects.Portal_cookie_message.getText().equals("By using our website, you agree to EMS� use of cookies."))
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.portal_cookie_details()));
			dasboardpageObjects.portal_cookie_details().click();
			for(int i=0;i<50;i++){};
			ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
			driver.switchTo().window(tabs2.get(1));
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.cookie_page()));
			if(dasboardpageObjects.cookie_page().getText().equals("Privacy & Cookie Policy"))
			{
				Result="Passed";
			}
			else
			{
				Result="Failed";
			}
			driver.close();
			driver.switchTo().window(tabs2.get(0));
		}
		else
		{
			Result="Failed";
		}

		return Result;	
	}
	public String Unread_message_count() throws InterruptedException{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.message_indicator_count()));
		if(dasboardpageObjects.message_indicator_count().getText()!=null)
		{
			Result="Passed"+":"+dasboardpageObjects.message_indicator_count().getText();
		}


		else
		{
			Result="Failed"+":"+dasboardpageObjects.message_indicator_count().getText()+":"+"No unread message are there for now";
		}
		return Result;
	}

	public String Unread_Document_count() throws InterruptedException{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.document_indicator_count()));
		if(dasboardpageObjects.document_indicator_count().getText()!=null)
		{
			Result="Passed"+":"+dasboardpageObjects.document_indicator_count().getText();
		}


		else
		{
			Result="Failed"+":"+dasboardpageObjects.document_indicator_count().getText()+":"+"No unread message are there for now";
		}
		return Result;
	}

	public String getDashboardUrl() throws InterruptedException{
		driver=this.getDriver();
		return driver.getCurrentUrl();
	}

	public String getAmountFromFundingWidget() throws InterruptedException
	{
		driver=this.getDriver();
		//		WebDriverWait wait = new WebDriverWait(driver, 50);
		//		JavascriptExecutor js = (JavascriptExecutor)driver;
		//		for(int i=0;i<=25;i++)
		//		{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.viewdetails_Funding()));}
		//		js.executeScript("arguments[0].click();", dasboardpageObjects.viewdetails_Funding());
		//
		//		//executor.execdasboardpageObjects.viewdetails_Funding().click();
		//		for(int i=0;i<=50;i++)
		//		{
		//			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Funding_text()));
		//
		//		}
		//		System.out.println(fundingpageobjects.amountDepositedToday_Funding.isCurrentlyVisible());
		//		wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.amountDepositedToday_Funding()));
		waitFor(fundingpageobjects.amountDepositedToday_Funding());
		String todayAmount= fundingpageobjects.amountDepositedToday_Funding().getText();
		System.out.println(todayAmount);
		return todayAmount;
	}

	public void clickMessagesLinkOnDashboard() throws InterruptedException
	{
		driver=this.getDriver();
		//waitFor(dasboardpageObjects.close_cookie).click();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messagesLink_dashboard()));
		dasboardpageObjects.messagesLink_dashboard().click();
	}

	public void clickDocumentsLinkOnDashboard() throws InterruptedException
	{
		driver=this.getDriver();
		//waitFor(dasboardpageObjects.close_cookie).click();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documentsLink_dashboard()));
		dasboardpageObjects.documentsLink_dashboard().click();
	}
	public void clickPreAuthorizationsLinkOnDashboard() throws InterruptedException
	{
		driver=this.getDriver();
		//waitFor(dasboardpageObjects.close_cookie).click();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.preauthorization_Link));
		dasboardpageObjects.preauthorization_Link.click();
	}
	public void clickAuthorizationsLinkOnDashboard() throws InterruptedException
	{
		driver=this.getDriver();
		//waitFor(dasboardpageObjects.close_cookie).click();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Authorizations_Link));
		dasboardpageObjects.Authorizations_Link.click();
	}
	public void clickTransactionsLinkOnDashboard() throws InterruptedException
	{
		driver=this.getDriver();
		//waitFor(dasboardpageObjects.close_cookie).click();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.transaction_Link));
		dasboardpageObjects.transaction_Link.click();
	}
	public void clickFundingLinkOnDashboard() throws InterruptedException
	{
		driver=this.getDriver();
		//waitFor(dasboardpageObjects.close_cookie).click();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.funding_Link));
		dasboardpageObjects.funding_Link.click();
	}

	public String checkAccountExpiryNotification() throws InterruptedException, AWTException{
		driver = this.getDriver();
		String Result;
		if(dasboardpageObjects.accountExpiryNotification.isCurrentlyVisible() && dasboardpageObjects.accountExpiryNotification.getText().contains("Your account will expire"))
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}

		return Result;

	}

	public String checkIfLoginSessionIsActive(String url,String timeout) throws InterruptedException, AWTException{
		driver = this.getDriver();
		String Result;
		Date d1=new Date();
		System.out.println(d1);
		Date d2=new Date();
		System.out.println(d2);
		long d3=(d2.getTime()-d1.getTime());

		while(d3!=(Long.parseLong(timeout)*60000)+4000)
		{
			d2=new Date();
			System.out.println();
			d3=(d2.getTime()-d1.getTime());
			System.out.println(d3);
		}

		waitFor(dasboardpageObjects.messagesLink_dashboard).click();
		if(driver.getCurrentUrl().equals(url))
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}



		return Result;

	}

	public String checkifImpersonatedUserNameisVisible(String impersonationUserName, String userName, String password)
	{
		driver=this.getDriver();
		waitFor(dasboardpageObjects.impersonationUserName).click();
		waitFor(dasboardpageObjects.impersonationUserName).sendKeys(impersonationUserName);
		waitFor(dasboardpageObjects.impersonationLogin).click();

		if(!dasboardpageObjects.impersonationErrorMessage.isCurrentlyVisible())
		{

			System.out.println(dasboardpageObjects.impersonatedUserNameText.getText());

			waitFor(dasboardpageObjects.endImpersonationSession).click();
			waitFor(dasboardpageObjects.impersonationLogout).click();

			waitFor(signonObjects.UserName()).click();
			waitFor(signonObjects.UserName()).sendKeys(userName);
			waitFor(signonObjects.Password()).click();
			waitFor(signonObjects.Password()).sendKeys(password);
			waitFor(signonObjects.Submit()).click();

			System.out.println("The username is:"+dasboardpageObjects.impersonationUserName.getAttribute("value"));
			if(!dasboardpageObjects.impersonationUserName.getAttribute("value").equals(impersonationUserName))
			{
				Result="Passed";
			}
			else
			{
				Result="Failed";
			}
		}
		else
		{
			Result=dasboardpageObjects.impersonationErrorMessage.getText();
		}

		return Result;
	}

	public String validateImpersonatedUserData(String impersonationUserName,String callCenterUserName, String callCenterPassword)
	{
		driver=this.getDriver();
		String paymentAmount=dasboardpageObjects.todayPaymentAmount.getText();
		String paymentCustomer=dasboardpageObjects.todayPaymentCustomers.getText();
		String salesAmount=dasboardpageObjects.todaySalesAmount.getText();
		String salesCustomer=dasboardpageObjects.todaySalesCustomers.getText();

		waitFor(dasboardpageObjects.logout).click();

		waitFor(signonObjects.UserName()).click();
		waitFor(signonObjects.UserName()).sendKeys(callCenterUserName);
		waitFor(signonObjects.Password()).click();
		waitFor(signonObjects.Password()).sendKeys(callCenterPassword);
		waitFor(signonObjects.Submit()).click();



		waitFor(dasboardpageObjects.impersonationUserName).click();
		waitFor(dasboardpageObjects.impersonationUserName).sendKeys(impersonationUserName);
		waitFor(dasboardpageObjects.impersonationLogin).click();


		if(!dasboardpageObjects.impersonationErrorMessage.isCurrentlyVisible())
		{

			String impersonationPaymentAmount=dasboardpageObjects.todayPaymentAmount.getText();
			String impersonationPaymentCustomer=dasboardpageObjects.todayPaymentCustomers.getText();
			String impersonationSalesAmount=dasboardpageObjects.todaySalesAmount.getText();
			String impersonationSalesCustomer=dasboardpageObjects.todaySalesCustomers.getText();

			if(paymentAmount.equals(impersonationPaymentAmount) && paymentCustomer.equals(impersonationPaymentCustomer)
					&& salesAmount.equals(impersonationSalesAmount) && salesCustomer.equals(impersonationSalesCustomer))
			{

				Result="Passed";
			}
			else
			{
				Result="Failed";
			}
		}
		else
		{
			Result=dasboardpageObjects.impersonationErrorMessage.getText();
		}

		return Result;
	}

	public String checkImpersonatedUserFunctionsareAvailable(String impersonationUserName,String callCenterUserName, String callCenterPassword)
	{
		driver=this.getDriver();
		String paymentAmount=dasboardpageObjects.todayPaymentAmount.getText();
		String paymentCustomer=dasboardpageObjects.todayPaymentCustomers.getText();
		String salesAmount=dasboardpageObjects.todaySalesAmount.getText();
		String salesCustomer=dasboardpageObjects.todaySalesCustomers.getText();


		waitFor(dasboardpageObjects.logout).click();

		waitFor(signonObjects.UserName()).click();
		waitFor(signonObjects.UserName()).sendKeys(callCenterUserName);
		waitFor(signonObjects.Password()).click();
		waitFor(signonObjects.Password()).sendKeys(callCenterPassword);
		waitFor(signonObjects.Submit()).click();

		waitFor(dasboardpageObjects.impersonationUserName).click();
		waitFor(dasboardpageObjects.impersonationUserName).sendKeys(impersonationUserName);
		waitFor(dasboardpageObjects.impersonationLogin).click();


		if(!dasboardpageObjects.impersonationErrorMessage.isCurrentlyVisible())
		{

			String impersonationPaymentAmount=dasboardpageObjects.todayPaymentAmount.getText();
			String impersonationPaymentCustomer=dasboardpageObjects.todayPaymentCustomers.getText();
			String impersonationSalesAmount=dasboardpageObjects.todaySalesAmount.getText();
			String impersonationSalesCustomer=dasboardpageObjects.todaySalesCustomers.getText();

			waitFor(dasboardpageObjects.preauthorization_Link);
			waitFor(dasboardpageObjects.Authorizations_Link);
			waitFor(dasboardpageObjects.transaction_Link);
			waitFor(dasboardpageObjects.funding_Link);

			if(paymentAmount.equals(impersonationPaymentAmount) && paymentCustomer.equals(impersonationPaymentCustomer)
					&& salesAmount.equals(impersonationSalesAmount) && salesCustomer.equals(impersonationSalesCustomer)
					&& dasboardpageObjects.preauthorization_Link.isCurrentlyVisible() && dasboardpageObjects.Authorizations_Link.isCurrentlyVisible()
					&& dasboardpageObjects.transaction_Link.isCurrentlyVisible() && dasboardpageObjects.funding_Link.isCurrentlyVisible())
			{

				Result="Passed";
			}
			else
			{
				Result="Failed";
			}
		}
		else
		{
			Result=dasboardpageObjects.impersonationErrorMessage.getText();
		}

		return Result;
	}


	public String validateTourGuide(String userName, String password)
	{

		driver=this.getDriver();
		JavascriptExecutor executor=(JavascriptExecutor)driver;

		if(signonObjects.Accept_TermsAndCondition.isCurrentlyVisible())
		{
			executor.executeScript("arguments[0].click()",signonObjects.Accept_TermsAndCondition);
		}

		waitFor(dasboardpageObjects.startTheTour);
		executor.executeScript("arguments[0].click()",dasboardpageObjects.startTheTour);
		waitFor(dasboardpageObjects.tourGuide_Next);
		while(dasboardpageObjects.tourGuide_Next.isCurrentlyVisible())
		{

			waitFor(dasboardpageObjects.tourGuide_Sections);
			String sections=dasboardpageObjects.tourGuide_Sections.getText();
			System.out.println("Tour guide section currently being covered:"+sections);
			tourguideSections.add(sections);
			new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.tourGuide_Next));
			executor.executeScript("arguments[0].click()",dasboardpageObjects.tourGuide_Next);

		}

		while(!dasboardpageObjects.tourGuide_Sections.isCurrentlyVisible())
		{
			waitFor(dasboardpageObjects.tourGuide_Sections);
		}
		String sections=dasboardpageObjects.tourGuide_Sections.getText();
		System.out.println("Tour guide section currently being covered:"+sections);
		tourguideSections.add(sections);

		waitFor(dasboardpageObjects.endTheTour).click();

		waitFor(dasboardpageObjects.logout).click();

		waitFor(signonObjects.UserName()).click();
		waitFor(signonObjects.UserName()).sendKeys(userName);
		waitFor(signonObjects.Password()).click();
		waitFor(signonObjects.Password()).sendKeys(password);
		waitFor(signonObjects.Submit()).click();

		if(!dasboardpageObjects.startTheTour.isCurrentlyVisible())
		{

			Result="Passed";
			System.out.println("\n Total Number of sections covered:"+tourguideSections.size());
		}



		return Result;
	}

	public String validatePreAuthorizationsDetails()
	{
		if(dasboardpageObjects.preAuthorizationsGraph.isCurrentlyVisible())
		{
			if(dasboardpageObjects.noExpiringPreAuthorizations.size() >0)
			{
				Result=dasboardpageObjects.noExpiringPreAuthorizations.get(0).getText();
			}
			else
			{
				Result="PreAuthorization details are displayed";
			}
		}
		else
		{
			Result="No PreAuthorization details displayed";
		}

		return Result;
	}
	public void getSalesDetails() throws ParseException
	{
		//NumberFormat format = NumberFormat.getCurrencyInstance();
		driver=this.getDriver();

		new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.dashboardPage_PreviousButton));
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click()",dasboardpageObjects.dashboardPage_PreviousButton);

		String salesAmount= dasboardpageObjects.todaySalesAmount.getText().substring(2).replaceAll(",","");
		String salesCustomers=dasboardpageObjects.todaySalesCustomers.getText();
		Double sales = Double.parseDouble(salesAmount);
		Double customers = Double.parseDouble(salesCustomers);
		System.out.println("SalesAmount:"+sales.toString());
		System.out.println("Customers:"+customers.toString());

		while(dasboardpageObjects.dashboardPage_PreviousButton.isPresent())
		{
			waitFor(dasboardpageObjects.todaySalesAmount);
			waitFor(dasboardpageObjects.todaySalesCustomers);
			salesAmount= dasboardpageObjects.todaySalesAmount.getText().substring(2).replaceAll(",","");
			salesCustomers=dasboardpageObjects.todaySalesCustomers.getText();
			sales = Double.parseDouble(salesAmount);
			customers = Double.parseDouble(salesCustomers);
			System.out.println("SalesAmount:"+sales.toString());
			System.out.println("Customers:"+customers.toString());

			combinedSalesAmount=combinedSalesAmount+sales;
			combinedSalesCustomers=combinedSalesCustomers+customers;

			new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.dashboardPage_PreviousButton));
			executor.executeScript("arguments[0].click()",dasboardpageObjects.dashboardPage_PreviousButton);
		}

		System.out.println("\n the combined sales amount is:"+combinedSalesAmount);
		System.out.println("\n the total number of sales customers is:"+combinedSalesCustomers);

	}
	
	public String getApprovalRatioInformation()
	{
		driver=this.getDriver();
		StringBuilder sb=new StringBuilder();
		if(!dasboardpageObjects.noTransactionsProcessed.isCurrentlyVisible())
		{
			String approvedPayment=dasboardpageObjects.paymentSuccess.getText();
			String declinedPayment=dasboardpageObjects.paymentDecline.getText();
			String paymentAmount=dasboardpageObjects.todayPaymentAmount.getText();
			String paymentCustomer=dasboardpageObjects.todayPaymentCustomers.getText();
			
			for(int i=0;i<dasboardpageObjects.paymentType.size() && i<dasboardpageObjects.paymentValue.size();i++)
			{
				sb.append("PaymentType:").append(dasboardpageObjects.paymentType.get(i).getText()).append("-").append("PaymentValue:").append(dasboardpageObjects.paymentValue.get(i).getText());
			}
			
			String paymentDetails=sb.toString();

			approvalDetails="PaymentAmount:"+paymentAmount+"Number of Customers:"+paymentCustomer+"Approved Payment:"+approvedPayment+"Declined Payment:"+declinedPayment+"Payment Details:"+paymentDetails;
			Result="Passed";	
		}
		else
		{
			Result=dasboardpageObjects.noTransactionsProcessed.getText();
		}
		
		return Result;
	}
	
	public ArrayList<String> getDashboardDetails()
	{
		driver=this.getDriver();
		String paymentDetails,paymentDetails1;
		StringBuilder sb=new StringBuilder();
		StringBuilder sb1=new StringBuilder();
		JavascriptExecutor executor=(JavascriptExecutor)driver;
		String currentDate=dasboardpageObjects.currentDate.getText();
		String todayFundingAmount=fundingpageobjects.amountDepositedToday_Funding.getText();
		if(!dasboardpageObjects.noTransactionsProcessed.isCurrentlyVisible())
		{
			String approvedPayment=dasboardpageObjects.paymentSuccess.getText();
			String declinedPayment=dasboardpageObjects.paymentDecline.getText();
			String paymentAmount=dasboardpageObjects.todayPaymentAmount.getText();
			String paymentCustomer=dasboardpageObjects.todayPaymentCustomers.getText();
			for(int i=0;i<dasboardpageObjects.paymentType.size() && i<dasboardpageObjects.paymentValue.size();i++)
			{
				sb.append("PaymentType:").append(dasboardpageObjects.paymentType.get(i).getText()).append("-").append("PaymentValue:").append(dasboardpageObjects.paymentValue.get(i).getText());
				
			}
			
			paymentDetails=sb.toString();
			approvalDetails="Current Date:"+currentDate+"PaymentAmount:"+paymentAmount+"Number of Customers:"+paymentCustomer+"Approved Payment:"+approvedPayment+"Declined Payment:"+declinedPayment+"Payment Details:"+paymentDetails;
			dashboardInformation.add(approvalDetails+"Amount deposited today:"+todayFundingAmount);	
			
		}
		else
		{
			approvalDetails="Current Date:"+currentDate+"Payment Details:"+dasboardpageObjects.noTransactionsProcessed.getText();
			dashboardInformation.add(approvalDetails+"Amount deposited today:"+todayFundingAmount);	
		}
		
		while(dasboardpageObjects.dashboardPage_PreviousButton.isPresent())
		{
			currentDate=dasboardpageObjects.currentDate.getText();
			waitFor(dasboardpageObjects.todaySalesAmount);
			waitFor(dasboardpageObjects.todaySalesCustomers);
			String salesAmount= dasboardpageObjects.todaySalesAmount.getText();
			String salesCustomers=dasboardpageObjects.todaySalesCustomers.getText();
			if(!dasboardpageObjects.noTransactionsProcessed.isCurrentlyVisible())
			{
			String approvedPayment=dasboardpageObjects.paymentSuccess.getText();
			String declinedPayment=dasboardpageObjects.paymentDecline.getText();
			String paymentAmount=dasboardpageObjects.todayPaymentAmount.getText();
			String paymentCustomer=dasboardpageObjects.todayPaymentCustomers.getText();
			for(int i=0;i<dasboardpageObjects.paymentType.size() && i<dasboardpageObjects.paymentValue.size();i++)
			{
				sb1.append("PaymentType:").append(dasboardpageObjects.paymentType.get(i).getText()).append("-").append("PaymentValue:").append(dasboardpageObjects.paymentValue.get(i).getText());
			}
			
			paymentDetails1=sb1.toString();
			approvalDetails="Current Date:"+currentDate+"Sales Amount:"+salesAmount+"Sales Customers:"+salesCustomers+"PaymentAmount:"+paymentAmount+"Number of Customers:"+paymentCustomer+"Approved Payment:"+approvedPayment+"Declined Payment:"+declinedPayment+"Payment Details:"+paymentDetails1;
			dashboardInformation.add(approvalDetails);	
			}
			else
			{
				approvalDetails="Current Date:"+currentDate+"Payment Details:"+"Sales Amount:"+salesAmount+"Sales Customers:"+salesCustomers+"Payment Details:"+dasboardpageObjects.noTransactionsProcessed.getText();
				dashboardInformation.add(approvalDetails);	
			}
			
			new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.dashboardPage_PreviousButton));
			executor.executeScript("arguments[0].click()",dasboardpageObjects.dashboardPage_PreviousButton);
		}
		return dashboardInformation;
		
	}

}



































*/