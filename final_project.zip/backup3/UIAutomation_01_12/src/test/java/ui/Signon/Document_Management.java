package ui.Signon;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


import com.thoughtworks.selenium.webdriven.JavascriptLibrary;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.AccountActivationPageObjects;
import ui.pageobjects.Signon.AdminConsoleDocumentsPageObjects;
import ui.pageobjects.Signon.AdminPage_object;
import ui.pageobjects.Signon.ChangePasswordPageObjects;
import ui.pageobjects.Signon.CommunicationSummaryPageObjects;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.DocumentsPageObjects;
import ui.pageobjects.Signon.EmailTemplatePageObjects;
import ui.pageobjects.Signon.ExportEmailPageObjects;
import ui.pageobjects.Signon.FundingPageObjects;
import ui.pageobjects.Signon.MerchantAdminPageObjects;
import ui.pageobjects.Signon.MessagesPageObjects;
import ui.pageobjects.Signon.ParametersPageObjects;
import ui.pageobjects.Signon.PreAuthorizationsPageObjects;
import ui.pageobjects.Signon.SMSTemplatePageObjects;
import ui.pageobjects.Signon.SettingsPageObjects;
import ui.pageobjects.Signon.SignonObjects;
import ui.pageobjects.Signon.UserManagementPageObjects;
import ui.pageobjects.Signon.UsersListPageObjects;

public class Document_Management extends PageObject{
	WebDriver driver =null;
	public String Result=null;
	boolean Status=false;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	AdminPage_object adminPageobjects;
	UserManagementPageObjects usermanagePageobjects;
	SettingsPageObjects settingspageobjects;
	ExportEmailPageObjects exportemailadminPageobjects;
	CommunicationSummaryPageObjects comsummaryadminPageobjects;
	EmailTemplatePageObjects emailtemplatePageobjects;
	SMSTemplatePageObjects smstemplatePageobjects;
	PreAuthorizationsPageObjects preauthobjects;
	MessagesPageObjects messagespageobjects;
	FundingPageObjects fundingpageobjects;
	UserManagementPageObjects usermanagementpageobjects;
	CommunicationSummaryPageObjects communicationSummaryPageObjects;
	AccountActivationPageObjects accountActivationPageObjects;
	ChangePasswordPageObjects changePasswordPageObjects; 
	MerchantAdminPageObjects merchantAdminPageObjects;
	UsersListPageObjects usersListPageObjects; 
	ParametersPageObjects parametersPageObjects;
	AdminConsoleDocumentsPageObjects documentAdminpageobjects;
	DocumentsPageObjects documentpageobjects;
	
	public String device;
	
	String document_link=null;

	long small_wait_time=50;
	long medium_wait_time=100;
	long large_wait_time=500;
	
	public ArrayList<String> documentTitle=new ArrayList<String>();
	public ArrayList<String> documentSummary=new ArrayList<String>();
	public ArrayList<String> receivedDate=new ArrayList<String>();
	public ArrayList<String> documentType=new ArrayList<String>();
	public ArrayList<String> documents=new ArrayList<String>();

	@Step
	public String permanent_link_Retrive(String userID_LBC,String password_LBC,String downloaded_Path) throws Throwable{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver,small_wait_time);
		wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.document_link()));
		documentAdminpageobjects.document_link.click();
		wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.search_Textbox()));
		/*documentAdminpageobjects.search_Textbox().sendKeys(Document_Title);
		documentAdminpageobjects.search_button().click();
		wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.search_Textbox()));*/
		//wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.selected_text()));
		System.out.println(documentAdminpageobjects.selected_text.isCurrentlyVisible());
		String Document_title=documentAdminpageobjects.selected_text().getText();
		if(documentAdminpageobjects.selected_text.isCurrentlyVisible())
		{
			System.out.println(documentAdminpageobjects.selected_text().getText());
			documentAdminpageobjects.selected_text().click();
			if(documentAdminpageobjects.document_link_of_each_document.isCurrentlyVisible())
			{
				wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.document_link_of_each_document()));
				document_link=documentAdminpageobjects.document_link_of_each_document().getText();
				driver.get(document_link);
				wait.until(ExpectedConditions.elementToBeClickable(signonObjects.userId_LBC()));
				signonObjects.userId_LBC().sendKeys(userID_LBC);
				wait.until(ExpectedConditions.elementToBeClickable(signonObjects.password_LBC()));
				signonObjects.password_LBC().sendKeys(password_LBC);
				signonObjects.submit_lbc().click();
				wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.dashboard_text_LBC()));
				File getLatestFile = getLatestFilefromDir(downloaded_Path);
			    String fileName = getLatestFile.getName();
			    String []filedetails=fileName.split("_");
			    long length = getLatestFile.length();
			   
			    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) || filedetails[0].contains(Document_title))
			    	{
			    		Result="Passed "+fileName+" The document can be downloaded from outside";
			    	}
			    else
			    	{
			    		Result="Failed "+"We didnot find the document in the folder";
			    	}
			}
			else
			{
				Result="Failed "+"The document link is not found";
			}
		}
		return Result;
	}
	@Step
	public String Add_a_new_document(String document_Name,String Alliance_name,String Language,String Upload_file,String attachmentPath,String Description_DocumentText) throws Throwable{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver,medium_wait_time);
		if(!documentAdminpageobjects.document_link.isCurrentlyVisible())
		{adminPageobjects.hidden_button.click();
		wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.document_link()));
		documentAdminpageobjects.document_link().click();
		wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.add_button()));
		documentAdminpageobjects.add_button().click();
		wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.documentName()));
		documentAdminpageobjects.documentName().sendKeys(document_Name);
		wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.alliance_code()));
		documentAdminpageobjects.alliance_code().sendKeys(Alliance_name);
		checkPageIsReady();
		for(int i=0;i<=30;i++)
		{waitFor(documentAdminpageobjects.language());
		checkPageIsReady();}
		documentAdminpageobjects.language().sendKeys(Language);
		for(int i=0;i<=30;i++)
		{checkPageIsReady();
		waitFor(documentAdminpageobjects.attachmentPath());}
		documentAdminpageobjects.attachmentPath().sendKeys(attachmentPath);
		documentAdminpageobjects.description().sendKeys(Description_DocumentText);
		for(int i=0;i<=30;i++)
		{waitFor(documentAdminpageobjects.documentPath());}
		documentAdminpageobjects.documentPath().sendKeys(Upload_file);
		for(int i=0;i<=30;i++)
		{waitFor(documentAdminpageobjects.uploadeButton());}
		documentAdminpageobjects.uploadeButton().click();
		File f = new File(Upload_file);
		System.out.println(f.getName());
		String filename=f.getName();
		wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.message_top_panel()));
		if(documentAdminpageobjects.message_top_panel().getText().contains('"'+filename+'"'+" was uploaded. Please save to continue"))
		{
			if(!documentAdminpageobjects.error_message.isCurrentlyVisible())
			{
				documentAdminpageobjects.submit_button().click();
				for(int i=0;i<=10;i++)
				{wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.message_top_panel()));}
				if(documentAdminpageobjects.message_top_panel().getText().contains("Document has been added successfully."))
				{
					Result="Passed "+documentAdminpageobjects.message_top_panel().getText();
				}
				else
				{
					Result="Failed "+"Document has not been added properly.";
				}
			}
			else
			{
				Result="Failed "+"Document needs more input.";
			}
		}
		else
		{
			Result="Failed "+"Failed to attach the file";
		}
		}
		return Result;
	}
	@Step
	public String Rename_a_document(String Rename_document,String Upload_file) throws Throwable{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver,small_wait_time);
//		if(!documentAdminpageobjects.document_link.isCurrentlyVisible())
//		{adminpageObjects.hidden_button.click();
		wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.home_link_admin));
		adminPageobjects.home_link_admin.click();
		wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.document_link()));
		documentAdminpageobjects.document_link.click();
		wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.selected_firstRow()));
		File f = new File(Upload_file);
		System.out.println(f.getName());
		String filename=f.getName();
		
		for(int i=0;i<documentAdminpageobjects.Document_Table_list.size();i++)	
		{
			if(documentAdminpageobjects.Document_Table_list.get(i).getText().contains(filename))
			{
				documentAdminpageobjects.selected_firstRow().click();
				waitFor(documentAdminpageobjects.documentName());
				documentAdminpageobjects.documentName().clear();
				documentAdminpageobjects.documentName().sendKeys(Rename_document);
				for(int i1=0;i<=10;i++)
				{waitFor(documentAdminpageobjects.submit_button());}
				documentAdminpageobjects.submit_button().click();
				for(int i1=0;i<=10;i++)
				{waitFor(documentAdminpageobjects.message_top_panel());}
				if(documentAdminpageobjects.message_top_panel().getText().contains("Document has been added successfully."))
				{
					Result="Passed "+documentAdminpageobjects.message_top_panel().getText();
				}
				else
				{
					Result="Failed "+"Document has not been added properly.";
				}
			}
			else
			{
				Result="Failed "+"No Document are there for now";
			}
		}

		return Result;
	}
	@Step
	public String Remove_a_document(String Upload_file) throws Throwable{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver,small_wait_time);
		wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.home_link_admin));
		adminPageobjects.home_link_admin.click();
		wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.document_link()));
		documentAdminpageobjects.document_link().click();
		File f = new File(Upload_file);
		System.out.println(f.getName());
		String filename=f.getName();
		wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.selected_firstRow()));
		for(int i=0;i<documentAdminpageobjects.Document_Table_list.size();i++)	
		{
			if(documentAdminpageobjects.Document_Table_list.get(i).getText().contains(filename))
			{
				for(int i1=0;i1<=10;i1++)
				{
					wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.delete_button()));
					checkPageIsReady();
				}
				documentAdminpageobjects.delete_button().click();
				for(int i1=0;i1<=80;i1++)
				{
					wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.message_top_panel()));
					checkPageIsReady();
				}
				if(documentAdminpageobjects.message_top_panel().getText().contains("Documents "+'"'+filename+'"'+" was deleted."))
				{
					Result="Passed "+documentAdminpageobjects.message_top_panel().getText();
				}
				else
				{
					Result="Failed "+"The document is not deleted.";
				}
				//"Documents "pdf-sample.pdf" was deleted."
			}
			else
			{
				Result="Failed "+"No Document are there for now";
			}
		}
		
		return Result;
		
	}
	@Step
	public String marked_unread_document(/*String folderName*/) throws Throwable{
		driver = this.getDriver();
		int count1=0;
		String Result1=null;
		WebDriverWait wait = new WebDriverWait(driver, small_wait_time);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		if(dasboardpageObjects.toggleButton_mobile.isCurrentlyVisible())
		 {		
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.toggleButton_mobile));
			executor.executeScript("arguments[0].click()",dasboardpageObjects.toggleButton_mobile);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documents_Link()));
			dasboardpageObjects.documents_Link().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documents_text()));
			int count=documentpageobjects.folderslist.size();
		    System.out.println("Number of folders is:"+count);
		    for(int i=0;i<documentpageobjects.folderslist.size();i++)
		    {
		    	System.out.println(documentpageobjects.folderslist.get(i).getText());
		    	waitFor(documentpageobjects.folderslist.get(i)).click();
		    	for(int i1=0;i1<documentpageobjects.DocumentList.size();i1++)
		    	{
		    		waitFor(documentpageobjects.DocumentList.get(i1));
		    		String unread_status=documentpageobjects.DocumentList.get(i1).getAttribute("class");
		    				if(unread_status.equals("ng-binding"))
		    				{
		    					Result1="Passed "+"For Now no unread documents are present";
		    				}
		                    
		    				else
		    				{
		    					
		    					count1 =count1+1;
		    					Result1="Passed "+"Unread count is : "+count1;
		    				}
		    	}    
				wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documents_Link()));
				dasboardpageObjects.documents_Link().click();
				wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documents_text()));
		    }
		 }
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documents_Link()));
			dasboardpageObjects.documents_Link().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documents_text()));
			int count=documentpageobjects.folderslist.size();
		    System.out.println("Number of folders is:"+count);
		    for(int i=0;i<documentpageobjects.folderslist.size();i++)
		    {
		    	System.out.println(documentpageobjects.folderslist.get(i).getText());
		    	waitFor(documentpageobjects.folderslist.get(i)).click();
		    	for(int i1=0;i1<documentpageobjects.DocumentList.size();i1++)
		    	{
		    		waitFor(documentpageobjects.DocumentList.get(i1));
		    		String unread_status=documentpageobjects.DocumentList.get(i1).getAttribute("class");
		    				if(unread_status.equals("ng-binding"))
		    				{
		    					Result1="Passed "+"For Now no unread documents are present";
		    				}
		                    
		    				else
		    				{
		    					
		    					count1 =count1+1;
		    					Result1="Passed "+"Unread count is : "+count1;
		    				}
		    	}    
				wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documents_Link()));
				dasboardpageObjects.documents_Link().click();
				wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documents_text()));
		    }
		}
	    Result=Result1;
	    
		return Result;
	}

	@Step
	public String Download_document_from_document_library(String downloaded_Path,String Alliance_code) throws Throwable{
		driver = this.getDriver();
		JavascriptLibrary jsLib = new JavascriptLibrary();
		int count1=0;
		String Result1=null;
		WebDriverWait wait = new WebDriverWait(driver, small_wait_time);
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		if(dasboardpageObjects.toggleButton_mobile.isCurrentlyVisible())
		 {		
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.toggleButton_mobile));
			executor.executeScript("arguments[0].click()",dasboardpageObjects.toggleButton_mobile);
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documents_Link()));
			dasboardpageObjects.documents_Link().click();
			for(int i=0;i<=50;i++)
			{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documents_text()));
			checkPageIsReady();}
			for(int i=0;i<documentpageobjects.AllDocumentListView.size();i++)
			{
				if(documentpageobjects.AllDocumentListView.get(i).isCurrentlyVisible())
				{
					executor.executeScript("arguments[0].click()",documentpageobjects.AllDocumentListView.get(i));
					for(int i1=0;i1<=50;i1++)
					{checkPageIsReady();}
					if(documentpageobjects.no_files_text.isCurrentlyVisible())
					{
						wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.all_document_link()));
						documentpageobjects.all_document_link().click();
					}
					else
					{
						wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.listwiseView()));
						documentpageobjects.listwiseView().click();
						for(int i1=0;i1<=50;i1++)
						{checkPageIsReady();}
						List<WebElement> allcheckbox_css=driver.findElements(By.cssSelector("input[id='cleckbox-all']"));
						System.out.println(allcheckbox_css);
						String id=allcheckbox_css.get(0).getAttribute("id");
			            System.out.println(id);
			            jsLib.executeScript(driver,"document.getElementById('"+id+"').click()");
			            String[]no_of_documents=documentpageobjects.no_of_document.getText().split("-");
			            int no_documents=Integer.parseInt(no_of_documents[1]);
			            if(no_documents>1)
			            { 
			            	wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.download_selected()));
				            documentpageobjects.download_selected().click();
				            for(int i1=0;i1<=150;i1++)
							{checkPageIsReady();
							wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.download_selected()));}
				            File getLatestFile = getLatestFilefromDir(downloaded_Path);
				    	    String fileName = getLatestFile.getName();
				    	    String []filedetails=fileName.split("_");
				    	    long length = getLatestFile.length();
				    	    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
				    	    		&& isDateValid(filedetails[1]) && fileName.endsWith(".zip"))
				    	    {
				    	    	Result="Passed "+fileName+" File got downloaded successfully";
				    	    }
				    	    else
				    	    {
				    	    	Result="Failed "+"File is not there in the folder";
				    	    }
				         }
			            else if(no_documents==1)
			            {
			            	wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.download_button()));
			            	documentpageobjects.download_button().click();
				            File getLatestFile = getLatestFilefromDir(downloaded_Path);
				    	    String fileName = getLatestFile.getName();
				    	    String []filedetails=fileName.split("_");
				    	    long length = getLatestFile.length();
				    	    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0))
				    	    {
				    	    	Result="Passed "+fileName+" File got downloaded successfully";
				    	    }
				    	    else
				    	    {
				    	    	Result="Failed "+"File is not there in the folder";
				    	    }
			            }
			    	    wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.all_document_link()));
						documentpageobjects.all_document_link().click();
					}
				}
				else
				{
					Result="Failed "+"No document folders are present right now";
				}
			}
		 }
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documents_Link()));
			dasboardpageObjects.documents_Link().click();
			for(int i=0;i<=50;i++)
			{wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documents_text()));
			checkPageIsReady();}
			for(int i=0;i<documentpageobjects.AllDocumentListView.size();i++)
			{
				if(documentpageobjects.AllDocumentListView.get(i).isCurrentlyVisible())
				{
					executor.executeScript("arguments[0].click()",documentpageobjects.AllDocumentListView.get(i));
					for(int i1=0;i1<=50;i1++)
					{checkPageIsReady();}
					if(documentpageobjects.no_files_text.isCurrentlyVisible())
					{
						wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.all_document_link()));
						documentpageobjects.all_document_link().click();
					}
					else
					{
						wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.listwiseView()));
						documentpageobjects.listwiseView().click();
						for(int i1=0;i1<=50;i1++)
						{checkPageIsReady();}
						List<WebElement> allcheckbox_css=driver.findElements(By.cssSelector("input[id='cleckbox-all']"));
						System.out.println(allcheckbox_css);
						String id=allcheckbox_css.get(0).getAttribute("id");
			            System.out.println(id);
			            jsLib.executeScript(driver,"document.getElementById('"+id+"').click()");
			            String[]no_of_documents=documentpageobjects.no_of_document.getText().split("-");
			            int no_documents=Integer.parseInt(no_of_documents[1]);
			            if(no_documents>1)
			            { 
			            	wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.download_selected()));
				            documentpageobjects.download_selected().click();
				            for(int i1=0;i1<=150;i1++)
							{checkPageIsReady();
							wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.download_selected()));}
				            File getLatestFile = getLatestFilefromDir(downloaded_Path);
				    	    String fileName = getLatestFile.getName();
				    	    String []filedetails=fileName.split("_");
				    	    long length = getLatestFile.length();
				    	    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
				    	    		&& isDateValid(filedetails[1]) && fileName.endsWith(".zip"))
				    	    {
				    	    	Result="Passed "+fileName+" File got downloaded successfully";
				    	    }
				    	    else
				    	    {
				    	    	Result="Failed "+"File is not there in the folder";
				    	    }
				         }
			            else if(no_documents==1)
			            {
			            	wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.download_button()));
			            	documentpageobjects.download_button().click();
				            File getLatestFile = getLatestFilefromDir(downloaded_Path);
				    	    String fileName = getLatestFile.getName();
				    	    String []filedetails=fileName.split("_");
				    	    long length = getLatestFile.length();
				    	    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0))
				    	    {
				    	    	Result="Passed "+fileName+" File got downloaded successfully";
				    	    }
				    	    else
				    	    {
				    	    	Result="Failed "+"File is not there in the folder";
				    	    }
			            }
			    	    wait.until(ExpectedConditions.elementToBeClickable(documentpageobjects.all_document_link()));
						documentpageobjects.all_document_link().click();
					}
				}
				else
				{
					Result="Failed "+"No document folders are present right now";
				}
			}
		}
			
		return Result;
		
	}
	public static boolean isDateValid(String date) 
	{
	    try {
	        DateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
	        df.setLenient(false);
	        df.parse(date);
	        return true;
	    } catch (ParseException e) {
	        return false;
	    }
	}
	public boolean isFileDownloaded(String downloadPath, String fileName) throws InterruptedException {
		boolean flag = false;
		File dir = new File(downloadPath);
	    File[] dir_contents = dir.listFiles();
	  	    
	    for (int i = 0; i < dir_contents.length; i++) {
	        if (dir_contents[i].getName().contains(fileName))
	            return flag=true;
	            }
		 
	    return flag;
	}
	private File getLatestFilefromDir(String dirPath) throws InterruptedException{
		for(int i1=0;i1<=80;i1++)
		{checkPageIsReady();}
	    File dir = new File(dirPath);
	    File[] files = dir.listFiles();
	    if (files == null || files.length == 0) {
	        return null;
	    }

	    File lastModifiedFile = files[0];
	    for (int i = 1; i < files.length; i++) {
	       if (lastModifiedFile.lastModified() < files[i].lastModified()) {
	           lastModifiedFile = files[i];
	       }
	    }
	    return lastModifiedFile;
	}
	public void checkPageIsReady() throws InterruptedException {

		  JavascriptExecutor js = (JavascriptExecutor)driver;


		  //Initially bellow given if condition will check ready state of page.
		/*  if (js.executeScript("return document.readyState").toString().equals("complete")){ 
		
		   return; 
		  } 
	*/
		  //This loop will rotate for 25 times to check If page Is ready after every 1 second.
		  //You can replace your value with 25 If you wants to Increase or decrease wait time.
		  for (int i=0; i<100; i++){ 
		   if (js.executeScript("return document.readyState").toString().equals("complete")){ 
			   
		    break; 
		   }
		   System.out.println("Page Is loaded.");
		  }
		 }



/*------------------------Raghu----------------------------------*/


@Step
public ArrayList<String> getDocumentsFolderList(){
	driver = this.getDriver();
	ArrayList<String> folderlist=new ArrayList<String>();

	int count=documentpageobjects.documentfolders().size();
	System.out.println("Number of folders is:"+count);
	for(WebElement element:documentpageobjects.documentfolders())
	{
		System.out.println("Folder name is:"+element.getText());
		folderlist.add(element.getText());
	}

	return folderlist;
}

public String clickFolder(String folderName)
{
	driver=this.getDriver();
	int count=documentpageobjects.folderslist.size();
	System.out.println("Number of folders is:"+count);
	for(WebElement element:documentpageobjects.folderslist)
	{
		if(element.getText().equalsIgnoreCase(folderName))
		{
			System.out.println("Folder name is:"+element.getText());
			waitFor(element).click();
			Result="Passed";
		}	
	}

	return Result;

}

public String getListofDocuments() throws InterruptedException
{

	driver=this.getDriver();	
	JavascriptExecutor executor=(JavascriptExecutor)driver;
	boolean flag=true;

	if(!documentpageobjects.noFileAvailability.isCurrentlyVisible())
	{

		waitFor(documentpageobjects.listView()).click();



		while(flag==true)
		{
			for(int i=0;i<10;i++)
			{
				waitFor(ExpectedConditions.elementToBeClickable(documentpageobjects.nameTitle));
			}


			if((documentpageobjects.nextButtonStatus.getAttribute("class").contains("disabled")))
			{
				flag=false;
			}

			System.out.println(documentpageobjects.documentTitles.size());
			System.out.println(documentpageobjects.documentSummaries.size());
			System.out.println(documentpageobjects.documentReceivedDate.size());
			if(!device.equalsIgnoreCase("mobile")){
			System.out.println(documentpageobjects.documentType.size());}


			for(int i=0;i<documentpageobjects.documentTitles.size();i++)
			{
				for(int j=0;j<10;j++)
				{
					waitFor(documentpageobjects.documentTitles.get(i));
					waitFor(documentpageobjects.documentSummaries.get(i));
					waitFor(documentpageobjects.documentReceivedDate.get(i));
					
					if(!device.equalsIgnoreCase("mobile")){
					waitFor(documentpageobjects.documentType.get(i));}

				}
				System.out.println("title is : "+documentpageobjects.documentTitles.get(i).getText());
				documentTitle.add(documentpageobjects.documentTitles.get(i).getText());
				System.out.println("summary is : "+documentpageobjects.documentSummaries.get(i).getText());
				documentSummary.add(documentpageobjects.documentSummaries.get(i).getText());
				System.out.println("Received Date is : "+documentpageobjects.documentReceivedDate.get(i).getText());
				receivedDate.add(documentpageobjects.documentReceivedDate.get(i).getText());
				
				if(!device.equalsIgnoreCase("mobile")){
				System.out.println("type is : "+documentpageobjects.documentType.get(i).getText());
				documentType.add(documentpageobjects.documentType.get(i).getText());}
			}
			System.out.println(flag);
			if(flag==true)
			{

				executor.executeScript("arguments[0].click()", documentpageobjects.nextButton());

			}

		}

		System.out.println(documentTitle.size());
		System.out.println(documentSummary.size());
		System.out.println(receivedDate.size());
		
		if(!device.equalsIgnoreCase("mobile")){
		System.out.println(documentType.size());}

		for(int i=0;i<documentTitle.size();i++)
		{
			if(device.equalsIgnoreCase("mobile")){
			String combined=documentTitle.get(i)+"||"+documentSummary.get(i)+"||"+receivedDate.get(i);
			documents.add(combined);}
			else
			{
			String combined=documentTitle.get(i)+"||"+documentSummary.get(i)+"||"+receivedDate.get(i)+"||"+documentType.get(i);
			documents.add(combined);}
		}


		Result="Passed";

	}
	else
	{
		Result="Failed";
	}

	return Result;
}
public String displayFirstTenDocuments() throws InterruptedException
{

	driver=this.getDriver();	

	if(!documentpageobjects.noFileAvailability.isCurrentlyVisible())
	{

		waitFor(documentpageobjects.listView()).click();


		System.out.println(documentpageobjects.documentTitles.size());


		for(int i=0;i<10 && i<documentpageobjects.documentTitles.size();i++)
		{
			System.out.println("title is : "+documentpageobjects.documentTitles.get(i).getText());
			documentTitle.add(documentpageobjects.documentTitles.get(i).getText());
		}

		System.out.println(documentTitle.size());


		if(documentTitle.size()==10)
		{

			Result="Passed";
		}
		else
		{
			Result= "Less Files Present";
		}

	}
	else
	{
		Result="No Files Present";
	}

	return Result;
}

public String verifyDocumentOrderByDate() throws InterruptedException, ParseException
{

	driver=this.getDriver();	
	boolean flag=true;

	if(!documentpageobjects.noFileAvailability.isCurrentlyVisible())
	{

		waitFor(documentpageobjects.listView()).click();

		while(flag==true)
		{

			if((documentpageobjects.nextButtonStatus.getAttribute("class").contains("disabled")))
			{
				flag=false;
			}

			System.out.println(documentpageobjects.documentReceivedDate.size());

			for(int i=0;i<10 && i<documentpageobjects.documentReceivedDate.size();i++)
			{

				System.out.println("Received Date is : "+documentpageobjects.documentReceivedDate.get(i).getText());
				receivedDate.add(documentpageobjects.documentReceivedDate.get(i).getText());


				System.out.println(flag);
				if(flag==true)
				{
					Actions actions=new Actions(driver);
					new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(documentpageobjects.nextButton()));
					actions.moveToElement(documentpageobjects.nextButton()).click().build().perform();
				}

			}
		}

		System.out.println("Count is:"+receivedDate.size());
		SimpleDateFormat format=new SimpleDateFormat("dd/MM/yyyy");
		ArrayList<Date> duplicateReceivedDate1= new ArrayList<Date>();
		ArrayList<Date> duplicateReceivedDate2= new ArrayList<Date>();
		for(int i=0;i<receivedDate.size();i++)
		{
			duplicateReceivedDate1.add(format.parse(receivedDate.get(i)));
			duplicateReceivedDate2.add(format.parse(receivedDate.get(i)));

		}
		Collections.sort(duplicateReceivedDate1);
		Collections.sort(duplicateReceivedDate2);
		Collections.reverse(duplicateReceivedDate1);
		Collections.reverse(duplicateReceivedDate2);

		System.out.println("Received Date:"+receivedDate);
		System.out.println("Duplicate Received Date1:"+duplicateReceivedDate1);
		System.out.println("Duplicate Received Date1:"+duplicateReceivedDate2);

		if(duplicateReceivedDate1.equals(duplicateReceivedDate2))
		{
			Result="Passed";
		}
		else
		{
			Result="Not in Descending order";
		}
	}
	else
	{
		Result="No Files Present";
	}

	return Result;
}


public String orderDocuments(String orderBy) throws ParseException
{

	String order=orderBy;
	String orderStatus;

	driver=this.getDriver();	
	//boolean flag=true;
	JavascriptExecutor executor=(JavascriptExecutor)driver;

	if(!documentpageobjects.noFileAvailability.isCurrentlyVisible())
	{

		waitFor(documentpageobjects.listView()).click();

		if(order.equalsIgnoreCase("title"))
		{
			orderStatus=orderDocumentsByTitle();
			if(orderStatus.equals("ascending"))
			{
				Result="Documents are intially in ascending order";
			}
			else if(orderStatus.equals("descending"))
			{
				Result="Documents are intially in descending order";
			}
			else
			{
				Result="Documents are intially in an unknown order";
			}

			executor.executeScript("arguments[0].click()",documentpageobjects.nameTitle);
			orderStatus=orderDocumentsByTitle();
			if(orderStatus.equals("ascending"))
			{
				Result=Result+" and then they have been sorted in ascending order";
			}
			else
			{
				Result=Result+" and then they have been sorted in descending order";
			}
			
			executor.executeScript("arguments[0].click()",documentpageobjects.nameTitle);
			orderStatus=orderDocumentsByTitle();
			if(orderStatus.equals("ascending"))
			{
				Result=Result+" and then they have been sorted in ascending order";
			}
			else
			{
				Result=Result+" and then they have been sorted in descending order";
			}
			
			
		}

		else if(order.equalsIgnoreCase("type"))
		{
			if(device.equalsIgnoreCase("mobile"))
			{
				Result="Document type is not displayed";
			}
			else
			{
				orderStatus=orderDocumentsByType();
				if(orderStatus.equals("ascending"))
				{
					Result="Documents are intially in ascending order";
				}
				else if(orderStatus.equals("descending"))
				{
					Result="Documents are intially in descending order";
				}
				else
				{
					Result="Documents are intially in an unknown order";
				}
				executor.executeScript("arguments[0].click()",documentpageobjects.typeTitle);
				orderStatus=orderDocumentsByType();
				if(orderStatus.equals("ascending"))
				{
					Result=Result+" and then they have been sorted in ascending order";
				}
				else
				{
					Result=Result+" and then they have been sorted in descending order";
				}

				executor.executeScript("arguments[0].click()",documentpageobjects.typeTitle);
				orderStatus=orderDocumentsByType();
				if(orderStatus.equals("ascending"))
				{
					Result=Result+" and then they have been sorted in ascending order";
				}
				else
				{
					Result=Result+" and then they have been sorted in descending order";
				}	
			}

		}
		else if(order.equalsIgnoreCase("date"))
		{
			orderStatus=orderDocumentsByDate();
			if(orderStatus.equals("ascending"))
			{
				Result="Documents are intially in ascending order";
			}
			else if(orderStatus.equals("descending"))
			{
				Result="Documents are intially in descending order";
			}
			else
			{
				Result="Documents are intially in an unknown order";
			}

			executor.executeScript("arguments[0].click()",documentpageobjects.dateTitle);
			orderStatus=orderDocumentsByDate();
			if(orderStatus.equals("ascending"))
			{
				Result=Result+" and then they have been sorted in ascending order";
			}
			else
			{
				Result=Result+" and then they have been sorted in descending order";
			}
			
			executor.executeScript("arguments[0].click()",documentpageobjects.dateTitle);
			orderStatus=orderDocumentsByDate();
			if(orderStatus.equals("ascending"))
			{
				Result=Result+" and then they have been sorted in ascending order";
			}
			else
			{
				Result=Result+" and then they have been sorted in descending order";
			}	

		}
		else
		{
			Result="Invalid sort type";
		}

	}
	else
	{
		Result="no files";
	}

	return Result;
}

public String orderDocumentsByDate() throws ParseException
{
	String result;
	driver=this.getDriver();

	for(int i=0;i<10;i++)
	{
		waitFor(ExpectedConditions.elementToBeClickable(documentpageobjects.dateTitle));
	}
	System.out.println(documentpageobjects.documentReceivedDate.size());

	for(int i=0;i<documentpageobjects.documentReceivedDate.size();i++)
	{
		System.out.println("Document Received Date is : "+documentpageobjects.documentReceivedDate.get(i).getText());
		receivedDate.add(documentpageobjects.documentReceivedDate.get(i).getText());
	}

	ArrayList<Date> duplicateDate1= new ArrayList<Date>();
	ArrayList<Date> duplicateDate2= new ArrayList<Date>();
	SimpleDateFormat format=new SimpleDateFormat("dd/MM/yyyy");

	for(int i=0;i<receivedDate.size();i++)
	{
		duplicateDate1.add(format.parse(receivedDate.get(i)));
		duplicateDate2.add(format.parse(receivedDate.get(i)));

	}
	Collections.sort(duplicateDate1);
	Collections.sort(duplicateDate2);
	Collections.reverse(duplicateDate2);

	if(receivedDate.equals(duplicateDate1))	
	{
		result="ascending";
	}
	else if(receivedDate.equals(duplicateDate2))
	{
		result="descending";
	}
	else
	{
		result="unknown";
	}
	return result;
}

public String orderDocumentsByType()
{
	String result;
	driver=this.getDriver();
	
	for(int i=0;i<10;i++)
	{
		waitFor(ExpectedConditions.elementToBeClickable(documentpageobjects.typeTitle));
	}


		System.out.println(documentpageobjects.documentType.size());

		for(int i=0;i<documentpageobjects.documentType.size();i++)
		{

			System.out.println("Document Type is : "+documentpageobjects.documentType.get(i).getText());
			documentType.add(documentpageobjects.documentType.get(i).getText());

		}

	ArrayList<String> duplicateType1= new ArrayList<String>();
	ArrayList<String> duplicateType2= new ArrayList<String>();
	for(int i=0;i<documentType.size();i++)
	{
		duplicateType1.add(documentType.get(i));
		duplicateType2.add(documentType.get(i));

	}
	Collections.sort(duplicateType1);
	Collections.sort(duplicateType2);
	Collections.reverse(duplicateType2);

	if(documentType.equals(duplicateType1))	
	{
		result="ascending";
	}
	else if(documentType.equals(duplicateType2))
	{
		result="descending";
	}
	else
	{
		result="unknown";
	}
	return result;
}

public String orderDocumentsByTitle()
{
	String result;
	driver=this.getDriver();
	
	for(int i=0;i<10;i++)
	{
		waitFor(ExpectedConditions.elementToBeClickable(documentpageobjects.nameTitle));
	}


		System.out.println(documentpageobjects.documentTitles.size());

		for(int i=0;i<documentpageobjects.documentTitles.size();i++)
		{

			System.out.println("Document Type is : "+documentpageobjects.documentTitles.get(i).getText());
			documentTitle.add(documentpageobjects.documentTitles.get(i).getText());

		}

	ArrayList<String> duplicateTitle1= new ArrayList<String>();
	ArrayList<String> duplicateTitle2= new ArrayList<String>();
	for(int i=0;i<documentTitle.size();i++)
	{
		duplicateTitle1.add(documentTitle.get(i));
		duplicateTitle2.add(documentTitle.get(i));

	}
	Collections.sort(duplicateTitle1);
	Collections.sort(duplicateTitle2);
	Collections.reverse(duplicateTitle2);

	if(documentTitle.equals(duplicateTitle1))	
	{
		result="ascending";
	}
	else if(documentTitle.equals(duplicateTitle2))
	{
		result="descending";
	}
	else
	{
		result="unknown";
	}
	return result;
}


public ArrayList<String> getDocuments() throws InterruptedException, ParseException
{

	driver=this.getDriver();
	JavascriptExecutor executor=(JavascriptExecutor)driver;
	boolean flag=true;

	if(!documentpageobjects.noFileAvailability.isCurrentlyVisible())
	{

		waitFor(documentpageobjects.listView()).click();

		while(flag==true)
		{
			
			for(int i=0;i<10;i++)
			{
				waitFor(ExpectedConditions.elementToBeClickable(documentpageobjects.nameTitle));
			}

			if((documentpageobjects.nextButtonStatus.getAttribute("class").contains("disabled")))
			{
				flag=false;
			}

			System.out.println(documentpageobjects.documentTitles.size());

			for(int i=0;i<10 && i<documentpageobjects.documentTitles.size();i++)
			{

				System.out.println("Docement Title is : "+documentpageobjects.documentTitles.get(i).getText());
				documentTitle.add(documentpageobjects.documentTitles.get(i).getText());
			}

			System.out.println(flag);
			if(flag==true)
			{
				executor.executeScript("arguments[0].click()",documentpageobjects.nextButton);
			}

		}

		System.out.println("Count is:"+documentTitle.size());
		Result="Passed";
	}

	else
	{
		Result="No Files Present";
	}

	return documentTitle;	
}

public String verifyDocumentPaths(String documentName, String allianceCode, String defaultLanguage) throws IOException{

	driver=this.getDriver();
	String[] paths={"Marketing Information","Newsletters","Video Tutorials","Manuals","Other"};
	int filecount=0;
	String Result;

	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.addDocument_button())).click();
	System.out.println("clicked on Add");
	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.documentName())).sendKeys(documentName);
	System.out.println("Document Name is"+documentAdminpageobjects.documentName().getAttribute("value"));
	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.allianceCode())).sendKeys(allianceCode);
	System.out.println("Selected the alliance code");
	waitFor(documentAdminpageobjects.defaultLanguage());
	documentAdminpageobjects.defaultLanguage().sendKeys(defaultLanguage);
	//new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.defaultLanguage())).sendKeys(defaultLanguage);
	System.out.println("Selected the default language");
	new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.documentfilepath()));

	Select select=new Select(documentAdminpageobjects.documentfilepath());
	List<WebElement> pathoptions=select.getOptions();
	int count=pathoptions.size();
	System.out.println("Number of options is:"+count);

	for(int i=0;i<paths.length;i++)
	{
		for(WebElement element:pathoptions)
		{
			System.out.println("Folder name is:"+element.getText());
			if(element.getText().contains(paths[i]))
			{
				filecount++;
				System.out.println("filecount is:"+filecount);
			}
		}
	}

	System.out.println("Total numbe of paths available in the options is:"+filecount);
	if(filecount==5)
	{
		Result="Passed";
	}
	else
	{
		Result="Failed";
	}


	return Result;


}

public ArrayList<String> getDocumentPaths(String allianceCode, String defaultLanguage) throws IOException{

	driver=this.getDriver();
	ArrayList<String> folderlist=new ArrayList<String>();

	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.addDocument_button())).click();
	System.out.println("clicked on Add");
	new WebDriverWait(driver,10).until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.allianceCode())).sendKeys(allianceCode);
	System.out.println("Selected the alliance code");
	waitFor(documentAdminpageobjects.defaultLanguage());
	documentAdminpageobjects.defaultLanguage().sendKeys(defaultLanguage);
	//new WebDriverWait(driver,60).until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.defaultLanguage())).sendKeys(defaultLanguage);
	System.out.println("Selected the default language");
	Select select=new Select(documentAdminpageobjects.documentfilepath());
	List<WebElement> pathoptions=select.getOptions();
	int count=pathoptions.size();
	System.out.println("Number of options is:"+count);
	for(WebElement element:pathoptions)
	{
		folderlist.add(element.getText());
	}
	
	System.out.println("The folders are:"+folderlist);

	return folderlist;


}



}

