package runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(monochrome=true,
features="src/test/resources/temp/",
glue="stepdefinitions",
strict=true,
tags="@MEPOE_5570_Messaging,@MEPOE_5568_Messaging,@MEPOE_5564_Messaging,@MEPOE_5565_Messaging,@MEPOE_5386_Messaging,@MEPOE_5572_Messaging,@MEPOE-5324_Terms_And_Conditions,@MEPOE-5378_Document_Management")
public class TestRunner3 {
//,@MEPOE_5570_Messaging,@MEPOE_5568_Messaging,@MEPOE_5564_Messaging,@MEPOE_5565_Messaging,@MEPOE_5386_Messaging,@MEPOE_5572_Messaging,@MEPOE-5324_Terms_And_Conditions,@MEPOE-5378_Document_Management	
	//"src/test/resources/features/"

}
