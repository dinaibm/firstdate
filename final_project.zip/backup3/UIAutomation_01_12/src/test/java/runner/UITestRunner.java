package runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.java.Before;
import net.serenitybdd.cucumber.CucumberWithSerenity;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(monochrome=true,
features="src/test/resources/temp",
glue="stepdefinitions",
strict=true,
tags="@ui,@uiapi,@funct")
public class UITestRunner {

	
}
