## System
* Version: <!-- geckodriver version -->
* Platform: <!-- e.g. Linux/macOS/Windows + version -->
* Firefox: <!-- from the about dialogue -->
* Selenium: <!-- binding + version -->


## Testcase

<!--
Provide a minimal HTML document
that can be used to reproduce the issue.
The document should only contain the bare necessities
required to observe the problem.
-->


## Stacktrace

<!--
Error and stacktrace produced by client binding.
-->


## Trace-level log

<!--
See https://github.com/mozilla/geckodriver#firefox-capabilities
for making geckodriver produce a trace-level log.

The short version is to either pass the -vv flag
or {"moz:firefoxOptions": {"log": {"level": "trace"}}} as a capability.
-->
