package CreateFeature;

/*import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;*/
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import util.ExcelUtil;

public class TestFea {
	
	public static void CreateFeatureFile() throws Exception {
		// TODO Auto-generated method stub
		 // The name of the file to open.
		String readFileName = "C:/Users/335010/Desktop/FD Docs/Sailasuta_Backup/SerenityBDD_Latest/bddserenity-serenitybdd/bddserenity-serenitybdd-17b1bfc700a6/src/test/resources/Templates/APITest.feature";
		String writeFilename = "C:/Users/335010/Desktop/FD Docs/Sailasuta_Backup/SerenityBDD_Latest/bddserenity-serenitybdd/bddserenity-serenitybdd-17b1bfc700a6/src/test/resources/features/APIupdate.feature";
     
        /*String readFileName ="serenitybdd/src/test/resources/Templates/Test.feature";
        String writeFilename = "serenitybdd/src/test/resources/features/Testupdate.feature";*/
        String Path="C:/Users/335010/Desktop/FD Docs/Sailasuta_Backup/SerenityBDD_Latest/bddserenity-serenitybdd/bddserenity-serenitybdd-17b1bfc700a6/Testsample.xlsx";
        int i = 0;
        String combined=null;
        try
        {
	        String varStringline = null,tagName=null;
	        BufferedWriter bw = null;
	        FileWriter fw = null;
	        PrintWriter printWriter = null;
	        String Exectag = null;	    
	        File file = new File(readFileName);
	        System.out.println(System.getProperty("user.dir"));
	        FileReader fileReader = new FileReader(file);
	        boolean bval1= file.exists();
	        boolean bval = file.setReadable(true);
	        BufferedReader bufferedReader = new BufferedReader(fileReader);
	        fw = new FileWriter(writeFilename);
	        bw = new BufferedWriter(fw);
	             while ((varStringline = bufferedReader.readLine()) != null) 
	        { 
	        	ExcelUtil.setExcelFile(Path, "Sheet1");
	        	System.out.println(ExcelUtil.getPhysicalNumberOfRows());
	        	for(i=1;i<=ExcelUtil.getPhysicalNumberOfRows();i++)
	        	{
	        		ExcelUtil.setExcelFile(Path, "Sheet1");  
	        		Exectag=ExcelUtil.getCellData(i, 0);

	        		if(varStringline.equalsIgnoreCase(Exectag))
	        		{
	        			tagName=varStringline;
	        		}


	        		/*int row=WriteExcel.getPhysicalNumberOfRows();*/

	        		if(varStringline.equalsIgnoreCase("#----") && tagName.equalsIgnoreCase(Exectag)){
	        			//String tag=ExcelUtil.getCellData(i,Findpointer(0,"Tags"));
	        			String report=ExcelUtil.getCellData(i,Findpointer(0,"report"));
	        			String appurl=ExcelUtil.getCellData(i,Findpointer(0,"appurl"));
	        			String status=ExcelUtil.getCellData(i,Findpointer(0,"status"));
	        			String Message=ExcelUtil.getCellData(i, Findpointer(0,"Message"));
	        			String ErrorCode=ExcelUtil.getCellData(i, Findpointer(0,"ErrorCode"));
	        			String userName=ExcelUtil.getCellData(i,Findpointer(0,"userName"));
	        			String password=ExcelUtil.getCellData(i,Findpointer(0,"password"));
	        			String allianceCode=ExcelUtil.getCellData(i, Findpointer(0,"allianceCode"));
	        			String AuthErrMessage=ExcelUtil.getCellData(i, Findpointer(0,"AuthErrMessage"));
	        			String Authaccessdenied=ExcelUtil.getCellData(i, Findpointer(0,"Authaccessdenied"));
	        			String AuthErrCause=ExcelUtil.getCellData(i, Findpointer(0,"AuthErrCause"));
	        			String currency=ExcelUtil.getCellData(i, Findpointer(0,"currency"));
	        			String userType=ExcelUtil.getCellData(i, Findpointer(0,"userType"));
	        			String pageNumber=ExcelUtil.getCellData(i, Findpointer(0,"pageNumber"));
	        			String accountStatus=ExcelUtil.getCellData(i, Findpointer(0,"accountStatus"));
	        			String profile=ExcelUtil.getCellData(i, Findpointer(0,"profile"));
	        			String firstName=ExcelUtil.getCellData(i, Findpointer(0,"firstName"));
	        			String lastName=ExcelUtil.getCellData(i, Findpointer(0,"lastName"));
	        			combined="|"+report+"|"+appurl+"|"+status+"|"+Message+"|"+ErrorCode+"|"+userName+"|"+password+"|"+allianceCode+"|"+AuthErrMessage+"|"+Authaccessdenied+"|"+AuthErrCause+"|"+currency+"|"+userType+"|"+pageNumber+"|"+accountStatus+"|"+profile+"|"+firstName+"|"+lastName+"|";
	        			bw.write(combined);
	        			bw.newLine();
	        		} 

	        	}

	        	bw.write(varStringline);
	        	bw.newLine();

	        }    
        
	        bufferedReader.close();fileReader.close();/*if (bw != null)*/bw.close();/*if (fw != null)*/fw.close();
     }     
        
        catch(FileNotFoundException ex) {
        System.out.println("Unable to open file '" + readFileName + "'");                
        }
        catch(IOException ex) {System.out.println("Error reading file '" + readFileName + "'");                  
            // Or we could just do this: 
            // ex.printStackTrace();
    }
  }
	private static int Findpointer(int i,String findstring) throws Exception
	{
		int Excel_col=ExcelUtil.getPhysicalNumberofcolumn(i);
		int column_number=0,column_number_final=0;
		for(int col=0;col<=Excel_col;col++)
		{
			if(ExcelUtil.getCellData(i, col).equalsIgnoreCase(findstring))
			{
				column_number=col;
			}
		}
		column_number_final=column_number;
		return column_number_final;	
	}
}
    




