package stepdefinitions;

public class ServiceURI {

public static final String getStateURI = "http://services.groupkt.com/state/get/{countryCode}/all";
}
