package stepdefinitions;

import org.json.JSONObject;
import org.json.XML;
import org.openqa.selenium.remote.server.handler.GetTagName;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ResponseBody;

import api.LoadRequest;

import api.PostRequest;

import api.ValidateRequest;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;
import Reports.TestResult;

public class Apidefinitions {
	TestResult lib=new TestResult();

public static Response responsebody;

	@Steps
	LoadRequest loadrequest;
	@Steps
	PostRequest postrequest;
	@Steps
	ValidateRequest validateRequest;
	
	@Before
	public void bfre(){
		//driver=new WrappedWebDriver().newDriver();
		//lib.initializeTest(loadrequest.getTag(arg1));
	} 
	
	@After
	public void aftr()
	{
		lib.closeTestReport();
		lib.endTestReport();
		lib.SummarizeTestReport();
	}
	
	/*@Given("^a request for Country \"([^\"]*)\"$")
	public void a_GET_Method_request_for_Country(String arg1) throws Throwable {
		lib.initializeTest("a_GET_Method_request_for_Country");
		lib.WriteReportStep("1", "Get Request", "", "", "");
		loadrequest.loadgetrequestdata(arg1);
		lib.WriteReportStep("2", "Get Request", "Get Request should be successful", "Get Request for country is Success", "Passed");
	}

	@When("^request is sent to \"([^\"]*)\"$")
	public void request_is_sent_to(String arg1) throws Throwable {
		System.out.println("2ndarg1"+arg1);
		lib.WriteReportStep("1", "Post Request", "", "", "");
		postrequest.postGETRequest(arg1);
		lib.WriteReportStep("2", "Post Request", "Request should be successful", "Request posted successfully", "Passed");
	}*/

	
	
		
/*	@And("^retrieved country code in \"([^\"]*)\" is \"([^\"]*)\"$")
	public void retrieved_state_count_in_is(String arg1, String arg2) throws Throwable {
		
		System.out.println("4tharg1"+arg1+"==>"+arg2);
		lib.WriteReportStep("1", "Retrive State Count", "", "", "");   
		validateRequest.resultvalidation(arg1,arg2,responsebody);
		lib.WriteReportStep("2", "Retrive State Count", "State Count should be successful", "Retrive State Count was Successful", "Passed");
	}*/
	
//----------------------------------------------------------------	
	
	@Given("^a request for application api \"([^\"]*)\" and \"([^\"]*)\"$")
	public void a_request_for_application_api(String arg1, String arg2) throws Throwable {
		lib.initializeTest("RequestForApplicationApiInfo"+arg2+"");
		lib.WriteReportStep("1", "Get Request url", "", "", "");
		loadrequest.loadgetrequestdata(arg1);
		lib.WriteReportStep("2", "Get Request url", "Get Request for MP should be successful", "Requested MP Application successfully", "Passed");
	}
	
	@When("^get request is sent to \"([^\"]*)\"$")
	public void get_request_is_sent_to(String arg1) throws Throwable {
		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest(arg1);
		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful", "Request posted successfully", "Passed");
	}

	@Then("^status code is \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void status_code_is(String arg1,String arg2,String arg3,String arg4,String arg5,String arg6) throws Throwable {
		
		String strResponse;
		lib.WriteReportStep("1", "Verify Response", "", "", "");
		strResponse=validateRequest.statuscode(arg1, responsebody);
		String[] strRep= strResponse.split("\\|");
		/*if(strRep[0].equalsIgnoreCase("200"))
		{*/
			String strJsonResponse;
			String[] strVal; 
			String[] strNode={"status","error","appName:versionNumber:buildDate"};
			lib.WriteReportStep("2", "Verify Response Code", "Response Code should be 200", "Response Code : <b>"+strRep[0]+"</b>", "Passed");
			if(strRep[1]!=null)
			{
				ValidateRequest.writexml("request for application api_"+arg6, strRep[1]);//strRep[1]
				strJsonResponse=ValidateRequest.JsonRead("request for application api_"+arg6,strNode);
				strVal=strJsonResponse.split("\\|");
				if(strVal[0].equalsIgnoreCase(arg2))
				{
					lib.WriteReportStep("2", "Verify Response", "Expected Response status should be success", "Response : <b>Status</b> ="+"<b>"+strVal[0]+"</b>", "Passed");
					/*for(int j=0;j<strVal.length;j++)
					{
						lib.WriteReportStep("2", "Verify Response", "Extract Response", "Response : <b>"+strNode[j]+ "</b> =" +"<b>"+strVal[j]+"</b>", "Passed");
					}*/
					String[] strRepCode=strVal[2].split("\\:");
					if(strRepCode[0].trim().equalsIgnoreCase((arg3).trim()))
					{
						lib.WriteReportStep("2", "Verify Response", "Expected Response Appname should be:<b> "+arg3+"</b>", "Response : <b>AppName</b> =" +"<b>"+strRepCode[0]+"</b>", "Passed");
					}
					if(strRepCode[1].trim().equalsIgnoreCase((arg4.trim())))
					{
						lib.WriteReportStep("2", "Verify Response", "Expected Response versionNumber should be :<b> "+arg4+"</b>", "Response : <b>VersionNumber</b> =" +"<b>"+strRepCode[1]+"</b>", "Passed");
					}
					if(strRepCode[2].trim().equalsIgnoreCase((arg5.trim())))
					{
						lib.WriteReportStep("2", "Verify Response", "Expected Response buildDate should :<b> "+arg5+"</b>", "Response : <b>BuildDate</b> =" +"<b>"+strRepCode[2]+"</b>", "Passed");
					}
				}
				else
				{
					String[] strRepCode=strVal[1].split("\\:");
					lib.WriteReportStep("2", "Verify Error Response ", "Error Reponse ", "Error Response Code : "+strRepCode[0]+"And"+strRepCode[1], "Failed");
				
				
				
				}
				
			}
	/*	}
		else
		{
			lib.WriteReportStep("2", "Verify Response Code", "Response Code should be 200", "Response Code : "+strRep[0], "Failed");
			// fail code
		}*/
	}
	
	/*@And("^verification of Merchant portal status in \"([^\"]*)\"$")
	public void VerificationMerchantPortalStatus(String arg1) throws Throwable {
		
		lib.WriteReportStep("1", "Retrieve application info", "", "", "");   
		validateRequest.resultvalidation(arg1,arg2,responsebody);
		lib.WriteReportStep("2", "Retrieve application info", "Application info should be retrieved", "Retrieve State Count was Successful", "Passed");
	}*/
	
	
}
