package stepdefinitions;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import CreateFeature.TestFea;
import Reports.TestResult;
import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;
import ui.Signon.MessagePage;
import ui.Signon.Signon;
import ui.Signon.dashboardPage;
import ui.pageobjects.Signon.SignonObjects;
import util.ExcelUtil;

public class UIDefinitions {
TestResult lib=new TestResult();
@Steps
Signon signonpage;
dashboardPage dashboardpage;
MessagePage messages;
public static WebDriver driver = null;

	@Before
	public void bfre() throws Exception{

	}
	@After
	public void aftr()
	{
		lib.closeTestReport();
		lib.endTestReport();
		lib.SummarizeTestReport();
	}
	
	@Given("^the Feature file path creattion$")
	public void the_Feature_file_path_creattion() throws Throwable {
		TestFea.CreateFeatureFile();
	}
	@Given("^the EMS portal and configure \"([^\"]*)\"$")
	public void the_EMS_portal(String report) throws Throwable {
		signonpage.loadbrowser();
		lib.initializeTest("RequestForApplicationUIInfo"+" "+report);
		lib.WriteReportStep("1", "Loading the browser", "", "", "");
	}

	@And("^user Navigate to URL \"([^\"]*)\"$")
	public void user_Navigate_to_URL(String arg1) throws Throwable {
		lib.WriteReportStep("1", "Get url", "", "", "");
		signonpage.navigate(arg1);
		lib.WriteReportStep("2", "Get url", "URL for MP should be successful", "Requested MP Application successfully", "Passed");
		
		
	}
	@And("^user click on RememberMe$")
	public void user_click_on_RememberMe() throws Throwable {
		signonpage.RememberMe();
	}

	@When("^user enter \"([^\"]*)\" as \"([^\"]*)\"$")
	public void user_enter_as(String FieldName, String FieldValue) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		lib.WriteReportStep("1", "Get username", "", "", "");
		String Result = signonpage.userInput(FieldName,FieldValue);
		if(Result.equals("Passed"))
		 {
			lib.WriteReportStep("2", "Verify the userid", "Get"+" "+FieldName, FieldName+":"+FieldValue, "Passed");
		 }
		 else
		 {
			 lib.WriteReportStep("2", "Verify the userid", "Get"+" "+FieldName, FieldName+":"+FieldValue, "Failed");
		 }
		
	}

	@And("^user entertext \"([^\"]*)\" as \"([^\"]*)\"$")
	public void user_entertext_as(String FieldName, String FieldValue) throws Throwable {
		lib.WriteReportStep("1", "Get Password", "", "", "");
	    String Result= signonpage.userInput(FieldName,FieldValue);
		if(Result.equals("Passed"))
		 {
			lib.WriteReportStep("2", "Verify the Password", "Get"+" "+FieldName, FieldName+":"+FieldValue, "Passed");
		 }
		 else
		 {
			 lib.WriteReportStep("2", "Verify the Password", "Get"+" "+FieldName, FieldName+":"+FieldValue, "Failed");
		 }
	}
	
	@Then("^user click Submit login and verify \"([^\"]*)\"$$")
	public void user_click_Submit_login_and_verify(String Welcome_text) throws Throwable {
		 lib.WriteReportStep("1", "Login to the application", "", "", "");
		 String Result= signonpage.Submitlogin(Welcome_text);
		 System.out.println(Result);
		 if(Result.equals("Passed"))
		 {
			 lib.WriteReportStep("2", "Verify Submit","Login to the application", "Successfully login to application","Passed");
		 }
		 else
		 {
			 lib.WriteReportStep("2", "Verify Submit","Login to the application", "Successfully login to application","Failed");
		 }
		 
	}
	
	@Then("^user Verify Dashboard cookie information link$")
	public void user_Verify_Dashboard_cookie_information_link() throws Throwable {
		 lib.WriteReportStep("1", "Verify Cookie information", "", "", "");
		 String Result=dashboardpage.Dashboard_cookie_information_link();
		 if(Result.equals("Passed"))
		 {
			 lib.WriteReportStep("2", "Verify cookie information Link","Verify cookie information", "Cookie information link is present","Passed");
		 }
		 else
		 {
			 lib.WriteReportStep("2", "Verify cookie information Link","Verify cookie information", "Cookie information link is not there","Failed");
		 }
		 
	}
	@Then("^user Verify Unread message count$")
	public void user_Verify_Unread_message_count() throws Throwable {
		 lib.WriteReportStep("1", "Verify Unread message count", "", "", "");
		 String Result=dashboardpage.Unread_message_count();
		 if(Result.contains("Passed"))
		 {
			 lib.WriteReportStep("2", "Verify Unread message count","Verify Unread message count", "Unread message count is : "+ Result,"Passed");
		 }
		 else
		 {
			 lib.WriteReportStep("2", "Verify Unread message count","Verify Unread message count", "No unread message are there : "+ Result,"Failed");
		 }
	}

	@Then("^user Verify Unread document count$")
	public void user_Verify_Unread_document_count() throws Throwable {
		lib.WriteReportStep("1", "Verify unread document count", "", "", "");
		String Result=dashboardpage.Unread_Document_count();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Unread Document count","Verify Unread Document count", "Unread Document count is : "+ Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Unread Document count","Verify Unread Document count", "No unread Document are there : "+ Result,"Failed");
		}
	}

	@Then("^user Verify all the dashboard Panel element and check \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_Verify_all_the_dashboard_Panel_element_and_check(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7) throws Throwable {
		lib.WriteReportStep("1", "Verify all the dashboard element", "", "", "");
		String Result=dashboardpage.Verify_dashboard_panel_Navigation(arg1,arg2,arg3,arg4,arg5,arg6,arg7);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Dashboard navigation","Verify Dashboard Navigation to all the widget", "Successfully navigated to each widget","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Dashboard navigation","Verify Dashboard Navigation to all the widget", "Failed to navigate to each widget","Failed");
		}
	}
	@Then("^user should navigate from Pre_authorisation Widget to detailed pre_authorisations view and check \"([^\"]*)\"$")
	public void user_should_navigate_from_Pre_authorisation_Widget_to_detailed_pre_authorisations_view_and_check(String Fieldname) throws Throwable {
		lib.WriteReportStep("1", "Verify Navigation from preAuth_widget", "", "", "");
		String Result=dashboardpage.Navigate_Preauth_Widget_to_detailed_preauth_view(Fieldname);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Navigation from preAuth_widget","Verify Navigation from preAuth_widget", "Successfully navigated to Preauth_View","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Navigation from preAuth_widget","Verify Navigation from preAuth_widget", "Failed to navigate to PreAuth_view","Failed");
		}
	}
	@Then("^user should navigate from Funding Widget to funding_summary view and check \"([^\"]*)\"$")
	public void user_should_navigate_from_Funding_Widget_to_funding_summary_view_and_check(String Fieldname) throws Throwable {
		lib.WriteReportStep("1", "Verify Navigation from funding_widget", "", "", "");
		String Result=dashboardpage.Navigate_Funding_Widget_to_detailed_funding_view(Fieldname);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Navigation from Funding Widget","Verify Navigation from Funding Widget", "Successfully navigated to Funding_View","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Navigation from preAuth_widget","Verify Navigation from preAuth_widget", "Failed to navigate to PreAuth_view","Failed");
		}
	}
	@Then("^user should navigate from Sales Widget to Transaction summary view and check the detailed Transaction view$")
	public void user_should_navigate_from_Sales_Widget_to_Transaction_summary_view_and_check_the_detailed_Transaction_view() throws Throwable {
		lib.WriteReportStep("1", "Verify Navigation from sales_widget", "", "", "");
		String Result=dashboardpage.Navigate_sales_to_transaction();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Navigation from sales Widget","Verify Navigation from sales Widget", "Successfully navigated to Transaction_View","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Navigation from sales_widget","Verify Navigation from sales_widget", "Failed to navigate to Transaction_view","Failed");
		}
	}
	
	@Then("^user should change the currency code to \"([^\"]*)\" and validate the dashboard$")
	public void user_should_change_the_currency_code_to_and_validate_the_dashboard(String arg1) throws Throwable {
		lib.WriteReportStep("1", "Verify currency_code change", "", "", "");
		String Result=dashboardpage.Change_currency_code(arg1);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify currency_code change","Verify currency_code change", "Successfully Changed to currency_code "+ Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify currency_code change","Verify currency_code change", "Failed to change the currency code","Failed");
		}
	}
	@Then("^user should change the Language code to \"([^\"]*)\" and validate the dashboard$")
	public void user_should_change_the_Language_code_to_and_validate_the_dashboard(String arg1) throws Throwable {
		lib.WriteReportStep("1", "Verify Language_code change", "", "", "");
		System.out.println(arg1);
		String Result=dashboardpage.Change_Language_code(arg1);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Language_code change","Verify Language_code change", "Successfully Changed to Language_code "+ Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Language_code change","Verify Language_code change", "Failed to Change the language","Failed");
		}
	}
	@Then("^User should be able to verify print option is working in messages as \"([^\"]*)\"$")
	public void user_should_be_able_to_verify_print_option_is_working_in_messages_as(String arg1) throws Throwable {
		lib.WriteReportStep("1", "Verify Print_option in Message change", "", "", "");
		String Result=messages.Print_option_Message(arg1);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Print_option in Message change","Verify Print_option in Message change", "Successfully Printed the message  ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Print_option in Message change","Verify Print_option in Message change", "Failed to Print the message ","Failed");
		}
	}
	@When("^user enterAlliance \"([^\"]*)\" as \"([^\"]*)\"$")
	public void user_enterAlliance_as(String Alliance, String Alliance_code) throws Throwable {
		lib.WriteReportStep("1", "Verify Alliance_code", "", "", "");
		String Result=signonpage.userInput(Alliance, Alliance_code);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Alliance_code","Verify Alliance_code", "Successfully Entered alliancecode ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Alliance_code","Verify Alliance_code", "Failed to Enter Alliance_code","Failed");
		}
		  
	}

	@When("^user click login button and enter to the admin console$")
	public void user_click_login_button_and_enter_to_the_admin_console() throws Throwable {
		lib.WriteReportStep("1", "Verify Login to Adminconsole", "", "", "");
		String Result=signonpage.login_admin_console();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Login to Adminconsole","Verify Login to Adminconsole", "Successfully Entered to adminconsole ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Login to Adminconsole","Verify Login to Adminconsole", "Failed to Enter into adminconsole","Failed");
		}
	}

	@Then("^user should be able to create the new message and give the input as \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_create_the_new_message_and_give_the_input_as(String Alliance_Name, String Language, String Type, String Title, String Sub_title, String Date_received, String Validity_type,String In_days_Validity_days, String message_body) throws Throwable {
		lib.WriteReportStep("1", "Verify create message", "", "", "");
		String Result=messages.Create_message(Alliance_Name,Language,Type,Title,Sub_title,Date_received,Validity_type,In_days_Validity_days,message_body);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify create message","Verify create message", "Successfully created message ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify create message","Verify create message", "Failed to create message","Failed");
		}
	}
	
	@Then("^User should be able to Navigate from message notification to the message detail$")
	public void User_should_be_able_to_Navigate_from_message_notification_to_the_message_detail() throws Throwable{
		lib.WriteReportStep("1", "Verify User should be navigate from messqage notification to message detail", "", "", "");
		String Result=dashboardpage.Navigate_to_message_view_from_notification();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be navigate from messqage notification to message detail","Verify User should be navigate from messqage notification to message detail", "Successfully navigate to message detail ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be navigate from messqage notification to message detail","Verify User should be navigate from messqage notification to message detail", "No unread message are there come back later","Failed");
		}
	}
	@When("^user click Submit login$")
	public void user_click_Submit_login() throws Throwable{
		lib.WriteReportStep("1", "Verify submit button for alert testcase", "", "", "");
		String Result=signonpage.Submitlogin_for_alert_testcase();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify submit button for alert testcase","Verify submit button for alert testcase", "Successfully navigate to Home Page ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify submit button for alert testcase","Verify submit button for alert testcase", "Failed to navigate to home page","Failed");
		}
	}
	@Then("^User should be able to view unread alerts it will appear directly after logging in$")
	public void User_should_be_able_to_view_unread_alerts_it_will_appear_directly_after_logging_in() throws Throwable{
		lib.WriteReportStep("1", "Verify User should be able to view unread allert", "", "", "");
		String Result=dashboardpage.Confirm_unread_alert_after_login();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be able to view unread allert","Verify User should be able to view unread allert", "Successfully confirming unread alert ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to view unread allert","Verify User should be able to view unread allert", "No unread alerts are there come back later","Failed");
		}
	}


	


}
