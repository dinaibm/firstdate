package Reports;

/*    */ import java.io.File;
/*    */ import java.io.FileFilter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MyFilter
/*    */   implements FileFilter
/*    */ {
/*    */   public boolean accept(File pathname)
/*    */   {
/* 14 */     if ((pathname.getName().toLowerCase().endsWith(".html")) || (pathname.getName().toLowerCase().endsWith(".htm")))
/*    */     {
/* 16 */       return true;
/*    */     }
/* 18 */     return false;
/*    */   }
/*    */ }
