package ui.pageobjects.Signon;

import java.util.List;

import org.openqa.selenium.WebElement;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class MessagePage_object  extends PageObject{
@FindBy(css="#merchant-portal > div.container.ng-isolate-scope.dashboard-page > div > navigation > div > ul > li.ng-scope.messages > a > span > span")
public WebElementFacade messages_Link;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(1) > div > h3")
public WebElementFacade messages_text;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.ng-isolate-scope > div > div.tab-pane.ng-scope.active > div > div.right-side.ng-scope > div > div.header-section > div > button.default-button.x-small.blue.print.ng-scope")
public WebElementFacade print_option;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.ng-isolate-scope > div > div.tab-pane.ng-scope.active > div > div.right-side.ng-scope > div > div.header-section > h4")
public WebElementFacade Message_Title;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.ng-isolate-scope > div > div.tab-pane.ng-scope.active > div > div.right-side.ng-scope > div > div.header-section > h5")
public WebElementFacade message_subTitle;

public WebElement messages_Link(){
    return messages_Link;
  }
public WebElement messages_text(){
    return messages_text;
  }
public WebElement print_option(){
    return print_option;
  }
public WebElement Message_Title(){
    return Message_Title;
  }
public WebElement message_subTitle() {
	return message_subTitle;
}

}
