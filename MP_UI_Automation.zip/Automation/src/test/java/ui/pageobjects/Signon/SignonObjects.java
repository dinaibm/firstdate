package ui.pageobjects.Signon;
import org.openqa.selenium.WebElement;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class SignonObjects extends PageObject{

//EMS
@FindBy(css="#username")
public WebElementFacade UserName;

@FindBy(css="#password")
public WebElementFacade Password;

@FindBy(css="label.ng-scope")
public WebElementFacade RememberMe;

@FindBy(css="#submit")
public WebElementFacade Submit;

//Admin
@FindBy(css="#allianceLogin")
public WebElement alliance;

@FindBy(css="#login")
public WebElement login_admin;

@FindBy(css="#panel-user-label")
public WebElement Welcome_text_admin;

public  WebElement UserName(){
    return UserName;
}
public WebElement Password(){
    return Password;
}
public WebElement Submit(){
    return Submit;
}
public WebElement RememberMe() {
	// TODO Auto-generated method stub
	return RememberMe;
}
public WebElement alliance(){
    return alliance;
}
public WebElement login_admin(){
    return login_admin;
}
public WebElement Welcome_text_admin(){
    return Welcome_text_admin;
}
}

