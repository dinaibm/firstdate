package ui.Signon;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.gl.E;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementState;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.AdminPage_Object;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.MessagePage_object;
import ui.pageobjects.Signon.SignonObjects;
public class dashboardPage extends PageObject{

	WebDriver driver =null;

	String Result=null;
	boolean Status=false;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;
	MessagePage_object messagepageObjects;	
	
@Step
public String Dashboard_cookie_information_link() throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 10);
	if(dasboardpageObjects.Portal_cookie_message.getText().equals("By using our website, you agree to EMS� use of cookies."))
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.portal_cookie_details()));
		dasboardpageObjects.portal_cookie_details().click();
		Thread.sleep(5000);
		ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.cookie_page()));
		if(dasboardpageObjects.cookie_page().getText().equals("Privacy & Cookie Policy"))
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}
		driver.close();
		driver.switchTo().window(tabs2.get(0));
	}
	else
	{
		Result="Failed";
	}
	
	return Result;	
}
@Step
public String Unread_message_count() throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 10);
	if(dasboardpageObjects.message_indicator_count.isCurrentlyVisible())
		
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.message_indicator_count()));
		if(dasboardpageObjects.message_indicator_count().getText()!=null)
		{
			Result="Passed"+":"+dasboardpageObjects.message_indicator_count().getText();
		}
		
	}
	
	else
	{
		Result="Passed"+":"+"No unread message are there for now";
	}
	return Result;
}
@Step
public String Unread_Document_count() throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 10);
	if(dasboardpageObjects.document_indicator_count.isCurrentlyVisible())	
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.document_indicator_count()));
		if(dasboardpageObjects.document_indicator_count().getText()!=null)
		{
			Result="Passed"+":"+dasboardpageObjects.document_indicator_count().getText();
		}
	}
	else
	{
		Result="Failed"+":"+dasboardpageObjects.document_indicator_count().getText()+":"+"No unread message are there for now";
	}
	return Result;
}
@Step
public String Verify_dashboard_panel_Navigation(String Pre_authorizations_Text, String Authorizations_Text, String Transactions_Text, String Funding_Text, String Messages_Text, String Documents_Text, String Help_Text) {
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 30);
	dasboardpageObjects.preauthorization_Link().click();
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.preauthorization_text()));
	if(dasboardpageObjects.preauthorization_text().getText().equals(Pre_authorizations_Text))
	{
		Status = true;
	}
	else
	{
		Status=false;
	}
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Authorizations_Link()));
	//new Actions(driver).moveToElement(dasboardpageObjects.Authorizations_Link).perform();  
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	executor.executeScript("arguments[0].click()", dasboardpageObjects.Authorizations_Link());
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Authorizations_text()));
	if(dasboardpageObjects.Authorizations_text().getText().equals(Authorizations_Text))
	{
	
		Status = true;
	}
	else
	{
		Status=false;
	}
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.transaction_Link()));
	executor.executeScript("arguments[0].click()", dasboardpageObjects.transaction_Link());
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.transaction_text()));
	if(dasboardpageObjects.transaction_text().getText().equals(Transactions_Text))
	{
		Status = true;
	}
	else
	{
		Status=false;
	}
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.funding_Link()));
	executor.executeScript("arguments[0].click()", dasboardpageObjects.funding_Link());
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.funding_text()));
	if(dasboardpageObjects.funding_text().getText().equals(Funding_Text))
	{
		Status = true;
	}
	else
	{
		Status=false;
	}
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messages_Link()));
	executor.executeScript("arguments[0].click()", dasboardpageObjects.messages_Link());
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.messages_text()));
	if(dasboardpageObjects.messages_text().getText().equals(Messages_Text))
	{
		Status = true;
	}
	else
	{
		Status=false;
	}
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documents_Link()));
	executor.executeScript("arguments[0].click()", dasboardpageObjects.documents_Link());
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.documents_text()));
	if(dasboardpageObjects.documents_text().getText().equals(Documents_Text))
	{
		Status = true;
	}
	else
	{
		Status=false;
	}
	/*wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_option()));
	executor.executeScript("arguments[0].click()", dasboardpageObjects.more_option());
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.help_option()));
	executor.executeScript("arguments[0].click()", dasboardpageObjects.help_option());
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.help_text()));
	if(dasboardpageObjects.help_text().getText().equals(Help_Text))
	{
		Status = true;
	}
	else{
		Status=false;
		
	}*/
	if (Status==true)
	{
		Result="Passed";
	}
	else
	{
		Result="Failed";
	}
	return Result;
}
@Step
public String Navigate_Preauth_Widget_to_detailed_preauth_view(String Preauth_text) throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 10);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.pre_authorization_widget()));
	if(dasboardpageObjects.pre_authorization_widget().getText().equals(Preauth_text))
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Navigate_Pre_auth_view()));
		dasboardpageObjects.Navigate_Pre_auth_view().click();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.preauthorization_text()));
		if(dasboardpageObjects.preauthorization_text().getText().equals(Preauth_text))
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}
	}
	return Result;
	
}
@Step
public String Navigate_Funding_Widget_to_detailed_funding_view(String funding_text) throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 10);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.view_details_funding()));
	dasboardpageObjects.view_details_funding().click();
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.funding_text()));
	if(dasboardpageObjects.funding_text().getText().equals(funding_text))
	{
		Result="Passed";
	}
	else
	{
		Result="Failed";
	}
	
	return Result;
	
}
@Step
public String Navigate_sales_to_transaction() throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver,50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Sales_dashboard_link()));
	executor.executeScript("arguments[0].click()", dasboardpageObjects.Sales_dashboard_link());
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Couldnot_find_result_text()));
	//driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	if(dasboardpageObjects.Couldnot_find_result_text.isDisplayed())
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.date_dropdown()));
		dasboardpageObjects.date_dropdown().click();
		dasboardpageObjects.Last_7_days_link().click();
		dasboardpageObjects.Apply_button().click();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.posting_date()));
		Result="Passed";	
	}
	else {
		Result="Failed";
	}
	return Result;	
}
@Step
public String Change_currency_code(String Currency_code) throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 20);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.currency_drop_down));
	dasboardpageObjects.currency_drop_down.click();
	if(Currency_code.equals("EUR"))
	{
		dasboardpageObjects.EUR_currency().click();
		if((dasboardpageObjects.currency_Text_Validation()).getText().contains("�"))
		{
			Result="Passed : "+ dasboardpageObjects.currency_Text_Validation().getText();
		}
	}
	else if(Currency_code.equals("USD"))
	{
		dasboardpageObjects.USD_currency().click();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.currency_Text_Validation()));
		if((dasboardpageObjects.currency_Text_Validation()).getText().contains("$"))
		{
			Result="Passed : "+ dasboardpageObjects.currency_Text_Validation().getText();
		}
	}
	else
	{
		Result="Failed";
	}
	
	return Result;
}
@Step
public String Change_Language_code(String Language_change) throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 20);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_option()));
	dasboardpageObjects.more_option().click();
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.settings()));
	dasboardpageObjects.settings().click();
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Language_dropDown()));
	dasboardpageObjects.Language_dropDown().click();
	if(Language_change.equals("Dutch"))
	{
		dasboardpageObjects.Dutch_Language().click();	
	}
	else if(Language_change.equals("English"))
	{
		dasboardpageObjects.English_Language().click();
	}
	else if(Language_change.equals("French"))
	{
		dasboardpageObjects.French_Language().click();
	}
	else if(Language_change.equals("German"))
	{
		dasboardpageObjects.German_Language().click();
	}
	dasboardpageObjects.Save_language_button().click();
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Continue_dashboard_button()));
	dasboardpageObjects.Continue_dashboard_button().click();
	if(dasboardpageObjects.payment_dashboard_text.isDisplayed())
	{
		Result="Passed "+": "+Language_change+"_"+dasboardpageObjects.payment_dashboard_text().getText();
	}
	else
	{
		Result="Failed";
	}
	return Result;
}
@Step
public String Navigate_to_message_view_from_notification()  throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 20);
	if(dasboardpageObjects.Message_Title_Notification.isCurrentlyVisible())	
	{
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Message_Title_Notification()));
	String message_title=dasboardpageObjects.Message_Title_Notification().getText();
	String Message_subTitle=dasboardpageObjects.Message_subtitle_notification().getText();
	dasboardpageObjects.Read_more_message_notofication().click();
	wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.Message_Title()));
	if(messagepageObjects.Message_Title().getText().equals(message_title) && messagepageObjects.message_subTitle().getText().equals(Message_subTitle))
	{
		Result="Passed" +" "+message_title;
	}
	else{
		Result= "Failed";
		
	}
	}
	else
	{
		Result="Failed";
	}
	return Result;

}
@Step
public String Confirm_unread_alert_after_login()  throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 20);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.unread_alerts()));
	if(dasboardpageObjects.unread_alerts.isCurrentlyVisible())
	{
		
		String alert_title=dasboardpageObjects.unread_alerts_title().getText();
		dasboardpageObjects.unread_alerts().click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Result="Passed "+alert_title;
		
	}
	else
	{
		Result="Failed";
	}
	
	return Result;
	
}
}
