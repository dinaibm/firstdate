package ui.Signon;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.AdminPage_Object;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.MessagePage_object;
import ui.pageobjects.Signon.SignonObjects;

public class MessagePage extends PageObject{
	WebDriver driver =null;
	String Result=null;
	boolean Status=false;
	MessagePage_object messagepageObjects;
	AdminPage_Object adminpageObjects;
		
@Step	
public String Print_option_Message(String Message_text){
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 20);
	messagepageObjects.messages_Link().click();
	wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.messages_text()));
	if(messagepageObjects.messages_text().getText().equals(Message_text))
	{
		wait.until(ExpectedConditions.elementToBeClickable(messagepageObjects.print_option()));
		messagepageObjects.print_option().click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Result="Passed";
	}
	else
	{
		Result="Failed";
	}
	return Result;
	}
@Step	
public String Create_message(String Alliance_Name, String language, String type, String title, String sub_title, String date_received, String Validity_type, String In_days_Validity_days, String message_body) throws InterruptedException{
		driver = this.getDriver();	
		WebDriverWait wait = new WebDriverWait(driver,60);
		wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.GUI_Message()));
		adminpageObjects.GUI_Message().click();
		wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.Add_message()));
		adminpageObjects.Add_message().click();
		wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.allianceCode_dropdown()));
		adminpageObjects.allianceCode_dropdown().sendKeys(Alliance_Name);
		System.out.println(Alliance_Name+"Donef0");
		wait.until(ExpectedConditions.elementToBeClickable(adminpageObjects.Language_msg_dropdown()));
		new Select(adminpageObjects.Language_msg_dropdown()).selectByVisibleText(language);
		adminpageObjects.type_dropdown().sendKeys(type);
		adminpageObjects.message_title().sendKeys(title);
		adminpageObjects.message_subTitle().sendKeys(sub_title);
		adminpageObjects.date_picker().sendKeys(date_received);
		adminpageObjects.Flag_notification().click();
		if(Validity_type.equals("In days"))
		{
			adminpageObjects.Indays_validity().click();
			adminpageObjects.Indays_validity_days().sendKeys(In_days_Validity_days);
		}
		else if(Validity_type.equals("Unlimited"))
		{
			adminpageObjects.unlimited_validity().click();
		}
		adminpageObjects.messagebody().sendKeys(message_body);
		adminpageObjects.save_button().click();
		System.out.println(adminpageObjects.Created_successfully_text().getText());
		if(adminpageObjects.Created_successfully_text().getText().contains("Message "+title+" has been added successfully."))
		{
			Result="Passed";
		}
		else
		{
			Result="Failed";
		}
	return Result;
	
}
}
