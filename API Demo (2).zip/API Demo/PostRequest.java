package api;


import org.apache.commons.collections.map.LinkedMap;
import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.eclipse.jetty.websocket.api.Session;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.remote.server.DriverSessions;
import org.openqa.selenium.remote.server.handler.GetAllSessions;
import org.openqa.selenium.remote.server.handler.GetCurrentUrl;
import org.junit.Test;
import org.junit.Assert;

import com.jayway.restassured.matcher.ResponseAwareMatcher;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ResponseBody;
import com.jayway.restassured.response.ValidatableResponse;
import com.jayway.restassured.specification.RequestSpecification;
import com.thoughtworks.selenium.webdriven.commands.GetCookieByName;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.swing.plaf.synth.SynthSpinnerUI;

import cucumber.api.java.en.Given;
import net.thucydides.core.annotations.Step;
import stepdefinitions.Apidefinitions;
import stepdefinitions.ServiceURI;
import net.serenitybdd.*;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.rest.SerenityRest;


public class PostRequest extends SerenityRest{


@SuppressWarnings("unchecked")
@Step
public void postGETRequest_applicationinfo(String appurl){
			
	Apidefinitions.responsebody = 
			given()
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getsalessummary(String appurl, String currency){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("currency",currency)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getSalesSummary_Impersonation(String appurl,String currency,String pseudoUserName){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("pseudoUserName",pseudoUserName)
			.param("currency",currency)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getAuthorisationSummary_Impersonation(String appurl,String currency,String pseudoUserName){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("pseudoUserName",pseudoUserName)
			.param("currency",currency)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getPreAuthSummaryImpersonation(String appurl,String currency, String fromDate, String toDate,String pseudoUserName){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("pseudoUserName",pseudoUserName)
			.param("fromDate",fromDate)
			.param("toDate",toDate)
			.param("currency",currency)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getPreAuthSummary(String appurl,String currency,String fromDate,String toDate){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("fromDate",fromDate)
			.param("toDate",toDate)
			.param("currency",currency)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getPaymentTypesByUserImpersonation(String appurl,String pseudoUserName){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("pseudoUserName",pseudoUserName)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getAuthorisationSummary(String appurl, String currency){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("currency",currency)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getAuthorisationSummaryExtended(String appurl, String currency){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("currency",currency)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_authorisationHistoryList(String appurl, String authId){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("authId",authId)
			.when()
			.get(appurl).andReturn().peek();
}


@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getPaymentTypesByUser(String appurl, String currency){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("currency",currency)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_validateUserName(String appurl, String userName){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("userName",userName)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_validatepseudousername(String appurl, String pseudoUserName){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("pseudoUserName",pseudoUserName)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getProfileList(String appurl, String userType){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("userType",userType)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getUserDetails(String appurl){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getSubAccountDetails(String appurl, String userName){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("userName",userName)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getAuthorisationList(String appurl,String fromDate,String toDate,String fromAmount,String toAmount){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("fromDate",fromDate)
			.param("toDate",toDate)
			.param("fromAmount",fromAmount)
			.param("toAmount",toAmount)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getPreAuthorisationList(String appurl,String fromDate,String toDate,String fromAmount,String toAmount){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("fromDate",fromDate)
			.param("toDate",toDate)
			.param("fromAmount",fromAmount)
			.param("toAmount",toAmount)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_ordersummary(String appurl,String fromDate,String toDate){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("fromDate",fromDate)
			.param("toDate",toDate)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getorder(String appurl,String fromDate,String toDate){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("fromDate",fromDate)
			.param("toDate",toDate)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getDeviceList_Impersonation(String appurl,String pseudoUserName){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("pseudoUserName",pseudoUserName)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getDeviceList(String appurl){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getDeviceListByLastUploadDate(String appurl){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getDeviceListByLastUploadDateImpersonation(String appurl,String pseudoUserName){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("pseudoUserName",pseudoUserName)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_exportDeviceList(String appurl,String fileType,String delimiter,String pageNumber){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("fileType",fileType)
			.param("delimiter",delimiter)
			.param("pageNumber",pageNumber)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getBatchList(String appurl){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getBatchListImpersonation(String appurl,String pseudoUserName){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("pseudoUserName",pseudoUserName)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getBatchDetails(String appurl,String currency,String terminalBatchNumId){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("currency",currency)
			.param("terminalBatchNumId",terminalBatchNumId)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_cashadvances(String appurl,String startDate, String endDate){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("startDate",startDate)
			.param("endDate",endDate)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_cashadvancesImpersonation(String appurl,String startDate, String endDate,String pseudoUserName){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("startDate",startDate)
			.param("endDate",endDate)
			.param("pseudoUserName",pseudoUserName)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getBatchDetailsImpersonation(String appurl,String currency,String terminalBatchNumId,String pseudoUserName){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("currency",currency)
			.param("terminalBatchNumId",terminalBatchNumId)
			.param("pseudoUserName",pseudoUserName)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getGsmTopUpList(String appurl,String gsmTopUpFromDate,String gsmTopUpToDate){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("gsmTopUpFromDate",gsmTopUpFromDate)
			.param("gsmTopUpToDate",gsmTopUpToDate)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getOfflineReportList(String appurl){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getAuthorisationListImpersonation(String appurl,String fromDate, String toDate, String fromAmount,
		String toAmount,String pseudoUserName){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("fromDate",fromDate)
			.param("toDate",toDate)
			.param("fromAmount",fromAmount)
			.param("toAmount",toAmount)
			.param("pseudoUserName",pseudoUserName)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getAccessData(String appurl, String profiles_Accessdata){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("profiles_Accessdata",profiles_Accessdata)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getPaymentTypesSummary(String appurl,String currencyCode,String paymentType1,String days){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("paymentType1",paymentType1)
			.param("currencyCode",currencyCode)			
			.param("days",days)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getPaymentTypeSummary_Impersonation(String appurl,String pseudoUserName,String currencyCode,String paymentType1,Integer days){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("pseudoUserName",pseudoUserName)
			.param("paymentType1",paymentType1)
			.param("currency",currencyCode)			
			.param("days",days)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getFilterAndColumnPreferences(String appurl){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getNewDocumentCount(String appurl){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getFolderList(String appurl){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getDocumentListByFolder(String appurl, String documentfolder, String pageNumber){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("documentFolder",documentfolder)
			.param("pageNumber",pageNumber)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getDocument(String appurl, String documentId){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("documentId",documentId)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getTerminalDetails(String appurl, String merchId){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("merchId",merchId)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getMerchantHierarchyList(String appurl){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getNewMessageCount(String appurl){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getMessageListbyUser(String appurl,String pageNo,String messageType){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("pageNo",pageNo)
			.param("messageType",messageType)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getPosList(String appurl,String merchantType, String posSubType,String posCode){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("merchantType",merchantType)
			.param("posSubType",posSubType)
			.param("posCode",posCode)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getInvoiceSummary(String appurl,String currency, String period){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("currencyCode",currency)
			.param("period",period)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getInvoiceList(String appurl, String fromDate, String toDate,String pageNumber){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("fromDate",fromDate)
			.param("toDate",toDate)
			.param("pageNumber",pageNumber)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getInvoiceListImpersonation(String appurl,String fromDate, String toDate, String pageNumber,String pseudoUserName){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("fromDate",fromDate)
			.param("toDate",toDate)
			.param("pageNumber",pageNumber)
			.param("pseudoUserName",pseudoUserName)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getInvoiceSummaryImpersonation(String appurl,String currency, String period, String pseudoUserName){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("currencyCode",currency)
			.param("period",period)
			.param("pseudoUserName",pseudoUserName)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getInvoiceDetails(String appurl, String invoiceId){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("invoiceId",invoiceId)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getDictionaryData(String appurl, String allianceCode, String Dictionary_category, String Dictionary_code, String Dictionary_languagecode){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("userName",allianceCode)
			.param("Dictionary_category",Dictionary_category)
			.param("Dictionary_code",Dictionary_code)
			.param("Dictionary_languagecode",Dictionary_languagecode)
			.when()
			.get(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public void postGETRequest_getUserList(String appurl, String pageNumber, String accountStatus, String profile, String firstName, String lastName, String userName){
		
	Apidefinitions.responsebody = 
			given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.param("pageNumber",pageNumber)
			.param("accountStatus",accountStatus)
			.param("profile",profile)
			.param("firstName",firstName)
			.param("lastName",lastName)
			.param("userName",userName)
			.when()
			.get(appurl).andReturn().peek();
}

public String getURI(String uri){
	String getreqUri = null;
	/*if(uri.equals("getStateURI"))
	{
	getreqUri=ServiceURI.getStateURI.toString().replace("{countryCode}", LoadRequest.countryCode);
	
	}*/
	return getreqUri;
		
}

public static void post(String appurl){
	 Apidefinitions.responsebody = given()
			 .headers(LoadRequest.jsonAsMap1)
			 .proxy("fdcproxy.1dc.com", 8080)
			 .when()
			 .get(appurl).andReturn();	
	
	}


/*public Map authenticateuser(String appurl, String userName, String password, String allianceCode){
	//countryCode=countryCd;
	LinkedHashMap<String,String> Authenticateuser = new LinkedHashMap<>();
	Authenticateuser.put("userName",userName);
	Authenticateuser.put("password",password);
	Authenticateuser.put("allianceCode",allianceCode);
	return Authenticateuser;
	System.out.println();
	}
*/
/*public Map postND(String uri, Map Authenticateuser){
	 Apidefinitions.responsebody = given()
			 .param("userName",userName)
			 .param("password",Authenticateuser)
			 .param("AllianceCode",Authenticateuser)
	 		 .post(uri);
	 		 String strtoken = Apidefinitions.responsebody.cookie(getDefaultSessionId());
	  
			
	 		System.out.println("sessiontoken"+strtoken);
	 		System.out.println(getDefaultSessionId().toString());
	 	
	return Authenticateuser;
	

}*/

@Step
public Response postrequest_authenticateUser(String appurl, String userName, String password, String allianceCode){
	 return Apidefinitions.responsebody = given()
			 .headers(LoadRequest.jsonAsMap1)
			 .proxy("fdcproxy.1dc.com", 8080)
			 .param("userName",userName)
			 .param("password",password)
			 .param("AllianceCode",allianceCode)
			 .when()
			 .post(appurl).andReturn().peek();
		

}


@SuppressWarnings("unchecked")
@Step
public Response postrequest_logout(String appurl){
	return Apidefinitions.responsebody = given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.when()
		    .post(appurl).andReturn().peek();
}

@SuppressWarnings("unchecked")
@Step
public Response postrequest_invalidateSession(String appurl,String allianceCode){
	return Apidefinitions.responsebody = given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
			.headers(LoadRequest.jsonAsMap)
			.param("allianceCode",allianceCode)
			.proxy("fdcproxy.1dc.com", 8080)
			.when()
		    .post(appurl).andReturn().peek();
	 		 		
}

/*@SuppressWarnings("unchecked")
@Step
public Response postrequest_blockUser(String appurl,String userName,String reasonForBlock){
	Map<String, String> blockuser = new HashMap<>();
		blockuser.put("userName", userName);
		blockuser.put("reasonForBlock", reasonForBlock);
	
	
	return Apidefinitions.responsebody = given()
			.cookies((Map<String, ?>)Serenity.sessionVariableCalled("cookies"))
			.headers(LoadRequest.jsonAsMap)
			.proxy("fdcproxy.1dc.com", 8080)
			.body(blockuser)			
			.when()
			.post(appurl).andReturn().peek();
	 		 		
}
	*/

@SuppressWarnings("unchecked")
@Step
public Response postrequest_blockUser(String appurl, String blockusername,String reasonForBlock){
      Map<String, String> blockUser = new HashMap<>();
      
      blockUser.put("reasonForBlock", reasonForBlock);
      blockUser.put("userName", blockusername);
      
      
      return Apidefinitions.responsebody = given()
                  /*.cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))*/
                  .headers(LoadRequest.jsonAsMap)
                  .proxy("fdcproxy.1dc.com", 8080)
                  .body(blockUser)
                  .when()
                  .post(appurl).andReturn().peek();
                 
}

@SuppressWarnings("unchecked")
@Step
public Response postrequest_saveFilterAndColumnPreferences(String appurl, String saveCriteria){
	
	Map<String, String> saveFilterAndColumnPreferences = new HashMap<>();
    
	saveFilterAndColumnPreferences.put("saveCriteria", saveCriteria);
	      
      return Apidefinitions.responsebody = given()
    		  	  .proxy("fdcproxy.1dc.com", 8080)
                  .cookies((Map<String, ?>)Serenity.sessionVariableCalled("loginsessioncookies"))
                  .headers(LoadRequest.jsonAsMap)
                  .body(saveFilterAndColumnPreferences)
                  .when()
                  .post(appurl).andReturn().peek();
                 
}



/*public HttpSession postND(String uri, Map Authenticateuser){
	 Apidefinitions.responsebody = given()
			 .param("userName","DemoAccount1")
			 .param("password","Password@1")
			 .param("AllianceCode","EMS")
			 .when()
			 .post(uri);//LoadRequest.jsonAsMap
	 		
	Apidefinitions.strSess= (HttpSession) given()
			 .param("userName","DemoAccount1")
			 .param("password","Password@1")
			 .param("AllianceCode","EMS")
			 .when()
			 .post(uri);
	
	return (HttpSession) Apidefinitions.strSess;
	
}*/



/*private ResponseAwareMatcher<Response> equalTo(String status) {
	// TODO Auto-generated method stub
	return null;
}

@Step
public void postPOSTRequest(String uri, Map Authenticateuser){
	
	 //Map postreq = (Map) postND(uri,Authenticateuser);
	postND(uri,Authenticateuser);
	

	
	 
}

public JSONObject postJson(String strJsonpath) throws FileNotFoundException, IOException, ParseException
{
    JSONParser parser = new JSONParser();
    Object obj = parser.parse(new FileReader(strJsonpath));
    JSONObject jsonObject = (JSONObject) obj;
	return jsonObject;
		 
}*/




}
