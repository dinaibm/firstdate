package stepdefinitions;

import java.io.File;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;
import javax.servlet.http.HttpSession;

import org.eclipse.jetty.websocket.api.Session;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.XML;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.server.handler.GetSessionCapabilities;
import org.openqa.selenium.remote.server.handler.GetTagName;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ResponseBody;
import com.jayway.restassured.response.ResponseBodyExtractionOptions;

import api.LoadRequest;

import api.PostRequest;

import api.ValidateRequest;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.SerenitySystemProperties;
import net.serenitybdd.screenplay.GivenWhenThen;
import net.thucydides.core.ThucydidesSystemProperty;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.util.EnvironmentVariables;
import net.thucydides.core.util.SystemEnvironmentVariables;
import Reports.TestResult;

import org.junit.Test;
import net.serenitybdd.core.SerenitySystemProperties;
public class Apidefinitions {
	TestResult lib=new TestResult();

public static Response responsebody;
public static HttpSession strSess;
public String strresponse;
public String strfilename;
public String strPath;
public String date1;
public static String JSESSIONID="";
public static String token="";
public static String loginsessiontoken="";
public static String cookies="";
public static String loginsessioncookies;
public static String proxy="fdcproxy.1dc.com";
public static int port = 8080 ;
public static String appurl="";

	@Steps
	LoadRequest loadrequest;
	@Steps
	PostRequest postrequest;
	@Steps
	ValidateRequest validateRequest;
	
	@Before
	public void bfre(){
		//driver=new WrappedWebDriver().newDriver();
		//lib.initializeTest(loadrequest.getTag(arg1));
		
	} 
	
	@After
	public void aftr()
	{
		lib.closeTestReport();
		lib.endTestReport();
		lib.SummarizeTestReport();
	}

/*
//------------------------------------------------------------------------------------------------
	API Description: User Authentication - Authenticates a user with his/her credentials
	API name: authenticateUser
//------------------------------------------------------------------------------------------------*/
	
	//Loads the request headers for the api
	@Given("^load request for user authentication \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_user_authentication(String domainurl, String report) throws Throwable {
		
		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1= dateFormat.format(date);
		System.out.println(""+date1);
		
		strfilename="Authenticate User_"+report+""+date1;
		System.out.println("*****"+strfilename);
		
		lib.initializeTest("Authenticate User_"+report+"");
		lib.WriteReportStep("1", "Get Request url", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata(appurl);
		lib.WriteReportStep("2", "Get Request url and load request", "Load Request for user authentication should be successful", "Request loaded for User Authentication successfully", "Passed");
	}
	
	//Posts the api request with the respective parameters provided and retrieves/writes the response
	@When("^post request for user authentication \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_request_for_user_authentication(String userName, String password, String allianceCode, String ErrorCode, int itrcount) throws Throwable {
		
		
		lib.WriteReportStep("1", "post request for user authentication", "", "", "");
		
		if(ErrorCode.equalsIgnoreCase("MPERR03")||ErrorCode.equalsIgnoreCase("MPERR13")||ErrorCode.equalsIgnoreCase("MPERR04")){
		
			for(int i=0;i<=itrcount;i++){
			
				postrequest.postrequest_authenticateUser(appurl, userName, password, allianceCode);
			}
		}
		else{
			
			postrequest.postrequest_authenticateUser(appurl, userName, password, allianceCode);
		}
			
		strresponse=Apidefinitions.responsebody.asString();
		System.out.println("Post response****"+strresponse);
		writejsonresponse(strfilename, strresponse);
		
		
		JSESSIONID = Apidefinitions.responsebody.cookie("JSESSIONID").substring(0, 40);
		
		Map<String, String> Ckies = Apidefinitions.responsebody.cookies();
		System.out.println("ckies"+Ckies);
		/*String JSESSIONID1 = Apidefinitions.responsebody.cookie("JSESSIONID");*/
		System.out.println("Session valueJSESSIONID"+JSESSIONID);
		/*System.out.println("Session valueJSESSIONID1"+JSESSIONID1);*/
		token = Apidefinitions.responsebody.headers().getValue("X-CSRF-TOKEN");
		System.out.println("Token value"+token);
		Serenity.setSessionVariable("CURRSESSIONID").to(JSESSIONID);
		Serenity.setSessionVariable("session").to(token);
		Serenity.setSessionVariable("cookies").to(Apidefinitions.responsebody.cookies());
		
		lib.WriteReportStep("2", "Post Request", "Request should be posted successful", "Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully", "Response retrieved successfully and placed in the path-" +"<b>"+strPath+"</b>", "Passed");
		
	}
	
	//Validate the status of api response and writes the report accordingly
	@Then("^verify user authentication response \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_user_authentication_response(String status, String ErrorCode, String Message, String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {
		
		
		System.out.println("verifyresponsestarted");
		String strStatus = Apidefinitions.responsebody.body().jsonPath().getJsonObject("status");
		System.out.println("strStatus is"+strStatus);
		
		validateRequest.verifyresponse(status,ErrorCode,Message,AuthErrMessage,Authaccessdenied,AuthErrCause);
		verifyresponsereport(status,ErrorCode,Message,AuthErrMessage,Authaccessdenied,AuthErrCause);
		
}

/*		
//------------------------------------------------------------------------------------------------
	API Description: getSalesSummary - Provides the Sales summary of the application
	API name: getSalesSummary
//------------------------------------------------------------------------------------------------*/

	//Loads the request headers for the api
		@Given("^load request for getSalesSummary \"([^\"]*)\" and \"([^\"]*)\"$")
		public void load_request_for_getSalesSummary(String domainurl, String report) throws Throwable {
			
			DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
			Date date = new Date();
			String date1= dateFormat.format(date);
			
			strfilename="getSalesSummary_"+report+""+date1;
			System.out.println("*****"+strfilename);
			
			lib.initializeTest("Sales Summary validation"+report+"");
			lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
			Appurlbuild(domainurl);
			loadrequest.loadgetrequestdata_authenticated(appurl,token);		
			lib.WriteReportStep("2", "Get Request url and load request", "Load Request for Sales Summary should be successful", "Request loaded for Sales Summary successfully", "Passed");
		}
		
		//Posts the api request with the respective parameters provided and retrieves/writes the response
		@When("^post get request for getSalesSummary \"([^\"]*)\"$")
		public void post_get_request_getSalesSummary(String currency) throws Throwable {
			
			lib.WriteReportStep("1", "Post Get Request", "", "", "");
			postrequest.postGETRequest_getsalessummary(appurl,currency);
			strresponse=Apidefinitions.responsebody.asString();
			writejsonresponse(strfilename, strresponse);
			
			lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful", "Request posted successfully", "Passed");
			lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully", "Response retrieved successfully and placed in the path-" +"<b>"+strPath+"</b>", "Passed");
		}
		
		//Validate the status of api response and writes the report accordingly
		@Then("^verify getSalesSummary response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
		public void verify_getSalesSummary_response_status(String status, String ErrorCode, String Message, String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {
			
			lib.WriteReportStep("1", "verify Sales Summary response status", "", "", "");
			validateRequest.verifyresponse(status,ErrorCode,Message,AuthErrMessage,Authaccessdenied,AuthErrCause);
			verifyresponsereport(status,ErrorCode,Message,AuthErrMessage,Authaccessdenied,AuthErrCause);
		}

/*		
//---------------------------------------------------------------------------------------------------------
	API Description: getSalesSummary_Impersonation - Provides the Sales summary of the impersonated user
	API name: getSalesSummary_Impersonation
//---------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getSalesSummary_Impersonation \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getSalesSummary_Impersonation(String logindomain,String domainurl, String report,String userName,String password,String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getSalesSummary_Impersonation_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Sales Summary validation for Impersonated user" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Sales Summary of impersonated user should be successful", "Request loaded for Sales Summary of impersonated user successfully",
				"Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getSalesSummary_Impersonation \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_getSalesSummary_Impersonation(String currency,String pseudoUserName) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getSalesSummary_Impersonation(appurl,currency,pseudoUserName);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getSalesSummary_Impersonation response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getSalesSummary_Impersonation_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Sales Summary for impersonated user response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//----------------------------------------------------------------------------------------------------------
	API Description: getAuthorisationSummary - Provides the Authorisation summary for the logged in profile
	API name: getAuthorisationSummary
//----------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getAuthorisationSummary \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getAuthorisationSummary(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getAuthorisationSummary_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Authorisation Summary validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Authorisation Summary should be successful", "Request loaded for Authorisation Summary successfully",
				"Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getAuthorisationSummary \"([^\"]*)\"$")
	public void post_get_request_getAuthorisationSummary(String currency) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getAuthorisationSummary(appurl, currency);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getAuthorisationSummary response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getAuthorisationSummary_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Authorisation Summary response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}
	
/*		
//----------------------------------------------------------------------------------------------------------
	API Description: getAuthorisationSummaryExtended - Provides the Authorisation summary for the logged in profile
	API name: getAuthorisationSummaryExtended
//----------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getAuthorisationSummaryExtended \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getAuthorisationSummaryExtended(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getAuthorisationSummaryExtended_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Extended Authorisation Summary validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Extended Authorisation Summary should be successful",
				"Request loaded for Extended Authorisation Summary successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getAuthorisationSummaryExtended \"([^\"]*)\"$")
	public void post_get_request_getAuthorisationSummaryExtended(String currency) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getAuthorisationSummaryExtended(appurl, currency);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getAuthorisationSummaryExtended response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getAuthorisationSummaryExtended_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Extended Authorisation Summary response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//----------------------------------------------------------------------------------------------------------
	API Description: getAuthorisationSummaryExtended - Provides the Authorisation summary for the logged in profile
	API name: getAuthorisationSummaryExtended
//----------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for authorisationHistoryList \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_authorisationHistoryList(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "authorisationHistoryList_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Authorisation history list validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Authorisation history list should be successful",
				"Request loaded for Authorisation history list successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for authorisationHistoryList \"([^\"]*)\"$")
	public void post_get_request_authorisationHistoryList(String authId) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_authorisationHistoryList(appurl, authId);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify authorisationHistoryList response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_authorisationHistoryList_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Authorisation history list response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

	
/*		
//----------------------------------------------------------------------------------------------------------
	API Description: getPreAuthorisationList - Provides the PreAuthorisation list for the logged in profile
	API name: getPreAuthorisationList
//----------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getPreAuthorisationList \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getPreAuthorisationList(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getPreAuthorisationList_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("PreAuthorisation list validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for PreAuthorisation list should be successful",
				"Request loaded for PreAuthorisation list successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getPreAuthorisationList \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_getPreAuthorisationList(String fromDate, String toDate, String fromAmount,
			String toAmount) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getPreAuthorisationList(appurl, fromDate, toDate, fromAmount, toAmount);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getPreAuthorisationList response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getPreAuthorisationList_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify PreAuthorisation list response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//----------------------------------------------------------------------------------------------------------
	API Description: getAuthorisationList - Provides the Authorisation list for the logged in profile
	API name: getAuthorisationList
//----------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getAuthorisationList \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getAuthorisationList(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getAuthorisationList_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Authorisation list validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Authorisation list should be successful",
				"Request loaded for Authorisation list successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getAuthorisationList \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_getAuthorisationList(String fromDate,String toDate,String fromAmount,String toAmount) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getAuthorisationList(appurl,fromDate,toDate,fromAmount,toAmount);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getAuthorisationList response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getAuthorisationList_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Authorisation list response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//-----------------------------------------------------------------------------------------------------------------
	API Description: getAuthorisationListImpersonation - Provides the Authorisation list for the impersonated user
	API name: getAuthorisationListImpersonation
//----------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getAuthorisationListImpersonation \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getAuthorisationListImpersonation(String logindomain, String domainurl, String report,
			String userName, String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getAuthorisationListImpersonation_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Authorisation list validation for impersonated user" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Impersonated Authorisation list should be successful",
				"Request loaded for Impersonated Authorisation list successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getAuthorisationListImpersonation \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_getAuthorisationListImpersonation(String fromDate, String toDate, String fromAmount,
			String toAmount,String pseudoUserName) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getAuthorisationListImpersonation(appurl, fromDate, toDate, fromAmount, toAmount, pseudoUserName);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getAuthorisationListImpersonation response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getAuthorisationListImpersonation_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Impersonated Authorisation list response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//-----------------------------------------------------------------------------------------------------------------
	API Description: ordersummary - Provides the order summary for the logged in user
	API name: ordersummary
//----------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for ordersummary \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_ordersummary(String logindomain, String domainurl, String report,
			String userName, String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "ordersummary_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("ordersummary" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for ordersummary should be successful",
				"Request loaded for ordersummary successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for ordersummary \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_ordersummary(String fromDate, String toDate) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_ordersummary(appurl, fromDate, toDate);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify ordersummary response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_ordersummary_response_status(String status, String ErrorCode,
			String Message, String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify ordersummary response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}
	
/*		
//-----------------------------------------------------------------------------------------------------------------
	API Description: getorder - Provides the orders for the logged in user
	API name: getorder
//----------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getorder \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getorder(String logindomain, String domainurl, String report, String userName,
			String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getorder_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("getorder" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for getorder should be successful", "Request loaded for getorder successfully",
				"Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getorder \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_getorder(String fromDate, String toDate) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getorder(appurl, fromDate, toDate);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getorder response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getorder_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify getorder response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//-----------------------------------------------------------------------------------------------------------------
	API Description: getPosList - Provides the order summary for the logged in user
	API name: getPosList
//----------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getPosList \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getPosList(String logindomain, String domainurl, String report, String userName,
			String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getPosList_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("getPosList" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for getPosList should be successful", "Request loaded for getPosList successfully",
				"Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getPosList \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_getPosList(String merchantType, String posSubType,String posCode) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getPosList(appurl, merchantType, posSubType, posCode);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getPosList response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getPosList_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify getPosList response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//---------------------------------------------------------------------------------------------------------------------
	API Description: getAuthorisationSummaryImpersonation - Provides the Authorisation summary of the impersonated user
	API name: getAuthorisationSummaryImpersonation
//---------------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getAuthorisationSummaryImpersonation \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getAuthorisationSummaryImpersonation(String logindomain, String domainurl, String report,
			String userName, String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getAuthorisationSummary_Impersonation_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Authorisation Summary validation for Impersonated user" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Authorisation Summary of impersonated user should be successful",
				"Request loaded for Authorisation Summary of impersonated user successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getAuthorisationSummaryImpersonation \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_for_getAuthorisationSummaryImpersonation(String currency, String pseudoUserName)throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getAuthorisationSummary_Impersonation(appurl, currency, pseudoUserName);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getAuthorisationSummaryImpersonation response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getAuthorisationSummaryImpersonation_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Authorisation Summary for impersonated user response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//---------------------------------------------------------------------------------------------------------------------
	API Description: getDeviceList_Impersonation - Provides the Device list for the impersonated user
	API name: getDeviceList_Impersonation
//---------------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getDeviceList_Impersonation \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getDeviceList_Impersonation(String logindomain, String domainurl, String report, String userName,
			String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getDeviceList_Impersonation_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Device list for the impersonated user validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Device list for the impersonated user should be successful", "Request loaded for Device list for the impersonated user successfully",
				"Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getDeviceList_Impersonation \"([^\"]*)\"$")
	public void post_get_request_for_getDeviceList_Impersonation(String pseudoUserName) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getDeviceList_Impersonation(appurl,pseudoUserName);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getDeviceList_Impersonation response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getDeviceList_Impersonation_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Device list for the impersonated user response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//---------------------------------------------------------------------------------------------------------------------
	API Description: getGsmTopUpList - Provides the GSM topup list for the logged in user
	API name: getGsmTopUpList
//---------------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getGsmTopUpList \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getGsmTopUpList(String logindomain, String domainurl, String report,
			String userName, String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getGsmTopUpList_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("GSM Topup list validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for GSM Topup list should be successful",
				"Request loaded for GSM Topup list successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getGsmTopUpList \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_for_getGsmTopUpList(String gsmTopUpFromDate,String gsmTopUpToDate) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getGsmTopUpList(appurl, gsmTopUpFromDate,gsmTopUpToDate);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getGsmTopUpList response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getGsmTopUpList_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Device list for the impersonated user response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//---------------------------------------------------------------------------------------------------------------------
	API Description: getOfflineReportList - Provides the offline report list for the logged in user
	API name: getOfflineReportList
//---------------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getOfflineReportList \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getOfflineReportList(String logindomain, String domainurl, String report, String userName,
			String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getOfflineReportList_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Offline Report list validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Offline report list should be successful",
				"Request loaded for Offline report list  successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getOfflineReportList$")
	public void post_get_request_for_getOfflineReportList() throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getOfflineReportList(appurl);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getOfflineReportList response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getOfflineReportList_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Offline report list response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//---------------------------------------------------------------------------------------------------------------------
	API Description: getDeviceList - Provides the Device list of the logged in user
	API name: getDeviceList
//---------------------------------------------------------------------------------------------------------------------*/

		// Loads the request headers for the api
		@Given("^load request for getDeviceList \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
		public void load_request_for_getDeviceList(String logindomain, String domainurl, String report, String userName,
				String password, String allianceCode) throws Throwable {

			DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
			Date date = new Date();
			String date1 = dateFormat.format(date);

			strfilename = "getDeviceList_" + report + "" + date1;
			System.out.println("*****" + strfilename);

			lib.initializeTest("Device list validation" + report + "");
			lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
			login(logindomain, userName, password, allianceCode);
			Appurlbuild(domainurl);
			loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
			lib.WriteReportStep("2", "Get Request url and load request",
					"Load Request for Device list should be successful",
					"Request loaded for Device list successfully", "Passed");
		}

		// Posts the api request with the respective parameters provided and
		// retrieves/writes the response
		@When("^post get request for getDeviceList$")
		public void post_get_request_for_getDeviceList() throws Throwable {

			lib.WriteReportStep("1", "Post Get Request", "", "", "");
			postrequest.postGETRequest_getDeviceList(appurl);
			strresponse = Apidefinitions.responsebody.asString();
			writejsonresponse(strfilename, strresponse);

			lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
					"Request posted successfully", "Passed");
			lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
					"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
		}

		// Validate the status of api response and writes the report accordingly
		@Then("^verify getDeviceList response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
		public void verify_getDeviceList_response_status(String status, String ErrorCode, String Message,
				String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

			lib.WriteReportStep("1", "verify Device list Summary response status", "", "", "");
			validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
			verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		}

/*		
//---------------------------------------------------------------------------------------------------------------------
	API Description: getDeviceListByLastUploadDate - Provides the Device list by last update date of the logged in user
	API name: getDeviceListByLastUploadDate
//---------------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getDeviceListByLastUploadDate \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getDeviceListByLastUploadDate(String logindomain, String domainurl, String report, String userName,
			String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getDeviceListByLastUploadDate_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Device list by last update date validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Device list by last update date should be successful", "Request loaded for Device list by last update date successfully",
				"Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getDeviceListByLastUploadDate$")
	public void post_get_request_for_getDeviceListByLastUploadDate() throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getDeviceListByLastUploadDate(appurl);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getDeviceListByLastUploadDate response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getDeviceListByLastUploadDate_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Device list by last update date response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}
	
/*		
//--------------------------------------------------------------------------------------------------------------------------------------
	API Description: getDeviceListByLastUploadDateImpersonation - Provides the Device list by last upload date for the impersonated user
	API name: getDeviceListByLastUploadDateImpersonation
//--------------------------------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getDeviceListByLastUploadDateImpersonation \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getDeviceListByLastUploadDateImpersonation(String logindomain, String domainurl, String report,
			String userName, String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getDeviceListByLastUploadDateImpersonation_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Device list for the impersonated user validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Device list by last upload date for the impersonated user should be successful",
				"Request loaded for Device list by last upload date for the impersonated user successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getDeviceListByLastUploadDateImpersonation \"([^\"]*)\"$")
	public void post_get_request_for_getDeviceListByLastUploadDateImpersonation(String pseudoUserName) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getDeviceListByLastUploadDateImpersonation(appurl, pseudoUserName);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getDeviceListByLastUploadDateImpersonation response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getDeviceListByLastUploadDateImpersonation_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Device list by last upload date for the impersonated user response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}
	
/*		
//---------------------------------------------------------------------------------------------------------------------
	API Description: exportDeviceList - Provides the Device list in the specified file format for the logged in user
	API name: exportDeviceList
//---------------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for exportDeviceList \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_exportDeviceList(String logindomain, String domainurl, String report,
			String userName, String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "exportDeviceList_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Export Device list validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_exportDeviceList(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Export Device list should be successful",
				"Request loaded for Export Device list successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for exportDeviceList \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_for_exportDeviceList(String fileType,String delimiter,String pageNumber) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_exportDeviceList(appurl,fileType,delimiter,pageNumber);
		strresponse = Apidefinitions.responsebody.asString();
		/*writejsonresponse(strfilename, strresponse);*/
		writejsonresponse_exportdevicelist(strfilename, strresponse, fileType);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify exportDeviceList response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_exportDeviceList_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Export Device list response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//---------------------------------------------------------------------------------------------------------------------
	API Description: getBatchList - Provides the batch list for the logged in user
	API name: getBatchList
//---------------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getBatchList \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getBatchList(String logindomain, String domainurl, String report, String userName,
			String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getBatchList_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Batch list validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Batch list should be successful",
				"Request loaded for Batch list successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getBatchList$")
	public void post_get_request_for_getBatchList()
			throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getBatchList(appurl);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getBatchList response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getBatchList_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Batch list response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//---------------------------------------------------------------------------------------------------------------------
	API Description: getBatchListImpersonation - Provides the batch list for the impersonated user
	API name: getBatchListImpersonation
//---------------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getBatchListImpersonation \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getBatchListImpersonation(String logindomain, String domainurl, String report, String userName,
			String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getBatchListImpersonation_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Batch list validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request", "Load Request for Batch list for impersonated user should be successful",
				"Request loaded for Batch list for impersonated user successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getBatchListImpersonation \"([^\"]*)\"$")
	public void post_get_request_for_getBatchListImpersonation(String pseudoUserName) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getBatchListImpersonation(appurl,pseudoUserName);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getBatchListImpersonation response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getBatchListImpersonation_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Batch list for impersonated user response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//---------------------------------------------------------------------------------------------------------------------
	API Description: getBatchList - Provides the batch list for the logged in user
	API name: getBatchList
//---------------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getBatchDetails \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getBatchDetails(String logindomain, String domainurl, String report, String userName,
			String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getBatchDetails_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Batch details validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request", "Load Request for Batch details should be successful",
				"Request loaded for Batch details successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getBatchDetails \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_for_getBatchDetails(String currency,String terminalBatchNumId) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getBatchDetails(appurl,currency,terminalBatchNumId);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getBatchDetails response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getBatchDetails_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Batch details response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//---------------------------------------------------------------------------------------------------------------------
	API Description: cashadvances - Provides the cashadvances for the logged in user
	API name: cashadvances
//---------------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for cashadvances \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_cashadvances(String logindomain, String domainurl, String report, String userName,
			String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "cashadvances_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Cash Advances validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Cash Advances should be successful", "Request loaded for Cash Advances successfully",
				"Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for cashadvances \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_for_cashadvances(String startDate, String endDate) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_cashadvances(appurl, startDate, endDate);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify cashadvances response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_cashadvances_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Cash Advances response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//---------------------------------------------------------------------------------------------------------------------
	API Description: cashadvancesImpersonation - Provides the cashadvances for the impersonated user
	API name: cashadvancesImpersonation
//---------------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for cashadvancesImpersonation \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_cashadvancesImpersonation(String logindomain, String domainurl, String report, String userName,
			String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "cashadvancesImpersonation_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Cash Advances validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Cash Advances for the impersonated user should be successful", "Request loaded for Cash Advances for the impersonated user successfully",
				"Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for cashadvancesImpersonation \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_for_cashadvancesImpersonation(String startDate, String endDate,String pseudoUserName) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_cashadvancesImpersonation(appurl, startDate, endDate,pseudoUserName);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify cashadvancesImpersonation response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_cashadvancesImpersonation_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Cash Advances for the impersonated user response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//---------------------------------------------------------------------------------------------------------------------
	API Description: getBatchList - Provides the batch list for the logged in user
	API name: getBatchList
//---------------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getBatchDetailsImpersonation \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getBatchDetailsImpersonation(String logindomain, String domainurl, String report, String userName,
			String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getBatchDetailsImpersonation_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Batch details validation for the impersonated user" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Batch details for the impersonated user should be successful", "Request loaded for Batch details for the impersonated user successfully",
				"Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getBatchDetailsImpersonation \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_for_getBatchDetailsImpersonation(String currency, String terminalBatchNumId,String pseudoUserName) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getBatchDetailsImpersonation(appurl, currency, terminalBatchNumId,pseudoUserName);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getBatchDetailsImpersonation response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getBatchDetailsImpersonation_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Batch details for the impersonated user response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//---------------------------------------------------------------------------------------------------------------------
	API Description: getInvoiceSummary - Provides the Invoice summary of the logged in user
	API name: getInvoiceSummary
//---------------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getInvoiceSummary \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getInvoiceSummary(String logindomain, String domainurl,
			String report, String userName, String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getInvoiceSummary_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Invoice Summary validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Invoice Summary should be successful",
				"Request loaded for Invoice Summary successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getInvoiceSummary \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_for_getInvoiceSummary(String currency, String period)
			throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getInvoiceSummary(appurl, currency, period);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getInvoiceSummary response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getInvoiceSummary_response_status(String status, String ErrorCode,
			String Message, String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Invoice Summary response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//---------------------------------------------------------------------------------------------------------------------
	API Description: getInvoiceSummaryImpersonation - Provides the Invoice summary for the impersonated user
	API name: getInvoiceSummaryImpersonation
//---------------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getInvoiceSummaryImpersonation \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getInvoiceSummaryImpersonation(String logindomain, String domainurl, String report, String userName,
			String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getInvoiceSummaryImpersonation_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Invoice Summary validation for the impersonated user" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Invoice Summary for the impersonated user should be successful",
				"Request loaded for Invoice Summary for the impersonated user successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getInvoiceSummaryImpersonation \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_for_getInvoiceSummaryImpersonation(String currency, String period, String pseudoUserName) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getInvoiceSummaryImpersonation(appurl, currency, period, pseudoUserName);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getInvoiceSummaryImpersonation response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getInvoiceSummaryImpersonation_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Invoice Summary for the impersonated user response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//---------------------------------------------------------------------------------------------------------------------
	API Description: getInvoiceList - Provides the Invoice list of the logged in user
	API name: getInvoiceList
//---------------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getInvoiceList \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getInvoiceList(String logindomain, String domainurl, String report, String userName,
			String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getInvoiceList_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Invoice list validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Invoice list should be successful", "Request loaded for Invoice list successfully",
				"Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getInvoiceList \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_for_getInvoiceList(String fromDate, String toDate, String pageNumber)
			throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getInvoiceList(appurl, fromDate, toDate, pageNumber);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getInvoiceList response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getInvoiceList_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Invoice list response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//---------------------------------------------------------------------------------------------------------------------
	API Description: getInvoiceListImpersonation - Provides the Invoice list of the impersonated user
	API name: getInvoiceListImpersonation
//---------------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getInvoiceListImpersonation \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getInvoiceListImpersonation(String logindomain, String domainurl, String report, String userName,
			String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getInvoiceListImpersonation_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Invoice list validation for the impersonated user" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Invoice list validation for the impersonated user should be successful", "Request loaded for Invoice list validation for the impersonated user successfully",
				"Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getInvoiceListImpersonation \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_for_getInvoiceListImpersonation(String fromDate, String toDate, String pageNumber,String pseudoUserName)
			throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getInvoiceListImpersonation(appurl, fromDate, toDate, pageNumber, pseudoUserName);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getInvoiceListImpersonation response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getInvoiceListImpersonation_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Invoice list validation for the impersonated user response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//---------------------------------------------------------------------------------------------------------------------
	API Description: getInvoiceDetails - Provides the Invoice details of the logged in user
	API name: getInvoiceDetails
//---------------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getInvoiceDetails \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getInvoiceDetails(String logindomain, String domainurl, String report, String userName,
			String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getInvoiceDetails_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Invoice details validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Invoice details should be successful", "Request loaded for Invoice details successfully",
				"Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getInvoiceDetails \"([^\"]*)\"$")
	public void post_get_request_for_getInvoiceDetails(String invoiceId)
			throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getInvoiceDetails(appurl, invoiceId);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getInvoiceDetails response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getInvoiceDetails_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Invoice list response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//----------------------------------------------------------------------------------------------------------
	API Description: getPreAuthSummary - Provides the Pre Authorisation summary for the logged in profile
	API name: getPreAuthSummary
//----------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getPreAuthSummary \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getPreAuthSummary(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getPreAuthSummary_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Pre Authorisation Summary validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Pre Authorisation Summary should be successful",
				"Request loaded for Pre Authorisation Summary successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getPreAuthSummary \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_getPreAuthSummary(String currency,String fromDate,String toDate) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getPreAuthSummary(appurl,currency,fromDate,toDate);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getPreAuthSummary response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getPreAuthSummary_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify getPreAuthSummary Summary response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//---------------------------------------------------------------------------------------------------------------------
	API Description: getPreAuthSummaryImpersonation - Provides the Pre Authorisation summary for the impersonated user
	API name: getPreAuthSummaryImpersonation
//---------------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getPreAuthSummaryImpersonation \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getPreAuthSummaryImpersonation(String logindomain, String domainurl, String report,
			String userName, String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getPreAuthSummary_Impersonation_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Pre Authorisation Summary validation for impersonated user" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Pre Authorisation Summary for impersonated user should be successful",
				"Request loaded for Pre Authorisation Summary for impersonated user successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getPreAuthSummaryImpersonation \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_getPreAuthSummaryImpersonation(String currency, String fromDate, String toDate,String pseudoUserName) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getPreAuthSummaryImpersonation(appurl, currency, fromDate, toDate,pseudoUserName);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getPreAuthSummaryImpersonation response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getPreAuthSummaryImpersonation_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify getPreAuthSummaryImpersonation response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//----------------------------------------------------------------------------------------------------------
	API Description: getPaymentTypesByUser - Provides the PaymentTypesByUser summary for the logged in profile
	API name: getPaymentTypesByUser
//----------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getPaymentTypesByUser \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getPaymentTypesByUser(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getPaymentTypesByUser_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Payment Types By User Summary validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Payment Types By User Summary should be successful",
				"Request loaded for Payment Types By User Summary successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getPaymentTypesByUser \"([^\"]*)\"$")
	public void post_get_request_getPaymentTypesByUser(String currency) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getPaymentTypesByUser(appurl, currency);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getPaymentTypesByUser response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getPaymentTypesByUser_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Payment Types By User Summary response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}
	
	/*		
//--------------------------------------------------------------------------------------------------------------------------------------------------
	API Description: getPaymentTypesByUserImpersonation - Provides the PaymentTypesByUser summary for the logged in profile of the impersonated user
	API name: getPaymentTypesByUserImpersonation
//--------------------------------------------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getPaymentTypesByUserImpersonation \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getPaymentTypesByUserImpersonation(String logindomain, String domainurl,String report, String userName, String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getPaymentTypesByUser_Impersonation_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Authorisation Summary validation for Impersonated user" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Authorisation Summary of impersonated user should be successful",
				"Request loaded for Authorisation Summary of impersonated user successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getPaymentTypesByUserImpersonation \"([^\"]*)\"$")
	public void post_get_request_for_getPaymentTypesByUserImpersonation(String pseudoUserName)
			throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getPaymentTypesByUserImpersonation(appurl,pseudoUserName);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getPaymentTypesByUserImpersonation response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getPaymentTypesByUserImpersonation_response_status(String status, String ErrorCode,
			String Message, String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Sales Summary for impersonated user response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//------------------------------------------------------------------------------------------------
	API Description: getProfileList - Provides the list of profiles based on the user types
	API name: getProfileList
//------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getProfileList \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getProfileList(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getProfileList_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Profile List validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Profile List should be successful", "Request loaded for Profile List successfully",
				"Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getProfileList \"([^\"]*)\"$")
	public void post_get_request_getProfileList(String userType) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getProfileList(appurl, userType);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getProfileList response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getProfileList_response_status(String status, String ErrorCode, String Message,String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Profile List response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}
	
/*	
//------------------------------------------------------------------------------------------------
	API Description: getUserDetails - Provides the User Details of the current logged in profile
	API name: getUserDetails
//------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getUserDetails \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getUserDetails(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getUserDetails_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("User Details validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for User Details should be successful", "Request loaded for User Details successfully",
				"Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When ("^post get request for getUserDetails")
	public void post_get_request_getUserDetails () throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getUserDetails(appurl);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getUserDetails response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getUserDetails_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify User Details response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}
				
/*	
//------------------------------------------------------------------------------------------------
	API Description: getUserList - Provides the User's list as per the search criteria
	API name: getUserList
//------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getUserList \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getUserList(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getUserList_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("User List validation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for User List should be successful", "Request loaded for User List successfully",
				"Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getUserList \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_getUserList(String pageNumber, String accountStatus, String profile, String firstName, String lastName, String userName) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getUserList(appurl,userName,accountStatus,profile,firstName,lastName,pageNumber);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getUserList response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getUserList_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify User List response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}
	
/*	
//-----------------------------------------------------------------------------------------------------------
	API Description: getSubAccountDetails - Provides the Sub account details of the current logged in profile
	API name: getSubAccountDetails
//-----------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getSubAccountDetails \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getSubAccountDetails(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getSubAccountDetails_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("get SubAccount Details" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for User Details should be successful", "Request loaded for User Details successfully",
				"Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getSubAccountDetails \"([^\"]*)\"$")
	public void post_get_request_getSubAccountDetails(String userName) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getSubAccountDetails(appurl,userName);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getSubAccountDetails response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getSubAccountDetails_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify get SubAccount Details response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*	
//-----------------------------------------------------------------------------------------------------------
	API Description: getAccessData - Provides the Access details of the current logged in profile
	API name: getAccessData
//-----------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getAccessData \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getAccessData(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getAccessData_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("get Access Data" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for getAccessData should be successful", "Request loaded for getAccessData successfully",
				"Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getAccessData \"([^\"]*)\"$")
	public void post_get_request_getAccessData(String profiles_Accessdata) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getAccessData(appurl, profiles_Accessdata);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getAccessData response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getAccessData_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify getAccessData response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}
	
/*	
//-----------------------------------------------------------------------------------------------------------
	API Description: getDictionaryData - Provides the dictionary details as per the provided input
	API name: getDictionaryData
//-----------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getDictionaryData \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getDictionaryData(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getDictionaryData_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("get Dictionary Data" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for getDictionaryData should be successful", "Request loaded for getDictionaryData successfully",
				"Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getDictionaryData \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_getDictionaryData(String allianceCode, String Dictionary_category, String Dictionary_code, String Dictionary_languagecode) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getDictionaryData(appurl,allianceCode,Dictionary_category,Dictionary_code,Dictionary_languagecode);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getDictionaryData response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getDictionaryData_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify getAccessData response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

	/*	
//----------------------------------------------------------------------------------------------------------------
	API Description: getFilterAndColumnPreferences - Provides the Filter and Column preferences of logged in user
	API name: getFilterAndColumnPreferences
//----------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getFilterAndColumnPreferences \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getFilterAndColumnPreferences(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getFilterAndColumnPreferences_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("get Filter And Column Preferences" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for getFilterAndColumnPreferences should be successful",
				"Request loaded for getFilterAndColumnPreferences successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getFilterAndColumnPreferences")
	public void post_get_request_getFilterAndColumnPreferences() throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getFilterAndColumnPreferences(appurl);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getFilterAndColumnPreferences response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getFilterAndColumnPreferences_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify getFilterAndColumnPreferences response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*	
//-----------------------------------------------------------------------------------------------------------
	API Description: getNewDocumentCount - Provides the new document count of the logged in user
	API name: getNewDocumentCount
//-----------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getNewDocumentCount \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getNewDocumentCount(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getNewDocumentCount_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("get New Document Count" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		Appurlbuild(domainurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for getNewDocumentCount should be successful",
				"Request loaded for getNewDocumentCount successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getNewDocumentCount")
	public void post_get_request_getNewDocumentCount() throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getNewDocumentCount(appurl);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getNewDocumentCount response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getNewDocumentCount_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify getNewDocumentCount response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}


/*	
//-----------------------------------------------------------------------------------------------------------
	API Description: getFolderList - Provides the folder list for the logged in user
	API name: getFolderList
//-----------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getFolderList \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getFolderList(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getFolderList_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("get Folder List" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for getFolderList should be successful",
				"Request loaded for getFolderList successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getFolderList")
	public void post_get_request_getFolderList() throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getFolderList(appurl);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getFolderList response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getFolderList_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify getFolderList response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*	
//-----------------------------------------------------------------------------------------------------------
	API Description: getDocumentListByFolder - Provides the document list by folder for the logged in user
	API name: getDocumentListByFolder
//-----------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getDocumentListByFolder \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getDocumentListByFolder(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getDocumentListByFolder_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("get Document List By Folder" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for getDocumentListByFolder should be successful", "Request loaded for getDocumentListByFolder successfully",
				"Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getDocumentListByFolder \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_getDocumentListByFolder(String pageNumber, String documentfolder) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getDocumentListByFolder(appurl,documentfolder,pageNumber);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getDocumentListByFolder response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getDocumentListByFolder_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify getDocumentListByFolder response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}
	
/*	
//-----------------------------------------------------------------------------------------------------------
	API Description: getDocument - Provides the document as per input for the logged in user
	API name: getDocument
//-----------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getDocument \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getDocument(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getDocument_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("get Document" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for getDocument should be successful",
				"Request loaded for getDocument successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getDocument \"([^\"]*)\"$")
	public void post_get_request_getDocument(String documentId) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getDocument(appurl, documentId);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getDocument response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getDocument_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify getDocument response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}
	
	
/*	
//-----------------------------------------------------------------------------------------------------------
	API Description: getTerminalDetails - Provides the terminal details as per merchant input for the logged in user
	API name: getTerminalDetails
//-----------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getTerminalDetails \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getTerminalDetails(String logindomain,String domainurl,String report,String userName,String password,String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getTerminalDetails_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("getTerminalDetails" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for getTerminalDetails should be successful", "Request loaded for getTerminalDetails successfully",
				"Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getTerminalDetails \"([^\"]*)\"$")
	public void post_get_request_getTerminalDetails(String merchId) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getTerminalDetails(appurl, merchId);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getTerminalDetails response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getTerminalDetails_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify getTerminalDetails response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}
	
	
/*	
//------------------------------------------------------------------------------------------------------------------------
	API Description: getMerchantHierarchyList - Provides the MerchantHierarchyList for the logged in user
	API name: getMerchantHierarchyList
//------------------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getMerchantHierarchyList \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getMerchantHierarchyList(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getMerchantHierarchyList_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("getMerchantHierarchyList" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for getMerchantHierarchyList should be successful", "Request loaded for getMerchantHierarchyList successfully",
				"Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getMerchantHierarchyList")
	public void post_get_request_getMerchantHierarchyList() throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getMerchantHierarchyList(appurl);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getMerchantHierarchyList response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getMerchantHierarchyList_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify getMerchantHierarchyList response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}
	
/*	
//------------------------------------------------------------------------------------------------------------------------
	API Description: getNewMessageCount - Provides the new message count for the logged in user
	API name: getNewMessageCount
//------------------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getNewMessageCount \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getNewMessageCount(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getNewMessageCount_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("getNewMessageCount" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for getNewMessageCount should be successful",
				"Request loaded for getNewMessageCount successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getNewMessageCount")
	public void post_get_request_getNewMessageCount() throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getNewMessageCount(appurl);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getNewMessageCount response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getNewMessageCount_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify getNewMessageCount response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}
	
/*	
//------------------------------------------------------------------------------------------------------------------------
	API Description: getMessageListbyUser - Provides the message list by user
	API name: getMessageListbyUser
//------------------------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getMessageListbyUser \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getMessageListbyUser(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getMessageListbyUser_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("getMessageListbyUser" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for getMessageListbyUser should be successful",
				"Request loaded for getMessageListbyUser successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getMessageListbyUser \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_getMessageListbyUser(String pageNo,String messageType) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getMessageListbyUser(appurl,pageNo,messageType);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getMessageListbyUser response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getMessageListbyUser_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify getMessageListbyUser response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}
/*	
//-----------------------------------------------------------------------------------------------------------
	API Description: getPaymentTypesSummary - Provides the payments summary as per input for the logged in user
	API name: getPaymentTypesSummary
//-----------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getPaymentTypesSummary \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getPaymentTypesSummary(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getPaymentTypesSummary_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("getPaymentTypesSummary" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for getPaymentTypesSummary should be successful", "Request loaded for getPaymentTypesSummary successfully",
				"Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getPaymentTypesSummary \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_getPaymentTypesSummary(String currencyCode,String paymentType1,String days) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getPaymentTypesSummary(appurl,currencyCode,paymentType1,days);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getPaymentTypesSummary response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getPaymentTypesSummary_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify getPaymentTypesSummary response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*	
//-----------------------------------------------------------------------------------------------------------
	API Description: getPaymentTypeSummary - Provides the document as per input for the logged in user
	API name: getPaymentTypeSummary
//-----------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for getPaymentTypeSummary \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_getPaymentTypeSummary(String logindomain,String domainurl,String report,String userName,String password,String allianceCode) throws Throwable {
		
		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "getPaymentTypeSummary_Impersonation" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("getPaymentTypeSummary_Impersonation" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for getPaymentTypeSummary should be successful",
				"Request loaded for getPaymentTypeSummary successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for getPaymentTypeSummary \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_get_request_getPaymentTypeSummary(String pseudoUserName,String currencyCode,String paymentType1,Integer days)
			throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_getPaymentTypeSummary_Impersonation(appurl, pseudoUserName,currencyCode, paymentType1, days);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify getPaymentTypeSummary response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_getPaymentTypeSummary(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify getPaymentTypeSummary response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

	/*	
//-----------------------------------------------------------------------------------------------------------
	API Description: blockUser - Blocks the application user as per the input
	API name: blockUser
//-----------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for blockUser \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_blockUser(String logindomain,String domainurl,String report,String userName,String password,String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "blockUser_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Block User" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		System.out.println("***"+userName+password+allianceCode);
		login_blockUser(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_blockUser(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for blockUser should be successful", "Request loaded for blockUser successfully",
				"Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post request for blockUser \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_request_blockUser(String blockusername, String reasonForBlock,String allianceCode) throws Throwable {

		lib.WriteReportStep("1", "post request for blockUser", "", "", "");
		Response response = postrequest.postrequest_blockUser(appurl,blockusername,reasonForBlock);
		strresponse = response.asString();
		System.out.println("Post response****" + strresponse);
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Request", "Request should be posted successful", "Request posted successfully",
				"Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
		//Logs out the current user session
		/*String apiurl = "https://uat1.merchantportal.firstdata.eu/MerchantApiWeb/rest/invalidateSession";
		postrequest.postrequest_invalidateSession(apiurl, allianceCode);*/
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify blockUser response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_blockUser_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify blockUser response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	
	}

/*	
//-----------------------------------------------------------------------------------------------------------
	API Description: saveFilterAndColumnPreferences - Blocks the application user as per the input
	API name: saveFilterAndColumnPreferences
//-----------------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for saveFilterAndColumnPreferences \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_saveFilterAndColumnPreferences(String logindomain,String domainurl, String report,String userName,String password,String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "saveFilterAndColumnPreferences_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("saveFilterAndColumnPreferences" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		System.out.println("***"+logindomain+userName+password+allianceCode);
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication1(appurl);
		lib.WriteReportStep("2", "Get Request url and load request", "Load Request for saveFilterAndColumnPreferences should be successful",
				"Request loaded for saveFilterAndColumnPreferences successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post request for saveFilterAndColumnPreferences \"([^\"]*)\"$")
	public void post_request_saveFilterAndColumnPreferences(String saveCriteria) throws Throwable {

		lib.WriteReportStep("1", "post request for saveFilterAndColumnPreferences", "", "", "");
		Response response = postrequest.postrequest_saveFilterAndColumnPreferences(appurl, saveCriteria);
		strresponse = response.asString();
		System.out.println("Post response****" + strresponse);
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Request", "Request should be posted successful", "Request posted successfully",
				"Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify saveFilterAndColumnPreferences response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_saveFilterAndColumnPreferences_response_status(String status, String ErrorCode, String Message, String AuthErrMessage,
			String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify saveFilterAndColumnPreferences response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}
	/*	
//------------------------------------------------------------------------------------------------
	API Description: invalidateSession - Invalidates the current session of the user
	API name: invalidateSession
//------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for invalidateSession \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_invalidateSession(String logindomain,String userName,String password,String allianceCode,String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);
		System.out.println("" + date1);

		strfilename = "invalidateSession_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Invalidate Session_" + report + "");
		/* lib.WriteReportStep("1", "Get Request url", "", "", ""); */
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_uniqueauthentication(appurl);
		/*loadrequest.loadgetrequestdata_invalidateSession(appurl);*/
		lib.WriteReportStep("2", "Get Request url and load request", "Load Request for invalidateSession should be successful",
				"Request loaded for invalidateSession successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post request for invalidateSession \"([^\"]*)\"$")
	public void post_request_for_invalidateSession(String allianceCode) throws Throwable {

		lib.WriteReportStep("1", "post request for invalidateSession", "", "", "");
		Response response = postrequest.postrequest_invalidateSession(appurl,allianceCode);
		strresponse = response.asString();
		System.out.println("Post response****" + strresponse);
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Request", "Request should be posted successful", "Request posted successfully",
				"Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");

	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify invalidateSession response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_invalidateSession_response(String status, String ErrorCode, String Message, String AuthErrMessage,
			String Authaccessdenied, String AuthErrCause) throws Throwable {

		System.out.println("verifyresponsestarted");
		String strStatus = Apidefinitions.responsebody.body().jsonPath().getJsonObject("status");
		System.out.println("strStatus is" + strStatus);

		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);

	}

/*
//------------------------------------------------------------------------------------------------
	API Description: validateUserName - Validates the username availablity
	API name: validateUserName
//------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for validateUserName \"([^\"]*)\" and \"([^\"]*)\"$")

	public void load_request_for_validateUserName(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "Validate UserName_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Validate UserName" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Validate UserName should be successful",
				"Request loaded for Validate UserName successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for validateUserName \"([^\"]*)\"$")
	public void post_get_request_validateUserName(String userName) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_validateUserName(appurl,userName);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify validateUserName response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_validateUserName_response_status(String status, String ErrorCode, String Message, String AuthErrMessage,
			String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Validate UserName response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}
	
/*
//------------------------------------------------------------------------------------------------
	API Description: validatepseudousername - Validates the username availablity
	API name: validatepseudousername
//------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for validatepseudousername \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")

	public void load_request_for_validatepseudousername(String logindomain, String domainurl, String report,
			String userName, String password, String allianceCode) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);

		strfilename = "Validate pseudoUserName_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Validate pseudoUserName" + report + "");
		lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
		login(logindomain, userName, password, allianceCode);
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata(appurl);
		lib.WriteReportStep("2", "Get Request url and load request",
				"Load Request for Validate pseudoUserName should be successful",
				"Request loaded for Validate pseudoUserName successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post get request for validatepseudousername \"([^\"]*)\"$")
	public void post_get_request_validatepseudousername(String pseudoUserName) throws Throwable {

		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postGETRequest_validatepseudousername(appurl, pseudoUserName);
		strresponse = Apidefinitions.responsebody.asString();
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful",
				"Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");
	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify validatepseudousername response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_validatepseudousername_response_status(String status, String ErrorCode, String Message,
			String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {

		lib.WriteReportStep("1", "verify Validate pseudoUserName response status", "", "", "");
		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
	}

/*		
//------------------------------------------------------------------------------------------------
		API Description: Application info - Provides the information on the application
		API name: applicationinfo
//------------------------------------------------------------------------------------------------*/

		//Loads the request headers for the api
		@Given("^load request for application info \"([^\"]*)\" and \"([^\"]*)\"$")
		public void load_request_for_application_info(String domainurl, String report) throws Throwable {
					
			DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
			Date date = new Date();
			String date1= dateFormat.format(date);
					
			strfilename="Application info_"+report+""+date1;
			System.out.println("*****"+strfilename);
					
			lib.initializeTest("Application Information validation"+report+"");
			lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
			Appurlbuild(domainurl);
			loadrequest.loadgetrequestdata(appurl);		
			lib.WriteReportStep("2", "Get Request url and load request", "Load Request for application info should be successful", "Request loaded for application info successfully", "Passed");
		}
				
		//Posts the api request with the respective parameters provided and retrieves/writes the response
		@When("^post get request for application info")
		public void post_get_request_application_info() throws Throwable {
					
			lib.WriteReportStep("1", "Post Get Request", "", "", "");
			postrequest.postGETRequest_applicationinfo(appurl);
			strresponse=Apidefinitions.responsebody.asString();
			writejsonresponse(strfilename, strresponse);
					
			lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful", "Request posted successfully", "Passed");
			lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully", "Response retrieved successfully and placed in the path-" +"<b>"+strPath+"</b>", "Passed");
		}
				
		//Validate the status of api response and writes the report accordingly
		@Then("^verify application info response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
		public void verify_application_info_response_status(String status, String ErrorCode, String Message, String AuthErrMessage,
				String Authaccessdenied, String AuthErrCause) throws Throwable {
					
			lib.WriteReportStep("1", "verify application info response status", "", "", "");
			validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
			verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		}		

/*
//------------------------------------------------------------------------------------------------
	API Description: logout - Logs out the user from the application
	API name: logout
//------------------------------------------------------------------------------------------------*/

	// Loads the request headers for the api
	@Given("^load request for logout \"([^\"]*)\" and \"([^\"]*)\"$")

	public void load_request_for_logout(String domainurl, String report) throws Throwable {

		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1 = dateFormat.format(date);
		System.out.println("" + date1);

		strfilename = "Logout_" + report + "" + date1;
		System.out.println("*****" + strfilename);

		lib.initializeTest("Logout_" + report + "");
		lib.WriteReportStep("1", "Get Request url", "", "", "");
		Appurlbuild(domainurl);
		loadrequest.loadgetrequestdata_authenticated(appurl, token);
		lib.WriteReportStep("2", "Get Request url and load request", "Load Request for logout should be successful",
				"Request loaded for logout successfully", "Passed");
	}

	// Posts the api request with the respective parameters provided and
	// retrieves/writes the response
	@When("^post request for logout$")
	public void post_request_for_logout() throws Throwable {

		lib.WriteReportStep("1", "post request for logout", "", "", "");
		Response response = postrequest.postrequest_logout(appurl);
		strresponse = response.asString();
		System.out.println("Post response****" + strresponse);
		writejsonresponse(strfilename, strresponse);

		lib.WriteReportStep("2", "Post Request", "Request should be posted successful", "Request posted successfully",
				"Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully",
				"Response retrieved successfully and placed in the path-" + "<b>" + strPath + "</b>", "Passed");

	}

	// Validate the status of api response and writes the report accordingly
	@Then("^verify logout response status \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_logout_response(String status, String ErrorCode, String Message, String AuthErrMessage,
			String Authaccessdenied, String AuthErrCause) throws Throwable {

		System.out.println("verifyresponsestarted");
		String strStatus = Apidefinitions.responsebody.body().jsonPath().getJsonObject("status");
		System.out.println("strStatus is" + strStatus);

		validateRequest.verifyresponse(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);
		verifyresponsereport(status, ErrorCode, Message, AuthErrMessage, Authaccessdenied, AuthErrCause);

	}

/*
//----------------------------------------------------------------------------------------
	Description: General method for writing report after verifying the response
//----------------------------------------------------------------------------------------*/

@Step
public void verifyresponsereport(String status,String ErrorCode,String Message,String AuthErrMessage,String Authaccessdenied,String AuthErrCause){
	
		String strStatus = Apidefinitions.responsebody.body().jsonPath().getJsonObject("status");
	
		if((strStatus!=null && strStatus.equalsIgnoreCase("success"))){
			
			lib.WriteReportStep("1", "verify user authentication response", "", "", "");
			lib.WriteReportStep("2", "verify user authentication response status", "Expected Response status should be:<b> "+status+"</b>", "Response : <b>Status</b> =" +"<b>"+strStatus+"</b>", "Passed");
		
		}
		
		else if(strStatus!=null && strStatus.equalsIgnoreCase("error")){
		
			lib.WriteReportStep("1", "verify user authentication response", "", "", "");
			lib.WriteReportStep("2", "verify user authentication response status", "Expected Response status should be:<b> "+status+"</b>", "Response : <b>Status</b> =" +"<b>"+strStatus+"</b>", "Passed");
			
			String strerrorcode = Apidefinitions.responsebody.body().jsonPath().getString("errors.code[0]");
			System.out.println("strcode is"+strerrorcode);
			lib.WriteReportStep("2", "verify user authentication response error code", "Expected Response error code should be:<b> "+ErrorCode+"</b>", "Response : <b>Status</b> =" +"<b>"+strerrorcode+"</b>", "Passed");
			
			String strmessage = Apidefinitions.responsebody.body().jsonPath().getString("errors.message[0]");
			System.out.println("strcode is"+strmessage);
			lib.WriteReportStep("2", "verify user authentication response error message", "Expected Response error message should be:<b> "+Message+"</b>", "Response : <b>Status</b> =" +"<b>"+strmessage+"</b>", "Passed");
		
		}
		
		else if(strStatus==null)
	     {
			
			lib.WriteReportStep("1", "verify user authentication response", "", "", "");
			String strcode= Apidefinitions.responsebody.body().jsonPath().getJsonObject("code");
			lib.WriteReportStep("2", "verify user authentication response error code", "Expected Response error code should be:<b> "+ErrorCode+"</b>", "Response : <b>Status</b> =" +"<b>"+strcode+"</b>", "Passed");
			
			String strautherrmessage= Apidefinitions.responsebody.body().jsonPath().getJsonObject("message");
			lib.WriteReportStep("2", "verify user authentication response error message", "Expected Response error message should be:<b> "+AuthErrMessage+"</b>", "Response : <b>Status</b> =" +"<b>"+strautherrmessage+"</b>", "Passed");
			
			boolean straccess= Apidefinitions.responsebody.body().jsonPath().getJsonObject("access-denied"); 
			lib.WriteReportStep("2", "verify user authentication response error message", "Expected Response error message should be:<b> "+Authaccessdenied+"</b>", "Response : <b>Status</b> =" +"<b>"+straccess+"</b>", "Passed"); 
	    	
			String strcause= Apidefinitions.responsebody.body().jsonPath().getJsonObject("cause");
	    	lib.WriteReportStep("2", "verify user authentication response error message", "Expected Response error message should be:<b> "+AuthErrCause+"</b>", "Response : <b>Status</b> =" +"<b>"+strcause+"</b>", "Passed"); 
	     
	     }
	     else
	     {
	    	 lib.WriteReportStep("1", "verify user authentication response", "", "", "");
				lib.WriteReportStep("2", "verify user authentication response status", "Expected Response status should be:<b> "+status+"</b>", "Response retrieved is: <b>Status</b> =" +"<b>"+strStatus+"</b>", "Failed");
				String strerrorcode = Apidefinitions.responsebody.body().jsonPath().getString("errors.code[0]");
				System.out.println("strcode is"+strerrorcode);
				lib.WriteReportStep("2", "verify user authentication response error code", "Expected Response error code should be:<b> "+ErrorCode+"</b>", "Response retrieved is: <b>Error code</b> =" +"<b>"+strerrorcode+"</b>", "Failed");
				
				String strmessage = Apidefinitions.responsebody.body().jsonPath().getString("errors.message[0]");
				System.out.println("strcode is"+strmessage);
				lib.WriteReportStep("2", "verify user authentication response error message", "Expected Response error message should be:<b> "+Message+"</b>", "Response retrieved is: <b>Message</b> =" +"<b>"+strmessage+"</b>", "Failed");
			
	     }
}

/*
//----------------------------------------------------------------------------------------
	Description: General method for writing json response in a separate file
//----------------------------------------------------------------------------------------*/
	
@Step
	public void writejsonresponse(String strfilename,String output) 
	{
      try
      {
    	DateFormat dateFormat = new SimpleDateFormat("MMddyyyy");
  		Date date = new Date();
  		String date1= dateFormat.format(date);
  		strPath= "C:\\Users\\F8T9I50\\Desktop\\FAB_Automation\\SerenityBDD_Latest\\Results\\Response\\"+date1+"\\"+strfilename+".json";
           
        System.out.println("File to write: "+strPath);
        File file = new File(strPath); // If you want to write as file to local.
        FileWriter fileWriter = new FileWriter(file);
        fileWriter.write(output);
        fileWriter.close();
        
      }
      catch(Exception e)
      {
           // Exit();
      }
}

@Step
public void writejsonresponse_exportdevicelist(String strfilename,String output,String fileType) 
{
  try
  {
	DateFormat dateFormat = new SimpleDateFormat("MMddyyyy");
		Date date = new Date();
		String date1= dateFormat.format(date);
		strPath= "C:\\Users\\F8T9I50\\Desktop\\FAB_Automation\\SerenityBDD_Latest\\Results\\Response\\"+date1+"\\"+strfilename+"."+fileType+"";
       
    System.out.println("File to write: "+strPath);
    File file = new File(strPath); // If you want to write as file to local.
    FileWriter fileWriter = new FileWriter(file);
    fileWriter.write(output);
    fileWriter.close();
    
  }
  catch(Exception e)
  {
       // Exit();
  }
}

/*
//----------------------------------------------------------------------------------------
	Description: General method to build the application url from base url for execution
//----------------------------------------------------------------------------------------*/
@Step
public void Appurlbuild(String domainurl) 
{
	EnvironmentVariables variables = SystemEnvironmentVariables.createEnvironmentVariables();
	String baseUrl = variables.getProperty(ThucydidesSystemProperty.WEBDRIVER_BASE_URL);
	appurl=baseUrl.concat(domainurl);
		
}

/*
//----------------------------------------------------------------------------------------
	Description: General method to build the application url from base url for execution
//----------------------------------------------------------------------------------------*/
@Step
public void login(String logindomain,String userName,String password,String allianceCode) 
{
	Appurlbuild(logindomain);
	loadrequest.loadgetrequestdata(appurl);
	postrequest.postrequest_authenticateUser(appurl, userName, password, allianceCode);
	loginsessiontoken = Apidefinitions.responsebody.headers().getValue("X-CSRF-TOKEN");
	Serenity.setSessionVariable("session").to(loginsessiontoken);
	Serenity.setSessionVariable("loginsessioncookies").to(Apidefinitions.responsebody.cookies());
		
}

public void login_blockUser(String logindomain,String userName,String password,String allianceCode) 
{
	Appurlbuild(logindomain);
	loadrequest.loadgetrequestdata(appurl);
	System.out.println("888***"+userName+password+allianceCode);
	postrequest.postrequest_authenticateUser(appurl, userName, password, allianceCode);
	JSESSIONID = Apidefinitions.responsebody.cookie("JSESSIONID").substring(0, 40);

	/*Map<String, String> Ckies = Apidefinitions.responsebody.cookies();
	System.out.println("ckies"+Ckies);
	String JSESSIONID1 = Apidefinitions.responsebody.cookie("JSESSIONID");
	System.out.println("Session valueJSESSIONID"+JSESSIONID);
	System.out.println("Session valueJSESSIONID1"+JSESSIONID1);*/
	token = Apidefinitions.responsebody.headers().getValue("X-CSRF-TOKEN");
	/*System.out.println("Token value"+token);
	Serenity.setSessionVariable("CURRSESSIONID").to(JSESSIONID);
	Serenity.setSessionVariable("session").to(token);
	Serenity.setSessionVariable("cookies").to(Apidefinitions.responsebody.cookies());*/
		
}


}

