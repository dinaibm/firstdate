package stepdefinitions;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import CreateFeature.TestFea;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;
import ui.pageobjects.registration.RegObjects;
import ui.registration.Registeration;
import util.ExcelUtil;

public class UIDefinitions {

@Steps
Registeration registeration;

//@Steps
//RegObjects regobjects;

public static WebDriver driver = null;

	@Before
	public void bfre() throws Exception{
		//driver=new WrappedWebDriver().newDriver();
		//Generate Feature file using excewl input
		
	}
	
	
	@Given("^the Feature file path creattion$")
	public void the_Feature_file_path_creattion() throws Throwable {
		TestFea.CreateFeatureFile();
	}
	@Given("^the EMS portal$")
	public void the_Registeration_portal() throws Throwable {
		registeration.loadbrowser();
	}

	@And("^user Navigate to URL \"([^\"]*)\"$")
	public void user_Navigate_to_URL(String arg1) throws Throwable {
		registeration.navigate(arg1);
		
	}
	@And("^user click on RememberMe$")
	public void user_click_on_RememberMe() throws Throwable {
		registeration.RememberMe();
	}

	@When("^user enter \"([^\"]*)\" as \"([^\"]*)\"$")
	public void user_enter_as(String FieldName, String FieldValue) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		registeration.userInput(FieldName,FieldValue);

	}

	@And("^user entertext \"([^\"]*)\" as \"([^\"]*)\"$")
	public void user_entertext_as(String FieldName, String FieldValue) throws Throwable {
		registeration.userInput(FieldName,FieldValue);
	    // Write code here that turns the phrase above into concrete actions
	 
	}
	
	@When("^user click Submit login$")
	public void user_click_Submit_login() throws Throwable {
	 registeration.Submitlogin();
	}
	@Then("^user Check LastLoginDate$")
	public void user_Check_LastLoginDate() throws Throwable {
		registeration.LastLoginDate();
	}
	@Then("^user Check DashboardDate$")
	public void user_Check_DashboardDate() throws Throwable {
		registeration.DashboardDate();
	}
	@Then("^user click Preauth$")
	public void user_click_Preauth() throws Throwable {
		registeration.Preauth();

	}
	@And("^user click on Detail$")
	public void user_click_on_Detail() throws Throwable {
		registeration.Detail();

	}
	/*
	@Then("^Submit Registeration is Successful with Message \"([^\"]*)\"$")
	public void submit_Registeration_is_Successful_with_Message(String ExpectedValue) throws Throwable {
	   registeration.RegisterationStatus(ExpectedValue);
	}*/
}
