package ui.Signon;

import java.io.File;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.AdminPage_object;
import ui.pageobjects.Signon.AuthorizationPage_object;
import ui.pageobjects.Signon.DashboardPage_objects;
import ui.pageobjects.Signon.DocumentPage_object;
import ui.pageobjects.Signon.FundingPage_object;
import ui.pageobjects.Signon.MessagePage_object;
import ui.pageobjects.Signon.PreAuthorizationPage_object;
import ui.pageobjects.Signon.SignonPage_objects;
import ui.pageobjects.Signon.TransactionPage_object;

public class Financial_Activity extends PageObject{
	WebDriver driver =null;
	String Result=null;
	boolean Status=false;
	MessagePage_object messagepageObjects;
	AdminPage_object adminpageObjects;
	DashboardPage_objects dasboardpageobjects;
	SignonPage_objects signonObjects;
	DocumentPage_object documentpageobjects;
	PreAuthorizationPage_object preauthorizationpageobjects;
	TransactionPage_object transactionpageobjects;
	FundingPage_object fundingpageobjects;
	AuthorizationPage_object authorizationpageobjects;
	String message_link=null;
		
@Step	
public String Verify_Time_Period_filter_For_Preauthorization(){
	driver = this.getDriver();
	String Result1,Result2,Result3,Result4=null;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.preauthorization_Link()));
	dasboardpageobjects.preauthorization_Link().click();
	driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	executor.executeScript("arguments[0].click()",preauthorizationpageobjects.date_dropdown());
	driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	System.out.println(preauthorizationpageobjects.Todays_Date_filter.isCurrentlyVisible());
	wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Todays_Date_filter()));
	if(preauthorizationpageobjects.Todays_Date_filter.isCurrentlyVisible() || preauthorizationpageobjects.LastsevenDays_filter.isCurrentlyVisible() 
			|| preauthorizationpageobjects.this_week_filter.isCurrentlyVisible() || preauthorizationpageobjects.Last_month_filter.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Todays_Date_filter()));
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Todays_Date_filter());
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.apply_button());
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.date_dropdown()));
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			Result1="Passed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else
		{
			Result1="Passed " +"Transaction data is present for today ";
		}
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.date_dropdown());
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.LastsevenDays_filter()));
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.LastsevenDays_filter());
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.apply_button());
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.date_dropdown()));
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			Result2="Passed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else
		{
			Result2="Passed " +"Transaction data is present for Last_seven_days ";
		}
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.date_dropdown());
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.this_week_filter()));
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.this_week_filter());
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.apply_button());
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.date_dropdown()));
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			Result3="Passed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else
		{
			Result3="Passed " +"Transaction data is present for This week ";
		}
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.date_dropdown());
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Last_month_filter()));
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.Last_month_filter());
		executor.executeScript("arguments[0].click()",preauthorizationpageobjects.apply_button());
		wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.date_dropdown()));
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		if(preauthorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			Result4="Passed "+preauthorizationpageobjects.search_error_message().getText();
		}
		else
		{
			Result4="Passed " +"Transaction data is present for This week ";
		}
		Result=Result1 +"   "+Result2+"  "+Result3+"  "+Result4;
	}
	else
	{
		Result="Failed "+"Service is unavailable for now come back later";
	}
	return Result;	
}
@Step	
public String Verify_transaction_xml_file_download(String downloaded_Path, String Alliance_code) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 500);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
	dasboardpageobjects.transaction_Link().click();
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
	//driver.manage().timeouts().implicitlyWait(1, TimeUnit.MINUTES);  
	checkPageIsReady();
	//wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.table_lastRow()));
	wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.export_button()));
	checkPageIsReady();
	if(transactionpageobjects.search_error_message.isCurrentlyVisible())
	{
		transactionpageobjects.export_button().click();
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.nodata_export_error_message()));
		if(transactionpageobjects.nodata_export_error_message.isCurrentlyVisible())
		{
			Result="Failed "+transactionpageobjects.nodata_export_error_message().getText();
		}
	}
	else
	{
		transactionpageobjects.export_button().click();
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.xmlFile_option()));
		executor.executeScript("arguments[0].click()",transactionpageobjects.xmlFile_option());
		transactionpageobjects.download_button().click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.export_button()));
		File getLatestFile = getLatestFilefromDir(downloaded_Path);
	    String fileName = getLatestFile.getName();
	    String []filedetails=fileName.split("_");
	    long length = getLatestFile.length();
	    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
	    		&& isDateValid(filedetails[2]) && fileName.endsWith(".xml") && filedetails[1].equals("A"))
	    	{
	    		Result="Passed "+fileName+" Its Related to authorization transaction";
	    	}
	    else if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
	    		&& isDateValid(filedetails[2]) && fileName.endsWith(".xml") && filedetails[1].equals("T"))
	    	{
	    		Result="Passed "+fileName+" Its Related to Transaction detail";
	    	}
	    else
	    	{
	    		Result="Failed "+"We didnot find the document in the folder";
	    	}
	}
		return Result;	
}
@Step	
public String Verify_transaction_xls_file_download(String downloaded_Path, String Alliance_code) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
	dasboardpageobjects.transaction_Link().click();
	waitFor(dasboardpageobjects.transaction_text());
	//waitFor(transactionpageobjects.table_lastRow());
	wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.export_button()));
	waitFor(transactionpageobjects.export_button());
	if(transactionpageobjects.search_error_message.isCurrentlyVisible())
	{
		executor.executeScript("arguments[0].click()",transactionpageobjects.export_button());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.nodata_export_error_message()));
		if(transactionpageobjects.nodata_export_error_message.isCurrentlyVisible())
		{
			Result="Failed "+transactionpageobjects.nodata_export_error_message().getText();
		}
	}
	else
	{
		executor.executeScript("arguments[0].click()",transactionpageobjects.export_button());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.xlsFile_option()));
		executor.executeScript("arguments[0].click()",transactionpageobjects.xlsFile_option());
		transactionpageobjects.download_button().click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.export_button()));
		File getLatestFile = getLatestFilefromDir(downloaded_Path);
	    String fileName = getLatestFile.getName();
	    String []filedetails=fileName.split("_");
	    long length = getLatestFile.length();
	    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
	    		&& isDateValid(filedetails[2]) && fileName.endsWith(".xls") && filedetails[1].equals("T"))
	    	{
	    		Result="Passed "+fileName+" Its Related to Transaction detail";
	    	}
	    else
	    	{
	    		Result="Failed "+"We didnot find the document in the folder";
	    	}
	}
	return Result;
}
@Step	
public String Verify_transaction_csv_file_download(String downloaded_Path, String Alliance_code) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
	dasboardpageobjects.transaction_Link().click();
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
	//waitFor(transactionpageobjects.table_lastRow());
	wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.export_button()));
	//waitFor(transactionpageobjects.export_button());
	if(transactionpageobjects.search_error_message.isCurrentlyVisible())
	{
		executor.executeScript("arguments[0].click()",transactionpageobjects.export_button());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.nodata_export_error_message()));
		if(transactionpageobjects.nodata_export_error_message.isCurrentlyVisible())
		{
			Result="Failed "+transactionpageobjects.nodata_export_error_message().getText();
		}
	}
	else
	{
		executor.executeScript("arguments[0].click()",transactionpageobjects.export_button());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.csvFile_option()));
		executor.executeScript("arguments[0].click()",transactionpageobjects.csvFile_option());
		transactionpageobjects.download_button().click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.export_button()));
		File getLatestFile = getLatestFilefromDir(downloaded_Path);
	    String fileName = getLatestFile.getName();
	    String []filedetails=fileName.split("_");
	    long length = getLatestFile.length();
	    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
	    		&& isDateValid(filedetails[2]) && fileName.endsWith(".csv") && filedetails[1].equals("T"))
	    	{
	    		Result="Passed "+fileName+" Its Related to Transaction detail";
	    	}
	    else
	    	{
	    		Result="Failed "+"We didnot find the document in the folder";
	    	}
	}
	return Result;
}
@Step	
public String Verify_funding_csv_file_download(String downloaded_Path, String Alliance_code, String Funding_Reference_number) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_Link()));
	dasboardpageobjects.funding_Link().click();
	waitFor(dasboardpageobjects.funding_text());
	checkPageIsReady();
	waitFor(fundingpageobjects.searchFieldText());
	fundingpageobjects.searchFieldText().sendKeys(Funding_Reference_number);
	waitFor(fundingpageobjects.search_button());
	executor.executeScript("arguments[0].click()",fundingpageobjects.search_button());
	waitFor(dasboardpageobjects.funding_text());
	checkPageIsReady();
	if(!fundingpageobjects.no_results_found.isCurrentlyVisible())
	{
		waitFor(fundingpageobjects.funding_refrence_number());
		if(fundingpageobjects.funding_refrence_number().getText().equals(Funding_Reference_number))
			{
				waitFor(fundingpageobjects.funding_refrence_number());
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon()));
				executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon());
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.view_batch_details()));
				executor.executeScript("arguments[0].click()",fundingpageobjects.view_batch_details());
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Export_button()));
				executor.executeScript("arguments[0].click()",fundingpageobjects.Export_button());
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.csvFile_option()));
				executor.executeScript("arguments[0].click()",fundingpageobjects.csvFile_option());
				executor.executeScript("arguments[0].click()",fundingpageobjects.Download_button());
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Export_button()));
				File getLatestFile = getLatestFilefromDir(downloaded_Path);
			    String fileName = getLatestFile.getName();
			    String []filedetails=fileName.split("_");
			    long length = getLatestFile.length();
			    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
			    		&& isDateValid(filedetails[2]) && fileName.endsWith(".csv") && filedetails[1].equals("F"))
			    	{
			    		Result="Passed "+fileName+" Its Related to Funding detail";
			    	}
			    else
			    	{
			    		Result="Failed "+"We didnot find the document in the folder";
			    	}
			}
		else
		{
			Result="Failed "+" We couldnot find the data for this particular refrence number ";
		}
	}
	else
	{
		Result="Failed "+fundingpageobjects.no_results_found().getText();
	}
return Result;
}
@Step	
public String Verify_Authorization_csv_file_download(String downloaded_Path, String Alliance_code) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_Link()));
	dasboardpageobjects.Authorizations_Link().click();
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_text()));
	wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.export_button()));
	System.out.println("dsdffdgg"+authorizationpageobjects.search_error_message().getText());
	System.out.println(authorizationpageobjects.search_error_message.isCurrentlyVisible());
	if(authorizationpageobjects.search_error_message.isCurrentlyVisible())
	{
		executor.executeScript("arguments[0].click()",authorizationpageobjects.export_button());
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.noRecords_after_export()));
		if(authorizationpageobjects.noRecords_after_export.isCurrentlyVisible())
		{
			Result="Failed "+authorizationpageobjects.noRecords_after_export().getText();
			authorizationpageobjects.close_button().click();
		}
	}
	else
	{
		waitFor(authorizationpageobjects.export_button());
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.export_button()));
		executor.executeScript("arguments[0].click()",authorizationpageobjects.export_button());
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.csv_button()));
		executor.executeScript("arguments[0].click()",authorizationpageobjects.csv_button());
		authorizationpageobjects.download_button().click();
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.export_button()));
		File getLatestFile = getLatestFilefromDir(downloaded_Path);
	    String fileName = getLatestFile.getName();
	    String []filedetails=fileName.split("_");
	    long length = getLatestFile.length();
	    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
	    		&& isDateValid(filedetails[2]) && fileName.endsWith(".csv") && filedetails[1].equals("A"))
	    	{
	    		Result="Passed "+fileName+" Its Related to Authorization detail";
	    	}
	    else
	    	{
	    		Result="Failed "+"We didnot find the document in the folder";
	    	}
	}
	return Result;
	
}
@Step	
public String Verify_Time_picker_in_transaction_view(String From_date, String To_date) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 500);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
	dasboardpageobjects.transaction_Link().click();
	checkPageIsReady();
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
	checkPageIsReady();
	waitForWithRefresh();
	//waitFor(transactionpageobjects.date_dropdown());
	
	wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
	checkPageIsReady();
	waitForWithRefresh();
	executor.executeScript("arguments[0].click()",transactionpageobjects.date_dropdown());
	wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.fromdate()));
	if(isDateValidforFromDate_Todate(From_date) && isDateValidforFromDate_Todate(To_date))
	{
		transactionpageobjects.fromdate().clear();
		transactionpageobjects.fromdate().sendKeys(From_date);
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.todate()));
		transactionpageobjects.todate().clear();
		transactionpageobjects.todate().sendKeys(To_date);
		transactionpageobjects.apply_button().click();
		Result="Passed "+"From Date and To date is valid date";
	}
	else
	{
		waitForWithRefresh();
		Result="Failed "+"From date and To date is not a valid date";
	}
	return Result;
}

@Step
public String Verify_Time_Period_filter_For_Transaction() throws Throwable{
	driver = this.getDriver();
	String Result1,Result2,Result3,Result4=null;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	dasboardpageobjects.transaction_Link().click();
	checkPageIsReady();
	WebDriverWait wait = new WebDriverWait(driver, 200);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
	checkPageIsReady();
	waitForWithRefresh();
	checkPageIsReady();
	waitForWithRefresh();
	checkPageIsReady();
    System.out.println(dasboardpageobjects.transaction_text.isCurrentlyVisible());
	wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
	waitForWithRefresh();
	executor.executeScript("arguments[0].click()",transactionpageobjects.date_dropdown());
	driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	System.out.println(preauthorizationpageobjects.Todays_Date_filter.isCurrentlyVisible());
	wait.until(ExpectedConditions.elementToBeClickable(preauthorizationpageobjects.Todays_Date_filter()));
	if(transactionpageobjects.Todays_Date_filter.isCurrentlyVisible() || transactionpageobjects.LastsevenDays_filter.isCurrentlyVisible() 
			|| transactionpageobjects.this_week_filter.isCurrentlyVisible() || transactionpageobjects.Last_month_filter.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Todays_Date_filter()));
		executor.executeScript("arguments[0].click()",transactionpageobjects.Todays_Date_filter());
		executor.executeScript("arguments[0].click()",transactionpageobjects.apply_button());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		if(transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			waitForWithRefresh();
			Result1="Passed "+transactionpageobjects.search_error_message().getText();
		}
		else
		{
			waitForWithRefresh();
			Result1="Passed " +"Transaction data is present for today ";
		}
		waitForWithRefresh();
		executor.executeScript("arguments[0].click()",transactionpageobjects.date_dropdown());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.LastsevenDays_filter()));
		executor.executeScript("arguments[0].click()",transactionpageobjects.LastsevenDays_filter());
		executor.executeScript("arguments[0].click()",transactionpageobjects.apply_button());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		if(transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			waitForWithRefresh();
			Result2="Passed "+transactionpageobjects.search_error_message().getText();
		}
		else
		{
			waitForWithRefresh();
			Result2="Passed " +"Transaction data is present for Last_seven_days ";
		}
		waitForWithRefresh();
		executor.executeScript("arguments[0].click()",transactionpageobjects.date_dropdown());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.this_week_filter()));
		executor.executeScript("arguments[0].click()",transactionpageobjects.this_week_filter());
		executor.executeScript("arguments[0].click()",transactionpageobjects.apply_button());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		if(transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			waitForWithRefresh();
			Result3="Passed "+transactionpageobjects.search_error_message().getText();
		}
		else
		{
			waitForWithRefresh();
			Result3="Passed " +"Transaction data is present for This week ";
		}
		waitForWithRefresh();
		executor.executeScript("arguments[0].click()",transactionpageobjects.date_dropdown());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.Last_month_filter()));
		executor.executeScript("arguments[0].click()",transactionpageobjects.Last_month_filter());
		executor.executeScript("arguments[0].click()",transactionpageobjects.apply_button());
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		if(transactionpageobjects.search_error_message.isCurrentlyVisible())
		{
			waitForWithRefresh();
			Result4="Passed "+transactionpageobjects.search_error_message().getText();
		}
		else
		{
			waitForWithRefresh();
			Result4="Passed " +"Transaction data is present for This week ";
		}
		waitForWithRefresh();
		Result=Result1 +"   "+Result2+"  "+Result3+"  "+Result4;
	}
	else
	{
		waitForWithRefresh();
		Result="Failed "+"Service is unavailable for now come back later";
	}
	return Result;	
}
@Step
public String Verify_From_date_should_be_before_to_date(String From_date, String To_date) throws Throwable{
	
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 500);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
	dasboardpageobjects.transaction_Link().click();
	checkPageIsReady();
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
	checkPageIsReady();
	waitForWithRefresh();
	//waitFor(transactionpageobjects.date_dropdown());
	wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
	checkPageIsReady();
	waitForWithRefresh();
	SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
    Date From_date1 = sdf.parse(From_date);
    Date To_date1 = sdf.parse(To_date);

    System.out.println("date1 : " + sdf.format(From_date1));
    System.out.println("date2 : " + sdf.format(To_date1));

    if (From_date1.compareTo(To_date1) > 0) {
        Result="Failed "+"From Date should not be after To date";
    } else if (From_date1.compareTo(To_date1) < 0) {
    	executor.executeScript("arguments[0].click()",transactionpageobjects.date_dropdown());
    	wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.fromdate()));
		transactionpageobjects.fromdate().clear();
		transactionpageobjects.fromdate().sendKeys(From_date);
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.todate()));
		transactionpageobjects.todate().clear();
		transactionpageobjects.todate().sendKeys(To_date);
		transactionpageobjects.apply_button().click();
		//wait.until(ExpectedConditions.elementToBeSelected(transactionpageobjects.date_dropdown()));
		Result="Passed "+"From Date is before to date";
    }
    else if(From_date1.compareTo(To_date1) == 0) {
        Result="Failed "+"From date is same as to date";
    }

	return Result;
}
@Step	
public String Verify_funding_xml_file_download(String downloaded_Path, String Alliance_code, String Funding_Reference_number) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 500);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_Link()));
	dasboardpageobjects.funding_Link().click();
	waitFor(dasboardpageobjects.funding_text());
	//wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.searchFieldText()));
	waitFor(fundingpageobjects.searchFieldText());
	fundingpageobjects.searchFieldText().sendKeys(Funding_Reference_number);
	waitFor(fundingpageobjects.search_button());
	fundingpageobjects.search_button().click();
	checkPageIsReady();
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.funding_text()));
	if(!fundingpageobjects.no_results_found.isCurrentlyVisible())
	{
		waitFor(fundingpageobjects.funding_refrence_number());
		if(fundingpageobjects.funding_refrence_number().getText().equals(Funding_Reference_number))
		
			{
			waitFor(fundingpageobjects.funding_refrence_number());
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.plus_icon()));
			executor.executeScript("arguments[0].click()",fundingpageobjects.plus_icon());
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.view_batch_details()));
			executor.executeScript("arguments[0].click()",fundingpageobjects.view_batch_details());
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Export_button()));
			executor.executeScript("arguments[0].click()",fundingpageobjects.Export_button());
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.xmlFile_option()));
			executor.executeScript("arguments[0].click()",fundingpageobjects.xmlFile_option());
			executor.executeScript("arguments[0].click()",fundingpageobjects.Download_button());
			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			wait.until(ExpectedConditions.elementToBeClickable(fundingpageobjects.Export_button()));
			File getLatestFile = getLatestFilefromDir(downloaded_Path);
		    String fileName = getLatestFile.getName();
		    String []filedetails=fileName.split("_");
		    long length = getLatestFile.length();
		    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
		    		&& isDateValid(filedetails[2]) && fileName.endsWith(".xml") && filedetails[1].equals("F"))
		    	{
		    		Result="Passed "+fileName+" Its Related to Funding detail";
		    	}
		    else
		    	{
		    		Result="Failed "+"We didnot find the document in the folder";
		    	}
			}
		else
		{
			Result="Failed "+"We couldnot find the data for this particular refrence number";
		}
	}
	else
	{
		Result="Failed "+fundingpageobjects.no_results_found().getText();
	}
return Result;
}
@Step
public String Verify_the_transaction_details_after_giving_dates(String From_date, String To_date) throws Throwable{
	
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 500);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
	dasboardpageobjects.transaction_Link().click();
	checkPageIsReady();
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
	checkPageIsReady();
	waitForWithRefresh();
	//waitFor(transactionpageobjects.date_dropdown());
	wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
	checkPageIsReady();
	waitForWithRefresh();
	executor.executeScript("arguments[0].click()",transactionpageobjects.date_dropdown());
	wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.fromdate()));
	transactionpageobjects.fromdate().clear();
	transactionpageobjects.fromdate().sendKeys(From_date);
	wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.todate()));
	transactionpageobjects.todate().clear();
	transactionpageobjects.todate().sendKeys(To_date);
	transactionpageobjects.apply_button().click();
	checkPageIsReady();
	wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_error_message()));
	if(transactionpageobjects.search_error_message.isCurrentlyVisible())
	{
	Result="Passed "+transactionpageobjects.search_error_message().getText();
    }
    else
    {
        Result="Passed "+"Transaction details are available for this particular date";
    }

	return Result;
}
@Step	
public String Verify_Authorization_xml_file_download(String downloaded_Path, String Alliance_code) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_Link()));
	dasboardpageobjects.Authorizations_Link().click();
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_text()));
	checkPageIsReady();
	//System.out.println("dsdffdgg"+authorizationpageobjects.search_error_message().getText());
	System.out.println(authorizationpageobjects.search_error_message.isCurrentlyVisible());
	if(authorizationpageobjects.search_error_message.isCurrentlyVisible())
	{
		//executor.executeScript("arguments[0].click()",authorizationpageobjects.export_button());
		//executor.executeScript("arguments[0].click()",authorizationpageobjects.date_dropdown());
		waitForWithRefresh();
		/*executor.executeScript("arguments[0].click()",authorizationpageobjects.date_dropdown());
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.LastsevenDays_filter()));
		executor.executeScript("arguments[0].click()",authorizationpageobjects.LastsevenDays_filter());
		executor.executeScript("arguments[0].click()",authorizationpageobjects.apply_button());
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.date_dropdown()));*/
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.export_button()));
		checkPageIsReady();
		waitFor(authorizationpageobjects.export_button());
		checkPageIsReady();
		authorizationpageobjects.export_button().click();
		waitFor(authorizationpageobjects.export_button());
		
		if(!authorizationpageobjects.noRecords_after_export.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.xml_button()));
			executor.executeScript("arguments[0].click()",authorizationpageobjects.xml_button());
			authorizationpageobjects.download_button().click();
			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.export_button()));
			File getLatestFile = getLatestFilefromDir(downloaded_Path);
		    String fileName = getLatestFile.getName();
		    String []filedetails=fileName.split("_");
		    long length = getLatestFile.length();
		    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
		    		&& isDateValid(filedetails[2]) && fileName.endsWith(".xml") && filedetails[1].equals("A"))
		    	{
		    		Result="Passed "+fileName+" Its Related to Authorization detail";
		    	}
		    else if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && filedetails[0].startsWith(Alliance_code) 
		    		&& isDateValid(filedetails[2]) && fileName.endsWith(".xml") && filedetails[1].equals("T"))
		    	{
		    		Result="Passed "+fileName+" Its Related to Transaction detail";
		    	}
		    else
		    	{
		    		Result="Failed "+"We didnot find the document in the folder";
		    	}
			
		}
		else
		{
			executor.executeScript("arguments[0].click()",authorizationpageobjects.close_button());
			Result="Failed"+"No data is available for export "+authorizationpageobjects.noRecords_after_export().getText();
		/*wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.noRecords_after_export()));
		if(authorizationpageobjects.noRecords_after_export.isCurrentlyVisible())
		{
			Result="Failed "+authorizationpageobjects.noRecords_after_export().getText();
			authorizationpageobjects.close_button().click();
		}*/
		}
	}
	return Result;
	
}
@Step	
public String verify_the_authorization_detail(String Order_ID,String From_date, String To_date) throws Throwable{
	driver = this.getDriver();
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_Link()));
	dasboardpageobjects.Authorizations_Link().click();
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.Authorizations_text()));
	checkPageIsReady();
	waitForWithRefresh();
	wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.date_dropdown()));
	if(authorizationpageobjects.search_error_message.isCurrentlyVisible())
	{
		executor.executeScript("arguments[0].click()",authorizationpageobjects.date_dropdown());
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.from_date()));
		if(isDateValidforFromDate_Todate(From_date) && isDateValidforFromDate_Todate(To_date))
		{
			authorizationpageobjects.from_date().clear();
			authorizationpageobjects.from_date().sendKeys(From_date);
			wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.to_date()));
			authorizationpageobjects.to_date().clear();
			authorizationpageobjects.to_date().sendKeys(To_date);
			authorizationpageobjects.apply_button().click();
		}
		checkPageIsReady();
		waitForWithRefresh();
		System.out.println(Order_ID);
		authorizationpageobjects.searchFieldText().sendKeys(Order_ID);
		executor.executeScript("arguments[0].click()",authorizationpageobjects.search_orderId());
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.search_button()));
		executor.executeScript("arguments[0].click()",authorizationpageobjects.search_button());
		checkPageIsReady();
		waitForWithRefresh();
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.date_dropdown()));
		System.out.println(authorizationpageobjects.search_success_message().getText().contains(Order_ID));
		if(authorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			Result="Failed "+authorizationpageobjects.search_error_message().getText();
		}
		else if(authorizationpageobjects.Authorization_date.isCurrentlyVisible() 
				&& authorizationpageobjects.search_success_message().getText().contains(Order_ID))
		{
			Result="Passed "+authorizationpageobjects.search_success_message().getText();
		}
	}
	else
	{
		checkPageIsReady();
		waitForWithRefresh();
		authorizationpageobjects.searchFieldText().sendKeys(Order_ID);
		authorizationpageobjects.search_orderId().click();
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.search_button()));
		executor.executeScript("arguments[0].click()",authorizationpageobjects.search_button());
		checkPageIsReady();
		waitForWithRefresh();
		wait.until(ExpectedConditions.elementToBeClickable(authorizationpageobjects.date_dropdown()));
		if(authorizationpageobjects.search_error_message.isCurrentlyVisible())
		{
			Result="Failed "+authorizationpageobjects.search_error_message().getText();
		}
		else if(authorizationpageobjects.Authorization_date.isCurrentlyVisible() 
				&& authorizationpageobjects.search_success_message().getText().contains(Order_ID))
		{
			Result="Passed "+authorizationpageobjects.search_success_message().getText();
		}
	}
	return Result;
}
@Step	
public String Search_the_transaction_detail_by_giving_single_search_criteria(String Merchant_ID_Transaction) throws Throwable{
	driver = this.getDriver();
	int count1=0;
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	WebDriverWait wait = new WebDriverWait(driver, 100);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_Link()));
	dasboardpageobjects.transaction_Link().click();
	checkPageIsReady();
	waitForWithRefresh();
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.transaction_text()));
	checkPageIsReady();
	waitForWithRefresh();
	wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.searchField_Text()));
	checkPageIsReady();
	waitForWithRefresh();
	wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.search_button()));
	checkPageIsReady();
	waitForWithRefresh();
	transactionpageobjects.searchField_Text().sendKeys(Merchant_ID_Transaction);
	transactionpageobjects.merchantID_search().click();
	transactionpageobjects.search_button().click();
	wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.date_dropdown()));
	if(transactionpageobjects.search_error_message.isCurrentlyVisible())
	{
		Result="Failed "+transactionpageobjects.search_error_message().getText();
	}
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(transactionpageobjects.postingDate_text()));
		int count=transactionpageobjects.merchantID_list.size();
        System.out.println("Number of rows in this page is:"+count);

        for(WebElement element:transactionpageobjects.merchantID_list)
        {
                if(element.getText().equalsIgnoreCase(Merchant_ID_Transaction))
                {
                	count1=count1+1;
                    System.out.println(element.getText());
                }
        }
        Result="Passed "+"Total merchant ID is : "+count1+" in this page";
	}

	return Result;
}
public static boolean isDateValidforFromDate_Todate(String date) 
{
    try {
        DateFormat df = new SimpleDateFormat("dd.MM.yyyy");
        df.setLenient(false);
        df.parse(date);
        return true;
    } catch (ParseException e) {
        return false;
    }
}
public static boolean isDateValid(String date) 
{
    try {
        DateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
        df.setLenient(false);
        df.parse(date);
        return true;
    } catch (ParseException e) {
        return false;
    }
}
public boolean isFileDownloaded(String downloadPath, String fileName) throws InterruptedException {
	boolean flag = false;
	File dir = new File(downloadPath);
    File[] dir_contents = dir.listFiles();
  	    
    for (int i = 0; i < dir_contents.length; i++) {
        if (dir_contents[i].getName().contains(fileName))
            return flag=true;
            }
	 
    return flag;
}
private File getLatestFilefromDir(String dirPath){
    File dir = new File(dirPath);
    File[] files = dir.listFiles();
    if (files == null || files.length == 0) {
        return null;
    }

    File lastModifiedFile = files[0];
    for (int i = 1; i < files.length; i++) {
       if (lastModifiedFile.lastModified() < files[i].lastModified()) {
           lastModifiedFile = files[i];
       }
    }
    return lastModifiedFile;
}

public void checkPageIsReady() throws InterruptedException {

	  JavascriptExecutor js = (JavascriptExecutor)driver;


	  //Initially bellow given if condition will check ready state of page.
	/*  if (js.executeScript("return document.readyState").toString().equals("complete")){ 
	
	   return; 
	  } 
*/
	  //This loop will rotate for 25 times to check If page Is ready after every 1 second.
	  //You can replace your value with 25 If you wants to Increase or decrease wait time.
	  for (int i=0; i<100; i++){ 
	   //To check page ready state.
	   if (js.executeScript("return document.readyState").toString().equals("complete")){ 
		   
	    break; 
	   }
	   System.out.println("Page Is loaded.");
	  }
	 }


}
