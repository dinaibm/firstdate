package ui.Signon;

import java.io.File;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.scheduling.ExpectedBackendCondition;
import ui.pageobjects.Signon.DashboardPage_objects;
import ui.pageobjects.Signon.MessagePage_object;
import ui.pageobjects.Signon.SettingsuserPage_object;
import ui.pageobjects.Signon.SignonPage_objects;

public class Terms_Conditions extends PageObject{

	WebDriver driver =null;

	String Result=null;
	boolean Status=false;
	SignonPage_objects signonObjects;
	DashboardPage_objects dasboardpageObjects;
	//MessagePage_Objects messagepageobjects;
	MessagePage_object messagepageObjects;
	SettingsuserPage_object settingspageobjects;
	
@Step
public String download_terms_and_condition(String downloaded_Path) throws InterruptedException{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver, 50);
	wait.until(ExpectedConditions.elementToBeClickable(signonObjects.download_TermsConditions()));
	if(signonObjects.download_TermsConditions.isCurrentlyVisible())
	{
	wait.until(ExpectedConditions.elementToBeClickable(signonObjects.download_TermsConditions()));
	signonObjects.download_TermsConditions().click();
	wait.until(ExpectedConditions.elementToBeClickable(signonObjects.Accept_TermsAndCondition()));
	File getLatestFile = getLatestFilefromDir(downloaded_Path);
    String fileName = getLatestFile.getName();
    long length = getLatestFile.length();
    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0))
    	{
    		Result="Passed "+fileName;
    	}
    else
    	{
    	Result="Failed "+"We didnot find the document in the folder";
    	}
	}
	return Result;	
}
@Step
public String Accept_terms_and_conditions() throws InterruptedException{
	driver = this.getDriver();
	WebDriverWait wait = new WebDriverWait(driver, 10);
	wait.until(ExpectedConditions.elementToBeClickable(signonObjects.Accept_TermsAndCondition()));
	if(signonObjects.Accept_TermsAndCondition.isCurrentlyVisible())
	{
		signonObjects.Accept_TermsAndCondition().click();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Welcome_message()));
		Result="Passed "+"Successfully accepted the terms and conditions ";
	}
	else
	{
		Result="Failed "+" There is no terms and conditions available come back later ";
	}
	return Result;
	
}

public boolean isFileDownloaded(String downloadPath, String fileName) {
	boolean flag = false;
    File dir = new File(downloadPath);
    File[] dir_contents = dir.listFiles();
  	    
    for (int i = 0; i < dir_contents.length; i++) {
        if (dir_contents[i].getName().contains(fileName))
            return flag=true;
            }

    return flag;
}
private File getLatestFilefromDir(String dirPath){
    File dir = new File(dirPath);
    File[] files = dir.listFiles();
    if (files == null || files.length == 0) {
        return null;
    }

    File lastModifiedFile = files[0];
    for (int i = 1; i < files.length; i++) {
       if (lastModifiedFile.lastModified() < files[i].lastModified()) {
           lastModifiedFile = files[i];
       }
    }
    return lastModifiedFile;
}
}
