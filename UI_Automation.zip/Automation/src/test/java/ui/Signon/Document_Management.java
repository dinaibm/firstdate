package ui.Signon;

import java.io.File;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.paulhammant.ngwebdriver.NgWebDriver;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.AdminPage_object;
import ui.pageobjects.Signon.DashboardPage_objects;
import ui.pageobjects.Signon.DocumentAdminPage_object;
import ui.pageobjects.Signon.DocumentPage_object;
import ui.pageobjects.Signon.MessagePage_object;
import ui.pageobjects.Signon.SignonPage_objects;

public class Document_Management extends PageObject{
	WebDriver driver =null;
	String Result=null;
	boolean Status=false;
	MessagePage_object messagepageObjects;
	AdminPage_object adminpageObjects;
	DocumentAdminPage_object documentAdminpageobjects;
	DashboardPage_objects dasboardpageobjects;
	SignonPage_objects signonObjects;
	DocumentPage_object documentpageobjects;
	String document_link=null;
	private static NgWebDriver ngDriver;

@Step
public String permanent_link_Retrive(String userID_LBC,String password_LBC,String downloaded_Path) throws Throwable{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver,50);
	wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.document_link()));
	documentAdminpageobjects.document_link.click();
	wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.search_Textbox()));
	/*documentAdminpageobjects.search_Textbox().sendKeys(Document_Title);
	documentAdminpageobjects.search_button().click();
	wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.search_Textbox()));*/
	//wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.selected_text()));
	System.out.println(documentAdminpageobjects.selected_text.isCurrentlyVisible());
	String Document_title=documentAdminpageobjects.selected_text().getText();
	if(documentAdminpageobjects.selected_text.isCurrentlyVisible())
	{
		System.out.println(documentAdminpageobjects.selected_text().getText());
		documentAdminpageobjects.selected_text().click();
		if(documentAdminpageobjects.document_link_of_each_document.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.document_link_of_each_document()));
			document_link=documentAdminpageobjects.document_link_of_each_document().getText();
			driver.get(document_link);
			wait.until(ExpectedConditions.elementToBeClickable(signonObjects.userId_LBC()));
			signonObjects.userId_LBC().sendKeys(userID_LBC);
			wait.until(ExpectedConditions.elementToBeClickable(signonObjects.password_LBC()));
			signonObjects.password_LBC().sendKeys(password_LBC);
			signonObjects.submit_lbc().click();
			wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.dashboard_text_LBC()));
			File getLatestFile = getLatestFilefromDir(downloaded_Path);
		    String fileName = getLatestFile.getName();
		    String []filedetails=fileName.split("_");
		    long length = getLatestFile.length();
		   
		    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) || filedetails[0].contains(Document_title))
		    	{
		    		Result="Passed "+fileName+" The document can be downloaded from outside";
		    	}
		    else
		    	{
		    		Result="Failed "+"We didnot find the document in the folder";
		    	}
		}
		else
		{
			Result="Failed "+"The document link is not found";
		}
	}
	return Result;
}
@Step
public String Add_a_new_document(String document_Name,String Alliance_name,String Language,String Upload_file,String attachmentPath,String Description_DocumentText) throws Throwable{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver,100);
	wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.document_link()));
	documentAdminpageobjects.document_link().click();
	wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.add_button()));
	documentAdminpageobjects.add_button().click();
	wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.documentName()));
	documentAdminpageobjects.documentName().sendKeys(document_Name);
	wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.alliance_code()));
	documentAdminpageobjects.alliance_code().sendKeys(Alliance_name);
	checkPageIsReady();
	waitFor(documentAdminpageobjects.language());
	checkPageIsReady();
	documentAdminpageobjects.language().sendKeys(Language);
	checkPageIsReady();
	waitFor(documentAdminpageobjects.attachmentPath());
	checkPageIsReady();
	documentAdminpageobjects.attachmentPath().sendKeys(attachmentPath);
	documentAdminpageobjects.description().sendKeys(Description_DocumentText);
	waitFor(documentAdminpageobjects.documentPath());
	documentAdminpageobjects.documentPath().sendKeys(Upload_file);
	waitFor(documentAdminpageobjects.uploadeButton());
	documentAdminpageobjects.uploadeButton().click();
	File f = new File(Upload_file);
	System.out.println(f.getName());
	String filename=f.getName();
	wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.message_top_panel()));
	if(documentAdminpageobjects.message_top_panel().getText().contains('"'+filename+'"'+" was uploaded. Please save to continue"))
	{
		if(!documentAdminpageobjects.error_message.isCurrentlyVisible())
		{
			documentAdminpageobjects.submit_button().click();
			wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.message_top_panel()));
			if(documentAdminpageobjects.message_top_panel().getText().contains("Document has been added successfully."))
			{
				Result="Passed "+documentAdminpageobjects.message_top_panel().getText();
			}
			else
			{
				Result="Failed "+"Document has not been added properly.";
			}
		}
		else
		{
			Result="Failed "+"Document needs more input.";
		}
	}
	else
	{
		Result="Failed "+"Failed to attach the file";
	}
	return Result;
}
@Step
public String Rename_a_document(String Rename_document,String Upload_file) throws Throwable{
	driver = this.getDriver();	
	WebDriverWait wait = new WebDriverWait(driver,50);
	wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.document_link()));
	documentAdminpageobjects.document_link().click();
	wait.until(ExpectedConditions.elementToBeClickable(documentAdminpageobjects.selected_firstRow()));
	File f = new File(Upload_file);
	System.out.println(f.getName());
	String filename=f.getName();
	if(documentAdminpageobjects.selected_firstRow().getText().contains(filename))
	{
		documentAdminpageobjects.selected_firstRow().click();
		waitFor(documentAdminpageobjects.documentName());
		documentAdminpageobjects.documentName().clear();
		documentAdminpageobjects.documentName().sendKeys(Rename_document);
		waitFor(documentAdminpageobjects.submit_button());
		documentAdminpageobjects.submit_button().click();
		waitFor(documentAdminpageobjects.message_top_panel());
		if(documentAdminpageobjects.message_top_panel().getText().contains("Document has been added successfully."))
		{
			Result="Passed "+documentAdminpageobjects.message_top_panel().getText();
		}
		else
		{
			Result="Failed "+"Document has not been added properly.";
		}
	}
	else
	{
		Result="Failed "+"No Document are there for now";
	}
	return Result;
}
@Step
public String marked_unread_document(/*String folderName*/) throws Throwable{
	driver = this.getDriver();
	int count1=0;
	String Result1=null;
	WebDriverWait wait = new WebDriverWait(driver, 20);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.documents_Link()));
	dasboardpageobjects.documents_Link().click();
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.documents_text()));
	int count=documentpageobjects.folderslist.size();
    System.out.println("Number of folders is:"+count);
/*for(WebElement unreadList:documentpageobjects.unreadList)
{
	waitFor(unreadList);
	if(unreadList.isDisplayed())
	{*/
		
	

    for(WebElement folderlist:documentpageobjects.folderslist)

    {
    	System.out.println(folderlist.getText());
    	 /* if(folderlist.getText().equalsIgnoreCase(folderName));
    	  {*/
    	waitFor(folderlist).click();
    	//waitFor(documentpageobjects.DocumentList);
   	for(WebElement documentList:documentpageobjects.DocumentList)
    	{
    		waitFor(documentList);
    		String unread_status=documentList.getAttribute("class");
    				if(unread_status.equals("ng-binding"))
    				{
    					Result1="Passed "+"For Now no unread documents are present";
    				}
                    
    				else
    				{
    					
    					count1 =count1+1;
    					Result1="Passed "+"Unread count is : "+count1;
    				}
    	}
	
            
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.documents_Link()));
		dasboardpageobjects.documents_Link().click();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageobjects.documents_text()));
    }


    Result=Result1;
    
	return Result;
}
public static boolean isDateValid(String date) 
{
    try {
        DateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
        df.setLenient(false);
        df.parse(date);
        return true;
    } catch (ParseException e) {
        return false;
    }
}
public boolean isFileDownloaded(String downloadPath, String fileName) throws InterruptedException {
	boolean flag = false;
	File dir = new File(downloadPath);
    File[] dir_contents = dir.listFiles();
  	    
    for (int i = 0; i < dir_contents.length; i++) {
        if (dir_contents[i].getName().contains(fileName))
            return flag=true;
            }
	 
    return flag;
}
private File getLatestFilefromDir(String dirPath){
    File dir = new File(dirPath);
    File[] files = dir.listFiles();
    if (files == null || files.length == 0) {
        return null;
    }

    File lastModifiedFile = files[0];
    for (int i = 1; i < files.length; i++) {
       if (lastModifiedFile.lastModified() < files[i].lastModified()) {
           lastModifiedFile = files[i];
       }
    }
    return lastModifiedFile;
}
public void checkPageIsReady() throws InterruptedException {

	  JavascriptExecutor js = (JavascriptExecutor)driver;


	  //Initially bellow given if condition will check ready state of page.
	/*  if (js.executeScript("return document.readyState").toString().equals("complete")){ 
	
	   return; 
	  } 
*/
	  //This loop will rotate for 25 times to check If page Is ready after every 1 second.
	  //You can replace your value with 25 If you wants to Increase or decrease wait time.
	  for (int i=0; i<100; i++){ 
	   //To check page ready state.
	   if (js.executeScript("return document.readyState").toString().equals("complete")){ 
		   
	    break; 
	   }
	   System.out.println("Page Is loaded.");
	  }
	 }


}

