package ui.Signon;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.AdminPage_object;
import ui.pageobjects.Signon.DashboardPage_objects;
import ui.pageobjects.Signon.ExportEmaiAdminlPage_object;
import ui.pageobjects.Signon.SettingsuserPage_object;
import ui.pageobjects.Signon.SignonPage_objects;
import ui.pageobjects.Signon.UserManagementPage_objects;
public class User_management extends PageObject{

	String Result=null,Error_message=null;
	WebDriver driver =null;
	SignonPage_objects signonObjects;
	DashboardPage_objects dasboardpageObjects;
	AdminPage_object adminPageobjects;
	UserManagementPage_objects usermanagePageobjects;
	SettingsuserPage_object settingspageobjects;
	ExportEmaiAdminlPage_object exportemailadminobjects;

@Step
public void loadbrowser(){
	
	System.out.println("Loading Browser");
	System.out.println("Launched CHrome Browser");
	driver = this.getDriver();	
}
	
@Step
public String navigate(String url) throws Exception{
	driver.get(url);
	WebDriverWait wait = new WebDriverWait(driver, 60);
	wait.until(ExpectedConditions.elementToBeClickable(signonObjects.UserName()));
	if(signonObjects.UserName.isCurrentlyVisible())
	{
		Result="Passed "+"WebPage is available for next action";
	}
	else
	{
		Result="Failed "+"WebPage in not loaded.";
	}
	return Result;
}
@Step
public void RememberMe() throws InterruptedException{
	WebDriverWait wait = new WebDriverWait(driver, 10);
	wait.until(ExpectedConditions.elementToBeClickable(signonObjects.RememberMe()));
	if(signonObjects.RememberMe().isDisplayed()){
		signonObjects.RememberMe().click();
	}
	
}
@Step
public String userInput(String fieldName, String fieldValue) throws InterruptedException{
	System.out.println(fieldName);
	WebDriverWait wait = new WebDriverWait(driver, 10);
	if (fieldName.equals("UserName")){
		wait.until(ExpectedConditions.elementToBeClickable(signonObjects.UserName()));
		signonObjects.UserName().sendKeys(fieldValue);
		Result="Passed";
	}
	
	else if(fieldName.equals("Password"))
	{
		signonObjects.Password().sendKeys(fieldValue);
		Result="Passed";
	}
	else if(fieldName.equals("Alliance"))
	{
		signonObjects.alliance().sendKeys(fieldValue);
		Result="Passed";
	}
	else
	{
		Result="Failed";
	}
	return Result;
}
@Step
public String Submitlogin_for_alert_testcase() throws InterruptedException{
	WebDriverWait wait = new WebDriverWait(driver, 30);
	
	signonObjects.Submit().click();
	if(signonObjects.error_message_invalidLogin.isCurrentlyVisible())
	{
		Result="Failed "+signonObjects.error_message_invalidLogin().getText();
	}
	else
	{
		Result="Passed "+"Successfully login to the system";
	}
	
	return Result;
	
}
@Step
public String Submitlogin(String welcome_text) throws InterruptedException{
	WebDriverWait wait = new WebDriverWait(driver, 30);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	signonObjects.Submit().click();
	waitForWithRefresh();
	//wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Welcome_message()));
	if(signonObjects.error_message_invalidLogin.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(signonObjects.error_message_invalidLogin()));
		Result="Failed "+signonObjects.error_message_invalidLogin().getText();
	}
	else
	{
		
		if(signonObjects.Accept_TermsAndCondition.isCurrentlyVisible())
		{
			executor.executeScript("arguments[0].click()",signonObjects.Accept_TermsAndCondition());
		}
		if(dasboardpageObjects.unread_alerts.isCurrentlyVisible())
		{
			executor.executeScript("arguments[0].click()",dasboardpageObjects.unread_alerts());
		}
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.login_date()));
		String login=dasboardpageObjects.login_date().getText();
		String status=dasboardpageObjects.Welcome_message().getText();
		System.out.println(welcome_text+" "+status+" "+login);
			if(dasboardpageObjects.Welcome_message().getText().contains(welcome_text)/* || dasboardpageObjects.login_date().equals("Last login ")*/)
			{
				Result="Passed "+"Successfully login to the system";
			}
	}
	return Result;
}
@Step
public String login_admin_console() throws InterruptedException{
	WebDriverWait wait = new WebDriverWait(driver, 30);
	signonObjects.login_admin().click();
	wait.until(ExpectedConditions.elementToBeClickable(signonObjects.Welcome_text_admin()));
	if(signonObjects.Welcome_text_admin().getText().contains("User"))
	{
		Result="Passed";
	}
	else {
		Result="Failed";
				
	}
	
	return Result;
}
@Step
public String last_login_date_time_in_home_page() throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 10);
	if(dasboardpageObjects.last_login_date_time.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.last_login_date_time()));
		String [] login_date_time=dasboardpageObjects.last_login_date_time().getText().split(",");
		Result="Passed  "+ "The last_login date is : "+login_date_time[0]+" and "+" The time is : "+login_date_time[1];
		
	}
	else
	{
		Result="Failed"+" No Last login date are available";
	}
	
	
	return Result;
}
@Step 
public String Create_email_template(String email_type, String description, String allianceType, String emailaddress, String Email_body_text, String attachmentPath) throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 10);
	adminPageobjects.Email_template().click();
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Add_button()));
	adminPageobjects.Add_button().click();
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.email_type()));
	adminPageobjects.email_type().sendKeys(email_type);
	adminPageobjects.email_description().sendKeys(description);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.allianceType()));
	adminPageobjects.allianceType().sendKeys(allianceType);
	adminPageobjects.fromEmailAddress().sendKeys(emailaddress);
	adminPageobjects.emailbody().sendKeys(Email_body_text);
	adminPageobjects.email_attachment().sendKeys(attachmentPath);
	adminPageobjects.uploadbutton_attachment_email().click();
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.save_button()));
	adminPageobjects.save_button().click();
	//if(adminPageobjects.Created_successfully_text().getText().contains("SHSH"))
	return Result;
	
}
@Step
public String create_new_allianz_user(String User_Type,String Alliance_name,String Profile_type,String First_Name,String last_name,String email_id,String UserName_new_alliance,String mobile_number,String Language)throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 1000);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.create_user()));
	adminPageobjects.create_user().click();
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.user_type()));
	adminPageobjects.user_type().sendKeys(User_Type);
	checkPageIsReady();
	waitForWithRefresh();
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.allianceType()));
	adminPageobjects.allianceType().sendKeys(Alliance_name);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.profile_type()));
	waitForWithRefresh();
	//driver.waitForAngular();
	adminPageobjects.profile_type().sendKeys(Profile_type);
	if(UserName_new_alliance.length()==8 || !(UserName_new_alliance.length()<8) || !(UserName_new_alliance.length()>25))
	{
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.firstName()));
	adminPageobjects.firstName().sendKeys(First_Name);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.lastName()));
	adminPageobjects.lastName().sendKeys(last_name);
	adminPageobjects.email_id().sendKeys(email_id);
	adminPageobjects.mobileNUmber().sendKeys(mobile_number);
	adminPageobjects.Language_msg_dropdown().sendKeys(Language);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.UserName_new_alliance()));
	adminPageobjects.UserName_new_alliance().sendKeys(UserName_new_alliance);
	Result="passed  ";
	}
	else
	{
		Result="Failed  ";
	}
		adminPageobjects.save_button().click();
		wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Created_successfully_text()));
		if(adminPageobjects.Created_successfully_text().getText().contains("User has been added successfully"))
		{
			Result="Passed  "+adminPageobjects.Created_successfully_text().getText();
		}
		else
		{
			Result="Failed  "+adminPageobjects.Created_successfully_text().getText();
		}
	return Result;	
}
@Step
public String Create_new_merchant(String User_Type,String Merchant_ID,String Profile_type,String First_Name,String last_name,String UserName_new_alliance,String email_id,String mobile_number,String Language) throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 100);
	//JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.create_user_boardingagent()));
	adminPageobjects.create_user_boardingagent.click();
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.user_type()));
	adminPageobjects.user_type().sendKeys(User_Type);
	checkPageIsReady();
	adminPageobjects.merchantID.isCurrentlyVisible();
	System.out.println(adminPageobjects.merchantID.isCurrentlyVisible());
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.merchantID()));
    adminPageobjects.merchantID().sendKeys(Merchant_ID);

    for(WebElement element:adminPageobjects.merchantList)

    {
        if(element.getText().contains(Merchant_ID))
        waitFor(element).click();
    }
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.profile_type()));
	adminPageobjects.profile_type().sendKeys(Profile_type);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.firstName()));
	adminPageobjects.firstName().sendKeys(First_Name);
	adminPageobjects.lastName().sendKeys(last_name);
	adminPageobjects.email_id().sendKeys(email_id);
	if(UserName_new_alliance.length()==8 || !(UserName_new_alliance.length()<8) || !(UserName_new_alliance.length()>25))
	{
		adminPageobjects.mobileNUmber().sendKeys(mobile_number);
		wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Language_msg_dropdown()));
		adminPageobjects.Language_msg_dropdown().sendKeys(Language);
		wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.UserName_new_alliance()));
		adminPageobjects.merchantID.isCurrentlyVisible();
		System.out.println(adminPageobjects.UserName_new_alliance.isCurrentlyVisible());
		wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.UserName_new_alliance()));
		adminPageobjects.UserName_new_alliance().sendKeys(UserName_new_alliance);	
	}
	else
	{
		Result="Failed  ";
	}
		adminPageobjects.save_button().click();
		if(adminPageobjects.Field_error_message.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Field_error_message()));
			Result="Failed "+"User cannot be created suceesfully "+adminPageobjects.Field_error_message().getText();
		}
		/*else if(adminPageobjects.PanelError.isCurrentlyVisible())
		{
			wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.PanelError()));
			Result="Failed "+"User cannot be created suceesfully "+adminPageobjects.PanelError().getText();
		}*/
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Created_successfully_text()));
			if(adminPageobjects.Created_successfully_text().getText().contains("User has been added successfully."))
			{
				wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Created_successfully_text()));
				Result="Passed  "+adminPageobjects.Created_successfully_text().getText();
			}
			else
			{
				wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Created_successfully_text()));
				Result="Failed "+"User cannot be created suceesfully "+adminPageobjects.PanelError().getText();
			}
		}
return Result;	
}
@Step
public String Validate_profile_information() throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 20);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_option()));
	dasboardpageObjects.more_option().click();
	dasboardpageObjects.settings().click();
	wait.until(ExpectedConditions.elementToBeClickable(settingspageobjects.First_LastName()));
	if(settingspageobjects.First_LastName.isCurrentlyVisible() && dasboardpageObjects.Welcome_message().getText().contains(settingspageobjects.First_LastName().getText()) && 
			settingspageobjects.email_addres.isCurrentlyVisible() && settingspageobjects.mobile_number.isCurrentlyVisible() && settingspageobjects.userName.isCurrentlyEnabled())
	{
		Result="Passed "+" Firstname and last Name of the account: "+settingspageobjects.First_LastName().getText()+" Email address of the account: "+
			settingspageobjects.email_addres().getText()+" Mobile Number of the user: "+settingspageobjects.mobile_number().getText()+" UserName of the user Account "+settingspageobjects.userName().getText();
	}
	else
	{
		Result="Failed "+"No in formation is there..Error in fetching the details";
	}
	return Result;
	
}
@Step
public String Change_Password_of_BO(String New_password, String password) throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 20);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.more_option()));
	dasboardpageObjects.more_option().click();
	dasboardpageObjects.settings().click();
	wait.until(ExpectedConditions.elementToBeClickable(settingspageobjects.changePassword_link()));
	executor.executeScript("arguments[0].click()",settingspageobjects.changePassword_link());
	if(settingspageobjects.oldPassword.isCurrentlyVisible() && settingspageobjects.newPassword.isCurrentlyVisible() && !password.equals(New_password) && New_password.length()==8 
			|| !(New_password.length()<8) && !(New_password.length()>=25))
	{
		settingspageobjects.oldPassword().sendKeys(password);
		settingspageobjects.newPassword().sendKeys(New_password);
		settingspageobjects.confirmPassword().sendKeys(New_password);
	}
	else
	{
		Result="Failed";
	}
	executor.executeScript("arguments[0].click()",settingspageobjects.continue_button());
	if(settingspageobjects.passwordErromessage.isCurrentlyVisible())
	{
		Result="Failed to change the password Got the error like : "+settingspageobjects.passwordErromessage().getText();
	}
	else
	{
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Continue_dashboard_button()));
		String SuccessPasswordMessage=settingspageobjects.passwordsetmessage().getText();
		dasboardpageObjects.Continue_dashboard_button().click();
		wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Welcome_message()));
		Result="Passed "+ " Successfully Change the password " +SuccessPasswordMessage;
	}
	return Result;	
}
@Step
public String Password_expire_message(String New_password, String password) throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 20);
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.passwordExpireMessage()));
	if(dasboardpageObjects.passwordExpireMessage.isCurrentlyVisible())
	{
		String ExpiredMessage = dasboardpageObjects.passwordExpireMessage().getText();
		dasboardpageObjects.passwordExpirelink().click();
		wait.until(ExpectedConditions.elementToBeClickable(settingspageobjects.oldPassword()));
		if(settingspageobjects.oldPassword.isCurrentlyVisible() && settingspageobjects.newPassword.isCurrentlyVisible() && !password.equals(New_password) && New_password.length()==8 
				|| !(New_password.length()<8) && !(New_password.length()>=25))
		{
			settingspageobjects.oldPassword().sendKeys(password);
			settingspageobjects.newPassword().sendKeys(New_password);
			settingspageobjects.confirmPassword().sendKeys(New_password);
		}
		else
		{
			Result="Failed";
		}
		settingspageobjects.continue_button().click();
		if(settingspageobjects.passwordErromessage.isCurrentlyVisible())
		{
			Result="Failed to change the password Got the error like : "+settingspageobjects.passwordErromessage().getText();
		}
		else
		{
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Continue_dashboard_button()));
			String SuccessPasswordMessage=settingspageobjects.passwordsetmessage().getText();
			dasboardpageObjects.Continue_dashboard_button().click();
			wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.Welcome_message()));
			Result="Passed "+" Previously got the message like this : "+ ExpiredMessage +" After changing the password :" +SuccessPasswordMessage;
		}
	}
	else
	{
		Result="Passed "+"Pasword has been changed ";
	}
	return Result;
}
@Step
public String Search_User_in_Admin_console(String First_Name, String last_name,String UserName_new_alliance) throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 20);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.users_list()));
	adminPageobjects.users_list().click();
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Filter_button()));
	adminPageobjects.Filter_button().click();
	waitFor(adminPageobjects.firstname_filter());
	//wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Filter_button()));
	//wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.firstname_filter()));
	adminPageobjects.firstname_filter().sendKeys(First_Name);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.lastname_filter()));
	adminPageobjects.lastname_filter().sendKeys(last_name);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.username_filter()));
	adminPageobjects.username_filter().sendKeys(UserName_new_alliance);
	wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.Applybutton_filter()));
	adminPageobjects.Applybutton_filter().click();
	if(!adminPageobjects.no_records_found.isCurrentlyVisible())
	{
		wait.until(ExpectedConditions.elementToBeClickable(adminPageobjects.selected_message()));
		if(adminPageobjects.username_text().getText().contains(UserName_new_alliance))
		{
			Result="Passed "+"Admin able to see the "+UserName_new_alliance;
		}
		else
		{
			Result="Failed "+"Username is not matched with "+UserName_new_alliance;
		}
	}
	else
	{
		Result="Failed "+adminPageobjects.no_records_found.getText();
	}
	return Result;
}
@Step
public String Export_the_alliance_user_list(String Alliance_name,String downloaded_Path) throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 50);
	//JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.elementToBeClickable(exportemailadminobjects.Export_email_link()));
	exportemailadminobjects.Export_email_link().click();
	waitFor(exportemailadminobjects.alliance_drop_down());
	if(exportemailadminobjects.No_record_found_text.isCurrentlyVisible())
	{
		exportemailadminobjects.alliance_drop_down().sendKeys(Alliance_name);
		checkPageIsReady();
		wait.until(ExpectedConditions.elementToBeClickable(exportemailadminobjects.First_Record()));
		waitFor(exportemailadminobjects.csv_button());
		exportemailadminobjects.csv_button().click();
		checkPageIsReady();
	    waitFor(exportemailadminobjects.csv_button());
	    driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		File getLatestFile = getLatestFilefromDir(downloaded_Path);
	    String fileName = getLatestFile.getName();
	    long length = getLatestFile.length();
	    checkPageIsReady();
	    waitFor(exportemailadminobjects.csv_button());
	    driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	    if(isFileDownloaded(downloaded_Path, fileName) && !(length==0) && fileName.endsWith(".csv"))
	    	{
	    		Result="Passed "+fileName+"Successfully exported the document";
	    	}
	    else
	    	{
	    		Result="Failed "+"We didnot find the document in the folder";
	    	}
	}
	
	return Result;
}
@Step
public String logout() throws Throwable{
	WebDriverWait wait = new WebDriverWait(driver, 50);
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.logout()));
	if(dasboardpageObjects.logout.isCurrentlyVisible())
	{
		executor.executeScript("arguments[0].click()",dasboardpageObjects.logout());
		Result="Passed "+ "Successfully logout from the system. ";
	}
	else
	{
		Result="Failed "+"Failed to logout. ";
	}
	return Result;
}
public boolean isFileDownloaded(String downloadPath, String fileName) throws InterruptedException {
	boolean flag = false;
	File dir = new File(downloadPath);
    File[] dir_contents = dir.listFiles();
  	    
    for (int i = 0; i < dir_contents.length; i++) {
        if (dir_contents[i].getName().contains(fileName))
            return flag=true;
            }
	 
    return flag;
}
private File getLatestFilefromDir(String dirPath) throws InterruptedException{
    File dir = new File(dirPath);
    File[] files = dir.listFiles();
    if (files == null || files.length == 0) {
        return null;
    }

    File lastModifiedFile = files[0];
    for (int i = 1; i < files.length; i++) {
       if (lastModifiedFile.lastModified() < files[i].lastModified()) {
           lastModifiedFile = files[i];
       }
    }
    return lastModifiedFile;
}
public void checkPageIsReady() throws InterruptedException {

	  JavascriptExecutor js = (JavascriptExecutor)driver;


	  //Initially bellow given if condition will check ready state of page.
	/*  if (js.executeScript("return document.readyState").toString().equals("complete")){ 
	
	   return; 
	  } 
*/
	  //This loop will rotate for 25 times to check If page Is ready after every 1 second.
	  //You can replace your value with 25 If you wants to Increase or decrease wait time.
	  for (int i=0; i<100; i++){ 
	   //To check page ready state.
	   if (js.executeScript("return document.readyState").toString().equals("complete")){ 
		   
	    break; 
	   }
	   System.out.println("Page Is loaded.");
	  }
	 }

}






