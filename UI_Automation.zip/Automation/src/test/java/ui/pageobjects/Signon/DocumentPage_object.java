package ui.pageobjects.Signon;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class DocumentPage_object extends PageObject{

//EMS
@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > ul > li:nth-child(1) > a > h3")
public WebElementFacade ENDemo_Link;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > ul > li:nth-child(2) > a > h3")
public WebElementFacade ENMarketingInfo_Link;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > ul > li:nth-child(3) > a > h3")
public WebElementFacade ENNewsLetter_Link;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > ul > li:nth-child(4) > a > h3")
public WebElementFacade ENVideo_Link;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > ul > li:nth-child(5) > a > h3")
public WebElementFacade ENManuals_Link;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > ul > li:nth-child(6) > a > h3")
public WebElementFacade ENOthers_Link;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > ul > li:nth-child(7) > a > h3")
public WebElementFacade ENTest_Link;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div > files-tile-view > a > i")
public WebElementFacade listwiseView;
//label[for$=cleckbox-0]
//input[type^=checkbox][id*=cleckbox-1]
@FindBy(css="[ng-model*='vm.allFilesSelected']")
public String Fileonecheckbox;

@FindBy(css="li > a[href*='#/documents/folder/']")
public List<WebElement> folderslist;

@FindBy(css="ul > li > a > h3 > span")
public List<WebElement> unreadList;

@FindBy(css="ul > li > div > p")
public List<WebElement> DocumentList;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div > files-table-view > table > tbody > tr:nth-child(2) > td:nth-child(1) > div > label")
public WebElementFacade Filetwocheckbox;


public  List<WebElement> unreadList(){
    return unreadList;
}
public  List<WebElement> folderslist(){
    return folderslist;
}
public  List<WebElement> DocumentList(){
    return DocumentList;
}
public  WebElement ENDemo_Link(){
    return ENDemo_Link;
}
public  WebElement ENMarketingInfo_Link(){
    return ENMarketingInfo_Link;
}
public  WebElement ENNewsLetter_Link(){
    return ENNewsLetter_Link;
}
public  WebElement ENVideo_Link(){
    return ENVideo_Link;
}
public  WebElement ENManuals_Link(){
    return ENManuals_Link;
}
public  WebElement ENOthers_Link(){
    return ENOthers_Link;
}
public  WebElement ENTest_Link(){
    return ENTest_Link;
}
public  String Fileonecheckbox(){
    return Fileonecheckbox;
}
public  WebElement Filetwocheckbox(){
    return Filetwocheckbox;
}
public WebElement listwiseView() {
	return listwiseView;
}
}
