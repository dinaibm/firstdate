package ui.pageobjects.Signon;

import java.util.List;

import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class TransactionPage_object extends PageObject{

//EMS	
@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > form > div.date-picker > div > span.input-group-btn > button > i")
//#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > form > div.date-picker > div > span.input-group-btn > button > i")
public WebElementFacade date_dropdown;
///.btn.flat-button
@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(1)")
public WebElementFacade Todays_Date_filter;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(2)")
public WebElementFacade LastsevenDays_filter;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(3)")
public WebElementFacade this_week_filter;

@FindBy(css=".extended-interface > button:nth-child(4)")
public WebElementFacade Last_month_filter;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > div > button.info.ng-scope")
public WebElementFacade apply_button;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > form > div.export > button > span.text.ng-scope")
public WebElementFacade export_button;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > no-records > div > div > div.header > span:nth-child(2)")
public WebElementFacade search_error_message;

@FindBy(css="#merchant-portal > div.modal.fade.ng-isolate-scope.popup.transaction-export.no-results.in > div > div > div.modal-body-norecords.ng-scope")
public WebElementFacade nodata_export_error_message;

@FindBy(css="#merchant-portal > div.modal.fade.ng-isolate-scope.popup.transaction-export.in > div > div > div.modal-body.ng-scope > div:nth-child(3) > p")
public WebElementFacade xmlFile_option;

@FindBy(css="#merchant-portal > div.modal.fade.ng-isolate-scope.popup.transaction-export.in > div > div > div.modal-body.ng-scope > div.export-inside.ng-scope.selected > p")
public WebElementFacade xlsFile_option;

@FindBy(css="#merchant-portal > div.modal.fade.ng-isolate-scope.popup.transaction-export.in > div > div > div.modal-body.ng-scope > div:nth-child(2) > p > span:nth-child(3)")
public WebElementFacade csvFile_option;

@FindBy(css="#merchant-portal > div.modal.fade.ng-isolate-scope.popup.transaction-export.in > div > div > div.modal-footer.ng-scope > button:nth-child(1)")
public WebElementFacade download_button;

@FindBy(css="span[class*=date-desktop]")
public WebElementFacade table_lastRow;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(5) > span.date > input")
public WebElementFacade fromdate;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(6) > span.date > input")
public WebElementFacade todate;

@FindBy(css="#search-container > ul > li:nth-child(2) > a > span:nth-child(3)")
public WebElementFacade merchantID_search;

@FindBy(css="[name*=oneSearchField]")
public WebElementFacade searchField_Text;

@FindBy(css="button.default-button.x-small.blue.search-button.desktop-tablet.ng-scope")
public WebElementFacade search_button;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-w-8.tg-fixed-w-8.tg-col-id-1.sortable > span > span.header-label.ng-binding.ng-scope")
public WebElementFacade postingDate_text;

@FindBy(css="div.tg-row > div.tg-column.ng-scope.tg-w-7.tg-fixed-w-7.tg-col-id-3 > span")
public List<WebElement> merchantID_list;

public List<WebElement> merchantID_list(){
	return merchantID_list;
}
public WebElement postingDate_text(){
	return postingDate_text;
}
public WebElement search_button(){
	return search_button;
}
public WebElement searchField_Text(){
	return searchField_Text;
}
public WebElement merchantID_search(){
	return merchantID_search;
}
public WebElement date_dropdown(){
	return date_dropdown;
}
public WebElement fromdate(){
	return fromdate;
}
public WebElement todate(){
	return todate;
}
public  WebElement Todays_Date_filter(){
    return Todays_Date_filter;
}
public  WebElement LastsevenDays_filter(){
    return LastsevenDays_filter;
}
public  WebElement this_week_filter(){
    return this_week_filter;
}
public  WebElement Last_month_filter(){
    return Last_month_filter;
}
public  WebElement apply_button(){
    return apply_button;
}
public WebElement search_error_message(){
	return search_error_message;
}
public WebElement export_button(){
	return export_button;
}
public WebElement nodata_export_error_message(){
	return nodata_export_error_message;
}
public WebElement xmlFile_option(){
	return xmlFile_option;
}
public WebElement xlsFile_option(){
	return xlsFile_option;
}
public WebElement csvFile_option(){
	return csvFile_option;
}
public WebElement download_button(){
	return download_button;
}
public WebElement table_lastRow(){
	return table_lastRow;
}
}
