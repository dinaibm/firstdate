package ui.pageobjects.Signon;
import org.openqa.selenium.WebElement;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class SignonPage_objects extends PageObject{

//EMS
@FindBy(css="#username")
public WebElementFacade UserName;

@FindBy(css="#password")
public WebElementFacade Password;

@FindBy(css="label.ng-scope")
public WebElementFacade RememberMe;

@FindBy(css="#submit")
public WebElementFacade Submit;

@FindBy(css="#main > div:nth-child(2) > div > div > div > div:nth-child(1) > div > div > section > div > form > div.fade-animation.validate-container.validation-error > div > p.ng-binding.ng-scope")
public WebElementFacade error_message_invalidLogin;

//LBC
@FindBy(css="body > div.modal.fade.ng-isolate-scope.login-modal.in > div > div > div > form > div.inputs > div:nth-child(2) > input")
public WebElementFacade userId_LBC;

@FindBy(css="body > div.modal.fade.ng-isolate-scope.login-modal.in > div > div > div > form > div.inputs > div:nth-child(3) > input")
public WebElementFacade password_LBC;

@FindBy(css="body > div.modal.fade.ng-isolate-scope.login-modal.in > div > div > div > form > div.inputs > button")
public WebElementFacade submit_lbc;

@FindBy(css="#merchant-portal > div.modal.fade.ng-isolate-scope.popup.terms-conditions.in > div > div > div.modal-footer.ng-scope > a")
public WebElementFacade download_TermsConditions;

@FindBy(css="#merchant-portal > div.modal.fade.ng-isolate-scope.popup.terms-conditions.in > div > div > div.modal-footer.ng-scope > button")
public WebElementFacade Accept_TermsAndCondition;

//Admin
@FindBy(css="#allianceLogin")
public WebElement alliance;

@FindBy(css="#login")
public WebElement login_admin;

@FindBy(css="#panel-user-label")
public WebElement Welcome_text_admin;

public  WebElement userId_LBC(){
    return userId_LBC;
}
public  WebElement password_LBC(){
    return password_LBC;
}
public  WebElement submit_lbc(){
    return submit_lbc;
}
public  WebElement UserName(){
    return UserName;
}
public WebElement Password(){
    return Password;
}
public WebElement Submit(){
    return Submit;
}
public WebElement error_message_invalidLogin(){
	return error_message_invalidLogin;
}
public WebElement RememberMe() {
	// TODO Auto-generated method stub
	return RememberMe;
}
public WebElement alliance(){
    return alliance;
}
public WebElement login_admin(){
    return login_admin;
}
public WebElement Welcome_text_admin(){
    return Welcome_text_admin;
}
public WebElement download_TermsConditions(){
	return download_TermsConditions;
}
public WebElement Accept_TermsAndCondition(){
	return Accept_TermsAndCondition;
}
}

