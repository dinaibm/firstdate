package ui.pageobjects.Signon;

import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class PreAuthorizationPage_object extends PageObject{

//EMS	
@FindBy(css=".btn.flat-button")
//#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > form > div.date-picker > div > span.input-group-btn > button > i")
public WebElementFacade date_dropdown;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(1)")
public WebElementFacade Todays_Date_filter;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(2)")
public WebElementFacade LastsevenDays_filter;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(3)")
public WebElementFacade this_week_filter;

@FindBy(css=".extended-interface > button:nth-child(4)")
public WebElementFacade Last_month_filter;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > div > button.info.ng-scope")
public WebElementFacade apply_button;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > preauthorization-search > no-records > div > div > div.header > span:nth-child(2)")
public WebElementFacade search_error_message;

public WebElement date_dropdown(){
	return date_dropdown;
}
public  WebElement Todays_Date_filter(){
    return Todays_Date_filter;
}
public  WebElement LastsevenDays_filter(){
    return LastsevenDays_filter;
}
public  WebElement this_week_filter(){
    return this_week_filter;
}
public  WebElement Last_month_filter(){
    return Last_month_filter;
}
public  WebElement apply_button(){
    return apply_button;
}
public WebElement search_error_message(){
	return search_error_message;
}
}
