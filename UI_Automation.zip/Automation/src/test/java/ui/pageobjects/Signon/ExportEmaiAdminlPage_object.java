package ui.pageobjects.Signon;

import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class ExportEmaiAdminlPage_object extends PageObject{

	//EMS
@FindBy(css="#menu-links > div:nth-child(4) > a")
public WebElementFacade Export_email_link;

@FindBy(css="[id*=id] > tfoot > tr > td > div")
public WebElementFacade No_record_found_text;

@FindBy(css="[name*=allianceName]")
public WebElementFacade alliance_drop_down;

@FindBy(css="[name*=csv]")
public WebElementFacade csv_button;

@FindBy(css="[id*=id] > tbody > tr:nth-child(1) > td:nth-child(1) > div")
public WebElementFacade First_Record;

public WebElement Export_email_link(){
	return Export_email_link;
}
public WebElement No_record_found_text(){
	return No_record_found_text;
}
public WebElement alliance_drop_down(){
	return alliance_drop_down;
}
public WebElement csv_button(){
	return csv_button;
}
public WebElement First_Record(){
	return First_Record;
}
}
