package ui.pageobjects.Signon;

import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
public class AuthorizationPage_object extends PageObject{
	
@FindBy(css=".btn.flat-button")
public WebElementFacade date_dropdown;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(2)")
public WebElementFacade LastsevenDays_filter;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(3)")
public WebElementFacade this_week_filter;

@FindBy(css=".extended-interface > button:nth-child(4)")
public WebElementFacade Last_month_filter;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > div > button.info.ng-scope")
public WebElementFacade apply_button;

@FindBy(css="authorization-search > no-records > div > div > div.header > span:nth-child(2)")
public WebElementFacade search_error_message;

@FindBy(css="authorization-search > form > div.export > button > span.text.ng-scope")
public WebElementFacade export_button;
//authorization-search > form > div.export > button > span.text.ng-scope
@FindBy(css="div.modal-body.ng-scope > div:nth-child(2) > p > span:nth-child(3)")
public WebElementFacade csv_button;

@FindBy(css="div.modal-footer.ng-scope > button.default-button.x-small.blue.ng-scope")
public WebElementFacade cancel_button;

@FindBy(css="div.modal-body.ng-scope > div:nth-child(3) > p > span:nth-child(3)")
public WebElementFacade xml_button;

@FindBy(css="div.modal-footer.ng-scope > button:nth-child(1)")
public WebElementFacade download_button;

@FindBy(css="div.modal-body-norecords.ng-scope")
public WebElementFacade noRecords_after_export;

@FindBy(css="#merchant-portal > div.modal.fade.ng-isolate-scope.popup.transaction-export.no-results.in > div > div > div.modal-footer-norecords.ng-scope > button")
public WebElementFacade close_button;

@FindBy(css="#search-container > ul > li:nth-child(3) > a > span:nth-child(3)")
public WebElementFacade search_orderId;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-1.sortable.sortby.sort-desc.tg-w-9.tg-fixed-w-9 > span > span.header-label.ng-binding.ng-scope")
public WebElementFacade Authorization_date;

@FindBy(css="div.col-lg-12.tab-inside.ng-scope > div > authorization-search > save-search > div > p")
public WebElementFacade search_success_message;

@FindBy(css="[name*=oneSearchField]")
public WebElementFacade searchFieldText;

@FindBy(css="authorization-search > form > form-search-input > div > button.default-button.x-small.blue.search-button.desktop-tablet.ng-scope")
public WebElementFacade search_button;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(5) > span.date > input")
public WebElementFacade from_date;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(6) > span.date > input")
public WebElementFacade to_date;

public WebElement from_date(){
	return from_date;
}
public WebElement to_date(){
	return to_date;
}
public WebElement searchFieldText(){
	return searchFieldText;
}
public WebElement search_button(){
	return search_button;
}
public WebElement search_success_message(){
	return search_success_message;
}
public WebElement Authorization_date(){
	return Authorization_date;
}
public WebElement search_orderId(){
	return search_orderId;
}
public WebElement cancel_button(){
	return cancel_button;
}
public WebElement close_button(){
	return close_button;
}
public WebElement date_dropdown(){
	return date_dropdown;
}
public  WebElement LastsevenDays_filter(){
    return LastsevenDays_filter;
}
public  WebElement this_week_filter(){
    return this_week_filter;
}
public  WebElement Last_month_filter(){
    return Last_month_filter;
}
public  WebElement apply_button(){
    return apply_button;
}
public WebElement search_error_message(){
	return search_error_message;
}
public WebElement export_button(){
	return export_button;
}
public WebElement csv_button(){
	return csv_button;
}
public WebElement xml_button(){
	return xml_button;
}
public WebElement download_button(){
	return download_button;
}
public WebElement noRecords_after_export(){
	return noRecords_after_export;
}
}
