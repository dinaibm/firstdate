package ui.pageobjects.Signon;

import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class UserManagementPage_objects extends PageObject{

	//EMS
@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div.col-lg-12.transactions-module.users-module.home-page.ng-scope > div > div.col-lg-12 > users-search > form > a > span")
public WebElementFacade create_user;

@FindBy(css="[name*=FIRST_NAME]")
public WebElementFacade First_Name;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > form > user-input:nth-child(2) > div > label > div.error-side > span")
public WebElementFacade Firstname_error_message;

@FindBy(css="[name*=LAST_NAME]")
public WebElementFacade last_name;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > form > user-input:nth-child(3) > div > label > div.error-side > span")
public WebElementFacade Lasname_error_message;

@FindBy(css="[name*=USERNAME]")
public WebElementFacade UserName_new_alliance;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > form > user-input:nth-child(4) > div > label > div.error-side > span")
public WebElementFacade username_error_message;

@FindBy(css="[name*=EMAIL_ADDRESS]")
public WebElementFacade email_id;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > form > user-input:nth-child(7) > div > label > div.error-side > span")
public WebElementFacade emailid_error_message;

@FindBy(css="[name*=MOBILE_PHONE_NUMBER]")
public WebElementFacade mobile_number;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > form > user-input:nth-child(8) > div > label > div.error-side > span")
public WebElementFacade mobileNumber_error_message;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > form > div > button")
public WebElementFacade Next_button;

@FindBy(css="#DROP_DOWN_USER_PROFILE > span.ng-binding.ng-scope")
public WebElementFacade profile_dropdown;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > div > div.bottom-navigation > button")
public WebElementFacade nextbutton_2ndpage;

//input[id*=mid-selected-] [value*=merchantId] [name*=mid-selected]
@FindBy(css="[value*=merchantId]")
public WebElementFacade click23;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div.modal-container > div.modal-body.ng-scope > div > form > form-search-input > div > button.default-button.x-small.blue.search-button.desktop-tablet.ng-scope")
public WebElementFacade merchantUserSelection;

@FindBy(css="#search")
public WebElementFacade search_text;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div.col-lg-12.transactions-module.users-module.home-page.ng-scope > div > div.col-lg-12 > users-search > form > form-search-input > div > button.default-button.x-small.blue.search-button.desktop-tablet.ng-scope")
public WebElementFacade search_button;


public WebElement create_user(){
	return create_user;
}
public WebElement First_Name(){
	return First_Name;
}
public WebElement last_name(){
	return last_name;
}
public WebElement UserName_new_alliance(){
	return UserName_new_alliance;
}	
public WebElement email_id(){
	return email_id;
}
public WebElementFacade mobile_number(){
	return mobile_number;
}
public WebElement Next_button(){
	return Next_button;
}
public WebElement profile_dropdown(){
	return profile_dropdown;
}
public WebElement nextbutton_2ndpage(){
	return nextbutton_2ndpage;
}
public WebElementFacade merchantUserSelection(){
	return merchantUserSelection;
}
public WebElementFacade search_text(){
	return search_text;
}
public WebElementFacade search_button(){
	return search_button;
}
public WebElement Lasname_error_message(){
	return Lasname_error_message;
}
public WebElement Firstname_error_message(){
	return Firstname_error_message;
}
public WebElement emailid_error_message(){
	return emailid_error_message;
}
public WebElement username_error_message(){
	return username_error_message;
}
public WebElement mobileNumber_error_message(){
	return mobileNumber_error_message;
}
public WebElement click23(){
	return click23;
}

}
