package ui.pageobjects.Signon;

import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class FundingPage_object extends PageObject{

	//EMS

@FindBy(css="[name*=oneSearchField]")
public WebElementFacade searchFieldText;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > div > funding-search > form > div > form-search-input > div > button.default-button.x-small.blue.search-button.desktop-tablet.ng-scope")
public WebElementFacade search_button;

@FindBy(css="div[class=more-icon]")
public WebElementFacade plus_icon;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > div > funding-search > form > no-records > div > div > div.header > span:nth-child(2)")
public WebElementFacade no_results_found;

@FindBy(css="div > span > div > div:nth-child(2) > span.bold.ng-binding")
public WebElementFacade funding_refrence_number;

@FindBy(css=".table > div:nth-child(1) > a:nth-child(2)")
public WebElementFacade view_batch_details;

@FindBy(css="button.default-button:nth-child(1)")
public WebElementFacade Export_button;

@FindBy(css="div.modal-body.ng-scope > div:nth-child(2) > p > span:nth-child(3)")
public WebElementFacade csvFile_option;

@FindBy(css="div.modal-body.ng-scope > div:nth-child(3) > p")
public WebElementFacade xmlFile_option;

@FindBy(css="div.modal-footer.ng-scope > button:nth-child(1)")
public WebElementFacade Download_button;

@FindBy(css="funding-search > form > no-records > div > div > div.header > span:nth-child(2)")
public WebElementFacade search_error_message;

@FindBy(css="funding-chart-directive > div > div.labels > a:nth-child(2)")
public WebElementFacade store_link;

@FindBy(css="div.tg-column.tg-header.ng-scope.tg-col-id-1.sortable.tg-w-7.tg-fixed-w-7 > span > span.header-label.ng-binding.ng-scope")
public WebElementFacade posting_date;


public WebElement search_error_message(){
	return search_error_message;
}
public  WebElement searchFieldText(){
    return searchFieldText;
}
public  WebElement search_button(){
    return search_button;
}
public  WebElement plus_icon(){
    return plus_icon;
}
public  WebElement no_results_found(){
    return no_results_found;
}
public  WebElement funding_refrence_number(){
    return funding_refrence_number;
}
public  WebElement view_batch_details(){
    return view_batch_details;
}
public  WebElement Export_button(){
    return Export_button;
}
public  WebElement csvFile_option(){
    return csvFile_option;
}
public WebElement xmlFile_option(){
	return xmlFile_option;
}
public  WebElement Download_button(){
    return Download_button;
}
}
