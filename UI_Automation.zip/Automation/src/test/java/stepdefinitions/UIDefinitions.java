package stepdefinitions;

import org.openqa.selenium.WebDriver;
import CreateFeature.TestFea;
import Reports.TestResult;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;
import ui.Signon.Document_Management;
import ui.Signon.Financial_Activity;
import ui.Signon.MessagePage;
import ui.Signon.Terms_Conditions;
import ui.Signon.User_management;
import ui.Signon.dashboardPage;

public class UIDefinitions {
TestResult lib=new TestResult();
@Steps
User_management userManagementPage;
dashboardPage dashboardpage;
MessagePage messages;
Terms_Conditions termsandConditions;
Document_Management documentManagement;
Financial_Activity financialactivity;
public static WebDriver driver = null;

	@Before
	public void bfre() throws Exception{

	}
	@After
	public void aftr()
	{
		lib.closeTestReport();
		lib.endTestReport();
		lib.SummarizeTestReport();
	}
	
	@Given("^the Feature file path creattion$")
	public void the_Feature_file_path_creattion() throws Throwable {
		TestFea.CreateFeatureFile();
	}
	@Given("^the EMS portal and configure \"([^\"]*)\"$")
	public void the_EMS_portal(String report) throws Throwable {
		userManagementPage.loadbrowser();
		lib.initializeTest("RequestForApplicationUIInfo"+" "+report);
		lib.WriteReportStep("1", "Loading the browser", "", "", "");
	}

	@And("^user Navigate to URL \"([^\"]*)\"$")
	public void user_Navigate_to_URL(String arg1) throws Throwable {
		lib.WriteReportStep("1", "Get url", "", "", "");
		String Result = userManagementPage.navigate(arg1);
		if(Result.contains("Passed"))
		 {
			lib.WriteReportStep("2", "Verify the URL", "Verify the URL",  "WebPage successfully loaded "+Result, "Passed");
		 }
		 else
		 {
			 lib.WriteReportStep("2", "Verify the URL", "Verify the URL", "Failed to load the webPage "+Result, "Failed");
		 }
	}
	@And("^user click on RememberMe$")
	public void user_click_on_RememberMe() throws Throwable {
		userManagementPage.RememberMe();
	}

	@When("^user enter \"([^\"]*)\" as \"([^\"]*)\"$")
	public void user_enter_as(String FieldName, String FieldValue) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		lib.WriteReportStep("1", "Get username", "", "", "");
		String Result = userManagementPage.userInput(FieldName,FieldValue);
		if(Result.contains("Passed"))
		 {
			lib.WriteReportStep("2", "Verify the userid", "Get"+" "+FieldName, FieldName+":"+"UserId Entered correctly", "Passed");
		 }
		 else
		 {
			 lib.WriteReportStep("2", "Verify the userid", "Get"+" "+FieldName, FieldName+":"+"Failed to enter the userID", "Failed");
		 }
		
	}

	@And("^user entertext \"([^\"]*)\" as \"([^\"]*)\"$")
	public void user_entertext_as(String FieldName, String FieldValue) throws Throwable {
		lib.WriteReportStep("1", "Get Password", "", "", "");
	    String Result= userManagementPage.userInput(FieldName,FieldValue);
		if(Result.contains("Passed"))
		 {
			lib.WriteReportStep("2", "Verify the Password", "Get"+" "+FieldName, FieldName+":"+"Password entered correctly", "Passed");
		 }
		 else
		 {
			 lib.WriteReportStep("2", "Verify the Password", "Get"+" "+FieldName, FieldName+":"+"Failed to enter the password", "Failed");
		 }
	}
	
	@Then("^user click Submit login and verify \"([^\"]*)\"$$")
	public void user_click_Submit_login_and_verify(String Welcome_text) throws Throwable {
		 lib.WriteReportStep("1", "Login to the application", "", "", "");
		 String Result= userManagementPage.Submitlogin(Welcome_text);
		 System.out.println(Result);
		 if(Result.contains("Passed"))
		 {
			 lib.WriteReportStep("2", "Verify Submit","Login to the application", "Successfully login to application "+Result,"Passed");
		 }
		 else
		 {
			 lib.WriteReportStep("2", "Verify Submit","Login to the application", "Failed to login to applicatio n"+Result,"Failed");
		 }
		 
	}
	
	@Then("^user Verify Dashboard cookie information link$")
	public void user_Verify_Dashboard_cookie_information_link() throws Throwable {
		 lib.WriteReportStep("1", "Verify Cookie information", "", "", "");
		 String Result=dashboardpage.Dashboard_cookie_information_link();
		 if(Result.contains("Passed"))
		 {
			 lib.WriteReportStep("2", "Verify cookie information Link","Verify cookie information", "Cookie information link is present","Passed");
		 }
		 else
		 {
			 lib.WriteReportStep("2", "Verify cookie information Link","Verify cookie information", "Cookie information link is not there","Failed");
		 }
		 
	}
	@Then("^user Verify Unread message count$")
	public void user_Verify_Unread_message_count() throws Throwable {
		 lib.WriteReportStep("1", "Verify Unread message count", "", "", "");
		 String Result=dashboardpage.Unread_message_count();
		 if(Result.contains("Passed"))
		 {
			 lib.WriteReportStep("2", "Verify Unread message count","Verify Unread message count", "Unread message count is : "+ Result,"Passed");
		 }
		 else
		 {
			 lib.WriteReportStep("2", "Verify Unread message count","Verify Unread message count", "No unread message are there : "+ Result,"Failed");
		 }
	}

	@Then("^user Verify Unread document count$")
	public void user_Verify_Unread_document_count() throws Throwable {
		lib.WriteReportStep("1", "Verify unread document count", "", "", "");
		String Result=dashboardpage.Unread_Document_count();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Unread Document count","Verify Unread Document count", "Unread Document count is : "+ Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Unread Document count","Verify Unread Document count", "No unread Document are there : "+ Result,"Failed");
		}
	}

	@Then("^user Verify all the dashboard Panel element and check \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_Verify_all_the_dashboard_Panel_element_and_check(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7) throws Throwable {
		lib.WriteReportStep("1", "Verify all the dashboard element", "", "", "");
		String Result=dashboardpage.Verify_dashboard_panel_Navigation(arg1,arg2,arg3,arg4,arg5,arg6,arg7);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Dashboard navigation","Verify Dashboard Navigation to all the widget", "Successfully navigated to each widget","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Dashboard navigation","Verify Dashboard Navigation to all the widget", "Failed to navigate to each widget","Failed");
		}
	}
	@Then("^user should navigate from Pre_authorisation Widget to detailed pre_authorisations view and check \"([^\"]*)\"$")
	public void user_should_navigate_from_Pre_authorisation_Widget_to_detailed_pre_authorisations_view_and_check(String Fieldname) throws Throwable {
		lib.WriteReportStep("1", "Verify Navigation from preAuth_widget", "", "", "");
		String Result=dashboardpage.Navigate_Preauth_Widget_to_detailed_preauth_view(Fieldname);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Navigation from preAuth_widget","Verify Navigation from preAuth_widget", "Successfully navigated to Preauth_View","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Navigation from preAuth_widget","Verify Navigation from preAuth_widget", "Failed to navigate to PreAuth_view","Failed");
		}
	}
	@Then("^user should navigate from Funding Widget to funding_summary view and check \"([^\"]*)\"$")
	public void user_should_navigate_from_Funding_Widget_to_funding_summary_view_and_check(String Fieldname) throws Throwable {
		lib.WriteReportStep("1", "Verify Navigation from funding_widget", "", "", "");
		String Result=dashboardpage.Navigate_Funding_Widget_to_detailed_funding_view(Fieldname);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Navigation from Funding Widget","Verify Navigation from Funding Widget", "Successfully navigated to Funding_View","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Navigation from preAuth_widget","Verify Navigation from preAuth_widget", "Failed to navigate to PreAuth_view","Failed");
		}
	}
	@Then("^user should navigate from Sales Widget to Transaction summary view and check the detailed Transaction view$")
	public void user_should_navigate_from_Sales_Widget_to_Transaction_summary_view_and_check_the_detailed_Transaction_view() throws Throwable {
		lib.WriteReportStep("1", "Verify Navigation from sales_widget", "", "", "");
		String Result=dashboardpage.Navigate_sales_to_transaction();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Navigation from sales Widget","Verify Navigation from sales Widget", "Successfully navigated to Transaction_View","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Navigation from sales_widget","Verify Navigation from sales_widget", "Failed to navigate to Transaction_view","Failed");
		}
	}
	
	@Then("^user should change the currency code to \"([^\"]*)\" and validate the dashboard$")
	public void user_should_change_the_currency_code_to_and_validate_the_dashboard(String arg1) throws Throwable {
		lib.WriteReportStep("1", "Verify currency_code change", "", "", "");
		String Result=dashboardpage.Change_currency_code(arg1);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify currency_code change","Verify currency_code change", "Successfully Changed to currency_code "+ Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify currency_code change","Verify currency_code change", "Failed to change the currency code","Failed");
		}
	}
	@Then("^user should change the Language code to \"([^\"]*)\" and validate the dashboard$")
	public void user_should_change_the_Language_code_to_and_validate_the_dashboard(String arg1) throws Throwable {
		lib.WriteReportStep("1", "Verify Language_code change", "", "", "");
		System.out.println(arg1);
		String Result=dashboardpage.Change_Language_code(arg1);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Language_code change","Verify Language_code change", "Successfully Changed to Language_code "+ Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Language_code change","Verify Language_code change", "Failed to Change the language","Failed");
		}
	}
	@Then("^User should be able to verify print option is working in messages as \"([^\"]*)\"$")
	public void user_should_be_able_to_verify_print_option_is_working_in_messages_as(String arg1) throws Throwable {
		lib.WriteReportStep("1", "Verify Print_option in Message change", "", "", "");
		String Result=messages.Print_option_Message(arg1);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Print_option in Message change","Verify Print_option in Message change", "Successfully Printed the message  ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Print_option in Message change","Verify Print_option in Message change", "Failed to Print the message ","Failed");
		}
	}
	@When("^user enterAlliance \"([^\"]*)\" as \"([^\"]*)\"$")
	public void user_enterAlliance_as(String Alliance, String Alliance_code) throws Throwable {
		lib.WriteReportStep("1", "Verify Alliance_code", "", "", "");
		String Result=userManagementPage.userInput(Alliance, Alliance_code);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Alliance_code","Verify Alliance_code", "Successfully Entered alliancecode ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Alliance_code","Verify Alliance_code", "Failed to Enter Alliance_code","Failed");
		}
		  
	}

	@When("^user click login button and enter to the admin console$")
	public void user_click_login_button_and_enter_to_the_admin_console() throws Throwable {
		lib.WriteReportStep("1", "Verify Login to Adminconsole", "", "", "");
		String Result=userManagementPage.login_admin_console();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Login to Adminconsole","Verify Login to Adminconsole", "Successfully Entered to adminconsole ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Login to Adminconsole","Verify Login to Adminconsole", "Failed to Enter into adminconsole","Failed");
		}
	}

	@Then("^user should be able to create the new message and give the input as \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_create_the_new_message_and_give_the_input_as(String Alliance_Name, String Language, String Type, String Title, String Sub_title, String Date_received, String Validity_type,String In_days_Validity_days, String message_body) throws Throwable {
		lib.WriteReportStep("1", "Verify create message", "", "", "");
		String Result=messages.Create_message(Alliance_Name,Language,Type,Title,Sub_title,Date_received,Validity_type,In_days_Validity_days,message_body);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify create message","Verify create message", "Successfully created message "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify create message","Verify create message", "Failed to create message","Failed");
		}
	}
	
	@Then("^User should be able to Navigate from message notification to the message detail$")
	public void User_should_be_able_to_Navigate_from_message_notification_to_the_message_detail() throws Throwable{
		lib.WriteReportStep("1", "Verify User should be navigate from message notification to message detail", "", "", "");
		String Result=dashboardpage.Navigate_to_message_view_from_notification();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be navigate from message notification to message detail","Verify User should be navigate from messqage notification to message detail", "Successfully navigate to message detail ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be navigate from message notification to message detail","Verify User should be navigate from messqage notification to message detail", "No unread message are there come back later","Failed");
		}
	}
	@When("^user click Submit login$")
	public void user_click_Submit_login() throws Throwable{
		lib.WriteReportStep("1", "Verify submit button for alert testcase", "", "", "");
		String Result=userManagementPage.Submitlogin_for_alert_testcase();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify submit button for alert testcase","Verify submit button for alert testcase", "Successfully navigate to Home Page ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify submit button for alert testcase","Verify submit button for alert testcase", "Failed to navigate to home page","Failed");
		}
	}
	@Then("^User should be able to view unread alerts it will appear directly after logging in$")
	public void User_should_be_able_to_view_unread_alerts_it_will_appear_directly_after_logging_in() throws Throwable{
		lib.WriteReportStep("1", "Verify User should be able to view unread allert", "", "", "");
		String Result=dashboardpage.Confirm_unread_alert_after_login();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be able to view unread allert","Verify User should be able to view unread allert", "Successfully confirming unread alert ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to view unread allert","Verify User should be able to view unread allert", "No unread alerts are there come back later","Failed");
		}
	}

	@Then("^User should be able to close the message notification and check the message will be in read status$")
	public void User_should_be_able_to_close_the_message_notification_and_check_the_message_will_be_in_read_status() throws Throwable{
		lib.WriteReportStep("1", "Verify User should be able to close the notification", "", "", "");
		String Result=dashboardpage.Close_message_notification();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be able to close the notification","Verify User should be able to close the notification", "Successfully closed the notification ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to close the notification","Verify User should be able to close the notification", "No unread Messages are there for now come back later","Failed");
		}
	}

	@Then("^User should be able click the unread message/Document count and go to the detailed view$")
	public void user_should_be_able_click_the_unread_message_Document_count_and_go_to_the_detailed_view() throws Throwable {
		lib.WriteReportStep("1", "Verify User should be able see the unread message and document", "", "", "");
		String Result=dashboardpage.Navigate_unread_message_detail_view();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be able see the unread message and document","Verify User should be able see the unread message and document", "Successfully Navigate to detailed message and document ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able see the unread message and document","Verify User should be able see the unread message and document", "Failed to navigate the document and message","Failed");
		}
	}
	@Then("^User should be able to download the attachment of the specific message as \"([^\"]*)\"$")
	public void user_should_be_able_to_download_the_attachment_of_the_specific_message_as(String message_Title) throws Throwable {
		lib.WriteReportStep("1", "Verify User should be able to download the attachment from the message", "", "", "");
		String Result=messages.Download_attachment_from_message(message_Title);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be able to download the attachment from the message","Verify User should be able to download the attachment from the message", "Successfully Downloaded the attachment ","Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to download the attachment from the message","Verify User should be able to download the attachment from the message", "No Attachment files are there in the particular message","Failed");
		}
	}
	@Then("^User should be able to validate all the property of the specific message title as \"([^\"]*)\"$")
		public void User_should_be_able_to_validate_all_the_property_of_the_specific_message_title_as(String message_Title) throws Throwable {
		lib.WriteReportStep("1", "Verify User should be able to download the attachment from the message", "", "", "");
		String Result=messages.validation_of_message_template(message_Title);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be able to download the attachment from the message","Verify User should be able to download the attachment from the message", "Successfully Downloaded the attachment "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to download the attachment from the message","Verify User should be able to download the attachment from the message", "No Attachment files are there in the particular message","Failed");
		}
	}

	@Then("^User should be able to get the permanent link from the message and login through the portal as \"([^\"]*)\" and \"([^\"]*)\" and validate the message title as \"([^\"]*)\"$")
	public void user_should_be_able_to_get_the_permanent_link_from_the_message_and_login_through_the_portal_as_and_and_validate_the_message_title_as(String userID_LBC, String password_LBC, String message_Title) throws Throwable {
		lib.WriteReportStep("1", "Verify User should be able to get the permanent link from the message", "", "", "");
		String Result=messages.permanent_link_Retrive(userID_LBC,password_LBC,message_Title);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be able to get the permanent link from the message","Verify User should be able to get the permanent link from the message", "Successfully get the permanent link"+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to get the permanent link from the message","Verify User should be able to get the permanent link from the message", "No permanent Link Found","Failed");
		}
	}
	@Then("^User should be able to Navigate through the message by pagination$")
	public void User_should_be_able_to_Navigate_through_the_message_by_pagination() throws Throwable {
		lib.WriteReportStep("1", "Verify User should be able to navigate through the message pages", "", "", "");
		String Result=messages.pagination_of_message();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be able to navigate through the message pages","Verify User should be able to navigate through the message pages", "Successfully pagination done"+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to navigate through the message pages","Verify User should be able to navigate through the message pages", "Failed to do the pagination"+Result,"Failed");
		}
	}
	@Then("^User should be able to see messages by default displayed in descending order by Date and Time of the message$")
	public void User_should_be_able_to_see_messages_by_default_displayed_in_descending_order_by_Date_and_Time_of_the_message() throws Throwable{
		lib.WriteReportStep("1", "Verify User should be able to see messages by default displayed in descending order by Date and Time of the message", "", "", "");
		String Result=messages.display_message_in_descending_order();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be able to see messages by default displayed in descending order by Date and Time of the message","Verify User should be able to see messages by default displayed in descending order by Date and Time of the message", "Successfully displayed the message by descending order"+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to see messages by default displayed in descending order by Date and Time of the message","Verify User should be able to see messages by default displayed in descending order by Date and Time of the message", "Failed to display the message by descending order"+Result,"Failed");
		}
	}
	@Then("^User should be able to see last login date and time displayed on the home page$")
	public void User_should_be_able_to_see_last_login_date_and_time_displayed_on_the_home_page() throws Throwable{
		lib.WriteReportStep("1", "Verify User should be able to see last login date and time displayed on the home page", "", "", "");
		String Result=userManagementPage.last_login_date_time_in_home_page();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be able to see last login date and time displayed on the home page","Verify User should be able to see last login date and time displayed on the home page", "Successfully displayed the last login date and time in the home page"+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to see last login date and time displayed on the home page","Verify User should be able to see last login date and time displayed on the home page", "Failed to display the Last login date and time in the homwe page"+Result,"Failed");
		}
	}
	@Then("^user should be able to create a new alliance user by giving \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_create_a_new_alliance_user_by_giving(String Language,String User_Type, String Alliance_name, String Profile_type, String First_Name, String last_name, String email_id, String UserName_new_alliance, String mobile_number) throws Throwable {
		lib.WriteReportStep("1", "Verify Admin should be able to Create new Allianz", "", "", "");
		String Result=userManagementPage.create_new_allianz_user(User_Type, Alliance_name, Profile_type, First_Name, last_name, email_id, UserName_new_alliance, mobile_number, Language);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Admin should be able to Create new Allianz","Verify Admin should be able to Create new Allianz", "Successfully Created the allianz"+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Admin should be able to Create new Allianz","Verify Admin should be able to Create new Allianz", "Failed to create the allianz"+Result,"Failed");
		}
	}
	@Then("^user should be able to create a new merchant user by giving \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_create_a_new_merchant_user_by_giving(String User_Type,String Merchant_ID,String Profile_type,String First_Name,String last_name,String UserName_new_alliance,String email_id,String mobile_number,String Language) throws Throwable {
		lib.WriteReportStep("1", "Verify Admin should be able to create a merchant", "", "", "");
		String Result=userManagementPage.Create_new_merchant(User_Type,Merchant_ID,Profile_type,First_Name, last_name, UserName_new_alliance, email_id, mobile_number, Language);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Admin should be able to create a merchant","Verify Admin should be able to create a merchant", "Successfully Created the Merchant"+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Admin should be able to create a merchant","Verify Admin should be able to create a merchant", "Failed to create the Merchant"+Result,"Failed");
		}
	}
	@Then("^user should be able to validate the profile information of the account$")
	public void user_should_be_able_to_validate_the_profile_information_of_the_account() throws Throwable{
		lib.WriteReportStep("1", "Verify BO should be able to validate profile information", "", "", "");
		String Result=userManagementPage.Validate_profile_information();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to validate profile information","Verify BO should be able to validate profile information", "Successfully verified the profile information"+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to validate profile information","Verify BO should be able to validate profile information", "Failed to verify the profile information"+Result,"Failed");
		}
	}

	@Then("^user should be able to change the password to a new one as \"([^\"]*)\" ,\"([^\"]*)\"$")
	public void user_should_be_able_to_change_the_password_to_a_new_one_as(String New_password, String password) throws Throwable {
		lib.WriteReportStep("1", "Verify BO should be able to change the password", "", "", "");
		String Result=userManagementPage.Change_Password_of_BO(New_password,password);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to change the password","Verify BO should be able to change the password", "Successfully Changed the password "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to change the password","Verify BO should be able to change the password", "Failed to Change the password "+Result,"Failed");
		}
	}
	@Then("^user should be able to download the terms and conditions in the given path \"([^\"]*)\"$")
	public void user_should_be_able_to_download_the_terms_and_conditions_in_the_given_path(String downloaded_Path) throws Throwable {
		lib.WriteReportStep("1", "Verify BO should be able to download the terms and conditions", "", "", "");
		String Result=termsandConditions.download_terms_and_condition(downloaded_Path);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to download the terms and conditions","Verify BO should be able to download the terms and conditions", "Successfully Downloaded the terms and conditions "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to download the terms and conditions","Verify BO should be able to download the terms and conditions", "Failed to Downloaded the terms and conditions "+Result,"Failed");
		}
	}
	@Then("^user should be able to accept the terms and conditions$")
	public void user_should_be_able_to_accept_the_terms_and_conditions() throws Throwable {
		lib.WriteReportStep("1", "Verify BO should be able to Accept the terms and conditions", "", "", "");
		String Result=termsandConditions.Accept_terms_and_conditions();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to accept the terms and conditions","Verify BO should be able to accept the terms and conditions", "Successfully accepted the terms and conditions "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to accept the terms and conditions","Verify BO should be able to accept the terms and conditions", "Failed to accept the terms and conditions "+Result,"Failed");
		}
	}
	@Then("^user should be able to see the password expiry message and change the password like \"([^\"]*)\" ,\"([^\"]*)\"$")
	public void user_should_be_able_to_see_the_password_expiry_message_and_change_the_password_like(String New_password, String password) throws Throwable {
		lib.WriteReportStep("1", "Verify BO should be able to see the expired message and able to change the password", "", "", "");
		String Result=userManagementPage.Password_expire_message(New_password,password);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to see the expired message and able to change the password","Verify BO should be able to see the expired message and able to change the password", "Successfully Changed the password "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to see the expired message and able to change the password","Verify BO should be able to see the expired message and able to change the password", "Failed to Change the password "+Result,"Failed");
		}
	}
	@Then("^user should be able to download multiple documents$")
	public void user_should_be_able_to_download_multiple_documents() throws Throwable {
		lib.WriteReportStep("1", "Verify BO should be able to download multiple documents", "", "", "");
		String Result=documentManagement.Download_multiple_document();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to download multiple documents","Verify BO should be able to download multiple documents", "Successfully downloaded the documents "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to download multiple documents","Verify BO should be able to download multiple documents", "Failed to download the documents "+Result,"Failed");
		}
	}
	@Then("^Then user should be able to navigate to the preAuthorization page and select any time period filter$")
	public void user_should_be_able_to_navigate_to_the_preAuthorization_page_and_select_any_time_period_filter() throws Throwable{
		lib.WriteReportStep("1", "Verify BO should be able to navigate to the preAuthorization page and select any time period filter", "", "", "");
		String Result=financialactivity.Verify_Time_Period_filter_For_Preauthorization();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to navigate to the preAuthorization page and select any time period filter","Verify BO should be able to navigate to the preAuthorization page and select any time period filter", "Successfully selected and verified every time period filter "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to navigate to the preAuthorization page and select any time period filter","Verify BO should be able to navigate to the preAuthorization page and select any time period filter", "Failed to Verify the time period filter "+Result,"Failed");
		}
	}
	@Then("^user should be able to get the xml report downloaded for transaction page and \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_get_the_xml_report_downloaded_for_transaction_page_and(String downloaded_Path, String Alliance_code) throws Throwable {
		lib.WriteReportStep("1", "Verify BO should be able to export the transaction details in xml format", "", "", "");
		String Result=financialactivity.Verify_transaction_xml_file_download(downloaded_Path, Alliance_code);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the transaction details in xml format","Verify BO should be able to export the transaction details in xml format", "Successfully exported the transaction detail "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the transaction details in xml format","Verify BO should be able to export the transaction details in xml format", "Failed to export the transaction detail "+Result,"Failed");
		}
	}
	@Then("^user should be able to modify the message content by giving \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_modify_the_message_content_by_giving(String Message_title, String Sub_title, String message_body, String Upload_file) throws Throwable {
		lib.WriteReportStep("1", "Verify CM should be able to modify the message content", "", "", "");
		String Result=messages.modify_the_Message(Message_title, Sub_title, message_body, Upload_file);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify CM should be able to modify the message content","Verify CM should be able to modify the message content", "Successfully modified a message "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify CM should be able to modify the message content","Verify CM should be able to modify the message content", "Failed to modify a message "+Result,"Failed");
		}  
	}

	@Then("^user should be able to delete the message by giving \"([^\"]*)\"$")
	public void user_should_be_able_to_delete_the_message_by_giving(String Message_title) throws Throwable {
		lib.WriteReportStep("1", "Verify CM should be able to delete a message", "", "", "");
		String Result=messages.delete_the_Message(Message_title);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify CM should be able to delete a message","Verify CM should be able to delete a message", "Successfully deleted the message from the system "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify CM should be able to delete a message","Verify CM should be able to delete a message", "Failed to delete the message "+Result,"Failed");
		}
	}
	@Then("^user should be able to search the user list by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_search_the_user_list_by_providing(String First_Name, String last_name, String UserName_new_alliance) throws Throwable {
		lib.WriteReportStep("1", "Verify Admin will be able to search the user by their name and user name", "", "", "");
		String Result=userManagementPage.Search_User_in_Admin_console(First_Name, last_name, UserName_new_alliance);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify Admin will be able to search the user by their name and user name","Verify Admin will be able to search the user by their name and user name", "Successfully got the user from the system "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify Admin will be able to search the user by their name and user name","Verify CM Admin will be able to search the user by their name and user name", "Failed to get the user "+Result,"Failed");
		}
	}
	@Then("^user should be able to get the xls report downloaded for transaction page by providing \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_get_the_xls_report_downloaded_for_transaction_page_by_providing(String downloaded_Path, String Alliance_code) throws Throwable {
		lib.WriteReportStep("1", "Verify BO should be able to export the transaction details in xls format", "", "", "");
		String Result=financialactivity.Verify_transaction_xls_file_download(downloaded_Path, Alliance_code);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the transaction details in xls format","Verify BO should be able to export the transaction details in xls format", "Successfully downloaded the transaction file "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the transaction details in xls format","Verify BO should be able to export the transaction details in xls format", "Failed to download the file "+Result,"Failed");
		}
	}
	@When("^user should be able to get the csv report downloaded from transaction page by providing \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_get_the_csv_report_downloaded_from_transaction_page_by_providing(String downloaded_Path, String Alliance_code) throws Throwable {
		lib.WriteReportStep("1", "Verify BO should be able to export the transaction details in csv format", "", "", "");
		String Result=financialactivity.Verify_transaction_csv_file_download(downloaded_Path, Alliance_code);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the transaction details in csv format","Verify BO should be able to export the transaction details in csv format", "Successfully downloaded the transaction file "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the transaction details in csv format","Verify BO should be able to export the transaction details in csv format", "Failed to download the file "+Result,"Failed");
		}
	}

	@When("^user should be able to export csv report from funding page by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_export_csv_report_from_funding_page_by_providing(String downloaded_Path, String Alliance_code, String Funding_Reference_number) throws Throwable {
		lib.WriteReportStep("1", "Verify BO should be able to export the transaction details in csv format", "", "", "");
		String Result=financialactivity.Verify_funding_csv_file_download(downloaded_Path, Alliance_code, Funding_Reference_number);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the Funding batch details in csv format","Verify BO should be able to export the Funding batch details in csv format", "Successfully downloaded the Funding file "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the Funding batch details in csv format","Verify BO should be able to export the Funding batch details in csv format", "Failed to download the file "+Result,"Failed");
		}
	}

	@Then("^user should be able to export csv report from Authorization page by providing \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_export_csv_report_from_Authorization_page_by_providing(String downloaded_Path, String Alliance_code) throws Throwable {
		lib.WriteReportStep("1", "Verify BO should be able to export the Authorization details in csv format", "", "", "");
		String Result=financialactivity.Verify_Authorization_csv_file_download(downloaded_Path, Alliance_code);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the Authorization details in csv format","Verify BO should be able to export the Authorization details in csv format", "Successfully downloaded the Authorization file "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the Authorization details in csv format","Verify BO should be able to export the Authorization details in csv format", "Failed to download the file "+Result,"Failed");
		}
	}
	@Then("^user should be able to provide the \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_provide_the(String From_date, String To_date) throws Throwable {
		lib.WriteReportStep("1", "Verify BO should be able to provide the date", "", "", "");
		String Result=financialactivity.Verify_Time_picker_in_transaction_view(From_date, To_date);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to provide the date","Verify BO should be able to provide the date", "Successfully provided the dates "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to provide the date","Verify BO should be able to provide the date", "Failed to provide the date "+Result,"Failed");
		}
	}
	@Then("^user should be able to navigate to the Transaction page and select any time period filter$")
	public void user_should_be_able_to_navigate_to_the_Transaction_page_and_select_any_time_period_filter() throws Throwable {
		lib.WriteReportStep("1", "Verify BO should be able to navigate to the Transaction page and select any time period filter", "", "", "");
		String Result=financialactivity.Verify_Time_Period_filter_For_Transaction();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to navigate to the Transaction page and select any time period filter","Verify BO should be able to navigate to the Transaction page and select any time period filter", "Successfully selected and verified every time period filter "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to navigate to the Transaction page and select any time period filter","Verify BO should be able to navigate to the Transaction page and select any time period filter", "Failed to Verify the time period filter "+Result,"Failed");
		}
	}
	@Then("^user should be able to verify the \"([^\"]*)\" should be before \"([^\"]*)\"$")
	public void user_should_be_able_to_verify_the_should_be_before(String From_date, String To_date) throws Throwable {
		lib.WriteReportStep("1", "Verify BO should be able verify from date is before to date", "", "", "");
		String Result=financialactivity.Verify_From_date_should_be_before_to_date(From_date, To_date);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able verify from date is before to date","Verify BO should be able verify from date is before to date", "Successfully verified from date before todate "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able verify from date is before to date","Verify BO should be able verify from date is before to date", "Failed to verify "+Result,"Failed");
		}
	}
	@When("^user should be able to export xml report from funding page by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_export_xml_report_from_funding_page_by_providing(String downloaded_Path, String Alliance_code, String Funding_Reference_number) throws Throwable {
		lib.WriteReportStep("1", "Verify BO should be able to export the transaction details in csv format", "", "", "");
		String Result=financialactivity.Verify_funding_xml_file_download(downloaded_Path, Alliance_code, Funding_Reference_number);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the Funding batch details in csv format","Verify BO should be able to export the Funding batch details in csv format", "Successfully downloaded the Funding file "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the Funding batch details in csv format","Verify BO should be able to export the Funding batch details in csv format", "Failed to download the file "+Result,"Failed");
		}
	}
	@Then("^user should be able to provide the \"([^\"]*)\", \"([^\"]*)\" and verify the transaction$")
	public void user_should_be_able_to_provide_the_and_verify_the_transaction(String From_date, String To_date) throws Throwable {
		lib.WriteReportStep("1", "Verify BO should be able to provide the dates and verify the transaction detail", "", "", "");
		String Result=financialactivity.Verify_the_transaction_details_after_giving_dates(From_date,To_date);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to provide the dates and verify the transaction detail","Verify BO should be able to provide the dates and verify the transaction detail", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to provide the dates and verify the transaction detail","Verify BO should be able to provide the dates and verify the transaction detail", "Failed to download the file "+Result,"Failed");
		}
	}
	@Then("^user should be able to retrieve a permanent document link by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_retrieve_a_permanent_document_link_by_providing(String userID_LBC, String password_LBC, String downloaded_Path) throws Throwable {
		lib.WriteReportStep("1", "Verify CM should be able to retrieve a permanent link for document", "", "", "");
		String Result=documentManagement.permanent_link_Retrive(userID_LBC, password_LBC, downloaded_Path);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify CM should be able to retrieve a permanent link for document","Verify CM should be able to retrieve a permanent link for document", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify CM should be able to retrieve a permanent link for document","Verify CM should be able to retrieve a permanent link for document", "Failed"+Result,"Failed");
		}
	}
	@Then("^user should be able to add by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_add_by_providing(String document_Name, String Alliance_name, String Language, String Upload_file, String attachmentPath, String Description_DocumentText) throws Throwable {
		lib.WriteReportStep("1", "Verify CM should be able to add a new document", "", "", "");
		String Result=documentManagement.Add_a_new_document(document_Name, Alliance_name, Language, Upload_file, attachmentPath, Description_DocumentText);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify CM should be able to add a new document","Verify CM should be able to add a new document", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify CM should be able to add a new document","Verify CM should be able to add a new document", "Failed"+Result,"Failed");
		}
	}

	@Then("^user should be able to rename a document by providing \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_rename_a_document_by_providing(String Rename_document,String Upload_file) throws Throwable {
		lib.WriteReportStep("1", "Verify CM should be able to rename a document", "", "", "");
		String Result=documentManagement.Rename_a_document(Rename_document, Upload_file);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify CM should be able to rename a document","Verify CM should be able to rename a document", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify CM should be able to rename a document","Verify CM should be able to rename a document", "Failed"+Result,"Failed");
		}
	}
	@Then("^user should be able to export xml report from Authorization page by providing \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_export_xml_report_from_Authorization_page_by_providing(String downloaded_Path, String Alliance_code) throws Throwable {
		lib.WriteReportStep("1", "Verify BO should be able to export the Authorization details in xml format", "", "", "");
		String Result=financialactivity.Verify_Authorization_xml_file_download(downloaded_Path, Alliance_code);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the Authorization details in xml format","Verify BO should be able to export the Authorization details in xml format", "Successfully downloaded the Authorization file "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to export the Authorization details in xml format","Verify BO should be able to export the Authorization details in xml format", "Failed to download the file "+Result,"Failed");
		}
	}
	@Then("^user should be able to navigate to the document and validate the document unread status$")
	public void user_should_be_able_to_navigate_to_the_document_and_validate_the_document_unread_status() throws Throwable {
		lib.WriteReportStep("1", "Verify BO should be able to validate the document unread status", "", "", "");
		String Result=documentManagement.marked_unread_document();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to validate the document unread status","Verify BO should be able to validate the document unread status", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to validate the document unread status","Verify BO should be able to validate the document unread status", "Failed to load the document page "+Result,"Failed");
		}
	}
	@Then("^user should be able to export the list of alliance users by providing \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_export_the_list_of_alliance_users_by_providing(String Alliance_name, String downloaded_Path) throws Throwable {
		lib.WriteReportStep("1", "Verify User should be able to export the list of alliance user list", "", "", "");
		String Result=userManagementPage.Export_the_alliance_user_list(Alliance_name, downloaded_Path);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify User should be able to export the list of alliance user list","Verify User should be able to export the list of alliance user list", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to export the list of alliance user list","Verify User should be able to export the list of alliance user list", Result,"Failed");
		}
	}
	@Then("^user should be able to search the authorization detail by providing \"([^\"]*)\", \"([^\"]*)\", \"([^\"]*)\"$")
	public void user_should_be_able_to_search_the_authorization_detail_by_providing(String Order_ID,String From_date, String To_date) throws Throwable
	{
		lib.WriteReportStep("1", "Verify user should be able to search the authorization detail by providing order_id", "", "", "");
		String Result=financialactivity.verify_the_authorization_detail(Order_ID,From_date,To_date);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to search the authorization detail by providing order_id","Verify User should be able to search the authorization detail by providing order_id", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to search the authorization detail by providing order_id","Verify User should be able to search the authorization detail by providing order_id", Result,"Failed");
		}
	}
	@Then("^user should be able to search the transaction detail by providing \"([^\"]*)\"$")
	public void user_should_be_able_to_search_the_transaction_detail_by_providing(String Merchant_ID_Transaction) throws Throwable
	{
		lib.WriteReportStep("1", "Verify user should be able to search the transaction detail by providing merchant_id", "", "", "");
		String Result=financialactivity.Search_the_transaction_detail_by_giving_single_search_criteria(Merchant_ID_Transaction);
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to search the transaction detail by providing merchant_id","Verify User should be able to search the transaction detail by providing merchant_id", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to search the transaction detail by providing merchant_id","Verify User should be able to search the transaction detail by providing merchant_id", Result,"Failed");
		}
	}
	@Then("^user should be able to validate the text disclaimer for each widget$")
	public void user_should_be_able_to_validate_the_text_disclaimer_for_each_widget() throws Throwable{
		lib.WriteReportStep("1", "Verify user should be able to verify the text disclaimer for each widget", "", "", "");
		String Result=dashboardpage.Validate_Disclaimer_widget();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify user should be able to verify the text disclaimer for each widget","Verify User should be able to verify the text disclaimer for each widget", Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify User should be able to verify the text disclaimer for each widget","Verify User should be able to verify the text disclaimer for each widget", Result,"Failed");
		}
	}
	@Then("^Logout from the application$")
	public void Logout_from_the_application() throws Throwable{
		lib.WriteReportStep("1", "Verify BO should be able to Logout from the system", "", "", "");
		String Result=userManagementPage.logout();
		if(Result.contains("Passed"))
		{
			 lib.WriteReportStep("2", "Verify BO should be able to Logout from the system","Verify BO should be able to Logout from the system", "Successfully Logout from the system "+Result,"Passed");
		}
		else
		{
			 lib.WriteReportStep("2", "Verify BO should be able to Logout from the system","Verify BO should be able to Logout from the system", "Failed to logout "+Result,"Failed");
		}
	}
	
}
