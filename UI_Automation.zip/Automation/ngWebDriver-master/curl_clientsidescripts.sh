#!/bin/sh

curl https://raw.githubusercontent.com/angular/protractor/master/lib/clientsidescripts.js -o src/main/resources/js/clientsidescripts.js
