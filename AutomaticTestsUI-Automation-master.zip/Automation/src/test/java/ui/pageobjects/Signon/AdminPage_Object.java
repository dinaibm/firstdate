package ui.pageobjects.Signon;

import org.openqa.selenium.WebElement;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class AdminPage_Object extends PageObject{

//EMS
@FindBy(css="#menu-links > div:nth-child(4) > a")
//#menu-links > div:nth-child(7) > a
public WebElementFacade GUI_Message;

@FindBy(css="#mainPanel > div.command-panel > a")
public WebElementFacade Add_message;

@FindBy(css="#id19 > h4 > span:nth-child(1)")
public WebElementFacade NewMessage_text;

@FindBy(css="#allianceCode")
public WebElementFacade allianceCode_dropdown;

@FindBy(css="#language")
public WebElementFacade Language_msg_dropdown;

@FindBy(css="#type")
public WebElementFacade type_dropdown;

@FindBy(css="#title")
public WebElementFacade message_title;

@FindBy(css="#subTitle")
public WebElementFacade message_subTitle;

@FindBy(name="startDate:date")
public WebElementFacade date_picker;
/*@FindBy(css="#id17")
public WebElementFacade date_picker;*/

@FindBy(css="#chk")
public WebElementFacade Flag_notification;

@FindBy(name="checkValidityInDays")
public WebElementFacade Indays_validity;
/*@FindBy(css="#id23")
public WebElementFacade Indays_validity;*/

@FindBy(name="checkUnlimitedValidity")
public WebElementFacade unlimited_validity;
/*@FindBy(css="#id26")
public WebElementFacade unlimited_validity;*/

@FindBy(css="#textarea_ifr")
public WebElementFacade messagebody;

@FindBy(name="sample")
public WebElement Indays_validity_days;
@FindBy(name="submitButton")
public WebElementFacade save_button;

@FindBy(css="#feedbackPanel > ul > li > span")
public WebElementFacade Created_successfully_text;

public  WebElement GUI_Message(){
    return GUI_Message;
}
public  WebElement Add_message(){
    return Add_message;
}
public  WebElement NewMessage_text(){
    return NewMessage_text;
}
public  WebElement allianceCode_dropdown(){
    return allianceCode_dropdown;
}
public  WebElement Language_msg_dropdown(){
    return Language_msg_dropdown;
}
public  WebElement type_dropdown(){
    return type_dropdown;
}
public  WebElement message_title(){
    return message_title;
}
public  WebElement message_subTitle(){
    return message_subTitle;
}
public  WebElement date_picker(){
    return date_picker;
}
public  WebElement Flag_notification(){
    return Flag_notification;
}
public  WebElement Indays_validity(){
    return Indays_validity;
}
public  WebElement Indays_validity_days(){
    return Indays_validity_days;
}

public  WebElement unlimited_validity(){
    return unlimited_validity;
}
public WebElement messagebody(){
	return messagebody;	
}
public WebElement save_button(){
	return save_button;
}
public WebElement Created_successfully_text(){
	return Created_successfully_text;
}
}
