package ui.pageobjects.Signon;

import org.openqa.selenium.WebElement;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class DashboardPage_Objects extends PageObject{
	
	

@FindBy(css="#main > div.row.content > div > div.row.ng-scope > div > div.header-info-bar > profile-information > div > span.hidden-xs.ng-binding")
public WebElementFacade Welcome_message;

@FindBy(css="#main > div.row.content > div > div.row.ng-scope > div > div.header-info-bar > profile-information > div > span:nth-child(2)")
public WebElementFacade login_date;

@FindBy(css="body > div.container.ng-isolate-scope.dashboard-page > div > navigation > div > ul > li.ng-scope.messages > a > span > i")
public WebElementFacade message_indicator_count;

@FindBy(css="body > div.container.ng-isolate-scope.dashboard-page > div > navigation > div > ul > li.ng-scope.documents > a > span > i")
public WebElementFacade document_indicator_count ;

@FindBy(css="#main > div:nth-child(1) > div > div:nth-child(3) > div > span")
public WebElementFacade Portal_cookie_message;

@FindBy(css="#main > div:nth-child(1) > div > div:nth-child(3) > div > a > span")
public WebElementFacade portal_cookie_details;

@FindBy(css="#block-views-header-block > div > div > div > section > section > h1 > span")
public WebElementFacade cookie_page;

@FindBy(css="#merchant-portal > div.container.ng-isolate-scope > div > navigation > div > ul > li.ng-scope.preauthorisations > a > span > span")
public WebElementFacade preauthorization_Link;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.header-container.horizontal-fixed > h3")
public WebElementFacade preauthorization_text;

@FindBy(css="#merchant-portal > div.container.ng-isolate-scope > div > navigation > div > ul > li.ng-scope.authorisations > a > span > span")
public WebElementFacade Authorizations_Link;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.header-container.horizontal-fixed > h3")
public WebElementFacade Authorizations_text;

@FindBy(css="#merchant-portal > div.container.ng-isolate-scope > div > navigation > div > ul > li.ng-scope.transaction > a > span > span")
public WebElementFacade transaction_Link;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.header-container.horizontal-fixed > h3")
public WebElementFacade transaction_text;

@FindBy(css="#merchant-portal > div.container.ng-isolate-scope > div > navigation > div > ul > li.ng-scope.funding > a > span > span")
public WebElementFacade funding_Link;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.header-container.horizontal-fixed > h3")
public WebElementFacade funding_text;

@FindBy(css="#merchant-portal > div.container.ng-isolate-scope > div > navigation > div > ul > li.ng-scope.messages > a > span > span")
public WebElementFacade messages_Link;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(1) > div > h3")
public WebElementFacade messages_text;

@FindBy(css="#merchant-portal > div.container.ng-isolate-scope > div > navigation > div > ul > li.ng-scope.documents > a > span > span")
public WebElementFacade documents_Link;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(1) > div > h3")
public WebElementFacade documents_text;

@FindBy(css="#merchant-portal > div.container.ng-isolate-scope > div > navigation > div > ul > li.ng-scope.more > a")
public WebElementFacade more_option;

@FindBy(css="#merchant-portal > div.container.ng-isolate-scope > div > navigation > div > ul > li.ng-scope.more > ul > li.ng-scope.faq > a > span > span")
public WebElementFacade help_option;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(1) > div > h3")
public WebElementFacade help_text;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > section > div.swiper-container > div.swiper-wrapper > div.dashboard-block-right.ng-scope > div.swiper-slide.flex-order-4.sw-right > preauth > section > div.header > h1")
public WebElementFacade pre_authorization_widget;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > section > div.swiper-container > div.swiper-wrapper > div.dashboard-block-right.ng-scope > div.swiper-slide.flex-order-4.sw-right > preauth > section > div.content > div > div.manage > a")
public WebElementFacade Navigate_Pre_auth_view;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > section > div.swiper-container > div.swiper-wrapper > div.dashboard-block-left > div.swiper-slide.flex-order-3.sw-left > transfers > div.header > span")
public WebElementFacade funding_Dashboard_Text;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > section > div.swiper-container > div.swiper-wrapper > div.dashboard-block-left > div.swiper-slide.flex-order-3.sw-left > transfers > div.header > a")
public WebElementFacade view_details_funding;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > no-records > div > div > div.header > span:nth-child(2)")
public WebElementFacade Couldnot_find_result_text;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > section > div.swiper-container > div.swiper-wrapper > div.dashboard-block-left > div.swiper-slide.flex-order-2.sw-left > sales > section > div.header > a")
public WebElementFacade Sales_dashboard_link;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div > div.col-lg-12.tab-inside.ng-scope > div > transaction-search > form > div.date-picker > div > span.input-group-btn > button > i")
public WebElementFacade date_dropdown;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > button:nth-child(2)")
public WebElementFacade Last_7_days_link;

@FindBy(css="#extended-datepicker-popup > div.extended-interface > div > button.info.ng-scope")
public WebElementFacade Apply_button;

@FindBy(css="#tg-7241 > div.tg-row-outer.tg-row-header-outer > div > div.tg-column.tg-header.ng-scope.tg-col-id-1.sortable.tg-w-8.tg-fixed-w-8 > span > span.header-label.ng-binding.ng-scope > span:nth-child(1)")
public WebElementFacade posting_date;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > section > div.header-chart > div > currency-selector > a > i.fa.fa-angle-down")
public WebElementFacade currency_drop_down;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > section > div.header-chart > div > currency-selector > ul > li:nth-child(1)")
public WebElementFacade EUR_currency;


@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > section > div.header-chart > div > currency-selector > ul > li:nth-child(2)")
public WebElementFacade USD_currency;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > section > div.swiper-container > div.swiper-wrapper > div.dashboard-block-left > div.swiper-slide.flex-order-1.sw-left > payments > div.content > div.heading > div.title.ng-binding")
public WebElementFacade currency_Text_Validation;


@FindBy(css="#merchant-portal > div.container.ng-isolate-scope.dashboard-page > div > navigation > div > ul > li.ng-scope.more.hover > ul > li.ng-scope.settings > a > span > span")
public WebElementFacade settings;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div > div.account-settings-details-container.personal > div.btn-group.dropdown > button.btn.dropdown-toggle > span")
public WebElementFacade Language_dropDown;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div > div.account-settings-details-container.personal > div.btn-group.dropdown.open > ul > li:nth-child(1) > a")
public WebElementFacade English_Language;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div > div.account-settings-details-container.personal > div.btn-group.dropdown.open > ul > li:nth-child(2) > a")
public WebElementFacade Dutch_Language;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div > div.account-settings-details-container.personal > div.btn-group.dropdown.open > ul > li:nth-child(3) > a")
public WebElementFacade French_Language;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div > div.account-settings-details-container.personal > div.btn-group.dropdown.open > ul > li:nth-child(4) > a")
public WebElementFacade German_Language;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > div > div > button")
public WebElementFacade Save_language_button;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > form > div:nth-child(2) > div > div > button")
public WebElementFacade Continue_dashboard_button;

@FindBy(css="#main > div.row.content > div > div:nth-child(2) > div > div:nth-child(1) > div > div:nth-child(2) > section > div.swiper-container > div.swiper-wrapper > div.dashboard-block-left > div.swiper-slide.flex-order-1.sw-left > payments > div.header > span")
public WebElementFacade payment_dashboard_text;

@FindBy(css="#main > div:nth-child(1) > div > div:nth-child(2) > div > button > span:nth-child(1)")
public WebElementFacade message_notofication_cross_symbol;

@FindBy(css="#main > div:nth-child(1) > div > div:nth-child(2) > div > a")
public WebElementFacade Read_more_message_notofication;

@FindBy(css="#main > div:nth-child(1) > div > div:nth-child(2) > div > h4")
public WebElementFacade Message_Title_Notification;

@FindBy(css="#main > div:nth-child(1) > div > div:nth-child(2) > div > p:nth-child(4)")
public WebElementFacade Message_subtitle_notification;

@FindBy(css="#merchant-portal > div.modal.fade.ng-isolate-scope.popup.new-alerts.in > div > div > button")
public WebElementFacade unread_alerts;

@FindBy(css="#merchant-portal > div.modal.fade.ng-isolate-scope.popup.new-alerts.in > div > div > p:nth-child(1)")
public WebElementFacade unread_alerts_title;

@FindBy(css="#merchant-portal > div.container.ng-isolate-scope > div > navigation > div > ul > li.ng-scope.logout > a > i")
public WebElementFacade logout;



public WebElement Welcome_message(){
    return Welcome_message;
  }
public WebElement login_date(){
    return login_date;
  }
public WebElement message_indicator_count(){
    return message_indicator_count;
  }
public WebElement document_indicator_count(){
    return document_indicator_count;
  }

public WebElement Portal_cookie_message(){
    return Portal_cookie_message;
  }
public WebElement portal_cookie_details(){
    return portal_cookie_details;
  }
 
public WebElement cookie_page(){
    return cookie_page;
  }
public WebElement preauthorization_Link(){
    return preauthorization_Link;
  }
public WebElement preauthorization_text(){
    return preauthorization_text;
  }
public WebElement transaction_Link(){
    return transaction_Link;
  }
public WebElement transaction_text(){
    return transaction_text;
  }
public WebElement Authorizations_text(){
    return Authorizations_text;
  }
public WebElement Authorizations_Link(){
    return Authorizations_Link;
  }
public WebElement funding_text(){
    return funding_text;
  }
public WebElement funding_Link(){
    return funding_Link;
  }
public WebElement messages_text(){
    return messages_text;
  }
public WebElement messages_Link(){
    return messages_Link;
  }
public WebElement documents_text(){
    return documents_text;
  }
public WebElement documents_Link(){
    return documents_Link;
  }

public WebElement more_option(){
    return more_option;
  }
public WebElement help_option(){
    return help_option;
  }

public WebElement help_text(){
    return help_text;
  }
public WebElement pre_authorization_widget(){
	return pre_authorization_widget;	
}
public WebElement Navigate_Pre_auth_view(){
	return Navigate_Pre_auth_view;	
}
public WebElement funding_Dashboard_Text(){
	return funding_Dashboard_Text;	
}
public WebElement view_details_funding(){
	return view_details_funding;	
}
public WebElement Sales_dashboard_link(){
	return Sales_dashboard_link;
}
public WebElement date_dropdown(){
	return date_dropdown;
}
public WebElement Last_7_days_link(){
	return Last_7_days_link;
}
public WebElement Apply_button(){
	return Apply_button;
}	
public WebElement Couldnot_find_result_text(){
	return Couldnot_find_result_text;
}
public WebElement posting_date(){
	return posting_date;
	
}
public WebElement currency_drop_down(){
    return currency_drop_down;
  }
public WebElement EUR_currency(){
    return EUR_currency;
  }
public WebElement USD_currency(){
    return USD_currency;
  }

public WebElement settings(){
    return settings;
  }
public WebElement Language_dropDown(){
	return Language_dropDown;
}
public WebElement English_Language(){
    return English_Language;
  }
public WebElement Dutch_Language(){
    return Dutch_Language;
  }
public WebElement French_Language(){
    return French_Language;
  }
public WebElement German_Language(){
    return German_Language;
  }
public WebElement Save_language_button(){
    return Save_language_button;
  }
public WebElement Continue_dashboard_button(){
    return Continue_dashboard_button;
  }
public WebElement payment_dashboard_text(){
    return payment_dashboard_text;
  }

public WebElement currency_Text_Validation(){
    return currency_Text_Validation;
  }
public WebElement message_notofication_cross_symbol(){
	return message_notofication_cross_symbol;
}
public WebElement Read_more_message_notofication(){
	return Read_more_message_notofication;
}
public WebElement Message_Title_Notification(){
    return Message_Title_Notification;
  }
public WebElement Message_subtitle_notification(){
    return Message_subtitle_notification;
  }
public WebElement unread_alerts(){
	return unread_alerts;
}
public WebElement unread_alerts_title(){
	return unread_alerts_title;
}
public WebElement logout(){
	return logout;
}
}
