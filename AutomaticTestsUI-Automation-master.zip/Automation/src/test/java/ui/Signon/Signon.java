package ui.Signon;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Step;
import ui.pageobjects.Signon.DashboardPage_Objects;
import ui.pageobjects.Signon.SignonObjects;
public class Signon extends PageObject{

	String Result=null;
	WebDriver driver =null;
	SignonObjects signonObjects;
	DashboardPage_Objects dasboardpageObjects;

@Step
public void loadbrowser(){
	
	System.out.println("Loading Browser");
	System.out.println("Launched CHrome Browser");
	driver = this.getDriver();	
}
	
@Step
public void navigate(String url) throws Exception{

	driver.get(url);	
}
@Step
public void RememberMe() throws InterruptedException{
	WebDriverWait wait = new WebDriverWait(driver, 10);
	wait.until(ExpectedConditions.elementToBeClickable(signonObjects.RememberMe()));
	if(signonObjects.RememberMe().isDisplayed()){
		signonObjects.RememberMe().click();
	}
	
}
@Step
public String userInput(String fieldName, String fieldValue) throws InterruptedException{
	System.out.println(fieldName);
	WebDriverWait wait = new WebDriverWait(driver, 10);
	if (fieldName.equals("UserName")){
		wait.until(ExpectedConditions.elementToBeClickable(signonObjects.UserName()));
		signonObjects.UserName().sendKeys(fieldValue);
		Result="Passed";
	}
	
	else if(fieldName.equals("Password"))
	{
		signonObjects.Password().sendKeys(fieldValue);
		Result="Passed";
	}
	else if(fieldName.equals("Alliance"))
	{
		signonObjects.alliance().sendKeys(fieldValue);
		Result="Passed";
	}
	return Result;
}
@Step
public String Submitlogin_for_alert_testcase() throws InterruptedException{
	WebDriverWait wait = new WebDriverWait(driver, 30);
	signonObjects.Submit().click();
	return Result;
	
}
@Step
public String Submitlogin(String welcome_text) throws InterruptedException{
	WebDriverWait wait = new WebDriverWait(driver, 30);
	signonObjects.Submit().click();
	wait.until(ExpectedConditions.elementToBeClickable(dasboardpageObjects.login_date()));
	String login=dasboardpageObjects.login_date().getText();
	String status=dasboardpageObjects.Welcome_message().getText();
	System.out.println(welcome_text+" "+status+" "+login);
	if(dasboardpageObjects.unread_alerts.isCurrentlyVisible())
	{
		dasboardpageObjects.unread_alerts().click();
		if(dasboardpageObjects.Welcome_message().getText().contains(welcome_text)/* || dasboardpageObjects.login_date().equals("Last login ")*/)
		{
			Result="Passed";
		}
		else {
			Result="Failed";
					
		}
	}
	
	return Result;
}
@Step
public String login_admin_console() {
	WebDriverWait wait = new WebDriverWait(driver, 30);
	signonObjects.login_admin().click();
	wait.until(ExpectedConditions.elementToBeClickable(signonObjects.Welcome_text_admin()));
	if(signonObjects.Welcome_text_admin().getText().contains("User"))
	{
		Result="Passed";
	}
	else {
		Result="Failed";
				
	}
	
	return Result;
}

/*public void Preauth() throws InterruptedException {
	// TODO Auto-generated method stub
	
	signonObjects.Preauth().click();
	
}
@Step
public void Detail() throws InterruptedException {
	// TODO Auto-generated method stub
	
	signonObjects.Detail().click();
	
}
@Step
public void LastLoginDate() throws InterruptedException {

	
	
	
	Date today = new Date();
	SimpleDateFormat formatDate= new SimpleDateFormat("dd/MM/yyyy HH:mm"); 
	String date = formatDate.format(today);
	String[] dateTime=date.split(" ");
	System.out.println(date);
	String[] actualValue= signonObjects.LastLoginDate().getText().split(",");
	System.out.println(actualValue[0]+"///"+dateTime[0].concat(",")+dateTime[1]);
	org.junit.Assert.assertEquals(dateTime[0],actualValue[0]);
	
}

@Step
public void DashboardDate(){
	Date date = new Date();
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEEE");
    String Day=simpleDateFormat.format(date);
    simpleDateFormat = new SimpleDateFormat("MMMM");
    String Month=simpleDateFormat.format(date);
    simpleDateFormat = new SimpleDateFormat("YYYY");
    String year=simpleDateFormat.format(date);
    simpleDateFormat=new SimpleDateFormat("dd");
    String curdate=simpleDateFormat.format(date);
    String Dashboarddate=Day+","+" "+Month+" "+curdate+","+" "+year;
    String actualValue= signonObjects.DashboardDate().getText();
    System.out.println(actualValue+"\\\\"+Dashboarddate);
    org.junit.Assert.assertEquals(actualValue,Dashboarddate);
    
    
}*/


}






