package common;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.Proxy.ProxyType;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class WebdriverUsingProxy {

private List<String> urlList = new ArrayList<String>();

@Before
public void setup() {
urlList.add("https://uat1.merchantportal.firstdata.eu/emsMerchantUI/#/");
//urlList.add("https://news.google.com");
}

@Test
public void passTraffixThroughProxyTest() throws InterruptedException {
String httpProxy = "fdcproxy.1dc.com:8080";
String sslProxy = "fdcproxy.1dc.com:8080";
String ftpProxy = "fdcproxy.1dc.com:8080";

DesiredCapabilities capability = new DesiredCapabilities();
addProxyCapabilities(capability, httpProxy, sslProxy, ftpProxy);

for (String url : urlList){
System.setProperty("webdriver.chrome.driver", "C:\\Users\\f8j6upo\\Downloads\\Automation\\Automation\\libs\\chromedriver.exe");
WebDriver driver = new ChromeDriver(capability);
driver.get(url);
Thread.sleep(5000);
//driver.close();
}
}


public static DesiredCapabilities addProxyCapabilities(DesiredCapabilities capability, String httpProxy, String sslProxy,
String ftpProxy) {
Proxy proxy = new Proxy();
proxy.setProxyType(ProxyType.MANUAL);
proxy.setHttpProxy(httpProxy);
proxy.setSslProxy(sslProxy);
proxy.setFtpProxy(ftpProxy);

capability.setCapability(CapabilityType.PROXY, proxy);
capability.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
return capability;
}
} 



/*
Proxy proxy = new Proxy();
proxy.setProxyType(ProxyType.MANUAL);
//properties = Settings.getInstance();
String proxyUrl = "fdcproxy.1dc.com:8080";
proxy.setHttpProxy(proxyUrl);
proxy.setFtpProxy(proxyUrl);
proxy.setSslProxy(proxyUrl);
DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
desiredCapabilities.setCapability(CapabilityType.PROXY, proxy);



*/
/*
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class WebdriverUsingProxy {

public static void main(String[] args) {

Proxy p=new Proxy();
p.setHttpProxy("http://fdcproxy.1dc.com:8080/accelerated_pac_base.pac:8080");
DesiredCapabilities cap=new DesiredCapabilities();
cap.setCapability(CapabilityType.PROXY, p);
WebDriver driver = new ChromeDriver(cap);

}
} */
