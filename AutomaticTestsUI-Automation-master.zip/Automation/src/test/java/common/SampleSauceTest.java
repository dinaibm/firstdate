/*package common;
 
 
/*import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import java.net.URL;
 
public class SampleSauceTest {
 
  public static final String USERNAME = "Dinakaran.GK";
  public static final String ACCESS_KEY = "a1a9080c-2a89-4f35-b9ed-cacc04a142c6";
  public static final String URL = "http://Dinakaran.GK:a1a9080c-2a89-4f35-b9ed-cacc04a142c6@ondemand.saucelabs.com:80/wd/hub";
 
  public static void main(String[] args) throws Exception {
 
    DesiredCapabilities caps = DesiredCapabilities.chrome();
    caps.setCapability("platform", "Windows XP");
    caps.setCapability("version", "43.0");
    caps.setCapability("browserName", "chrome");
//caps.setCapability("version", "60");
 
 
    WebDriver driver = new RemoteWebDriver(new URL(URL), caps);
    driver.get("https://google.com");
    System.out.println("title of page is: " + driver.getTitle());
    
    driver.quit();
  }
} */
 
 
 
 /*
 
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.Proxy.ProxyType;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
 
public class SampleSauceTest {
 
public static WebDriver driver = null;
public static final String USERNAME = "Dinakaran.GK";
public static final String ACCESS_KEY = "a1a9080c-2a89-4f35-b9ed-cacc04a142c6";
public static final String URL = "https://" + USERNAME + ":" + ACCESS_KEY + "@ondemand.saucelabs.com:80/wd/hub";

private static ThreadLocal<WebDriver> webDriverSauce = new ThreadLocal<WebDriver>();
private static ThreadLocal<String> sessionId = new ThreadLocal<String>();
 
/*public static void main(String[] args) throws Exception { */
/*	public static void SauceTest() throws MalformedURLException {
driver = createdriver("chrome", "41", "Windows 7", "Testcase");
driver.get("https://uat1.merchantportal.firstdata.eu/MerchantAdminWeb/login");
System.out.println("title of page is: " + driver.getTitle());
 
driver.quit();
return;
} 
 
public static WebDriver createdriver(String browser, String version, String os, String methodName)
throws MalformedURLException {
 
	DesiredCapabilities capabilities = new DesiredCapabilities();
	
	/* Proxy proxy = new Proxy();
	proxy.setProxyType(ProxyType.MANUAL);
	String proxyUrl = "fdcproxy.1dc.com:8080";
	proxy.setHttpProxy(proxyUrl);
	proxy.setFtpProxy(proxyUrl);
	proxy.setSslProxy(proxyUrl);
	capabilities.setCapability(CapabilityType.PROXY, proxy);
	capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true); */

//DesiredCapabilities capabilities = new DesiredCapabilities();
/*capabilities.setCapability(CapabilityType.BROWSER_NAME, browser);
if (version != null) {
capabilities.setCapability(CapabilityType.VERSION, version);
}
capabilities.setCapability(CapabilityType.PLATFORM, os);
 
String jobName = methodName + '_' + os + '_' + browser + '_' + version;
capabilities.setCapability("name", jobName);
 
webDriverSauce.set(new RemoteWebDriver(
		new URL("http://" + USERNAME + ":" + ACCESS_KEY + "@localhost:4445/wd/hub"), capabilities));

//new URL("http://" + USERNAME + ":" + ACCESS_KEY + "@ondemand.saucelabs.com:80/wd/hub"), capabilities));

String id = ((RemoteWebDriver) getWebDriver()).getSessionId().toString();
sessionId.set(id);
 
String message = String.format("SauceOnDemandSessionID=%1$s job-name=%2$s", id, jobName);
System.out.println(message);
 
return webDriverSauce.get();
 
}
 
public static WebDriver getWebDriver() {
System.out.println("WebDriver" + webDriverSauce.get());
return webDriverSauce.get();
}
 
public String getSessionId() {
return sessionId.get();
}
}
*/

package common;



import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

//import org.openqa.selenium.Proxy;
//import org.openqa.selenium.Proxy.ProxyType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;


public class SampleSauceTest {
 
public static WebDriver driver = null;
public static final String USERNAME = "Dinakaran.GK";
public static final String ACCESS_KEY = "a1a9080c-2a89-4f35-b9ed-cacc04a142c6";
public static final String URL = "https://" + USERNAME + ":" + ACCESS_KEY + "@ondemand.saucelabs.com:80/wd/hub";
private static ThreadLocal<WebDriver> webDriverSauce = new ThreadLocal<WebDriver>();
private static ThreadLocal<String> sessionId = new ThreadLocal<String>();
 
/*public static void main(String[] args) throws Exception {*/
public static WebDriver SauceTest() throws MalformedURLException {
	// TODO Auto-generated method stub
	 driver = createdriver("chrome", "41", "Windows 7", "Testcase");
	 
	 //driver = createdriver("Browser", "4.4", "Android", "Testcase");

	// driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
	// driver.manage().timeouts().pageLoadTimeout(120, TimeUnit.SECONDS);
	 
//driver.get("www.google.com");
//driver.get("https://uat1.merchantportal.firstdata.eu/MerchantAdminWeb/login");
System.out.println("title of page is: " + driver.getTitle());
//driver.quit();
return driver;

} 
 
public static WebDriver createdriver(String browser, String version, String os, String methodName)
throws MalformedURLException {
 
	/*Proxy proxy = new Proxy();
	proxy.setProxyType(ProxyType.MANUAL);
	String proxyUrl = "fdcproxy.1dc.com:8080";
	proxy.setHttpProxy(proxyUrl);
	proxy.setFtpProxy(proxyUrl);
	proxy.setSslProxy(proxyUrl);
	DesiredCapabilities capabilities = new DesiredCapabilities();
	capabilities.setCapability(CapabilityType.PROXY, proxy);
	capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);  */

DesiredCapabilities capabilities = new DesiredCapabilities();
capabilities.setCapability(CapabilityType.BROWSER_NAME, browser);
if (version != null) {
capabilities.setCapability(CapabilityType.VERSION, version);
}
capabilities.setCapability(CapabilityType.PLATFORM, os);


	/*DesiredCapabilities capabilities = DesiredCapabilities.iphone();
	capabilities.setCapability("appiumVersion", "1.7.1");
	capabilities.setCapability("deviceName","Samsung Galaxy Nexus Emulator");
	capabilities.setCapability("deviceOrientation", "portrait");
	capabilities.setCapability("platformVersion",version);
	capabilities.setCapability("platformName", os);
	capabilities.setCapability("browserName", browser); */
	
 
String jobName = methodName + '_' + os + '_' + browser + '_' + version;
capabilities.setCapability("name", jobName);
 
webDriverSauce.set(new RemoteWebDriver(
new URL("http://" + USERNAME + ":" + ACCESS_KEY + "@localhost:4445/wd/hub"), capabilities));
String id = ((RemoteWebDriver) getWebDriver()).getSessionId().toString();
sessionId.set(id);
 
String message = String.format("SauceOnDemandSessionID=%1$s job-name=%2$s", id, jobName);
System.out.println(message);


return webDriverSauce.get();
 
}
 
public static WebDriver getWebDriver() {
System.out.println("WebDriver" + webDriverSauce.get());
return webDriverSauce.get();
}
 
public String getSessionId() {
return sessionId.get();
}


}




 