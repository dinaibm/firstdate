package stepdefinitions;

import java.io.File;
import java.io.FileWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;
import javax.servlet.http.HttpSession;

import org.eclipse.jetty.websocket.api.Session;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.XML;
import org.openqa.selenium.remote.server.handler.GetSessionCapabilities;
import org.openqa.selenium.remote.server.handler.GetTagName;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ResponseBody;
import com.jayway.restassured.response.ResponseBodyExtractionOptions;

import api.LoadRequest;

import api.PostRequest;

import api.ValidateRequest;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import net.serenitybdd.screenplay.GivenWhenThen;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import Reports.TestResult;

import org.junit.Test;

public class Apidefinitions {
	TestResult lib=new TestResult();

public static Response responsebody;
public static HttpSession strSess;
public String strresponse;
public String strfilename;
public String strPath;
public String date1;

	@Steps
	LoadRequest loadrequest;
	@Steps
	PostRequest postrequest;
	@Steps
	ValidateRequest validateRequest;
	
	@Before
	public void bfre(){
		//driver=new WrappedWebDriver().newDriver();
		//lib.initializeTest(loadrequest.getTag(arg1));
	} 
	
	@After
	public void aftr()
	{
		lib.closeTestReport();
		lib.endTestReport();
		lib.SummarizeTestReport();
	}
	//--------------------------------------------------------------------
	/*@Given("^a request for Country \"([^\"]*)\"$")
	public void a_GET_Method_request_for_Country(String arg1) throws Throwable {
		lib.initializeTest("a_GET_Method_request_for_Country");
		lib.WriteReportStep("1", "Get Request", "", "", "");
		loadrequest.loadgetrequestdata(arg1);
		lib.WriteReportStep("2", "Get Request", "Get Request should be successful", "Get Request for country is Success", "Passed");
	}

	@When("^request is sent to \"([^\"]*)\"$")
	public void request_is_sent_to(String arg1) throws Throwable {
		System.out.println("2ndarg1"+arg1);
		lib.WriteReportStep("1", "Post Request", "", "", "");
		postrequest.postGETRequest(arg1);
		lib.WriteReportStep("2", "Post Request", "Request should be successful", "Request posted successfully", "Passed");
	}*/

	
	
		
/*	@And("^retrieved country code in \"([^\"]*)\" is \"([^\"]*)\"$")
	public void retrieved_state_count_in_is(String arg1, String arg2) throws Throwable {
		
		System.out.println("4tharg1"+arg1+"==>"+arg2);
		lib.WriteReportStep("1", "Retrive State Count", "", "", "");   
		validateRequest.resultvalidation(arg1,arg2,responsebody);
		lib.WriteReportStep("2", "Retrive State Count", "State Count should be successful", "Retrive State Count was Successful", "Passed");
	}*/
	
//----------------------------------------------------------------	
	
	@Given("^a request for application api \"([^\"]*)\" and \"([^\"]*)\"$")
	public void a_request_for_application_api(String arg1, String arg2) throws Throwable {
		lib.initializeTest("RequestForApplicationApiInfo"+arg2+"");
		lib.WriteReportStep("1", "Get Request url", "", "", "");
		loadrequest.loadgetrequestdata(arg1);
		lib.WriteReportStep("2", "Get Request url", "Get Request for MP should be successful", "Requested MP Application successfully", "Passed");
	}
	
	@When("^get request is sent to \"([^\"]*)\"$")
	public void get_request_is_sent_to(String arg1) throws Throwable {
		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		
		postrequest.postGETRequest(arg1);
		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful", "Request posted successfully", "Passed");
	}

	@Then("^status code is \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void status_code_is(String arg1,String arg2,String arg3,String arg4,String arg5,String arg6) throws Throwable {
		
		String strResponse;
		lib.WriteReportStep("1", "Verify Response", "", "", "");
		strResponse=validateRequest.statuscode(arg1, responsebody);
		String[] strRep= strResponse.split("\\|");
		/*if(strRep[0].equalsIgnoreCase("200"))
		{*/
			String strJsonResponse;
			String[] strVal; 
			String[] strNode={"status","error","appName:versionNumber:buildDate"};
			lib.WriteReportStep("2", "Verify Response Code", "Response Code should be 200", "Response Code : <b>"+strRep[0]+"</b>", "Passed");
			if(strRep[1]!=null)
			{
				ValidateRequest.writexml("request for application api_"+arg6, strRep[1]);//strRep[1]
				strJsonResponse=ValidateRequest.JsonRead("request for application api_"+arg6,strNode);
				strVal=strJsonResponse.split("\\|");
				if(strVal[0].equalsIgnoreCase(arg2))
				{
					lib.WriteReportStep("2", "Verify Response", "Expected Response status should be success", "Response : <b>Status</b> ="+"<b>"+strVal[0]+"</b>", "Passed");
					/*for(int j=0;j<strVal.length;j++)
					{
						lib.WriteReportStep("2", "Verify Response", "Extract Response", "Response : <b>"+strNode[j]+ "</b> =" +"<b>"+strVal[j]+"</b>", "Passed");
					}*/
					String[] strRepCode=strVal[2].split("\\:");
					if(strRepCode[0].trim().equalsIgnoreCase((arg3).trim()))
					{
						lib.WriteReportStep("2", "Verify Response", "Expected Response Appname should be:<b> "+arg3+"</b>", "Response : <b>AppName</b> =" +"<b>"+strRepCode[0]+"</b>", "Passed");
					}
					if(strRepCode[1].trim().equalsIgnoreCase((arg4.trim())))
					{
						lib.WriteReportStep("2", "Verify Response", "Expected Response versionNumber should be :<b> "+arg4+"</b>", "Response : <b>VersionNumber</b> =" +"<b>"+strRepCode[1]+"</b>", "Passed");
					}
					if(strRepCode[2].trim().equalsIgnoreCase((arg5.trim())))
					{
						lib.WriteReportStep("2", "Verify Response", "Expected Response buildDate should :<b> "+arg5+"</b>", "Response : <b>BuildDate</b> =" +"<b>"+strRepCode[2]+"</b>", "Passed");
					}
				}
				else if(strVal[0].equalsIgnoreCase(arg2))
				{
					String[] strRepCode=strVal[1].split("\\:");
					lib.WriteReportStep("2", "Verify Error Response ", "Error Reponse ", "Error Response Code : "+strRepCode[0]+"And"+strRepCode[1], "Failed");
				
				}
				else
				{
					
				}
				
			}
	/*	}
		else
		{
			lib.WriteReportStep("2", "Verify Response Code", "Response Code should be 200", "Response Code : "+strRep[0], "Failed");
			// fail code
		}*/
	}
	
	/*@And("^verification of Merchant portal status in \"([^\"]*)\"$")
	public void VerificationMerchantPortalStatus(String arg1) throws Throwable {
		
		lib.WriteReportStep("1", "Retrieve application info", "", "", "");   
		validateRequest.resultvalidation(arg1,arg2,responsebody);
		lib.WriteReportStep("2", "Retrieve application info", "Application info should be retrieved", "Retrieve State Count was Successful", "Passed");
	}*/
	
	//-----------------------------------------------------------------------------
	
	@Given("^a request for application api post \"([^\"]*)\" and \"([^\"]*)\"$")
	public void a_request_for_application_api_post(String arg1, String arg2) throws Throwable {
		lib.initializeTest("RequestForApplicationApiInfo"+arg2+"");
		lib.WriteReportStep("1", "Get Request url", "", "", "");
		//loadrequest.loadpostrequestdata(loadrequest.POST_API("https://uat1.merchantportal.firstdata.eu/MerchantApiWeb/v4/rest/authenticateUser?"), "D:\\Results\\JsonRequests\\authentication.json");
		//loadrequest.loadpostrequestdata("https://uat1.merchantportal.firstdata.eu/MerchantApiWeb/v4/rest/authenticateUser?", "D:\\Results\\JsonRequests\\authentication.json");
		lib.WriteReportStep("2", "Get Request url", "Get Request for MP should be successful", "Requested MP Application successfully", "Passed");
	}
	
	@When("^post request is sent to \"([^\"]*)\"$")
	public void post_request_is_sent_to(String arg1) throws Throwable {
		String strResponse;
		lib.WriteReportStep("1", "Post Get Request", "", "", "");
		postrequest.postJson("D:\\Results\\JsonRequests\\authentication.json");
		strResponse=loadrequest.GET_ExeAPI_ReqPropertyJSON("https://uat1.merchantportal.firstdata.eu/MerchantApiWeb/v4/rest/authenticateUser");
		System.out.println("vaary"+strResponse);
		lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful", "Request posted successfully", "Passed");
	}
	
	@Then("^get request code \"([^\"]*)\"$")
	public void post_ExecuteRequest(String arg1) throws Throwable 
	{
		loadrequest.loadgetrequestdata(arg1);
		postrequest.postGETRequest(arg1);
	}



//-------------------------------------------------------------

	@Given("^load request for user authentication \"([^\"]*)\" and \"([^\"]*)\"$")
	public void load_request_for_user_authentication(String appurl, String report) throws Throwable {
		DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
		Date date = new Date();
		String date1= dateFormat.format(date);
		System.out.println(""+date1);
		strfilename="Authenticate User_"+report+""+date1;
		System.out.println("*****"+strfilename);
		lib.initializeTest("Authenticate User_"+report+"");
		lib.WriteReportStep("1", "Get Request url", "", "", "");
		loadrequest.loadgetrequestdata(appurl);
		lib.WriteReportStep("2", "Get Request url and load request", "Load Request for user authentication should be successful", "Request loaded for User Authentication successfully", "Passed");
	}
	
	@When("^post request for user authentication \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void post_request_for_user_authentication(String appurl, String userName, String password, String allianceCode) throws Throwable {
		lib.WriteReportStep("1", "post request for user authentication", "", "", "");
		/*postrequest.authenticateuser(appurl, userName, password, allianceCode);
		postrequest.postND(appurl, Authenticateuser);
		Map usrauthenticate = postrequest.authenticateuser(appurl, userName, password, allianceCode);
		//System.out.println("******"+usrauthenticate.toString());
		postrequest.postPOSTRequest(appurl, usrauthenticate);*/
		
		Response response=postrequest.postND(appurl, userName, password, allianceCode);
		
		strresponse=response.asString();
		
		System.out.println("Post response****"+strresponse);
		writejsonresponse(strfilename, strresponse);
		
		
		/*postrequest.postGETRequest("https://uat1.merchantportal.firstdata.eu/MerchantApiWeb/rest/secure/user/financialData/sales/getSalesSummary?currency=EUR");
		*/
		//Session Login = responsebody();
		
		/*Session strsssion=(Session) responsebody.detailedCookies();
		if(strsssion.isOpen())
		{
			System.out.println("Session is on");
		}
		*/
		//postrequest.postPOSTRequest(appurl, usrauthenticate);
		// postrequest.get("https://uat1.merchantportal.firstdata.eu/MerchantApiWeb/rest/secure/user/financialData/sales/getSalesSummary?currency=EUR")

		lib.WriteReportStep("2", "Post Request", "Request should be posted successful", "Request posted successfully", "Passed");
		lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully", "Response retrieved successfully and placed in the path-" +"<b>"+strPath+"</b>", "Passed");
		
	}
	@Then("^verify user authentication response \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_user_authentication_response(String status, String ErrorCode, String Message, String AuthErrMessage, String Authaccessdenied, String AuthErrCause) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("verifyresponsestarted");
		String strStatus = Apidefinitions.responsebody.body().jsonPath().getJsonObject("status");
		System.out.println("strStatus is"+strStatus);
		validateRequest.verifyresponse(status,ErrorCode,Message,AuthErrMessage,Authaccessdenied,AuthErrCause);
		verifyresponsereport(status,ErrorCode,Message,AuthErrMessage,Authaccessdenied,AuthErrCause);
		
}
		


//----------------------------------------------------------------------------

@Given("^load request for application info \"([^\"]*)\" and \"([^\"]*)\"$")
public void load_request_for_application_info(String appurl, String report) throws Throwable {
	DateFormat dateFormat = new SimpleDateFormat("MMddyyyyhhss");
	Date date = new Date();
	String date1= dateFormat.format(date);
	lib.initializeTest("Application Information validation"+report+"");
	lib.WriteReportStep("1", "Get Request url and load request", "", "", "");
	loadrequest.loadgetrequestdata(appurl);
	strfilename="Application info_"+report+""+date1;
	System.out.println("*****"+strfilename);
	
	lib.WriteReportStep("2", "Get Request url and load request", "Load Request for application info should be successful", "Request loaded for application info successfully", "Passed");
}

@When("^post get request application info \"([^\"]*)\"$")
public void post_get_request_application_info(String appurl) throws Throwable {
	lib.WriteReportStep("1", "Post Get Request", "", "", "");
	postrequest.postGETRequest(appurl);
	strresponse=Apidefinitions.responsebody.asString();
	writejsonresponse(strfilename, strresponse);
	lib.WriteReportStep("2", "Post Get Request", "Request should be posted successful", "Request posted successfully", "Passed");
	lib.WriteReportStep("2", "Retrieve Response", "Response should be retrieved successfully", "Response retrieved successfully and placed in the path-" +"<b>"+strPath+"</b>", "Passed");
}

@Then("^verify application info response status \"([^\"]*)\"$")
public void verify_application_info_response_status(String status) throws Throwable {
	lib.WriteReportStep("1", "verify application info response status", "", "", "");
	validateRequest.verifyresponse(status, "", "", "", "", "");
	verifyresponsereport(status, "", "", "", "", "");
}
//---------------------------------------------------------
public void verifyresponsereport(String status,String ErrorCode,String Message,String AuthErrMessage,String Authaccessdenied,String AuthErrCause){
	String strStatus = Apidefinitions.responsebody.body().jsonPath().getJsonObject("status");
	if((strStatus!=null && strStatus.equalsIgnoreCase("success"))){
		lib.WriteReportStep("1", "verify user authentication response", "", "", "");
		lib.WriteReportStep("2", "verify user authentication response status", "Expected Response status should be:<b> "+status+"</b>", "Response : <b>Status</b> =" +"<b>"+strStatus+"</b>", "Passed");
		}
		else if(strStatus!=null && strStatus.equalsIgnoreCase("error")){
		lib.WriteReportStep("1", "verify user authentication response", "", "", "");
		lib.WriteReportStep("2", "verify user authentication response status", "Expected Response status should be:<b> "+status+"</b>", "Response : <b>Status</b> =" +"<b>"+strStatus+"</b>", "Passed");
		String strerrorcode = Apidefinitions.responsebody.body().jsonPath().getString("errors.code[0]");
		System.out.println("strcode is"+strerrorcode);
		lib.WriteReportStep("2", "verify user authentication response error code", "Expected Response error code should be:<b> "+ErrorCode+"</b>", "Response : <b>Status</b> =" +"<b>"+strerrorcode+"</b>", "Passed");
		String strmessage = Apidefinitions.responsebody.body().jsonPath().getString("errors.message[0]");
		System.out.println("strcode is"+strmessage);
		lib.WriteReportStep("2", "verify user authentication response error message", "Expected Response error message should be:<b> "+Message+"</b>", "Response : <b>Status</b> =" +"<b>"+strmessage+"</b>", "Passed");
		}
		else if(strStatus==null)
	     {
			lib.WriteReportStep("1", "verify user authentication response", "", "", "");
			String strcode= Apidefinitions.responsebody.body().jsonPath().getJsonObject("code");
			lib.WriteReportStep("2", "verify user authentication response error code", "Expected Response error code should be:<b> "+ErrorCode+"</b>", "Response : <b>Status</b> =" +"<b>"+strcode+"</b>", "Passed");
			String strautherrmessage= Apidefinitions.responsebody.body().jsonPath().getJsonObject("message");
			lib.WriteReportStep("2", "verify user authentication response error message", "Expected Response error message should be:<b> "+AuthErrMessage+"</b>", "Response : <b>Status</b> =" +"<b>"+strautherrmessage+"</b>", "Passed");
			boolean straccess= Apidefinitions.responsebody.body().jsonPath().getJsonObject("access-denied"); 
			lib.WriteReportStep("2", "verify user authentication response error message", "Expected Response error message should be:<b> "+Authaccessdenied+"</b>", "Response : <b>Status</b> =" +"<b>"+straccess+"</b>", "Passed"); 
	    	String strcause= Apidefinitions.responsebody.body().jsonPath().getJsonObject("cause");
	    	lib.WriteReportStep("2", "verify user authentication response error message", "Expected Response error message should be:<b> "+AuthErrCause+"</b>", "Response : <b>Status</b> =" +"<b>"+strcause+"</b>", "Passed"); 
	     }
	     else
	     {
	    	 System.out.println("Exception thrown");
	     }
}
	
@Step
public void writejsonresponse(String strfilename,String output) 
{
      try
      {
    	DateFormat dateFormat = new SimpleDateFormat("MMddyyyy");
  		Date date = new Date();
  		String date1= dateFormat.format(date);
  		strPath= "D:\\Results\\Response\\"+date1+"\\"+strfilename+".json";
           
        System.out.println("File to write: "+strPath);
        File file = new File(strPath); // If you want to write as file to local.
        FileWriter fileWriter = new FileWriter(file);
        fileWriter.write(output);
        fileWriter.close();
        
      }
      catch(Exception e)
      {
           // Exit();
      }
}
}
